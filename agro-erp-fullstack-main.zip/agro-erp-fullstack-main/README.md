# agro-erp-fullstack

This project was created with [Better-T-Stack](https://github.com/AmanVarshney01/create-better-t-stack), a modern TypeScript stack that combines Next.js, Express, and more.

## Features

- **TypeScript** - For type safety and improved developer experience
- **Next.js** - Full-stack React framework
- **TailwindCSS** - Utility-first CSS for rapid UI development
- **Shared UI package** - shadcn/ui primitives live in `packages/ui`
- **Express** - Fast, unopinionated web framework
- **Bun** - Runtime environment
- **Drizzle** - TypeScript-first ORM
- **PostgreSQL** - Database engine
- **Authentication** - Better-Auth
- **Biome** - Linting and formatting
- **Husky** - Git hooks for code quality
- **Turborepo** - Optimized monorepo build system

## Getting Started

First, install the dependencies:

```bash
bun install
```

## Database Setup

This project supports three explicit database targets:

- `local`: An already-running local PostgreSQL instance, using the native `pg` driver
- `neon`: Neon development database, using the Neon serverless driver
- `production`: PostgreSQL on the production host, using the native `pg` driver

Environment files use the same target names:

- `apps/server/.env.development.local`
- `apps/server/.env.development.neon`
- `apps/server/.env.production`
- `apps/web/.env.development`
- `apps/web/.env.production`

Copy the corresponding `.example` file when setting up a new environment.

### Local PostgreSQL

Configure `apps/server/.env.development.local` to point to an existing local
PostgreSQL instance, then run:

```bash
bun run db:push:local
bun run dev:local
```

The repository does not provision PostgreSQL or application containers.

### Neon development

Configure `apps/server/.env.development.neon`, then run:

```bash
bun run db:push:neon
bun run dev:neon
```

`DATABASE_URL_DIRECT` is preferred for Neon Drizzle operations when present.
The application continues to use `DATABASE_URL`.

### Production PostgreSQL

Production commands are deliberately named in full:

```bash
bun run db:migrate:production
bun run build:production
```

Use generated migrations for production deployments. `db:push:production`
exists for controlled manual use but should not be the normal deployment path.

Drizzle configurations are:

- `packages/db/drizzle.dev-local.config.ts`
- `packages/db/drizzle.dev-neon.config.ts`
- `packages/db/drizzle.prod.config.ts`

Open [http://localhost:3001](http://localhost:3001) for the web application.
The API runs at [http://localhost:3000](http://localhost:3000).

## Deploying on Vercel

This repository is a Turborepo with two separate deploy targets that you can import as two Vercel projects from the same Git repository:

- `apps/web` is the Next.js frontend
- `apps/server` is the Express API and auth service

Vercel can deploy both apps as separate projects. The frontend uses the Next.js preset. The backend is deployed as a single Vercel Function from the Express app in `apps/server/src/index.ts`.

### Vercel project setup

1. Create a Vercel project for the frontend and set the root directory to `apps/web`.
2. Create a second Vercel project for the backend and set the root directory to `apps/server`.
3. Add the same GitHub repository to both projects. Every push will trigger both deployments.

### Build commands

Use the package scripts or the direct Turbo commands:

- Frontend: `bun run build:web` or `turbo build --filter=web...`
- Backend: `bun run build:server` or `turbo build --filter=server...`

### Frontend deployment

1. Set the frontend project `NEXT_PUBLIC_SERVER_URL` to the backend deployment URL you want the browser to call.
2. Use the `Next.js` framework preset.
3. Keep `NEXT_PUBLIC_SERVER_URL` stable if you want previews to keep pointing at the production backend.
4. If you want preview frontend deployments to call preview backend deployments, you must manage those URLs explicitly per environment.

### Environment variables

Use these example files as the source of truth for required variables:

- `apps/web/.env.production.example`
- `apps/server/.env.production.example`

For Vercel, the frontend project needs `NEXT_PUBLIC_SERVER_URL`. The backend
project needs the database and auth variables shown in the server example.

## UI Customization

React web apps in this stack share shadcn/ui primitives through `packages/ui`.

- Change design tokens and global styles in `packages/ui/src/styles/globals.css`
- Update shared primitives in `packages/ui/src/components/*`
- Adjust shadcn aliases or style config in `packages/ui/components.json` and `apps/web/components.json`

### Add more shared components

Run this from the project root to add more primitives to the shared UI package:

```bash
npx shadcn@latest add accordion dialog popover sheet table -c packages/ui
```

Import shared components like this:

```tsx
import { Button } from "@agro-erp-fullstack/ui/components/button";
```

### Add app-specific blocks

If you want to add app-specific blocks instead of shared primitives, run the shadcn CLI from `apps/web`.

## Git Hooks and Formatting

- Initialize hooks: `bun run prepare`
- Format and lint fix: `bun run check`

## Project Structure

```
agro-erp-fullstack/
├── apps/
│   ├── web/         # Frontend application (Next.js)
│   └── server/      # Backend API (Express)
├── packages/
│   ├── ui/          # Shared shadcn/ui components and styles
│   ├── auth/        # Authentication configuration & logic
│   └── db/          # Database schema & queries
```

## Available Scripts

- `bun run dev` / `bun run dev:local`: Start against local PostgreSQL
- `bun run dev:neon`: Start against Neon
- `bun run build`: Build all applications
- `bun run dev:web`: Start only the web application
- `bun run dev:server`: Start only the server
- `bun run check-types`: Check TypeScript types across all apps
- `bun run db:push:local`: Push schema changes to local PostgreSQL
- `bun run db:push:neon`: Push schema changes to Neon
- `bun run db:migrate:production`: Apply migrations to production PostgreSQL
- `bun run db:generate`: Generate database client/types
- `bun run db:studio:local`: Open Drizzle Studio for local PostgreSQL
- `bun run db:studio:neon`: Open Drizzle Studio for Neon
- `bun run check`: Run Biome formatting and linting
