# Inventory Management Module Implementation Plan

## Summary

Build the inventory module around the current stock model you chose:

`product.quantity` remains the immediately orderable/dispatchable quantity.  
`product.reservedQuantity` remains committed stock from placed orders.  
So the UI will show `Available / Dispatchable = quantity`, plus `Reserved = reservedQuantity`.

Access will use existing roles:

- `manager`: full inventory access, reports, stock adjustments, alert history, dispatch override.
- `warehouse`: inventory operations, GRN, outward, dispatch queue.
- `advisor`: view-only finished-goods availability through order placement and a read-only inventory view.

Batch number and expiry date will be optional everywhere.

Alerts will be persistent database rows. Rows are never deleted; active alerts are marked resolved when stock/expiry conditions recover. Inventory events will be append-only and typed, so movement logs and alert logs do not conflict.

## Data Model Changes

Add a new schema file:

`packages/db/src/schema/inventory.ts`

Export it from:

`packages/db/src/schema/index.ts`

Add enums:

- `inventory_category`: `raw_material`, `packing_material`, `finished_good`
- `inventory_event_type`: `inward`, `outward`, `order_reservation`, `order_cancellation`, `order_dispatch`, `manual_adjustment`, `alert_opened`, `alert_resolved`
- `inventory_alert_type`: `low_stock`, `expiring_product`
- `inventory_alert_status`: `active`, `resolved`

Add `inventory_item` for raw and packing materials:

- `id`
- `category`: raw or packing only
- `name`
- `itemCode`
- `unit`
- `currentStock`: `numeric(12,3)`
- `lowStockThreshold`: `numeric(12,3)`
- `supplierName`
- `lastInventoryUpdatedAt`
- `createdAt`
- `updatedAt`

UI labels will map `lowStockThreshold` as:

- Raw material: “Minimum Stock Level”
- Packing material: “Reorder Level”

Extend `product` for finished goods inventory metadata:

- `skuCode`: nullable, unique when present
- `minimumStockLevel`: integer, default `0`
- `batchNumber`: nullable
- `expiryDate`: nullable date
- `warehouseLocation`: nullable
- `lastInventoryUpdatedAt`: timestamp

Add `inventory_event` as the append-only ledger:

- `id`
- `eventType`
- `category`
- `inventoryItemId`: nullable
- `productId`: nullable
- `quantityDelta`
- `quantityBefore`
- `quantityAfter`
- `reservedBefore`: nullable
- `reservedAfter`: nullable
- `referenceOrderId`: nullable
- `manualOrderNumber`: nullable
- `batchNumber`: nullable
- `supplierName`: nullable
- `reason`: nullable
- `remarks`: nullable
- `approvedByUserId`: nullable
- `actorUserId`
- `createdAt`

Add `inventory_alert`:

- `id`
- `alertType`
- `status`
- `category`
- `inventoryItemId`: nullable
- `productId`: nullable
- `message`
- `triggeredValue`
- `thresholdValue`
- `openedEventId`
- `resolvedEventId`: nullable
- `activeAt`
- `resolvedAt`: nullable
- `createdAt`
- `updatedAt`

Indexes:

- `inventory_item_category_idx`
- `inventory_item_item_code_uidx`
- `inventory_event_category_created_at_idx`
- `inventory_event_product_id_idx`
- `inventory_event_inventory_item_id_idx`
- `inventory_alert_status_idx`
- `inventory_alert_product_id_idx`
- `inventory_alert_inventory_item_id_idx`

Migration flow:

- Update Drizzle schema.
- Run `bun run db:generate`.
- Existing products get `minimumStockLevel = 0`; movement history starts from the first new inventory operation after deployment.

## Stock Rules

Order placed:

- Validate requested quantity is `<= product.quantity`.
- Block if `product.quantity <= 0`.
- Decrease `product.quantity`.
- Increase `product.reservedQuantity`.
- Insert `inventory_event` with `order_reservation`.
- Recompute low-stock alert for each product.

Order cancelled before dispatch:

- Increase `product.quantity`.
- Decrease `product.reservedQuantity`, clamped at `0`.
- Insert `inventory_event` with `order_cancellation`.
- Recompute alerts.

Order dispatched:

- Decrease `product.reservedQuantity`, clamped at `0`.
- Do not decrease `product.quantity`, because it was already deducted at order placement.
- Insert `inventory_event` with `order_dispatch`.
- Set `order.dispatchedAt`.
- Delivery after dispatch will not change stock.

Manual return stock is out of scope for automatic order transitions. Returned products should be added through GRN after inspection.

GRN / stock inward:

- Raw and packing: increase `inventory_item.currentStock`.
- Finished goods: increase `product.quantity`.
- Optional fields: batch number, supplier, remarks, manual order number.
- Insert `inventory_event` with `inward`.
- Recompute active/resolved alerts.

Stock outward:

- Used for damage, expiry, internal usage.
- Raw and packing: reduce `inventory_item.currentStock`.
- Finished goods: reduce `product.quantity`.
- Block outward if requested quantity exceeds current dispatchable stock.
- Require reason and approved-by user.
- Insert `inventory_event` with `outward`.
- Recompute alerts.

Low-stock alert logic:

- Raw/packing: active when `currentStock < lowStockThreshold`.
- Finished goods: active when `product.quantity < product.minimumStockLevel`.
- If condition becomes true and no active alert exists, create `inventory_alert` and an `alert_opened` event.
- If condition becomes false and an active alert exists, mark it `resolved`, set `resolvedAt`, and create an `alert_resolved` event.

Expiry alert logic:

- Default threshold: expiry within 30 days.
- Applies to finished goods with `expiryDate`.
- Optional expiry means no expiry alert.
- Active alert resolves if expiry is removed or moved outside the 30-day window.

## Server API

Add:

`apps/server/src/routes/inventory.ts`

Register in:

`apps/server/src/index.ts`

Also update CORS methods to include `PATCH`, since the app already uses PATCH.

Endpoints:

- `GET /api/inventory/summary`
- `GET /api/inventory/items?category=raw_material|packing_material`
- `POST /api/inventory/items`
- `PATCH /api/inventory/items/:itemId`
- `GET /api/inventory/finished-goods`
- `PATCH /api/inventory/finished-goods/:productId`
- `POST /api/inventory/inward`
- `POST /api/inventory/outward`
- `GET /api/inventory/events`
- `GET /api/inventory/alerts?status=active|resolved|all`
- `GET /api/inventory/dispatch/orders`
- `PATCH /api/inventory/dispatch/orders/:orderId/status`

Permissions:

- Read summary/items/events/alerts: `manager`, `warehouse`
- Read finished goods availability: `manager`, `warehouse`, `advisor`
- Create/update items, GRN, outward: `manager`, `warehouse`
- Dispatch status updates: `manager`, `warehouse`
- Reports: `manager`, `warehouse`
- Advisor inventory API access is finished-goods read-only.

Use Zod request schemas for every mutating endpoint.

Use explicit transaction helpers for multi-step stock changes. If the current Neon HTTP Drizzle client does not expose transactions in this repo version, update `packages/db/src/index.ts` to use a transaction-capable Neon serverless driver. Order creation, cancellation, dispatch, GRN, outward, event creation, and alert recomputation should happen in one database transaction where possible.

For oversell protection, product reservation must use a conditional update equivalent to:

`WHERE product.id = productId AND product.quantity >= requestedQuantity`

If no row is updated, return a 400 error with a clear insufficient-stock message.

## Order Module Integration

Update `apps/server/src/routes/advisor.ts`:

- Keep advisor order creation.
- Replace current manual compensation blocks with transaction-based stock reservation.
- Insert `inventory_event` rows for reservations and cancellations.
- Recompute alerts after reservation/cancellation.
- Keep advisor cancellation only for cancellable pre-dispatch statuses.
- Remove advisor ownership of fulfillment status movement from UI and server behavior.

Update `apps/server/src/routes/orders.ts`:

- Orders team still verifies queued orders.
- Approval continues moving `created -> picked`, sending the order into the warehouse queue.
- Cancellation from verification releases reservation and creates inventory events.

Warehouse dispatch flow:

- Warehouse sees picked/packed/RTD orders in `/inventory/dispatch`.
- Warehouse advances `picked -> packed -> rtd -> dispatched -> delivered`.
- Inventory reserved stock is cleared when target status becomes `dispatched`.
- Everyone else can view order status, but only manager/warehouse can advance fulfillment.

Update order create options:

- Continue returning `quantity`, `reservedQuantity`, and `availableQuantity`.
- Add `dispatchableQuantity`, equal to `product.quantity` under the current model.
- Order UI should disable add/increment when `dispatchableQuantity` is `0`.

## Web Pages

Follow the `/scratchpad` route and `ui-patterns.tsx` conventions:

- `PageShell`
- `PageHeader`
- `MetricCard`
- `StatusPill`
- `Surface`
- `EmptyState`
- `LoadingState`
- `ErrorState`
- warm shadcn base, green primary accents, scan-first cards, clear spacing

Respect your page rule:

- Page-specific TSX stays inside the page file.
- Only reusable pieces used by more than one page go under `apps/web/src/components`.

Add API helpers:

- `apps/web/src/lib/inventory-api.ts`
- `apps/web/src/lib/inventory-api-client.ts`

Add pages:

- `apps/web/src/app/inventory/page.tsx`
  - Manager/warehouse: stock summary, active alerts, daily movement, raw/packing/finished totals.
  - Advisor: read-only finished goods availability.
- `apps/web/src/app/inventory/items/page.tsx`
  - Raw and packing material inventory.
  - Category switcher.
  - Manager/warehouse create/update controls.
- `apps/web/src/app/inventory/finished-goods/page.tsx`
  - Product inventory view with SKU, quantity, reserved quantity, batch, expiry, warehouse location, low-stock state.
  - Manager/warehouse can update inventory metadata.
  - Advisor read-only.
- `apps/web/src/app/inventory/grn/page.tsx`
  - Stock inward form.
  - Category selector.
  - Quantity added, batch number, supplier, remarks, manual order number.
- `apps/web/src/app/inventory/outward/page.tsx`
  - Stock outward form.
  - Quantity reduced, reason, approved by.
- `apps/web/src/app/inventory/alerts/page.tsx`
  - Active and resolved alert history.
  - Active alerts appear first.
- `apps/web/src/app/inventory/dispatch/page.tsx`
  - Warehouse dispatch queue.
  - Status actions for picked, packed, RTD, dispatched, delivered.

Update `apps/web/src/components/header.tsx`:

- Manager: add `Inventory`.
- Warehouse: add `Inventory` and dispatch access.
- Advisor: add read-only `Inventory` or keep visibility inside order placement; preferred implementation is a read-only `Inventory` link showing finished goods only.

## UI Behavior

Dashboard metrics:

- Raw material stock count
- Packing material stock count
- Finished goods dispatchable units
- Reserved finished goods units
- Active low-stock alerts
- Active expiry alerts
- Daily stock in
- Daily stock out
- Daily reserved stock

Alerts UI:

- Use `StatusPill` tones:
  - Low stock: warning or danger depending severity.
  - Expiring soon: warning.
  - Resolved: neutral.
- Active alerts should show item, category, current value, threshold, and timestamp.

GRN/outward forms:

- Use explicit labels.
- Quantity must be numeric and positive.
- Show current stock before submit.
- Show resulting stock preview before submit.
- Disable submit while pending.
- Use toast success/error.

Finished goods in order placement:

- Show available/dispatchable quantity near each product.
- Disable product add button when dispatchable is zero.
- Clamp quantity steppers to dispatchable quantity.
- If backend rejects due to race-condition stock change, show the server error and keep the cart editable.

## Public Interfaces / Types

Add shared frontend response interfaces locally in page files unless reused across pages.

Server request schemas:

- `createInventoryItemSchema`
- `updateInventoryItemSchema`
- `updateFinishedGoodInventorySchema`
- `stockInwardSchema`
- `stockOutwardSchema`
- `dispatchStatusSchema`

Important response shapes:

- `InventorySummaryResponse`
- `InventoryItemsResponse`
- `FinishedGoodsInventoryResponse`
- `InventoryEventsResponse`
- `InventoryAlertsResponse`
- `DispatchOrdersResponse`

No external/public package API is required beyond the new schema exports.

## Validation And Edge Cases

Handle:

- Duplicate item codes.
- Negative or zero quantities.
- Outward quantity greater than current stock.
- Order quantity greater than dispatchable quantity.
- Concurrent order placement for the same product.
- Cancellation after dispatch blocked from stock release.
- Dispatch attempted twice.
- Missing product/item reference.
- Optional batch/expiry left blank.
- Low-stock alert opened only once while already active.
- Low-stock alert resolved only when stock recovers.
- Expiry alert not created when expiry is blank.
- Advisor attempting mutation receives 403.
- Warehouse attempting manager-only account/product pricing routes remains blocked.

## Verification

Add focused Bun tests for pure inventory logic if helper functions are extracted:

- Low-stock alert opens.
- Low-stock alert does not duplicate while active.
- Low-stock alert resolves after resupply.
- Expiry alert opens within 30 days.
- Current stock model reservation math:
  - order placed: `quantity - qty`, `reserved + qty`
  - order cancelled: `quantity + qty`, `reserved - qty`
  - order dispatched: `reserved - qty`, `quantity unchanged`

Manual/API acceptance scenarios:

- Manager creates raw material, adds GRN, sees dashboard stock increase.
- Warehouse creates packing GRN and outward damage entry.
- Advisor sees finished goods quantity but cannot mutate inventory.
- Advisor cannot place order beyond dispatchable quantity.
- Two simultaneous orders cannot oversell the same product.
- Orders team cancellation releases reserved stock.
- Warehouse dispatch clears reserved stock.
- Low-stock alert becomes active after order/outward.
- Resupply marks old alert resolved and creates no duplicate active alert.
- Expiring product appears in active alerts.
- On-screen reports show current stock, active alerts, daily stock in, stock out, and reserved stock.

Run before handoff:

- `bun run check-types`
- `bun x ultracite check`
- `bun run build`

## Assumptions And Defaults

- “Admin” means existing `manager`; UI copy should continue saying `Manager`.
- No new `admin` role will be added.
- `product.quantity` remains current dispatchable stock.
- `reservedQuantity` remains committed stock.
- Batch number and expiry date are optional everywhere.
- Expiring product threshold defaults to 30 days.
- Alerts are stored in `inventory_alert`; event history is stored in `inventory_event`.
- Alert rows are never deleted.
- Reports are on-screen summaries only; no CSV export in the first implementation.
- Existing product catalog remains the source of finished goods.
- Raw and packing inventory use the new `inventory_item` table.
- Existing stock history before this implementation will not be backfilled into movement events.
