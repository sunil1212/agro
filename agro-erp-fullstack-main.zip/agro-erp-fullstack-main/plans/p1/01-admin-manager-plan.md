# Admin (Formerly Manager) Priority 1 Plan

## Scope

1. Replace the advisor weekly sales target with daily and monthly targets.
2. Add branch-scoped packing-sheet CSV export.
3. Add branch-scoped booking-sheet CSV export.

This plan uses “Admin” for the current `admin` role. Existing route names such as `/api/manager` may remain during P1 to avoid unnecessary routing churn.

---

## Feature A: Daily and Monthly Advisor Targets

### Current state

Database:

- `user_sales_target.daily_sales_target` exists.
- `user_sales_target.monthly_sales_target` exists.

Application:

- `apps/server/src/lib/manager.ts` still validates `weeklySalesTarget`.
- `apps/server/src/services/accounts.ts` accepts `weeklySalesTarget`.
- The service incorrectly writes that value into `monthlySalesTarget`.
- `apps/web/src/app/accounts/create/actions.ts` uses `weeklySalesTarget`.
- `apps/web/src/app/accounts/create/page.tsx` shows one weekly input.
- `apps/web/src/app/accounts/page.tsx` displays one weekly badge.
- Manager stats still calls monthly target data “weekly”.

### Required API contract

Replace:

```ts
weeklySalesTarget?: number;
```

with:

```ts
dailySalesTarget?: number;
monthlySalesTarget?: number;
```

For advisor account creation, both values should be explicit non-negative numbers. Decide whether zero means “no target” or an actual zero target; P1 can preserve the current zero-default behavior.

Recommended Zod fragment:

```ts
const salesTargetSchema = z.object({
	dailySalesTarget: z.number().finite().nonnegative(),
	monthlySalesTarget: z.number().finite().nonnegative(),
});

export const createAccountSchema = z
	.object({
		// existing account fields
		role: z.enum(superAdminAssignableRoles),
		dailySalesTarget: z.number().finite().nonnegative().optional(),
		monthlySalesTarget: z.number().finite().nonnegative().optional(),
	})
	.superRefine((values, context) => {
		if (values.role !== "advisor") {
			return;
		}

		if (values.dailySalesTarget === undefined) {
			context.addIssue({
				code: "custom",
				message: "Daily sales target is required",
				path: ["dailySalesTarget"],
			});
		}

		if (values.monthlySalesTarget === undefined) {
			context.addIssue({
				code: "custom",
				message: "Monthly sales target is required",
				path: ["monthlySalesTarget"],
			});
		}
	});
```

Do not require target fields for logistics, team leader, warehouse, or admin creation.

### Server service changes

File:

`apps/server/src/services/accounts.ts`

Update `CreateAccountServiceInput`:

```ts
export interface CreateAccountServiceInput {
	createdByUserId: string;
	dailySalesTarget?: null | number;
	email: string;
	managerCode?: null | string;
	monthlySalesTarget?: null | number;
	name: string;
	password: string;
	role: UserRole;
}
```

Create a focused helper:

```ts
const upsertAdvisorSalesTarget = async (
	database: Database,
	input: {
		dailySalesTarget: number;
		monthlySalesTarget: number;
		userId: string;
	}
): Promise<void> => {
	await database
		.insert(userSalesTarget)
		.values({
			dailySalesTarget: input.dailySalesTarget.toFixed(2),
			monthlySalesTarget: input.monthlySalesTarget.toFixed(2),
			userId: input.userId,
		})
		.onConflictDoUpdate({
			set: {
				dailySalesTarget: input.dailySalesTarget.toFixed(2),
				monthlySalesTarget: input.monthlySalesTarget.toFixed(2),
			},
			target: userSalesTarget.userId,
		});
};
```

Only invoke it when:

- role is `advisor`
- both values are numbers

Do not create a target row for non-advisor roles.

### Account creation transaction concern

The Better Auth signup and subsequent Drizzle updates are not currently one transaction. P1 does not need to redesign auth creation, but target insertion failure can leave an account without targets.

Required behavior:

- If account creation succeeds but target insertion fails, return a descriptive server error and log the created account ID.
- Prefer extracting account post-processing into a function that can be retried safely.
- `user_sales_target.user_id` is a primary key, so retry via upsert is idempotent.

### Manager route changes

File:

`apps/server/src/routes/manager.ts`

In the account creation handler:

```ts
const createdAccount = await createAccount({
	createdByUserId: session.user.id,
	dailySalesTarget:
		values.role === "advisor" ? values.dailySalesTarget : null,
	email: values.email,
	managerCode: managerCodeResult.managerCode,
	monthlySalesTarget:
		values.role === "advisor" ? values.monthlySalesTarget : null,
	name: values.name,
	password: values.password,
	role: values.role,
});
```

Remove every compatibility alias named `weeklySalesTarget`.

### Account list response changes

File:

`apps/server/src/services/accounts.ts`

Select:

```ts
dailySalesTarget: userSalesTarget.dailySalesTarget,
monthlySalesTarget: userSalesTarget.monthlySalesTarget,
```

Return:

```ts
{
	dailySalesTarget: string | null;
	monthlySalesTarget: string | null;
}
```

### Frontend action changes

File:

`apps/web/src/app/accounts/create/actions.ts`

```ts
export interface CreateManagedAccountInput {
	dailySalesTarget: number;
	email: string;
	managerCode: null | string;
	monthlySalesTarget: number;
	name: string;
	password: string;
	role: AssignableRole;
}
```

The result should return both values.

### Account creation form changes

File:

`apps/web/src/app/accounts/create/page.tsx`

Default values:

```ts
dailySalesTarget: 0,
monthlySalesTarget: 0,
```

Render only for advisor:

```tsx
<div className="grid gap-4 sm:grid-cols-2">
	<form.Field name="dailySalesTarget">
		{(field) => (
			<TargetNumberField
				field={field}
				label="Daily sales target"
				placeholder="5000"
			/>
		)}
	</form.Field>
	<form.Field name="monthlySalesTarget">
		{(field) => (
			<TargetNumberField
				field={field}
				label="Monthly sales target"
				placeholder="150000"
			/>
		)}
	</form.Field>
</div>
```

Use:

- `type="number"`
- `min="0"`
- `step="0.01"`
- numeric conversion that treats an empty field consistently

Do not use `Number("")` implicitly without deciding whether empty means zero.

Recommended parser:

```ts
const parseTargetInput = (value: string): number =>
	value.trim() === "" ? 0 : Number(value);
```

Update copied profile text:

```ts
`Daily sales target: ${profile.dailySalesTarget}`,
`Monthly sales target: ${profile.monthlySalesTarget}`,
```

Display role option as “Logistics Executive”, not “Logistics”.

### Account list UI changes

File:

`apps/web/src/app/accounts/page.tsx`

Update interface:

```ts
interface ManagedAccount {
	dailySalesTarget: null | string;
	monthlySalesTarget: null | string;
	// existing fields
}
```

Advisor badges:

```tsx
<StatusPill>
	Daily {currencyFormatter.format(Number(account.dailySalesTarget ?? 0))}
</StatusPill>
<StatusPill>
	Monthly {currencyFormatter.format(Number(account.monthlySalesTarget ?? 0))}
</StatusPill>
```

### Stats compatibility work

Files:

- `apps/server/src/routes/manager.ts`
- `apps/web/src/features/manager/stats/stats-client.tsx`

Although target editing is a P2 item, P1 must remove misleading weekly naming.

Minimum safe P1 behavior:

- Return both daily and monthly targets.
- Daily progress compares current-day sales to daily target.
- Monthly progress compares current-month sales to monthly target.
- If a full stats redesign is intentionally deferred, display target values without a single ambiguous aggregate “targetProgress”.

Do not calculate lifetime sales divided by monthly target. That is semantically invalid.

Suggested DTO:

```ts
interface AdvisorTargetProgress {
	daily: {
		sales: number;
		target: number | null;
		progress: number | null;
	};
	monthly: {
		sales: number;
		target: number | null;
		progress: number | null;
	};
}
```

### Target feature tests

Server tests:

1. Advisor creation with daily `5000` and monthly `150000` creates both columns.
2. Advisor creation with a negative target returns 400.
3. Logistics creation ignores/does not persist target values.
4. Account list returns both targets.
5. Advisor import creates advisors with null or zero targets according to the selected policy.
6. Existing rows with only monthly target remain readable.

Frontend tests/manual checks:

1. Advisor role shows both fields.
2. Switching to logistics hides both fields.
3. Switching back to advisor restores valid defaults.
4. Copied profile contains daily and monthly values.
5. Account list contains no “Weekly” label.

---

## Feature B: Branch-Scoped Packing CSV

### Source reference

`apps/public/example_docs/Packing Sheet.png`

The image shows one order expanded into multiple product rows.

Recommended columns inferred from the sample:

1. `ORDER_ID`
2. `STATUS`
3. `PRODUCT_NAME`
4. `PACK_SIZE`
5. `QUANTITY`
6. `LINE_TOTAL`
7. `ORDER_TOTAL`
8. `PAYMENT_MODE`
9. `COD_AMOUNT`

Before implementation, confirm these exact headers against the business owner. The sample image has no header row, so the plan must not pretend the header names are authoritative.

### Row expansion rule

- One CSV row per order item.
- Order-level fields appear only on the first row for that order, matching the visual sample.
- Product fields appear on every item row.
- Insert one blank row between orders only if operations explicitly wants visual separation. For machine-friendly CSV, repeating order-level fields is safer.

Recommended P1 default: repeat order-level fields on every item row. It sorts and filters correctly in spreadsheets.

Example mapper:

```ts
interface PackingExportSourceRow {
	codAmount: string;
	lineTotalAmount: string;
	orderId: string;
	orderStatus: OrderStatus;
	orderTotalAmount: string;
	packageQuantity: string | null;
	packageUnit: string | null;
	paymentMode: PaymentMode;
	productName: string;
	quantity: number;
}

const toPackingCsvRow = (row: PackingExportSourceRow) => ({
	ORDER_ID: row.orderId,
	STATUS: formatOrderStatus(row.orderStatus),
	PRODUCT_NAME: row.productName,
	PACK_SIZE: formatPackSize(row.packageQuantity, row.packageUnit),
	QUANTITY: String(row.quantity),
	LINE_TOTAL: row.lineTotalAmount,
	ORDER_TOTAL: row.orderTotalAmount,
	PAYMENT_MODE: formatPaymentMode(row.paymentMode),
	COD_AMOUNT: row.codAmount,
});
```

### Branch scope

Admin endpoint must infer the branch from the logged-in admin.

Query shape:

```ts
db
	.select(/* export fields */)
	.from(order)
	.innerJoin(orderCreator, eq(orderCreator.id, order.createdByUserId))
	.innerJoin(
		creatorManagerCode,
		eq(creatorManagerCode.userId, orderCreator.id)
	)
	.innerJoin(orderItem, eq(orderItem.orderId, order.id))
	.innerJoin(product, eq(product.skuCode, orderItem.productSku))
	.where(
		and(
			eq(creatorManagerCode.managerCode, sessionManagerCode),
			eq(order.status, "confirmed"),
			isNotNull(order.orderId)
		)
	);
```

Use Drizzle aliases because `user_manager_code` may be joined for multiple users.

Ordering:

1. `order.createdAt ASC`
2. `order.id ASC`
3. `orderItem.createdAt ASC`

This makes serial output deterministic.

### Endpoint

Recommended:

`GET /api/manager/order-exports/packing.csv`

Validation:

- require an Admin session/action
- infer branch code
- optional validated date range
- default status `confirmed`

File name:

`packing-sheet-<BRANCH_CODE>-<YYYY-MM-DD>.csv`

---

## Feature C: Branch-Scoped Booking CSV

### Source reference

`apps/public/example_docs/Booking Sheet Format.csv`

The export should preserve the carrier’s expected column order.

### Booking CSV fixed metadata rows

The reference contains:

- blank first row
- customer name row
- customer ID row
- date row
- header row
- data rows

Implement these as explicit template constants, not ad hoc arrays spread through a React component.

```ts
const BOOKING_CUSTOMER_NAME = "FARMTABLE SUPPLIERS LLP-1000060572";
const BOOKING_CUSTOMER_ID = "1000060572";
const BOOKING_SENDER_MOBILE = "7028706451";
```

The sample contains both “Growmize pvt ltd” and sender address data. Put all static sender fields in one frozen object:

```ts
const BOOKING_SENDER = {
	addressLine1: "SASWAD INDUSTRIAL AREA, SASWAD, PUNE MH - 412301",
	addressLine2: "SASWAD INDUSTRIAL AREA, SASWAD, PUNE MH - 412301",
	city: "Pune",
	companyName: "",
	email: "growmizeagri@gmail.com",
	mobileNumber: "7028706451",
	name: "Growmize pvt ltd",
	pincode: "412301",
	state: "Maharashtra",
} as const;
```

Confirm capitalization and legal sender name before production. Preserve the sample values until the owner provides replacements.

### Required dynamic mapping

| Booking column | Value |
|---|---|
| `SERIAL NUMBER` | 1-based increment in export order |
| `BARCODE NO` | `order_consignment.consignment_number` |
| `PHYSICAL WEIGHT` | blank |
| `RECEIVER CITY` | farmer district unless a separate city field is introduced |
| `RECEIVER PINCODE` | farmer pincode |
| `RECEIVER NAME` | farmer name |
| `RECEIVER ADD LINE 1` | formatted farmer address |
| `RECEIVER ADD LINE 2` | same formatted farmer address, matching sample |
| `ACK` | `COD` for COD/partial orders; confirm value for prepaid |
| `SENDER MOBILE NO` | hardcoded sample sender number |
| `RECEIVER MOBILE NO` | farmer primary mobile |
| `CODR/COD` | `COD` when `totalCodAmount > 0`, otherwise blank/prepaid rule |
| `VALUE FOR CODR/COD` | `order.totalCodAmount` |
| static parcel shape/dimensions | preserve sample/static values or blank according to approved template |
| sender fields | hardcoded template |
| `RECEIVER STATE/UT` | farmer state |
| `FT-N0.` | `order.orderId` |

The user explicitly requested weight to be blank even though the sample rows contain weights. Follow the request, not the sample data.

### Farmer address formatter

Create one tested formatter used by booking CSV and future labels:

```ts
const formatFarmerPostalAddress = (farmer: {
	addressAt: string;
	district: string;
	nearbyLandmark: string | null;
	pincode: string;
	post: string;
	state: string;
	taluka: string;
}): string =>
	[
		`At - ${farmer.addressAt}`,
		`Post - ${farmer.post}`,
		farmer.nearbyLandmark
			? `Landmark - ${farmer.nearbyLandmark}`
			: null,
		`Taluka - ${farmer.taluka}`,
		`District - ${farmer.district}`,
		`State - ${farmer.state.toUpperCase()}`,
		`Pincode - ${farmer.pincode}`,
	]
		.filter(Boolean)
		.join(", ");
```

### Export eligibility

Booking rows require:

- non-null business order ID
- assigned consignment
- farmer address
- confirmed order by default

If any selected order lacks a consignment, do not silently emit a blank barcode.

Recommended response:

```json
{
  "success": false,
  "message": "3 selected orders do not have consignment numbers",
  "orderIds": ["..."]
}
```

For a direct CSV endpoint, validate first and return 409 JSON before setting CSV headers.

### Exact column order

Copy the header order from `Booking Sheet Format.csv` exactly. Define it as a tuple and map every row through it:

```ts
const BOOKING_HEADERS = [
	"SERIAL NUMBER",
	"BARCODE NO",
	"PHYSICAL WEIGHT",
	// ... every reference column in exact order ...
	"FT-N0.",
] as const;
```

Never generate headers with `Object.keys()` for this carrier format.

### CSV escaping

Create a shared helper:

```ts
const CSV_ESCAPE_PATTERN = /[",\r\n]/;

export const escapeCsvCell = (value: unknown): string => {
	const text = value == null ? "" : String(value);
	return CSV_ESCAPE_PATTERN.test(text)
		? `"${text.replaceAll('"', '""')}"`
		: text;
};
```

Use `\r\n` line endings for spreadsheet/carrier compatibility.

### Endpoint

Recommended:

`GET /api/manager/order-exports/booking.csv`

File name:

`booking-sheet-<BRANCH_CODE>-<YYYY-MM-DD>.csv`

---

## Admin Export UI

Recommended placement:

- Add an “Order exports” card to `apps/web/src/features/dashboard/manager-dashboard.tsx`, or
- Add a focused route `/order-exports`.

Prefer a route when filters are required.

Suggested UI:

- status fixed to Confirmed for P1
- optional date range
- order count preview
- “Download packing CSV”
- “Download booking CSV”

Download helper:

```ts
const downloadAuthenticatedFile = async (
	url: string,
	fallbackFileName: string
): Promise<void> => {
	const response = await fetch(url, { credentials: "include" });
	if (!response.ok) {
		const error = await response.json().catch(() => null);
		throw new Error(error?.message ?? "Export failed");
	}

	const blob = await response.blob();
	const objectUrl = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = objectUrl;
	link.download = getFileNameFromDisposition(response) ?? fallbackFileName;
	link.click();
	URL.revokeObjectURL(objectUrl);
};
```

Show a toast for:

- empty export
- missing consignments
- authorization failure
- successful download

---

## Admin Acceptance Criteria

### Targets

- Weekly target input is gone.
- Daily and monthly target inputs appear only for advisor creation.
- Both values are persisted to their correct columns.
- Account list and copied credentials use daily/monthly wording.
- No active production code maps weekly target to monthly target.

### Exports

- Admin exports only orders from their own branch.
- Packing export includes one row per order item.
- Booking serial numbers begin at 1 and increment without gaps inside one file.
- Booking barcode equals consignment number.
- Booking physical weight is blank.
- Receiver details come from farmer data.
- Sender mobile and sender data use the approved constants.
- Last booking column contains the business order ID.
- Export rejects orders without confirmed business ID or consignment.
- CSV values containing commas, quotes, or line breaks remain valid.

---

## Admin Implementation Checklist

- [x] Replace manager validation fields.
- [x] Replace account service input fields.
- [x] Write both target columns.
- [x] Update account create action types.
- [x] Update account form.
- [x] Update copied profile.
- [x] Update account list DTO and UI.
- [x] Remove misleading weekly stats naming.
- [x] Create shared CSV helper.
- [x] Create shared order export service.
- [x] Add admin packing endpoint.
- [x] Add admin booking endpoint.
- [x] Add admin export UI.
- [x] Add branch authorization tests.
- [x] Add CSV mapping tests.
- [x] Run type checks and Ultracite.

