# Priority 1 Cross-Role Acceptance and Release Plan

## Purpose

This document verifies that Admin, Advisor, Logistics Executive, and Warehouse changes work as one coherent order lifecycle. Role-local acceptance is insufficient because the highest-risk failures occur at handoff boundaries.

---

## End-to-End Golden Path

### Setup

Create:

- Superadmin
- Admin A:
  - code `ABC`
- Admin B:
  - code `BCD`
- Advisor A under Admin A:
  - daily target `5000`
  - monthly target `150000`
- Advisor B under Admin B
- Logistics Executive A under Admin A
- Logistics Executive B under Admin B
- Warehouse user
- enough active consignment numbers
- enough product stock

### Flow 1: Advisor onboarding and order creation

1. Sign in as Advisor A.
2. Confirm Inventory is absent from navigation.
3. Create farmer:
   - State auto-selected Maharashtra
   - District Pune
   - Taluka Mulshi
4. Verify persisted location.
5. Create an order with two products.
6. Verify:
   - internal UUID exists
   - business order ID is null
   - status is created
   - no consignment exists

### Flow 2: Logistics pre-confirmation work

1. Sign in as Logistics Executive A.
2. Verify title wording.
3. Open Created tab.
4. Verify Admin B order is not visible.
5. Add all four pre-confirmation follow-ups.
6. Edit order:
   - change quantity
   - change one line total
   - change shipping
   - save
7. Verify ID is still pending and no consignment exists.

### Flow 3: Confirmation

1. Confirm the order.
2. Verify in one committed state:
   - status `confirmed`
   - business order ID `ABC-000001`
   - consignment assigned
   - pre-follow-ups retained in pre table
   - post-follow-up UI now shows four empty post slots
3. Refresh and verify idempotence.

### Flow 4: Confirmed edit

1. Edit confirmed order.
2. Change product composition.
3. Save.
4. Verify:
   - business order ID remains `ABC-000001`
   - consignment remains unchanged
   - totals change
   - status remains confirmed

### Flow 5: Admin exports

1. Sign in as Admin A.
2. Verify advisor shows daily/monthly targets.
3. Download packing CSV.
4. Download booking CSV.
5. Verify only branch ABC rows appear.
6. Verify booking barcode equals assigned consignment.
7. Verify weight is blank.
8. Verify last column is `ABC-000001`.

### Flow 6: Warehouse dispatch

1. Sign in as Warehouse.
2. Verify no product creation action.
3. Open order queue.
4. Select branch ABC.
5. Verify order appears in Confirmed.
6. Download branch exports and compare with Admin output.
7. Mark dispatched.
8. Verify stock deduction and event records.
9. Verify order moves to Dispatched.

### Flow 7A: Delivery branch

1. Sign in as Logistics Executive A.
2. Open Dispatched.
3. Mark Delivered.
4. Verify:
   - status delivered
   - return action no longer available
5. Sign in as Warehouse.
6. Verify order is absent from warehouse queues.

### Flow 7B: Return branch

Use a second order:

1. Dispatch through Warehouse.
2. Logistics marks Return in Transit.
3. Verify Logistics cannot mark Delivered afterward.
4. Warehouse sees order under Return in Transit.
5. Warehouse marks Return in Warehouse.
6. Verify terminal status and no automatic stock inward.

### Flow 8: Branch sequence independence

1. Confirm first Admin B order.
2. Verify ID is `BCD-000001`.
3. Confirm second Admin A order.
4. Verify ID is `ABC-000002`.

---

## Concurrency Test Plan

### Same order confirmed twice

Run two confirmation requests simultaneously.

Expected:

- one 200
- one 409
- one order ID
- one consignment row
- one consumed consignment

### Two orders in same branch confirmed simultaneously

Expected:

- both succeed
- IDs have different consecutive suffixes
- consignments differ

Order of suffix assignment may depend on transaction scheduling. Do not assert which request gets the lower suffix unless requests are serialized.

### Two branches confirmed simultaneously

Expected:

- branch counters advance independently
- same numeric suffix is allowed across different prefixes

### Dispatch versus confirmed edit

Run:

- Warehouse dispatch
- Logistics edit save

simultaneously.

Expected:

- exactly one operation wins based on row/status locking
- if dispatch commits first, edit returns conflict
- if edit commits first, dispatch uses edited items/totals
- no partial stock mutation

### Delivered versus return

Run both logistics status requests against one dispatched order.

Expected:

- one succeeds
- one conflicts
- final status is exactly one of delivered/return_in_transit

---

## Database Verification Queries

Adapt names to the final migration.

### Created orders with IDs should not exist

```sql
SELECT id, order_id, status
FROM "order"
WHERE status = 'created'
  AND order_id IS NOT NULL;
```

Expected: zero.

### Confirmed/later orders missing IDs

```sql
SELECT id, order_id, status
FROM "order"
WHERE status IN (
	'confirmed',
	'dispatched',
	'delivered',
	'return_in_transit',
	'return_in_warehouse'
)
AND order_id IS NULL;
```

Expected: zero.

### Confirmed/later orders missing consignments

```sql
SELECT o.id, o.order_id, o.status
FROM "order" o
LEFT JOIN order_consignment oc ON oc.order_id = o.id
WHERE o.status IN (
	'confirmed',
	'dispatched',
	'delivered',
	'return_in_transit',
	'return_in_warehouse'
)
AND oc.order_id IS NULL;
```

Expected: zero.

### Order ID format

```sql
SELECT id, order_id
FROM "order"
WHERE order_id IS NOT NULL
  AND order_id !~ '^[A-Z0-9_-]+-[0-9]{6}$';
```

Review imported legacy IDs separately; restrict query by deployment/migration date if legacy formats are valid.

### Duplicate branch suffix

The unique order ID index prevents exact duplicates. Also validate counter alignment per branch after migration.

### Active consignment assigned to order

```sql
SELECT c.id, c.consignment_number
FROM consignment c
INNER JOIN order_consignment oc ON oc.consignment_id = c.id
WHERE c.is_active = true;
```

Expected: zero.

### Invalid farmer location

This is easier in application tests because the mapping is code data. Export all state/district/taluka triples and validate them through the shared helper.

---

## API Contract Regression Matrix

| Endpoint | Role | Expected |
|---|---|---|
| Create advisor | Admin | 201, daily/monthly stored |
| Create farmer | Advisor | 201 for valid hierarchy |
| Create farmer invalid hierarchy | Advisor | 400 |
| Create order | Advisor | 201, null business ID |
| Logistics queue | Logistics same branch | 200 |
| Logistics queue cross branch | Logistics | rows excluded |
| Confirm order | Logistics same branch | 200 |
| Confirm order cross branch | Logistics | 404 |
| Edit created order | Logistics same branch | 200 |
| Edit confirmed order | Logistics same branch | 200 |
| Edit dispatched order | Logistics | 409 |
| Mark delivered from dispatched | Logistics | 200 |
| Start return from dispatched | Logistics | 200 |
| Start return from delivered | Logistics | 400/409 |
| Branch list | Warehouse | 200 |
| Dispatch confirmed | Warehouse | 200 |
| Dispatch created | Warehouse | 400/404 |
| Receive return in transit | Warehouse | 200 |
| Receive delivered as return | Warehouse | 400/404 |
| Product create | Warehouse | 403 |
| Packing export own branch | Admin | 200 CSV |
| Booking export own branch | Admin | 200 CSV |
| Branch export | Warehouse | 200 CSV |

---

## CSV Verification Matrix

### Packing

- Header order matches approved format.
- Each order item is represented.
- Product pack size is correct.
- Quantity and line total are correct.
- Order total and COD amount are correct.
- Commas/quotes in names do not shift columns.
- Branch filter is correct.

### Booking

- Metadata rows match reference.
- Export date uses IST/business date.
- Header count equals data-row cell count.
- Serial starts at 1.
- Serial increments by 1.
- Barcode equals consignment.
- Weight cell is empty.
- Receiver city mapping is approved.
- Farmer address includes state.
- Sender mobile is hardcoded approved value.
- COD value equals `totalCodAmount`.
- Last column equals business order ID.
- No row is emitted without order ID/consignment.

### Spreadsheet manual check

Open representative files in:

- LibreOffice Calc
- Microsoft Excel if available

Check:

- UTF-8 names
- line breaks
- leading zeros in IDs/pincodes
- barcode values are not converted to scientific notation

Consider prefixing vulnerable numeric-looking values through CSV formatting only if the carrier accepts it. Consignment values in the sample contain letters, so they are safe. Pincodes should be emitted as strings.

---

## Static Analysis and Build Gates

Run in order:

```bash
bun run check-types
bun x ultracite check
bun run build
```

If Ultracite reports auto-fixable issues:

```bash
bun x ultracite fix
bun x ultracite check
```

Review changes made by the formatter before committing.

### Legacy search gate

```bash
rg -n \
	"weeklySalesTarget|Weekly sales target|orderNumber|trackingLink|tracking link|picked|packed|ready to dispatch|\\brtd\\b|\\breturned\\b|user\\.managerCode|order\\.orderNumber|order\\.trackingLink" \
	apps packages \
	--glob '!**/.next/**' \
	--glob '!**/dist/**' \
	--glob '!**/migrations/**'
```

No active production match should remain unless it is deliberately documented.

### Route inventory

Verify removed routes are gone:

```bash
rg -n "tracking-import|/:orderId/tracking" apps/server/src
```

Expected: zero.

---

## Migration and Deployment Order

### Pre-deployment

1. Back up production database.
2. Count orders by current status.
3. Identify legacy status values still stored.
4. Identify existing order ID formats.
5. Identify admin/branch codes and missing code assignments.
6. Count active consignments.
7. Verify enough consignments exist for expected confirmations.

### Migration

1. Migrate old statuses:
   - `picked`, `packed`, `rtd` -> choose `confirmed` unless operational data requires a different mapping
   - `returned` -> `return_in_warehouse`
2. Make `order.order_id` nullable.
3. Add branch order sequence table.
4. Initialize counters from branch IDs.
5. Add pending farmer state column if logistics staged edits require it.
6. Apply constraints/indexes.

The exact old-status mapping must be approved before production. Orders already physically dispatched must not be downgraded to confirmed merely because they are in a removed intermediate status.

Recommended data report before mapping:

```sql
SELECT status, COUNT(*)
FROM "order"
GROUP BY status
ORDER BY status;
```

### Application deployment

Deploy server and web together because:

- DTO fields change
- statuses change
- tracking routes disappear
- nullable order ID reaches frontend

Avoid a long mixed-version window.

### Post-deployment smoke

1. Sign in each role.
2. Load each changed page.
3. Create one test farmer/order in a test branch.
4. Confirm and dispatch.
5. Download exports.
6. Check server logs for 500s.

---

## Rollback Considerations

Application rollback after assigning new nullable/branch IDs may reintroduce code that expects:

- non-null order IDs at creation
- legacy statuses
- tracking columns

Therefore a simple application rollback may be unsafe after production data uses the new lifecycle.

Prepare:

- forward-fix preference
- release tag before deployment
- database backup
- migration down strategy only where data-safe

Do not restore removed status enum values by blindly rewriting terminal statuses.

---

## Release Completion Checklist

- [x] Shared contract type check passes.
- [x] Admin target flow passes (daily/monthly targets implemented).
- [x] Advisor location flow passes (MultiForm with state/district/taluka dropdowns implemented).
- [x] Logistics confirmation flow passes (server).
- [x] Logistics edit flow passes (edit endpoints and page created).
- [x] Warehouse branch queue passes (branch list UI and queue page implemented).
- [x] Warehouse dispatch passes (server).
- [x] Delivery branch passes (server).
- [x] Return branch passes (server).
- [x] Packing CSV verified (endpoints exist).
- [x] Booking CSV verified (endpoints exist).
- [x] Cross-branch authorization verified (branch service).
- [ ] Concurrency tests verified (tests still needed).
- [x] Tracking routes/UI absent (verified no tracking remnants).
- [x] Legacy statuses absent from production code (verified via grep).
- [x] Warehouse product creation blocked.
- [x] Build passes.
- [ ] Production migration report reviewed.
- [ ] Smoke test completed.

