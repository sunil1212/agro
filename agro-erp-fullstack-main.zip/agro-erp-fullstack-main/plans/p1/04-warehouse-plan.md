# Warehouse Priority 1 Plan

## Scope

1. Remove the tracking-link module and CSV import.
2. Remove warehouse product creation functionality.
3. Create branch-first order bifurcation.
4. Show warehouse-relevant order statuses.
5. Move confirmed orders directly to dispatched.
6. Show return-in-transit orders and allow receipt into return-in-warehouse.
7. Add branch-scoped packing and booking exports.
8. Enforce delivered/return mutual exclusion through the shared lifecycle.

Read the shared orchestration plan first. Warehouse work depends on canonical status and branch services.

---

## Feature A: Remove Warehouse Tracking-Link Module

### Current functionality

`apps/web/src/app/inventory/dispatch/page.tsx` currently:

- downloads a tracking CSV
- parses uploaded tracking CSV
- previews conflicts
- supports overrides
- imports tracking links
- stores tracking rows/state
- displays current tracking links

`apps/server/src/routes/inventory.ts` currently:

- selects `order.trackingLink`
- exposes a tracking PATCH route
- exposes a tracking import route

The current Drizzle schema no longer has `order.trackingLink`, and type checking already fails on these references.

### Delete from frontend

Remove:

- `TrackingImportResponse`
- `TrackingImportStatus`
- `TrackingImportRow`
- tracking CSV headers
- CSV parser used only for tracking
- URL validation
- tracking import status derivation
- tracking state
- tracking upload handler
- tracking download handler
- override state and UI
- apply import mutation
- `TrackingCsvPanel`
- tracking fields from `DispatchOrder`
- tracking-related icons and copy

Do not leave a hidden component or dead function.

### Delete from server validation

File:

`apps/server/src/lib/inventory-routes.ts`

Delete:

- `trackingLink` from `dispatchStatusSchema`
- `updateTrackingLinkSchema`
- `trackingLinkImportSchema`

New dispatch schema:

```ts
export const dispatchStatusSchema = z.object({
	status: z.enum(["dispatched", "return_in_warehouse"]),
});
```

It is better to use actor-specific schemas:

```ts
export const warehouseDispatchSchema = z.object({
	status: z.literal("dispatched"),
});

export const warehouseReturnReceiptSchema = z.object({
	status: z.literal("return_in_warehouse"),
});
```

### Delete from server routes

File:

`apps/server/src/routes/inventory.ts`

Delete:

- `PATCH /dispatch/orders/:orderId/tracking`
- `POST /dispatch/orders/tracking-import`
- tracking fields in selects/responses
- tracking write in status update

### Delete public artifacts only if authorized

Current untracked files include:

- `apps/public/consignments/tracking-links-2026-06-13.csv`
- `apps/public/consignments/test.csv`

They appear to be test/generated artifacts. Do not delete user files merely because the module is removed unless the repository owner confirms they are disposable. Add them to the cleanup checklist.

### Verification

```bash
rg -n -i "trackingLink|tracking link|tracking-import|TRACKING_LINK" \
	apps/server/src apps/web/src packages \
	--glob '!**/.next/**'
```

Expected result: zero production matches.

---

## Feature B: Remove Warehouse Product Creation

### Current warehouse access

RBAC currently grants warehouse:

```ts
...productReadActions,
...productWriteActions,
```

Warehouse header currently contains:

```ts
{ to: "/products", label: "Products" }
```

Warehouse dashboard contains:

- Update product inventory
- Create product

### Required interpretation

The request says:

- remove product creation from warehouse
- Superadmin is the only role that can now create products

Therefore remove warehouse product write permissions, not merely the dashboard card.

### RBAC changes

File:

`apps/server/src/lib/rbac.ts`

Change warehouse permissions to:

```ts
warehouse: [
	"crop:read_pdf",
	...productReadActions,
	"inventory:read",
	"inventory:manage",
	"inventory:read_finished_goods",
],
```

Remove:

- `product:create`
- `product:update`
- `product:deactivate`
- `product:reactivate`

If warehouse still needs to update stock metadata through inventory endpoints, that remains under `inventory:manage`.

### UI changes

Files:

- `apps/web/src/components/header.tsx`
- `apps/web/src/features/dashboard/warehouse-dashboard.tsx`

Remove:

- Create product quick action.
- Any link to `/products/create`.

Decide whether warehouse keeps read-only Products:

- The task says remove product creation, not product viewing.
- Keep `/products` only if it renders read-only controls based on permissions.
- If the current products page exposes edit/create actions without role gating, either:
  - remove Products link for warehouse, or
  - make the page read-only for warehouse.

P1 safest behavior:

- remove Products from warehouse nav
- keep inventory finished-goods views for stock work
- enforce server RBAC

### Direct-route checks

Warehouse requests must fail:

- `POST /api/manager/products`
- product update/deactivate/reactivate endpoints

Warehouse direct visit to `/products/create` should not provide a working mutation.

Because Next proxy is authentication-only, API RBAC is mandatory.

---

## Feature C: Branch-First Order Queue

### Required UX

When Warehouse selects Order Queue:

1. Show a list/grid of branches.
2. Show counts by warehouse-relevant status.
3. Selecting a branch opens that branch’s queue.
4. Queue has tabs for:
   - Confirmed
   - Dispatched
   - Return: in transit
   - Return: in warehouse

Delivered orders are not visible to Warehouse.

### Branch source

Use the shared branch service based on:

- Admin users
- `user_manager_code`

Do not infer branches from distinct orders only. A branch with zero orders should still appear.

Recommended branch DTO:

```ts
interface WarehouseBranchSummary {
	adminName: string;
	adminUserId: string;
	counts: {
		confirmed: number;
		dispatched: number;
		returnInTransit: number;
		returnInWarehouse: number;
	};
	managerCode: string;
}
```

### Endpoints

Recommended:

- `GET /api/inventory/branches`
- `GET /api/inventory/branches/:managerCode/orders`

Optional query:

`?status=confirmed`

The server should support all allowed warehouse statuses and default to all.

Alternative one-call endpoint:

- return branches and all orders

Do not use that for large data. Branch summaries plus selected branch orders scale better.

### Branch list query

Pseudo-query:

```ts
const branches = await db
	.select({
		adminName: adminUser.name,
		adminUserId: adminUser.id,
		managerCode: adminManagerCode.managerCode,
	})
	.from(adminUser)
	.innerJoin(
		adminManagerCode,
		eq(adminManagerCode.userId, adminUser.id)
	)
	.where(eq(adminUser.role, "admin"))
	.orderBy(asc(adminManagerCode.managerCode));
```

Counts can be:

- a grouped query by creator manager code and status
- merged into branch rows in memory

Ensure orders created by team leaders/advisors still map through their own `user_manager_code`.

### Branch order query

Required fields:

```ts
interface WarehouseOrderDto {
	approvedAt: string | null;
	approvedByName: string | null;
	consignmentNumber: string | null;
	createdAt: string;
	dispatchedAt: string | null;
	farmerName: string;
	id: string;
	items: Array<{
		lineTotalAmount: string;
		productName: string;
		productSku: string;
		quantity: number;
	}>;
	orderId: string;
	status:
		| "confirmed"
		| "dispatched"
		| "return_in_transit"
		| "return_in_warehouse";
}
```

For warehouse-visible states, order ID and consignment should be non-null because confirmation assigns both. Still keep defensive server checks.

Query scope:

```ts
where(
	and(
		eq(orderCreatorManagerCode.managerCode, requestedManagerCode),
		inArray(order.status, warehouseStatuses)
	)
)
```

Validate requested manager code exists. Return 404 for unknown branch.

### Next.js routes

Recommended:

- `/inventory/dispatch` branch list
- `/inventory/dispatch/[managerCode]` selected branch queue

This gives:

- shareable URLs
- browser back behavior
- refresh persistence

If preserving one page with state, put branch code in search params:

`/inventory/dispatch?branch=ABC`

Dynamic route is clearer.

### Branch list UI

Use cards or a compact table.

Each branch entry:

- manager code
- admin name
- confirmed count
- dispatched count
- return-in-transit count
- return-in-warehouse count
- “Open queue” action

Empty branch:

- still visible
- count badges all zero
- opens an empty state

### Queue tabs

```ts
const warehouseTabs = [
	{ label: "Confirmed", status: "confirmed" },
	{ label: "Dispatched", status: "dispatched" },
	{ label: "Return: in transit", status: "return_in_transit" },
	{ label: "Return: in warehouse", status: "return_in_warehouse" },
] as const;
```

Actions:

| Tab | Warehouse action |
|---|---|
| Confirmed | Mark Dispatched |
| Dispatched | None; tracking/read-only |
| Return: in transit | Mark Return in Warehouse |
| Return: in warehouse | None; terminal |

The word “tracking” here means observing status, not a tracking-link field.

---

## Feature D: Direct Confirmed-to-Dispatched Flow

### Remove old stages

Delete from warehouse code:

- `picked`
- `packed`
- `rtd`
- `getNextDispatchStatus()` legacy chain
- packed-stage reservation logic

New warehouse transition helper:

```ts
export const getNextWarehouseStatus = (
	status: WarehouseOrderStatus
): WarehouseOrderStatus | null => {
	switch (status) {
		case "confirmed":
			return "dispatched";
		case "return_in_transit":
			return "return_in_warehouse";
		default:
			return null;
	}
};
```

### Inventory side effects

Current code:

- reserves inventory on `packed`
- deducts reservation on `dispatched`

`packed` no longer exists.

P1 recommended stock behavior:

- On `confirmed` -> `dispatched`, validate and deduct physical stock directly.
- Record `order_dispatch` inventory events.
- Do not use reserved quantity for the new flow unless reservations move to confirmation.

Refactor `dispatchProductReservation()` or create:

```ts
async function dispatchConfirmedOrderStock(
	database: Database,
	input: {
		actorUserId: string;
		orderId: string;
	}
): Promise<void> {
	const items = await getOrderItemsForInventory(database, input.orderId);

	for (const item of items) {
		await deductProductStockForDispatch(database, {
			actorUserId: input.actorUserId,
			productId: item.productId,
			quantity: item.quantity,
			referenceOrderId: input.orderId,
		});
	}
}
```

Use conditional stock updates:

```ts
where(
	and(
		eq(productInventory.productId, productId),
		gte(productInventory.quantity, quantity)
	)
)
```

If any product is insufficient:

- rollback every stock deduction
- leave order `confirmed`
- return 409 with product name/SKU

Do not partially dispatch.

### Dispatch transaction

In one transaction:

1. Load branch-scoped order.
2. Validate status `confirmed`.
3. Validate business ID and consignment exist.
4. Load order items.
5. Deduct stock and write events.
6. Conditional update order to:
   - `status = dispatched`
   - `dispatchedAt = now`
7. Commit.

Pseudo-code:

```ts
await db.transaction(async (tx) => {
	const currentOrder = await getWarehouseOrderForUpdate(tx, orderId);
	assertOrderTransitionAllowed({
		actorRole: "warehouse",
		currentStatus: currentOrder.status,
		nextStatus: "dispatched",
	});

	await dispatchConfirmedOrderStock(tx, {
		actorUserId: session.user.id,
		orderId,
	});

	const [updated] = await tx
		.update(order)
		.set({
			dispatchedAt: new Date(),
			status: "dispatched",
		})
		.where(
			and(
				eq(order.id, orderId),
				eq(order.status, "confirmed")
			)
		)
		.returning({ id: order.id });

	if (!updated) {
		throw new DomainError("Order status changed; refresh and try again");
	}
});
```

### UI action

Confirmed row:

- button `Mark dispatched`
- confirmation dialog includes order ID and item count
- loading state
- on success remove from Confirmed tab and increment Dispatched count

Reloading branch summary is acceptable for P1.

---

## Feature E: Return Receipt

### Required flow

Logistics:

`dispatched` -> `return_in_transit`

Warehouse:

`return_in_transit` -> `return_in_warehouse`

### Server rule

Warehouse endpoint accepts only:

```ts
currentStatus === "return_in_transit"
nextStatus === "return_in_warehouse"
```

Conditional update:

```ts
await db
	.update(order)
	.set({ status: "return_in_warehouse" })
	.where(
		and(
			eq(order.id, orderId),
			eq(order.status, "return_in_transit")
		)
	);
```

### Returned stock policy

The user requested status receipt, not automatic restocking.

Do not automatically add returned products to sellable stock unless business confirms:

- package condition
- damaged/usable quantities
- batch/expiry handling

P1:

- status change only
- optional future separate return inspection/inward workflow

### UI

Return-in-transit row:

- button `Mark received in warehouse`
- confirmation dialog
- on success move to Return in Warehouse tab

Return-in-warehouse:

- read-only
- terminal state

---

## Feature F: Delivered/Return Mutual Exclusion

Warehouse does not mark delivered, but its queries and transitions must respect logistics outcomes.

Required behavior:

- Once logistics marks `delivered`, order disappears from Warehouse Dispatched.
- Once logistics marks `return_in_transit`, order moves from Warehouse Dispatched to Return in Transit.
- Warehouse cannot set delivered.
- Warehouse cannot receive a return from delivered.

This is primarily enforced by:

- atomic logistics conditional transition from `dispatched`
- warehouse queue status filter
- warehouse conditional return receipt

Do not add special booleans such as `isReturned`; status is the source of truth.

---

## Feature G: Branch-Scoped Packing and Booking Exports

### Shared implementation

Use `apps/server/src/services/order-exports.ts` from the Admin plan.

Warehouse must not maintain a second CSV mapper.

### Endpoints

- `GET /api/inventory/branches/:managerCode/order-exports/packing.csv`
- `GET /api/inventory/branches/:managerCode/order-exports/booking.csv`

Authorization:

- require warehouse inventory access
- validate branch exists
- no restriction to warehouse’s own branch because warehouse is global in current role model

Default order status:

- `confirmed`

This matches packing/booking preparation before dispatch.

Optional UI status selection should be deferred unless operations needs re-exports after dispatch.

### Placement

Selected branch queue header:

- branch code and admin name
- Download packing CSV
- Download booking CSV
- Refresh

Disable export buttons when confirmed count is zero.

Do not depend only on the client count; server still handles empty results.

### Booking requirements inherited from Admin plan

- serial number increments
- barcode is consignment number
- physical weight blank
- farmer receiver details
- hardcoded approved sender details
- last column business order ID

### Packing requirements inherited from Admin plan

- one row per order item
- product name, package size, quantity, line total
- order-level total/payment fields
- deterministic order

### Export consistency test

For branch ABC and same filters:

- Admin packing export rows must equal Warehouse packing export rows.
- Admin booking export rows must equal Warehouse booking export rows.

Only file names may differ if desired; data must not.

---

## Warehouse Page Refactor

The existing dispatch page mixes:

- queue loading
- status mutations
- tracking CSV parsing
- tracking preview
- row rendering

After deleting tracking, split into:

- `apps/web/src/features/warehouse/branches/branch-list.tsx`
- `apps/web/src/features/warehouse/orders/warehouse-order-queue.tsx`
- `apps/web/src/features/warehouse/orders/warehouse-order-row.tsx`
- `apps/web/src/features/warehouse/orders/warehouse-order-actions.tsx`
- `apps/web/src/features/warehouse/orders/warehouse-export-actions.tsx`

Routes:

- `apps/web/src/app/inventory/dispatch/page.tsx`
- `apps/web/src/app/inventory/dispatch/[managerCode]/page.tsx`

Keep data fetching patterns consistent with the current client API architecture. If using Server Components, use `fetchInventoryApi` and ensure session cookies are forwarded.

---

## Warehouse API Authorization

Current `inventory:manage` includes Superadmin and Warehouse. Admin may have `inventory:read` but not manage.

For P1:

- branch list: Warehouse and Superadmin if desired
- dispatch mutation: Warehouse only, unless Superadmin operational override is intended
- return receipt: Warehouse only
- exports: Warehouse; Admin uses manager endpoints

Consider adding explicit actions:

- `warehouse_order:read`
- `warehouse_order:dispatch`
- `warehouse_order:receive_return`
- `warehouse_order:export`

P1 may reuse `inventory:manage`, but explicit permissions are clearer and safer.

If adding actions, update:

- `appActions`
- permission map
- route guards
- tests

---

## Warehouse Tests

### Tracking removal

1. Dispatch page has no upload input.
2. Dispatch page has no tracking download.
3. Tracking PATCH route is absent.
4. Tracking import route is absent.
5. DTO has no tracking field.

### Product creation removal

1. Warehouse dashboard has no Create Product card.
2. Warehouse nav has no create-product entry point.
3. Warehouse product create API returns 403.
4. Superadmin can still create products.
5. Warehouse inventory stock operations still work.

### Branch queue

1. All admin branches appear.
2. Empty branch appears with zero counts.
3. Selecting branch scopes orders correctly.
4. Branch ABC never shows branch BCD order.
5. Only warehouse statuses appear.
6. Delivered and cancelled orders do not appear.

### Dispatch

1. Confirmed order dispatches.
2. Created order cannot dispatch.
3. Already dispatched order cannot dispatch again.
4. Insufficient stock rolls back every mutation.
5. Successful dispatch deducts all item stock and writes events.
6. Dispatched timestamp is set.
7. Order moves tabs.

### Return

1. Return in transit appears.
2. Warehouse can mark return in warehouse.
3. Delivered order cannot be received as return.
4. Return in warehouse is terminal/read-only.
5. Receipt does not automatically restock.

### Exports

1. Packing export is branch-scoped.
2. Booking export is branch-scoped.
3. Exported confirmed orders have IDs and consignments.
4. Missing consignment causes explicit failure.
5. Admin and Warehouse exports match.

---

## Warehouse Acceptance Criteria

- Tracking CSV panel and tracking routes are completely removed.
- Warehouse cannot create/update/deactivate products.
- Order queue first shows branches.
- Selected branch shows Confirmed, Dispatched, Return in Transit, and Return in Warehouse.
- Confirmed orders move directly to Dispatched.
- Dispatched orders are read-only in Warehouse.
- Delivered orders disappear from Warehouse.
- Return in transit can move only to Return in warehouse.
- Warehouse can download packing and booking CSVs for the selected branch.
- All server mutations are role- and status-validated.

---

## Warehouse Implementation Checklist

- [x] Delete tracking types, parser, state, UI, and imports.
- [x] Delete tracking validation schemas.
- [x] Delete tracking routes.
- [x] Remove warehouse product write RBAC.
- [x] Remove Create Product dashboard action.
- [x] Remove or make Products navigation read-only.
- [x] Add branch list service/endpoint.
- [x] Add branch summary counts.
- [x] Add branch list page.
- [x] Add selected branch queue route/page.
- [x] Replace legacy warehouse status constants.
- [x] Delete packed-stage reservation logic.
- [x] Add confirmed-to-dispatched transaction.
- [x] Add return receipt transaction.
- [x] Add selected-branch export buttons.
- [x] Reuse shared order export service.
- [x] Add authorization and lifecycle tests.
- [x] Run global legacy-term search.
- [x] Run type checks and Ultracite.

