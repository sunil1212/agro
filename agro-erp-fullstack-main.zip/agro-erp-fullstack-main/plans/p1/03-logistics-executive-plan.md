# Logistics Executive Priority 1 Plan

## Scope

1. Display “Logistics Executive” as the role title.
2. Introduce branch-prefixed six-digit business order IDs.
3. Assign business order ID and consignment when an order is confirmed.
4. Add a full order edit page based on the advisor order workspace.
5. Permit edits only in `created` and `confirmed`.
6. Remove tracking-link functionality.
7. Split pre-confirmation and post-confirmation follow-ups.
8. Replace legacy lifecycle tabs and actions with the final status model.

This is the highest-risk P1 slice because it changes identity allocation, concurrency, order totals, farmer details, inventory assumptions, and lifecycle authorization.

Read `00-orchestration-and-shared-contracts.md` before implementing.

---

## Feature A: Logistics Executive Naming

### Existing schema support

`packages/db/src/schema/role-title-map.json` already maps:

```json
"logistics": "Logistics Executive"
```

### Required surfaces

Search all display strings:

```bash
rg -n -i '"Logistics"|>Logistics<|logistics teammate|logistics team' \
	apps/web apps/server packages \
	--glob '!**/.next/**'
```

Change user-facing role labels to:

- `Logistics Executive` for singular account/title
- `Logistics team` only in generic operational descriptions when appropriate

Likely files:

- `apps/web/src/app/accounts/create/page.tsx`
- `apps/web/src/components/header.tsx`
- `apps/web/src/features/dashboard/manager-dashboard.tsx`
- `apps/web/src/app/orders/verification/page.tsx`
- sign-in/sign-up role copy if visible

Do not rename:

- role enum `logistics`
- API domain `/api/orders`
- permission action `logistics_order:verify` during P1 unless a broader cleanup is intended

Acceptance:

- Created logistics accounts store title from `roleTitleMap`.
- Account creation dropdown shows “Logistics Executive”.
- Queue page eyebrow/title uses “Logistics Executive”.

---

## Feature B: Business Order ID Lifecycle

### Identity requirements

- Advisor creates an order with an internal UUID.
- Business order ID is `null` in `created`.
- Logistics confirms the order.
- The confirmation transaction allocates:
  - branch sequence
  - formatted business order ID
  - active consignment number
- Status becomes `confirmed`.
- The business order ID never changes afterward.

### Required schema work

As documented in the shared plan:

1. Make `order.order_id` nullable.
2. Add `branch_order_sequence`.

Do not use a global sequence.

Examples:

- Admin code `ABC`, first branch order: `ABC-000001`
- Admin code `ABC`, 9000th branch order: `ABC-009000`
- Admin code `BCD`, 9000th branch order: `BCD-009000`

### Creation route change

File:

`apps/server/src/routes/advisor.ts`

Remove:

```ts
const orderNumber = buildOrderNumber();
```

Remove or delete `buildOrderNumber()` from `apps/server/src/lib/advisor.ts`.

Insert:

```ts
await database.insert(order).values({
	id: orderId,
	orderId: null,
	// existing fields
	status: "created",
});
```

Response:

```ts
{
	success: true,
	order: {
		id: orderId,
		orderId: null,
		status: "created",
	}
}
```

Update UI types so `orderId` is nullable.

Display fallback:

```ts
const displayOrderId = order.orderId ?? "Pending confirmation";
```

Do not display the internal UUID as the order ID.

---

## Feature C: Atomic Confirmation and Consignment Assignment

### Current route

`POST /api/orders/verification/:orderId/approve`

Recommended rename:

`POST /api/orders/verification/:orderId/confirm`

For P1 compatibility, the frontend and backend can keep `/approve` while changing semantics. A cleaner implementation may add `/confirm` and remove `/approve` in the same release.

### Branch resolution

Current code references removed `user.managerCode`. Replace with the shared branch service.

Confirmation must prove:

1. Logistics user belongs to manager code `X`.
2. Order creator belongs to manager code `X`.
3. Admin/branch owner for code `X` exists.
4. Current order status is `created`.

Use 404 for cross-branch order IDs to avoid leaking existence.

### Transaction algorithm

All steps below must execute in one database transaction:

1. Lock/re-read target order.
2. Validate branch ownership.
3. Validate current status is `created`.
4. Apply pending farmer details, if retained by the final edit architecture.
5. Allocate next branch sequence atomically.
6. Build business order ID.
7. Claim one active consignment with `FOR UPDATE SKIP LOCKED`.
8. Update order:
   - `orderId`
   - `status = confirmed`
   - approval audit fields
9. Insert `order_consignment` snapshot using the same business order ID.
10. Mark consignment inactive.
11. Delete pending farmer update row if it has been committed to farmer.
12. Commit.

Pseudo-code:

```ts
await db.transaction(async (tx) => {
	const currentOrder = await getOrderForConfirmation(tx, internalOrderId);

	assertOrderBelongsToBranch(currentOrder, logisticsBranch);
	assertStatus(currentOrder.status, "created");
	assertNull(currentOrder.orderId);

	const sequence = await allocateBranchOrderSequence(tx, {
		adminUserId: logisticsBranch.adminUserId,
	});
	const businessOrderId = formatBranchOrderId(
		logisticsBranch.managerCode,
		sequence
	);

	const availableConsignment = await claimActiveConsignment(tx);
	if (!availableConsignment) {
		throw new DomainError("No active consignment numbers are available");
	}

	await applyPendingFarmerUpdate(tx, currentOrder);

	const [updatedOrder] = await tx
		.update(order)
		.set({
			approvedAt: new Date(),
			approvedByUserId: session.user.id,
			orderId: businessOrderId,
			status: "confirmed",
		})
		.where(
			and(
				eq(order.id, internalOrderId),
				eq(order.status, "created"),
				isNull(order.orderId)
			)
		)
		.returning({ id: order.id });

	if (!updatedOrder) {
		throw new DomainError("Order is no longer available for confirmation");
	}

	await tx.insert(orderConsignment).values({
		assignedAt: new Date(),
		consignmentId: availableConsignment.id,
		consignmentNumber: availableConsignment.consignmentNumber,
		id: crypto.randomUUID(),
		orderId: internalOrderId,
		orderNumber: businessOrderId,
	});

	await tx
		.update(consignment)
		.set({ isActive: false })
		.where(
			and(
				eq(consignment.id, availableConsignment.id),
				eq(consignment.isActive, true)
			)
		);
});
```

### Why the conditional order update matters

Two logistics users can open the same created order. The second confirmation must fail cleanly after the first commits.

The transaction should not:

- consume a second sequence permanently if the confirmation fails
- consume a second consignment
- overwrite the existing order ID

PostgreSQL transaction rollback protects the sequence-table update and consignment state if they occur in the same transaction.

### Consignment query

Current raw SQL pattern is appropriate:

```sql
SELECT id, consignment_number
FROM consignment
WHERE is_active = true
ORDER BY added_at ASC, created_at ASC
LIMIT 1
FOR UPDATE SKIP LOCKED;
```

After selecting, update with `is_active = true` in the predicate and verify one row returned.

### Failure responses

Map domain failures explicitly:

- no active consignment: 409
- already confirmed/concurrent update: 409
- cross-branch/not found: 404
- invalid current status: 400 or 409
- missing branch code: 409 configuration error

Do not send raw database errors to the client.

### Confirmation response

Return the allocated identifiers:

```json
{
  "success": true,
  "order": {
    "id": "internal-uuid",
    "orderId": "XYZ-009000",
    "consignmentNumber": "GR333073882IN",
    "status": "confirmed"
  }
}
```

Update the queue row in local state from this response or reload the queue.

---

## Feature D: Final Logistics Status Tabs

### Current legacy tabs

The current verification page includes:

- created
- picked
- packed
- ready to dispatch / rtd
- dispatched
- delivered
- return in transit
- return in warehouse
- returned
- cancelled

### Required tabs

Use:

```ts
const logisticsStatusOrder = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;
```

The user specifically requested removal of picked, packed, ready to dispatch, and returned.

### Logistics action rules

| Status | Primary actions |
|---|---|
| `created` | Review, Edit, Confirm, Cancel, pre-confirmation follow-ups |
| `confirmed` | Review, Edit, post-confirmation follow-ups |
| `dispatched` | Review, Mark Delivered, Start Return, post-confirmation follow-ups |
| `delivered` | Review, post-confirmation follow-ups; no return action |
| `return_in_transit` | Review, post-confirmation follow-ups; warehouse owns next transition |
| `return_in_warehouse` | Review, post-confirmation follow-ups; terminal |
| `cancelled` | Review, optionally Reopen if existing behavior remains |

The requirement says edits are allowed in `created` and `confirmed`. Both UI and API must use this same predicate:

```ts
export const editableOrderStatuses = ["created", "confirmed"] as const;
```

### Status labels

Centralize formatting:

```ts
export const ORDER_STATUS_LABELS = {
	cancelled: "Cancelled",
	confirmed: "Confirmed",
	created: "Created",
	delivered: "Delivered",
	dispatched: "Dispatched",
	return_in_transit: "Return: in transit",
	return_in_warehouse: "Return: in warehouse",
} as const satisfies Record<OrderStatus, string>;
```

Do not use `replaceAll("_", " ")` for final product labels because return statuses require punctuation/capitalization.

---

## Feature E: Full Order Edit Page

### Required behavior

From the logistics queue, show an Edit button next to Review when status is:

- `created`
- `confirmed`

Edit page allows:

- selecting/changing farmer
- product selection
- quantity
- unit price if current advisor workspace exposes it
- selling price
- line total overrides
- shipping charge
- payment mode
- paid amount
- transaction UTR
- payment screenshot
- coupon code if supported

Must preserve:

- internal `order.id`
- assigned `order.orderId`
- `order_consignment` row
- consignment number
- approval audit fields unless business explicitly wants re-approval
- status

### Route design

Recommended page:

`apps/web/src/app/orders/[orderId]/edit/page.tsx`

The URL parameter is the internal UUID.

Recommended API endpoints:

- `GET /api/orders/verification/:orderId/edit`
- `PATCH /api/orders/verification/:orderId`

Alternative:

- reuse advisor create-options endpoint plus a logistics order detail endpoint

The logistics endpoint is preferable because it can enforce branch scope and return edit permissions in one response.

### Reusing the advisor workspace

Do not copy `OrderWorkspace`.

Refactor it into explicit create/edit modes:

```ts
type OrderWorkspaceMode =
	| {
			kind: "create";
			onSubmit: (input: CreateOrderRequest) => Promise<void>;
	  }
	| {
			kind: "edit";
			orderId: string;
			onSubmit: (input: UpdateOrderRequest) => Promise<void>;
	  };

interface OrderWorkspaceProps {
	data: OrderOptionsResponse;
	initialDraft?: OrderDraftSnapshot;
	mode: OrderWorkspaceMode;
}
```

Avoid inferring mode from the presence of an order ID alone.

### Zustand draft isolation

Current store key:

`advisor-order-draft`

If reused for editing, stale create data can overwrite edit initialization.

Make the workspace controlled by local state and remove persistence from edit mode.

Do not store an edit draft in the same `sessionStorage` key as a create draft.

Edit persistence is unnecessary, avoid it.


### Edit loader response

Return:

```ts
interface OrderEditResponse {
	canEdit: boolean;
	order: {
		consignmentNumber: string | null;
		farmerId: string;
		id: string;
		items: Array<{
			lineTotalAmount: string;
			productId: string;
			quantity: number;
			sellingPricePerUnit: string;
			unitPricePerUnit: string;
		}>;
		orderId: string | null;
		paidAmount: string;
		paymentMode: PaymentMode;
		shippingCharges: string;
		status: OrderStatus;
		transactionScreenshotBase64: string | null;
		transactionUtr: string | null;
	};
	options: {
		farmers: FarmerOption[];
		products: ProductOption[];
	};
	success: true;
}
```

Include product IDs by joining `order_item.product_sku` to `product.sku_code`.

### Server update schema

Do not trust client totals.

Reuse/create a common order write schema:

```ts
const orderWriteSchema = z.object({
	farmerId: z.string().uuid(),
	items: z
		.array(
			z.object({
				lineTotalAmount: z.number().finite().nonnegative(),
				productId: z.string().min(1),
				quantity: z.number().int().positive(),
				sellingPricePerUnit: z.number().finite().nonnegative(),
				unitPricePerUnit: z.number().finite().nonnegative(),
			})
		)
		.min(1),
	paidAmount: z.number().finite().nonnegative().optional(),
	paymentMode: z.enum(["cod", "partial_payment", "prepaid"]),
	shippingCharges: z.number().finite().nonnegative(),
	transactionScreenshotBase64: z.string().optional(),
	transactionUtr: z.string().trim().optional(),
});
```

### Server-side recalculation

For update:

1. Validate selected farmer exists.
2. Validate unique product IDs.
3. Load product snapshots.
4. Validate quantities.
5. Recalculate subtotal from accepted line totals.
6. Recalculate discounts according to current supported rules.
7. Recalculate grand total.
8. Validate paid amount against payment mode.
9. Recalculate total COD.

Do not accept client-supplied subtotal, grand total, or total COD as authoritative.

### Product price policy

The request says full edit access including line totals. Current create flow allows line-total override and submits unit/selling prices.

Explicitly preserve this behavior:

- `unitPricePerUnit`: MRP/base unit price snapshot
- `sellingPricePerUnit`: effective per-unit selling price
- `lineTotalAmount`: manually adjustable line total

Validation should ensure:

- finite, non-negative values
- quantity > 0
- optional business constraint such as line total not exceeding MRP total only if currently required

Do not silently reset edited line totals to product catalog price.

### Transactional update

Perform update in one transaction:

1. Lock or re-read order.
2. Verify same branch.
3. Verify status is still editable.
4. Update farmer reference.
5. Update order totals/payment fields.
6. Upsert discount row.
7. Upsert payment transaction.
8. Replace order items.
9. Preserve order ID and consignment.

Safe item replacement:

```ts
await tx.delete(orderItem).where(eq(orderItem.orderId, internalOrderId));
await tx.insert(orderItem).values(nextItems);
```

The unique `(order_id, product_sku)` index requires de-duplicated products.

### Confirmed-order inventory implications

Current warehouse logic reserves stock at the old `packed` stage. That stage is removed. Under the new flow, confirmed orders are not yet reserved in the current schema.

Choose one explicit policy:

- P1 recommended: validate against current available stock during edit and deduct on dispatch; no reservation at confirmation.
- If reservation is moved to confirmation, editing a confirmed order must release old reservations and apply new reservations atomically.

Do not leave old packed-stage reservation code reachable.

The shared Warehouse plan recommends direct stock deduction on dispatch, matching the simplified lifecycle.

### Farmer edit semantics

The current logistics review supports pending edits to farmer contact/address.

If editing farmer master fields is also required:

- include farmer phone, state, district, taluka, address, post, pincode, landmark
- stage changes in `order_pending_farmer_update`
- current table lacks farmer state replacement semantics
- schema additions may be required

Safe P1 plan:

- Keep the existing “Farmer details” review editor for contact/address updates.
- Extend pending farmer updates with `state` if those edits remain.

Do not mutate a farmer master record merely because an order switched to another farmer.

### Edit race behavior

If order status changes to `dispatched` while edit page is open:

- PATCH must return 409.
- UI must show “This order can no longer be edited because its status changed.”
- Reload order/return to queue.

### Edit page UI

Header:

- title: `Edit order`
- show business order ID or “Pending confirmation”
- show status pill
- show consignment if assigned

Submit button:

- `Save order changes`
- disabled during save
- success toast
- redirect back to logistics queue with the same active status tab if practical

Do not label edit submission “Confirm order”; that is ambiguous with lifecycle confirmation.

---

## Feature F: Remove Tracking-Link Module

### Server deletion list

Files:

- `apps/server/src/lib/orders.ts`
  - delete `updateTrackingLinkSchema`
  - delete `trackingLink` fields from DTO types
- `apps/server/src/routes/orders.ts`
  - delete `PATCH /verification/:orderId/tracking`
  - remove tracking selection/update
- `apps/server/src/lib/inventory-routes.ts`
  - delete tracking schemas/import schemas
- `apps/server/src/routes/inventory.ts`
  - Warehouse details are in the Warehouse plan

### Frontend deletion list

File:

`apps/web/src/app/orders/verification/page.tsx`

Delete:

- `trackingLink` from `VerificationOrder`
- tracking state
- tracking effect
- `onSaveTracking`
- tracking input
- tracking save button
- tracking labels/copy
- descriptions that say “tracking”

Keep:

- consignment number display
- delivered/return actions in dispatched state only

### Details page language

`apps/web/src/features/advisor/orders/details/order-details-client.tsx` currently describes consignment as “Post office tracking number”. This is not necessarily a tracking-link module, but use clearer copy:

- label: `Consignment number`
- helper: `Assigned when logistics confirms the order`

### Verification

```bash
rg -n -i "trackingLink|tracking link|tracking-import|CURRENT_TRACKING_LINK|TRACKING_LINK" \
	apps packages \
	--glob '!**/.next/**' \
	--glob '!**/migrations/**'
```

Expected: no production matches.

---

## Feature G: Follow-Up Phase Split

### Required phase behavior

`created`:

- heading: `Pre Order Confirmation Follow Ups`
- four text boxes
- read/write `pre_order_confirmation_follow_up`

All later statuses:

- heading: `Order Status Follow Ups`
- four entries
- read/write `post_order_follow_up`

Later statuses include:

- `confirmed`
- `dispatched`
- `delivered`
- `return_in_transit`
- `return_in_warehouse`
- optionally `cancelled` depending on desired cancellation behavior

Recommended cancelled behavior:

- cancelled before confirmation continues showing pre-confirmation follow-ups
- if cancellation can occur only from created, this preserves phase history

Create helper:

```ts
export const getFollowUpPhase = (
	status: OrderStatus
): "pre_confirmation" | "post_confirmation" =>
	status === "created" || status === "cancelled"
		? "pre_confirmation"
		: "post_confirmation";
```

### Query changes

Current route coalesces pre and post columns. Remove that.

Options:

1. Query both tables and choose in mapping.
2. Query status first, then phase-specific table.

For queue performance, query both but map explicitly:

```ts
const followUps =
	getFollowUpPhase(currentOrder.status) === "pre_confirmation"
		? getFollowUps(currentOrder.preFollowUpColumns, ...)
		: getFollowUps(currentOrder.postFollowUpColumns, ...);
```

Do not allow pre text to appear in post slots via `coalesce`.

### Update route

The existing update route already chooses table based on status, but extend phase logic for `cancelled` and canonical statuses.

Return phase:

```json
{
  "success": true,
  "phase": "post_confirmation",
  "followUps": []
}
```

### Ownership rule

Current behavior allows only the original follow-up author to edit a non-empty slot.

Preserve unless business requests shared editing.

### Dropdown ambiguity

The task summary says post-order follow-ups should have dropdown entries, but:

- no dropdown option list was provided
- no storage column exists
- status columns were removed from schema

P1 implementation instruction:

- render text areas using existing text storage
- change heading and table source by phase
- do not add a dropdown without a defined domain and migration
- include a TODO/product question in the PR description

---

## Feature H: Dispatched Actions and Return Guard

### Required logistics actions

Only when current status is `dispatched`:

- Mark Delivered
- Start Return

Schema:

```ts
export const logisticsStatusUpdateSchema = z.object({
	status: z.enum(["delivered", "return_in_transit"]),
});
```

Server checks:

```ts
if (currentOrder.status !== "dispatched") {
	throw new DomainError(
		"Only dispatched orders can be marked delivered or returned"
	);
}
```

This fixes current legacy behavior that permits starting return from `delivered`.

Use a conditional update:

```ts
const [updatedOrder] = await db
	.update(order)
	.set({ status: values.status })
	.where(
		and(
			eq(order.id, internalOrderId),
			eq(order.status, "dispatched")
		)
	)
	.returning({ status: order.status });

if (!updatedOrder) {
	throw new DomainError("Order status changed; refresh and try again");
}
```

This guarantees:

- delivered cannot later become return in transit
- returned cannot later become delivered
- double clicks resolve safely

### UI confirmation

Use an AlertDialog for both terminal branch choices:

- Mark delivered?
- Start return?

Explain mutual exclusivity.

Disable buttons while request is pending.

---

## Logistics Queue Refactor Strategy

The current page is over 1,000 lines. P1 is a good time to split it, but avoid a broad visual rewrite.

Recommended files:

- `apps/web/src/features/logistics/orders/logistics-order-types.ts`
- `apps/web/src/features/logistics/orders/logistics-order-queue.tsx`
- `apps/web/src/features/logistics/orders/logistics-order-row.tsx`
- `apps/web/src/features/logistics/orders/logistics-order-sheet.tsx`
- `apps/web/src/features/logistics/orders/follow-up-panel.tsx`
- `apps/web/src/features/logistics/orders/farmer-details-editor.tsx`
- `apps/web/src/features/logistics/orders/order-actions.tsx`

Page file should load/session-coordinate and render the feature component.

Do not define large components inside the page component.

---

## Logistics API Authorization

Every logistics mutation must:

1. authenticate
2. require `logistics_order:verify`
3. get logistics branch context
4. join order creator to `user_manager_code`
5. compare branch code
6. validate lifecycle status
7. perform conditional mutation

Create a reusable loader:

```ts
async function getBranchScopedLogisticsOrder(
	database: Database,
	input: {
		logisticsUserId: string;
		orderId: string;
	}
): Promise<BranchScopedOrder | null> {
	// One canonical branch-scoped query.
}
```

Avoid copying this authorization query into confirm, edit, follow-up, cancel, and status handlers.

---

## Logistics Tests

### Order ID allocation

1. Created order has null business order ID.
2. Confirmation generates `<CODE>-000001`.
3. Tenth order generates `<CODE>-000010`.
4. 9000th order formats `<CODE>-009000`.
5. Different branches can share suffix.
6. Same branch confirmations cannot share suffix.
7. Failed confirmation rolls back sequence.
8. Existing business order ID is never overwritten.

### Consignment allocation

1. Oldest active consignment is selected.
2. Selected consignment becomes inactive.
3. One order gets only one order-consignment row.
4. No active consignment returns 409 and leaves order created.
5. Concurrent confirmations cannot claim the same consignment.
6. Order ID and consignment are both present or both absent.

### Edit

1. Created order can be edited.
2. Confirmed order can be edited.
3. Dispatched order GET may load read-only data but PATCH returns 409/403.
4. Editing items recalculates totals.
5. Duplicate product IDs are rejected.
6. Payment mode validation works.
7. Order ID remains unchanged.
8. Consignment remains unchanged.
9. Cross-branch logistics cannot load or update.
10. Status race rejects stale edit.

### Follow-ups

1. Created uses pre table.
2. Confirmed uses post table.
3. Pre values do not appear as post values.
4. Four slots remain independently editable by owner.
5. Phase label changes after confirmation.

### Lifecycle

1. Created can confirm.
2. Confirmed cannot deliver.
3. Dispatched can deliver.
4. Dispatched can start return.
5. Delivered cannot start return.
6. Return in transit cannot deliver.
7. Removed legacy statuses are absent from API types and tabs.

### Tracking removal

1. No tracking route exists.
2. No tracking field in DTO.
3. No tracking input in sheet.
4. No tracking import UI.

---

## Logistics Acceptance Criteria

- All role labels say Logistics Executive where referring to the user title.
- Advisor-created orders do not have a business order ID.
- Confirmation atomically assigns branch business order ID and consignment.
- Confirmation status is `confirmed`.
- Queue contains only canonical statuses.
- Edit button appears only for created/confirmed.
- Server rejects edits outside created/confirmed.
- Full order totals and items can be edited without changing order ID.
- Tracking-link module is absent.
- Created shows four pre-confirmation follow-ups.
- Confirmed and later show four post-confirmation follow-ups.
- Only dispatched orders expose Delivered and Return in Transit actions.
- Delivered and return paths are mutually exclusive.

---

## Logistics Implementation Checklist

- [x] Update user-facing role labels.
- [x] Make order ID nullable.
- [x] Add branch sequence table and allocator.
- [x] Remove temporary order number generation at advisor creation.
- [x] Add branch-scoped confirmation service.
- [x] Allocate order ID and consignment in one transaction.
- [x] Return allocated identifiers.
- [x] Replace legacy status constants.
- [x] Replace queue tabs.
- [x] Remove tracking server routes and DTO fields.
- [x] Remove tracking frontend state and UI.
- [x] Split follow-up query mapping by phase.
- [x] Update follow-up headings.
- [x] Add edit loader endpoint.
- [x] Add transactional edit endpoint.
- [x] Refactor advisor workspace for explicit edit mode.
- [x] Isolate create/edit draft state.
- [x] Add edit page and queue button.
- [x] Add dispatched-only status actions.
- [x] Add concurrency and authorization tests.
- [x] Run global legacy-term search.
- [x] Run type checks and Ultracite.

