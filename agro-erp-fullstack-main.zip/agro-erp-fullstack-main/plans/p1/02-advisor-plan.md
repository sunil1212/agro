# Advisor Priority 1 Plan

## Scope

1. Add dependent State -> District -> Taluka dropdowns to farmer onboarding.
2. Remove the Inventory navigation item for advisors.

Database schema already includes `farmer.state`. The current server validation and insert path do not yet accept or write it.

---

## Feature A: State, District, and Taluka Mapping

### Source data

`apps/public/example_docs/MHT District Taluka Mapping.txt`

The source currently contains Maharashtra districts and comma-separated talukas. It should be converted once into a typed frontend data module. Do not parse the public text file in the browser at runtime.

### Recommended module location

Because this mapping is specific to farmer forms in the web app, use:

`apps/web/src/features/advisor/farmers/location-map.ts`

If multiple apps later need it, move it to a dedicated shared package. Do not put application data inside a generic UI primitive file.

### Extensible data shape

Use stable codes internally and display labels separately.

```ts
export interface TalukaOption {
	code: string;
	label: string;
}

export interface DistrictOption {
	code: string;
	label: string;
	talukas: readonly TalukaOption[];
}

export interface StateOption {
	code: string;
	label: string;
	districts: readonly DistrictOption[];
}

export const FARMER_LOCATION_MAP = [
	{
		code: "MH",
		label: "Maharashtra",
		districts: [
			{
				code: "AHMEDNAGAR_AHILYANAGAR",
				label: "Ahmednagar (Ahilyanagar)",
				talukas: [
					{ code: "AKOLE", label: "Akole" },
					{ code: "SANGAMNER", label: "Sangamner" },
					// Continue with every source entry.
				],
			},
		],
	},
] as const satisfies readonly StateOption[];
```

Persist labels, not codes, in the current text columns:

- `state = "Maharashtra"`
- `district = "Pune"`
- `taluka = "Mulshi"`

Codes exist to make UI selection stable and to support future label changes. The form can derive labels before submission.

Alternative simpler shape:

```ts
export const LOCATION_MAP = {
	Maharashtra: {
		Pune: ["Ambegaon", "Baramati", "Bhor", "Daund"],
	},
} as const;
```

The coded array is preferred because it supports duplicate names and future metadata without changing form logic.

### Data conversion quality checks

The implementation model must verify:

- Every non-empty district line has one following taluka line.
- Taluka values are trimmed.
- No empty taluka is emitted.
- No duplicate district label exists inside Maharashtra.
- No duplicate taluka exists inside one district.
- Parenthetical renamed districts remain exactly as supplied:
  - `Ahmednagar (Ahilyanagar)`
  - `Dharashiv (Osmanabad)`
  - `Chhatrapati Sambhajinagar (Aurangabad)`
- Maharashtra is the only state for P1.

Add a unit test or development assertion:

```ts
for (const state of FARMER_LOCATION_MAP) {
	const districtCodes = new Set<string>();
	for (const district of state.districts) {
		if (districtCodes.has(district.code)) {
			throw new Error(`Duplicate district code: ${district.code}`);
		}
		districtCodes.add(district.code);
	}
}
```

Do not leave this assertion executing in a hot render loop.

---

## Form Contract Changes

### Current shared UI location

`packages/ui/src/components/multi-form.tsx`

This component currently:

- defines `CreateFarmerFormValues`
- defines its own Zod form schema
- renders location inputs
- has free-text district and taluka fields
- has no state field

### Architectural caution

`packages/ui` should ideally contain generic visual components, while state-specific business mapping belongs in `apps/web`. Passing location options as props avoids importing application-specific Maharashtra data into the shared UI package.

Recommended props:

```ts
export interface FarmerStateOption {
	code: string;
	districts: readonly {
		code: string;
		label: string;
		talukas: readonly {
			code: string;
			label: string;
		}[];
	}[];
	label: string;
}

export interface MultiFormProps {
	// existing props
	locationOptions: readonly FarmerStateOption[];
}
```

Update `CreateFarmerPage`:

```tsx
<MultiForm
	advisors={options.advisors}
	crops={options.crops}
	defaultServiceByUserId={options.currentAdvisor.id}
	locationOptions={FARMER_LOCATION_MAP}
	onSubmit={handleSubmit}
	referralFarmers={options.referralFarmers}
/>
```

### Form value shape

Add:

```ts
state: string;
```

Full location portion:

```ts
export interface CreateFarmerFormValues {
	state: string;
	district: string;
	taluka: string;
	addressAt: string;
	post: string;
	pincode: string;
	nearbyLandmark?: string;
	// existing fields
}
```

Persist labels in these three fields.

### Default selection logic

Requirement:

- If only one state exists, auto-select it.
- When a state is selected, show only its districts.
- When a district is selected, show only its talukas.

Recommended helpers:

```ts
const getOnlyOptionValue = <T extends { label: string }>(
	options: readonly T[]
): string => (options.length === 1 ? options[0]?.label ?? "" : "");

const defaultState = getOnlyOptionValue(locationOptions);
const defaultDistrict =
	locationOptions.length === 1 &&
	locationOptions[0]?.districts.length === 1
		? locationOptions[0].districts[0]?.label ?? ""
		: "";
```

For P1:

- `state` defaults to `Maharashtra`.
- `district` remains empty because there are multiple districts.
- `taluka` remains empty.

### Dependent reset rules

When state changes:

1. Set new state.
2. Clear district.
3. Clear taluka.
4. If the state has exactly one district, auto-select it.
5. If that district has exactly one taluka, auto-select it.

When district changes:

1. Set new district.
2. Clear taluka.
3. If the district has exactly one taluka, auto-select it.

Pseudo-code:

```ts
const handleStateChange = (nextState: string): void => {
	form.setValue("state", nextState, { shouldValidate: true });

	const districts = getDistrictsForState(nextState);
	const nextDistrict = getOnlyOptionValue(districts);
	form.setValue("district", nextDistrict, { shouldValidate: true });

	const talukas = nextDistrict
		? getTalukasForDistrict(nextState, nextDistrict)
		: [];
	form.setValue("taluka", getOnlyOptionValue(talukas), {
		shouldValidate: true,
	});
};
```

Do not leave a taluka selected after its district changes.

### Dropdown order

The “Location details” section must render in this order:

1. State dropdown
2. District dropdown
3. Taluka dropdown
4. Village / At
5. Post
6. Pincode
7. Nearby Landmark

This is explicitly different from the current order.

### Dropdown component

Use the existing shadcn Select components already imported by `multi-form.tsx`.

State:

```tsx
<Controller
	control={form.control}
	name="state"
	render={({ field, fieldState }) => (
		<Field data-invalid={fieldState.invalid}>
			<FieldLabel htmlFor="state">State</FieldLabel>
			<Select
				name={field.name}
				onValueChange={handleStateChange}
				value={field.value}
			>
				<SelectTrigger
					aria-invalid={fieldState.invalid}
					className="w-full"
					id="state"
				>
					<SelectValue placeholder="Select state" />
				</SelectTrigger>
				<SelectContent>
					{locationOptions.map((state) => (
						<SelectItem key={state.code} value={state.label}>
							{state.label}
						</SelectItem>
					))}
				</SelectContent>
			</Select>
			{fieldState.invalid ? (
				<FieldError errors={[fieldState.error]} />
			) : null}
		</Field>
	)}
/>
```

District:

- disabled until state is selected
- options derived only from selected state

Taluka:

- disabled until district is selected
- options derived only from selected state and district

### Auto-selection implementation

Set initial values in `useForm`:

```ts
const initialState =
	locationOptions.length === 1 ? locationOptions[0]?.label ?? "" : "";

const form = useForm<FormSchema>({
	defaultValues: {
		// existing values
		state: initialState,
		district: "",
		taluka: "",
	},
});
```

If options can change after mount, use an effect that only fills blank values. Do not overwrite a user selection:

```ts
useEffect(() => {
	if (
		locationOptions.length === 1 &&
		!form.getValues("state")
	) {
		form.setValue("state", locationOptions[0]?.label ?? "");
	}
}, [form, locationOptions]);
```

In the current app options are static imports, so an effect should not be necessary.

### Reset behavior after successful creation

The current reset sets district and taluka to empty. Preserve the only state selection:

```ts
form.reset({
	// existing blank values
	state: initialState,
	district: "",
	taluka: "",
});
```

### Fix nearby structural issue while editing

The current component contains a duplicated `<Select` token near the Service By field. Confirm the actual source and fix it as part of the same file edit if present. Do not leave syntax/type defects in a touched file.

---

## Frontend Validation

Add state to the form Zod schema:

```ts
state: z.string().trim().min(1, "State is required"),
district: z.string().trim().min(1, "District is required"),
taluka: z.string().trim().min(1, "Taluka is required"),
```

Zod alone validates only non-empty values. Add hierarchy validation:

```ts
.superRefine((values, context) => {
	if (!isValidLocationSelection({
		state: values.state,
		district: values.district,
		taluka: values.taluka,
	})) {
		context.addIssue({
			code: "custom",
			message: "Select a valid state, district, and taluka",
			path: ["taluka"],
		});
	}

	// Preserve existing secondary-phone and crop-date checks.
});
```

Implement:

```ts
export const isValidLocationSelection = (input: {
	district: string;
	state: string;
	taluka: string;
}): boolean => {
	const state = FARMER_LOCATION_MAP.find(
		(option) => option.label === input.state
	);
	const district = state?.districts.find(
		(option) => option.label === input.district
	);
	return Boolean(
		district?.talukas.some((option) => option.label === input.taluka)
	);
};
```

---

## Server Validation and Persistence

Frontend mapping is not a security boundary. A direct API client can submit arbitrary district/taluka strings.

### Shared validation data

The server cannot import from `apps/web`.

Choose one:

1. Move the pure location data to a shared package/module consumable by server and web.
2. Keep a generated JSON data file in a shared package and expose typed helpers.

Recommended:

`packages/location-data/src/maharashtra.ts`

This requires creating a small workspace package. If avoiding a package for P1, place shared data under:

`packages/db/src/data/farmer-locations.ts`

but note that location data is not conceptually a database schema.

Do not duplicate the full Maharashtra map separately in server and web; it will drift.

### Server schema

File:

`apps/server/src/lib/advisor.ts`

Add:

```ts
state: z.string().trim().min(1, "State is required"),
```

Then refine:

```ts
export const createFarmerSchema = z
	.object({
		// fields
		state: z.string().trim().min(1, "State is required"),
		district: z.string().trim().min(1, "District is required"),
		taluka: z.string().trim().min(1, "Taluka is required"),
	})
	.superRefine((values, context) => {
		if (!isValidFarmerLocation(values)) {
			context.addIssue({
				code: "custom",
				message: "Invalid state, district, or taluka selection",
				path: ["taluka"],
			});
		}
	});
```

### Insert

File:

`apps/server/src/lib/advisor.ts`

In `insertFarmerWithCrops`:

```ts
state: parsedValues.state.trim(),
district: parsedValues.district.trim(),
taluka: parsedValues.taluka.trim(),
```

### Response/detail queries

Add `state` to farmer detail responses:

- `GET /api/advisor/farmers/:farmerId`
- any logistics farmer edit/detail DTO
- booking export source
- future label source

The database default of Maharashtra is useful for legacy records, but new writes must explicitly send the selected state.

### Order pending farmer update

The current `order_pending_farmer_update` schema shown in the repository does not contain a state field. Logistics full edit can change farmer details. Decide during the Logistics phase:

- If logistics may change state before confirmation, add `state` to the pending update table.
- If logistics full edit writes directly to farmer only on confirmation, include state in that edit DTO.

The safe design is to add `state` to `order_pending_farmer_update`; otherwise a farmer can have district/taluka changed without a matching state.

---

## Accessibility and UX Requirements

- State, district, and taluka must have visible labels.
- Disabled dropdowns must still explain why through placeholder text:
  - “Select state first”
  - “Select district first”
- Keyboard navigation must work through the existing Select primitive.
- Do not auto-open the next dropdown after selection.
- Auto-selection of the only state must be visible in the trigger.
- Validation error should be attached to the incorrect dependent field.
- Use stable codes as React keys.
- Preserve responsive two-column layout.

Suggested grid:

```tsx
<div className="grid gap-6 md:grid-cols-2">
	<StateField />
	<DistrictField />
	<TalukaField />
	<VillageField />
	<PostField />
	<PincodeField />
	<LandmarkField className="md:col-span-2" />
</div>
```

The exact grid order must remain logical in DOM order, not only visual CSS order.

---

## Feature B: Remove Inventory from Advisor Navigation

### Current location

`apps/web/src/components/header.tsx`

Current advisor links include:

```ts
{ to: "/inventory", label: "Inventory" }
```

Delete that entry.

Required resulting list:

```ts
const advisorLinks = [
	{ to: "/farmers", label: "Farmers" },
	{ to: "/orders", label: "Orders" },
	{ to: "/tasks", label: "Tasks" },
] as const;
```

### Security note

Removing a navigation link does not remove API access.

Current RBAC grants advisors:

```ts
"inventory:read_finished_goods"
```

The user asked to remove the tab because advisors no longer need inventory. Confirm whether direct inventory access must also be removed.

Recommended P1 interpretation:

- Remove advisor navigation.
- Remove advisor `inventory:read_finished_goods` permission.
- Ensure order creation still gets product availability through the advisor order options endpoint, not the inventory endpoint.
- Direct `/inventory` pages should reject or redirect advisors.

Files to inspect:

- `apps/server/src/lib/rbac.ts`
- `apps/server/src/lib/inventory.ts`
- `apps/server/src/lib/inventory-routes.ts`
- `apps/web/src/app/inventory/**`

Change:

```ts
advisor: [
	"crop:read_pdf",
	"product:list",
	"product:read",
	"farmer:manage",
	"advisor_order:manage",
],
```

Remove advisor from `finishedGoodsReadRoles` / `canReadFinishedGoodsRole` if those helpers remain.

Do not remove product information from order creation; that uses `/api/advisor/orders/create-options`.

### Route-level page guard

The Next.js proxy only checks authentication, not roles. API authorization is the source of truth, but pages may briefly render an error for an unauthorized direct URL.

P1 options:

- Keep the page and let API return 403.
- Add a role-aware page guard for better UX.

At minimum, verify `/inventory` does not expose data to an advisor after RBAC removal.

---

## Advisor Tests

### Mapping tests

1. Location map has exactly one state.
2. Maharashtra auto-selects.
3. District remains blank initially.
4. Selecting Pune exposes Pune talukas only.
5. Selecting Mulshi submits:
   - `state: "Maharashtra"`
   - `district: "Pune"`
   - `taluka: "Mulshi"`
6. Changing Pune to Nashik clears Mulshi.
7. A manually crafted Pune + Nashik taluka API request returns 400.
8. All source districts are present.
9. Every source taluka is present exactly once under its district.

### Persistence tests

1. Newly created farmer stores state.
2. Farmer detail response returns state.
3. Booking export receives state from farmer data.
4. Legacy farmer with database default remains readable.

### Navigation and authorization tests

1. Advisor header has no Inventory link.
2. Advisor direct inventory API request returns 403 if RBAC is removed.
3. Warehouse and Superadmin inventory access still works.
4. Advisor order creation still loads products.

---

## Advisor Acceptance Criteria

- State is a dropdown and auto-selects Maharashtra.
- District options depend on state.
- Taluka options depend on district.
- Invalid hierarchy combinations are rejected on the server.
- Form location order is State, District, Taluka, then remaining address fields.
- Successful submission writes `farmer.state`.
- Reset preserves the only supported state.
- Advisor navigation no longer contains Inventory.
- Advisor cannot retrieve inventory data directly if the permission-removal interpretation is accepted.

---

## Advisor Implementation Checklist

- [x] Convert source mapping to typed shared data.
- [x] Add map integrity tests.
- [x] Add location options prop to `MultiForm`.
- [x] Add state to server Zod schema.
- [x] Add server hierarchy validation.
- [x] Write state during farmer insertion.
- [x] Return state in farmer details.
- [x] Remove Inventory advisor nav item.
- [x] Remove advisor inventory permission if approved by scope.
- [x] Verify order creation product loading.
- [x] Run type checks and Ultracite.
- [x] Add state/district/taluka Select fields (frontend).
- [x] Add dependent reset and single-option selection logic (frontend).
- [x] Reorder location fields (frontend).
- [x] Preserve state on form reset (frontend).
- [x] Add state to form types and Zod schema (frontend).

