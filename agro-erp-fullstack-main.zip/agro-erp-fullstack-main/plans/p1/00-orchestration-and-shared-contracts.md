# Priority 1 Implementation Orchestration and Shared Contracts

Date prepared: 19 June 2026

## Purpose

This document is the execution controller for all Priority 1 work. It defines the shared contracts that must be settled before role-specific work begins, the safe implementation order, ownership boundaries, database risks, verification gates, and handoff rules.

The role plans are:

1. `01-admin-manager-plan.md`
2. `02-advisor-plan.md`
3. `03-logistics-executive-plan.md`
4. `04-warehouse-plan.md`
5. `05-cross-role-acceptance-and-release-plan.md`

The smaller implementation model must read this file first, then read the role file for the slice it is implementing.

---

## Requested P1 Outcome

### Admin, formerly Manager

- Replace the advisor weekly target input with daily and monthly target inputs.
- Export branch-scoped packing and booking CSV files.

### Advisor

- Add State -> District -> Taluka dependent dropdowns to farmer onboarding.
- Remove Inventory from advisor navigation.

### Logistics Executive

- Display the role title as “Logistics Executive”.
- Assign a branch-prefixed, six-digit order ID only when a created order is confirmed.
- Assign a consignment number in the same confirmation transaction.
- Reuse the advisor order workspace in edit mode and allow full edits only while status is `created` or `confirmed`.
- Remove tracking-link functionality.
- Split four pre-confirmation follow-ups from four post-confirmation follow-ups.
- Use only the final order lifecycle statuses.

### Warehouse

- Remove tracking-link CSV import and tracking-link editing.
- Remove warehouse product creation access and UI.
- Show branch-first order queues.
- Show only warehouse-relevant statuses.
- Move `confirmed` orders directly to `dispatched`.
- Move `return_in_transit` orders to `return_in_warehouse`.
- Download branch-scoped packing and booking CSV files.

### Explicitly outside this current P1 plan

- Barcode/label-sheet PDF generation is not included because it was not present in the latest P1 task list, even though `apps/public/example_docs/Label Sheet.png` exists.
- Editing an advisor's targets after account creation remains P2.
- Barcode waybill and invoice generation remain later priorities.
- Automatic restocking of returned products is not included.

---

## Repository Findings That Change the Implementation Order

The database schema and application code are currently out of sync.

### The Drizzle schema already contains

- `user_sales_target.daily_sales_target`
- `user_sales_target.monthly_sales_target`
- `user_manager_code`
- `order_status` values:
  - `created`
  - `confirmed`
  - `dispatched`
  - `delivered`
  - `return_in_transit`
  - `return_in_warehouse`
  - `cancelled`
- `consignment`
- `order_consignment`
- `farmer.state`
- separate pre-order and post-order follow-up tables
- no `order.trackingLink` field

### The application still contains legacy references

- `weeklySalesTarget`
- `user.managerCode`
- `order.orderNumber`
- `order.trackingLink`
- `picked`
- `packed`
- `rtd`
- `returned`
- tracking CSV import routes and UI

### Current baseline verification

`bun run check-types` fails in `apps/server/src/routes/orders.ts` and `apps/server/src/routes/inventory.ts` because those modules still use the legacy contract.

Do not start with isolated UI edits. First reconcile the shared contract or subsequent work will be built on types and queries that do not compile.

---

## Canonical Domain Contract

Use these names consistently in database schema, API responses, frontend types, labels, tests, and exports.

### Internal database identity versus business order ID

- `order.id`
  - Internal immutable UUID.
  - Created as soon as the advisor submits the order.
  - Used in URLs, foreign keys, API route parameters, React keys, and internal joins.
- `order.orderId`
  - Human-facing business identifier.
  - `null` while status is `created`.
  - Assigned exactly once when the order changes from `created` to `confirmed`.
  - Format: `<ADMIN_CODE>-<SIX_DIGIT_BRANCH_SEQUENCE>`.
  - Example: `XYZ-009000`.
- API DTO field:
  - Prefer `orderId` for the business identifier.
  - Prefer `id` for the internal UUID.
  - Do not continue introducing the alias `orderNumber`.

Example DTO:

```ts
interface OrderIdentityDto {
	id: string;
	orderId: string | null;
}
```

### Branch identity

The current normalized source of branch identity is `user_manager_code`.

- An admin owns one unique manager/admin code.
- Advisor, team leader, and logistics accounts created under that admin receive the same code.
- Orders belong to a branch through the creator’s `user_manager_code`.
- Warehouse can read all branches.
- Admin and logistics users can read only their own branch.

Do not query `user.managerCode`; that field no longer exists in the Drizzle schema.

Recommended helper:

```ts
type BranchContext = {
	adminUserId: string;
	managerCode: string;
};

async function getBranchContextForUser(
	database: Database,
	userId: string
): Promise<BranchContext | null> {
	// Join user_manager_code to the admin user that owns the same code.
	// Return one normalized branch object used by all role routes.
}
```

Create one shared server service, for example:

`apps/server/src/services/branches.ts`

It should provide:

- `getUserManagerCode(database, userId)`
- `requireUserManagerCode(database, userId)`
- `listBranches(database)`
- `getBranchByManagerCode(database, managerCode)`
- a reusable branch-scope SQL predicate/helper

Do not duplicate manager-code lookup logic in manager, orders, advisor, and inventory routes.

### Role titles

- Stored role remains `logistics`.
- Display title is `Logistics Executive`.
- Use `getDefaultTitleForRole()` or `roleTitleMap`.
- Do not rename the database enum from `logistics`.

### Order status state machine

Canonical statuses:

```ts
export const orderStatuses = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;
```

Allowed transitions:

| Actor | From | To | Notes |
|---|---|---|---|
| Logistics | `created` | `confirmed` | Assign order ID and consignment atomically |
| Logistics | `created` | `cancelled` | Existing cancellation flow may remain |
| Logistics | `cancelled` | `created` | Existing reopen flow may remain if product owner wants it |
| Warehouse | `confirmed` | `dispatched` | Direct transition; no picked/packed/RTD |
| Logistics | `dispatched` | `delivered` | Only valid delivered transition |
| Logistics | `dispatched` | `return_in_transit` | Return can start only here |
| Warehouse | `return_in_transit` | `return_in_warehouse` | Terminal warehouse return receipt |

Forbidden transitions:

- `delivered` -> `return_in_transit`
- `return_in_transit` -> `delivered`
- `return_in_warehouse` -> `delivered`
- `confirmed` -> `delivered`
- `created` -> `dispatched`
- any edit after `dispatched`

Centralize this in one server module, for example:

`apps/server/src/domain/order-lifecycle.ts`

Pseudo-code:

```ts
export const ORDER_TRANSITIONS = {
	logistics: {
		created: ["confirmed", "cancelled"],
		cancelled: ["created"],
		dispatched: ["delivered", "return_in_transit"],
	},
	warehouse: {
		confirmed: ["dispatched"],
		return_in_transit: ["return_in_warehouse"],
	},
} as const;

export function assertOrderTransitionAllowed(input: {
	actorRole: "logistics" | "warehouse";
	currentStatus: OrderStatus;
	nextStatus: OrderStatus;
}): void {
	const allowed = ORDER_TRANSITIONS[input.actorRole][input.currentStatus] ?? [];
	if (!allowed.includes(input.nextStatus)) {
		throw new DomainError("Invalid order status transition");
	}
}
```

The server must enforce transitions. Hiding a button is not authorization.

### Follow-up storage contract

- Status `created` reads and writes `pre_order_confirmation_follow_up`.
- Every status after confirmation reads and writes `post_order_follow_up`.
- Do not `coalesce()` the pre and post tables into one ambiguous row.
- Return the phase explicitly:

```ts
type FollowUpPhase = "pre_confirmation" | "post_confirmation";

interface FollowUpResponse {
	phase: FollowUpPhase;
	entries: FollowUpEntry[];
}
```

Open product ambiguity:

The request mentions post-order “dropdown entries”, but the current schema stores only text and the migrations intentionally removed follow-up status columns. Do not invent serialized dropdown values inside the text field. Implement post-confirmation text follow-ups using the existing schema unless exact dropdown options and persistence requirements are supplied. Record this assumption in the PR.

### Tracking links

Tracking links are removed, not hidden.

Delete:

- validation schemas
- route handlers
- DTO fields
- frontend state
- frontend panels
- tracking CSV generation/import parser
- tracking-related copy
- stale files under public consignments if they are test artifacts and the owner approves deletion

Do not re-add an `order.trackingLink` schema column.

---

## Required Database Decisions

The user indicated most schema changes are already complete. Two additional changes are still required for the requested behavior.

### 1. `order.order_id` must be nullable

Current Drizzle schema:

```ts
orderId: text("order_id").notNull()
```

Required:

```ts
orderId: text("order_id")
```

Keep the unique index. PostgreSQL permits multiple `NULL` values in a normal unique index.

Migration:

```sql
ALTER TABLE "order"
ALTER COLUMN "order_id" DROP NOT NULL;
```

Creation code must write `orderId: null`.

Every consumer must support `string | null`:

- order list
- order details
- logistics queue
- edit page
- warehouse queue
- packing and booking export

UI copy before confirmation should be “Pending confirmation”, not a generated temporary business ID. Internal UUID may be shown only in a developer/debug context.

### 2. Add an atomic branch-scoped sequence

Do not implement this using `COUNT(*) + 1` or `MAX(order_id) + 1` without a lock. Two confirmations can happen concurrently.

Recommended table:

```ts
export const branchOrderSequence = pgTable("branch_order_sequence", {
	adminUserId: text("admin_user_id")
		.primaryKey()
		.references(() => user.id, { onDelete: "cascade" }),
	lastValue: integer("last_value").default(0).notNull(),
	updatedAt: timestamp("updated_at")
		.defaultNow()
		.$onUpdate(() => new Date())
		.notNull(),
});
```

Why key by admin user ID instead of code:

- The admin user is the stable branch owner.
- Manager/admin codes are display/business identifiers and might eventually be editable.
- The generated order ID still uses the current code.

Atomic allocation pattern inside the same confirmation transaction:

```sql
INSERT INTO branch_order_sequence (admin_user_id, last_value)
VALUES ($1, 1)
ON CONFLICT (admin_user_id)
DO UPDATE SET
	last_value = branch_order_sequence.last_value + 1,
	updated_at = now()
RETURNING last_value;
```

Formatting:

```ts
const ORDER_SEQUENCE_WIDTH = 6;

export const formatBranchOrderId = (
	managerCode: string,
	sequence: number
): string =>
	`${managerCode}-${String(sequence).padStart(ORDER_SEQUENCE_WIDTH, "0")}`;
```

Legacy initialization:

- If legacy branch-prefixed order IDs already exist, initialize `last_value` to the maximum parsed six-digit suffix per branch.
- Imported historical order IDs that do not match the new pattern must not affect the new sequence.
- Add a pre-deployment query/report to identify collisions.

---

## Shared Export Contract

Admin and Warehouse must call the same export service. Do not implement duplicate CSV mappers in two frontend pages.

Recommended server modules:

- `apps/server/src/services/order-exports.ts`
- `apps/server/src/lib/csv.ts`

Recommended endpoints:

- `GET /api/manager/order-exports/packing.csv`
  - Admin session.
  - Branch inferred from session.
- `GET /api/manager/order-exports/booking.csv`
  - Admin session.
  - Branch inferred from session.
- `GET /api/inventory/branches/:managerCode/order-exports/packing.csv`
  - Warehouse session.
  - Explicit validated branch.
- `GET /api/inventory/branches/:managerCode/order-exports/booking.csv`
  - Warehouse session.
  - Explicit validated branch.

Optional query filters:

- `status=confirmed`
- `from=YYYY-MM-DD`
- `to=YYYY-MM-DD`

P1 default:

- Export `confirmed` orders for packing/booking work.
- If the UI allows exporting other statuses, the selected status must be explicit.

Use server-generated CSV rather than frontend-only mapping because:

- authorization and branch scope remain server-side
- both roles share exactly the same format
- large exports do not require loading every row into React state
- static sender details have one source of truth

Response headers:

```ts
response
	.status(200)
	.setHeader("Content-Type", "text/csv; charset=utf-8")
	.setHeader(
		"Content-Disposition",
		`attachment; filename="${fileName}"`
	)
	.send(csvText);
```

Use a UTF-8 BOM if Marathi or other non-ASCII names must open correctly in Excel:

```ts
const csvBody = `\uFEFF${rows.join("\r\n")}`;
```

---

## Safe Execution Sequence

### Phase 0: Baseline and contract reconciliation

Owner: one model/agent only, because these files are shared by every role.

Tasks:

1. Add nullable order ID migration.
2. Add branch order sequence migration and schema.
3. Create canonical order status constants/types.
4. Create branch service based on `user_manager_code`.
5. Replace stale `order.orderNumber` references with `order.orderId`.
6. Remove all server references to `order.trackingLink`.
7. Replace legacy statuses.
8. Restore `bun run check-types`.

Gate:

```bash
bun run check-types
```

must pass before role UI implementation proceeds.

### Phase 1: Admin targets and Advisor location/navigation

These slices can be implemented independently after Phase 0.

- Admin account target contract.
- Advisor location mapping and nav removal.

Gate:

- create advisor with daily/monthly values
- create farmer with valid Maharashtra hierarchy
- direct `/inventory` API access remains server-authorized according to RBAC; navigation removal alone is not presented as security

### Phase 2: Logistics confirmation and identity allocation

Implement:

- atomic branch order ID allocation
- atomic consignment allocation
- `created` -> `confirmed`
- updated logistics queue tabs and labels
- follow-up phase split
- tracking removal

Gate:

- simultaneous confirmations generate unique sequential IDs in the same branch
- two branches can both generate suffix `000001`
- a failed confirmation assigns neither ID nor consignment

### Phase 3: Logistics full order edit

Implement after confirmation contract stabilizes because the edit mutation must preserve assigned IDs and consignment links.

Gate:

- full edit works in `created` and `confirmed`
- edit is rejected by the server in all other states
- assigned `order.orderId` and `order_consignment` remain unchanged
- totals are server-recomputed

### Phase 4: Warehouse branch queue and direct dispatch

Implement:

- branch directory
- branch status queue
- `confirmed` -> `dispatched`
- `return_in_transit` -> `return_in_warehouse`
- remove product creation entry points
- remove tracking import

Gate:

- warehouse can switch branches
- delivered orders disappear from warehouse queues
- return transitions are mutually exclusive with delivered

### Phase 5: Shared exports

Implement the service once, then expose buttons in Admin and Warehouse.

Gate:

- identical branch/order data produces identical packing/booking rows regardless of caller role
- unauthorized branch export receives 403/404
- CSV opens in Excel/LibreOffice without shifted columns

### Phase 6: Cross-role regression and release

Follow `05-cross-role-acceptance-and-release-plan.md`.

---

## Parallel Work Ownership Rules

If multiple smaller models are used, assign disjoint write sets.

### Shared-contract worker

Owns:

- `packages/db/src/schema/order.ts`
- new migration files
- `apps/server/src/domain/order-lifecycle.ts`
- `apps/server/src/services/branches.ts`
- shared DTO/constants modules

### Admin worker

Owns:

- account schemas and account service target fields
- account create/list UI
- admin export buttons/endpoints

Must not modify the lifecycle service.

### Advisor worker

Owns:

- location mapping module
- `packages/ui/src/components/multi-form.tsx`
- farmer create schema/write path
- advisor navigation

### Logistics worker

Owns:

- orders verification routes
- logistics verification page
- order edit route/page and reusable order workspace changes

### Warehouse worker
### Logistics worker

Owns:

- orders verification routes
- logistics verification page
- order edit route/page and reusable order workspace changes
Owns:

- inventory dispatch routes
- warehouse branch queue UI
- warehouse dashboard/header links
- warehouse export buttons

### Integration owner

Owns:

- conflict resolution
- end-to-end tests
- global search for legacy terms
- final Ultracite/type checks

---

## Global Search Checklist

Before considering P1 complete, all production references should be reviewed:

```bash
rg -n \
	"weeklySalesTarget|weekly sales target|weekly_target|orderNumber|trackingLink|tracking link|picked|packed|ready to dispatch|\\brtd\\b|\\breturned\\b|user\\.managerCode|order\\.orderNumber|order\\.trackingLink" \
	apps packages \
	--glob '!**/.next/**' \
	--glob '!**/dist/**' \
	--glob '!**/migrations/meta/**'
```

Expected remaining matches:

- historical SQL migrations
- historical documentation explicitly describing old behavior
- no active route, schema, UI, or type references

---

## Definition of Done

P1 is not complete until all of the following are true:

- `bun run check-types` passes.
- `bun x ultracite check` passes, or every remaining issue is documented as pre-existing and unrelated.
- The application contains one canonical status list.
- No tracking-link UI or API remains.
- Created orders have `orderId = null`.
- Confirmation atomically assigns order ID and consignment.
- Branch order sequence is concurrency-safe.
- Logistics edits are server-blocked outside `created` and `confirmed`.
- Warehouse uses branch-first queues.
- Admin and Warehouse exports are branch-scoped.
- Farmer state/district/taluka combinations are server-validated.
- Advisor no longer sees Inventory in navigation.
- Warehouse no longer sees or can invoke product creation.
- Cross-role transition tests pass.
