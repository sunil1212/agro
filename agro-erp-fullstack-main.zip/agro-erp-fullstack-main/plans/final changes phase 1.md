17 June 2026

# Superadmin
- [2] Crop list , edit features.
- [2] Show sales stats for all branch managers (admin) in a dashboard.
- [2] Rename manager role to admin. Rename admin role to superadmin.
- [2] Only create Admins and Warehouse.

# Manager
- [1] Add daily & monthly target field for advisor. Remove weekly target.
- [2] Change advisor daily and monthly targets.
- [3] Add two new roles called Team Leader and Senior Advisor who are advisor roles with same functionality.
- [2] Better UI for sales by order status. Monthly sales breakdown by order status.
- [2] Show logistics tracking status + edit feature.
- [2] Give all advisor & logitics functionality to manager role for their own branch employees.
- [1] Export packing sheet and booking sheet for same branch.
- [3] Promote advisor to senior advisor.
- [3] Let manager assign advisor to a team leader on account creation or later.

# Team Leader
- [3] View stats of advisors. No edit. No Download.
- [3] Order edit functionality.
- [3] Team leader targets = Sum of advisor targets.

# Advisor
- [2] Add new navigation item for crop-pdfs that opens in new tab. Advisor will see list of crops and on clicking the pdf will open in new page.
- [2] Show daily , monthly sales and targets on dashboard by order status.
- [2] Show tasks only on scheduled date. Not all tasks and pending tasks of past. Add task complete button. and categorize as current tasks , pending tasks/backlogs tasks.
- [2] Task Feedback where advisor adds remarks of how task was completed to finish the task. (Text Field)
- [1] Location details of farmer onboarding add dropdowns for State -> District -> Taluka with mappings.
- [1] Remove inventory tab.
- [2] Allow addition of new crops to farmer with sowing date.

# Logistics
- [1] Change name to logistics executive.
- [1] Order ID format change with Manager (Admin) prefix code.
- [1] Assign order id and consignment id on order approval.
- [1] Add new page called order edit that hooks into advisor order page and allows logistics full edit access. Allow edit access only in created and confirmed stage.
- [1] Remove tracking link module completely.
- [1] On created show "4 Call Follow Ups" textboxes. and from then on show "4 Order status Follow Ups" with dropdown entries.
- [1] Changed "picked" to "confirmed". remove "packed" and "ready to dispatch" and "returned".

# Warehouse
- [1] Remove tracking link module completely.
- [1] Remove product creation from warehouse.
- [1] Create branchiwse order bifurcation.
- [1] Create product packing export and booking sheet export branch wise. 
- [1] Barcode pdf export ( Label sheet ).
- [1] Block return option after delivered. And block delivered if returned. Return option available only in dispatch phase.


# Last Priority
- [4] Target module with 2 pivot tables capturing historical monthly , daily targets + table caputuring daily target met or not.
- [3] Barcode Waybill PDF.
- [3] Invoice generation with barcode.


# Priority List :
## 0th priority -> Mandatory (1 day)
- [X] DB cleanup. Remove waste columns, Create new columns pivot tables.
- [X] Legacy data migration test (given samples).
- [X] Product Migration
- [X] Farmer Migration
- [X] Order Migration
- [X] If data migration test successful create temporary migration UI for imports.
- [] Create subdomain for api.growmize.org for backend.

## 1st priority -> Changes to core application flow : (12 hrs -> 2 days)
- [X] 15m - Add daily & monthly target field for advisor. Remove weekly target.
- [X] 30m - Farmer location form changes.
- [X] 05m - Remove inventory tab.
- [X] 05m - Change name to logistics executive.
- [X] 1hr - Order ID format change to start with manager/branch code.
- [X] 1hr - Assign Order ID and consignment ID on order approval.
- [X] 4hr - Allow logistics to edit orders before dispatch.
- [X] 20m - Remove tracking link module completely.
- [X] 30m - On created show "4 Call Follow Ups" textboxes. and from then on show "4 Order status Follow Ups" with dropdown entries.
- [X] 30m - Changed "picked" to "confirmed". remove "packed" and "ready to dispatch" and "returned".
- [X] 10m - Remove product creation from warehouse.
- [X] 20m - Create branchwise order bifurcation.
- [X] 2hr - Create product packing export and booking sheet export branch wise. 
- [] 1hr - Barcode pdf export ( Label sheet ).
- [X] 30m - Block return option after delivered. And block delivered if returned. Return option available only in dispatch phase.
- [X] 30m - Remove order id sku code unique constraint from order-items table.

## 2nd priority -> Current existing module enhancement : (10hrs -> 2 days)
- [X] 1hr - Crop list , edit features.
- [X] 2hr - Show sales stats for all branch managers (admin) in a dashboard.
- [X] 10m - Rename manager role to admin. Rename admin role to superadmin.
- [X] 05m - Only create Admins and Warehouse.
- [X] 15m - Change advisor daily and monthly targets.
- [X] 1hr - Better UI for sales by order status. Monthly sales breakdown by order status.
- [X] 1hr - Show logistics tracking status + edit feature.
- [X] 3hr - Give all advisor & logistics functionality to manager role for their own branch employees.
- [X] 30m - Add new navigation item for crop-pdfs that opens in new tab. Advisor will see list of crops and on clicking the pdf will open in new page.
- [X] 30m - Show daily , monthly sales and targets on dashboard by order status.
- [] 30m - Show tasks only on scheduled date. Not all tasks and pending tasks of past. Add task complete button. and categorize as current tasks , pending tasks/backlogs tasks.
- [X] 20m - Task Feedback where advisor adds remarks of how task was completed to finish the task. (Text Field)
- [X] 15m - Allow addition of new crops to farmer with sowing date.

## 3rd priority -> Additional module creation/rework : (7hrs)
- [X] 30m - Add two new roles called Team Leader and Senior Advisor who are advisor roles with same functionality.
- [X] 15m - Promote advisor to senior advisor.
- [X] 30m - Let manager assign advisor to a team leader on account creation or later.
- [] 1hr - View stats of advisors. No edit. No Download.
- [] 1hr - Order edit functionality.
- [X] 20m - Team leader targets = Sum of advisor targets.
- [] 3hr - Barcode Waybill PDF.
- [] 1hr - Invoice generation with barcode.

## 4th priority -> Future scope :
- [] Target module with 2 pivot tables capturing historical monthly , daily targets + table capturing daily target met or not.
- [] UI Polish
