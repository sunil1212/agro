"use client";

import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import {
	ChevronLeftIcon,
	ChevronRightIcon,
	MoreHorizontalIcon,
} from "lucide-react";
import type * as React from "react";
import { type Button, buttonVariants } from "./button";

function Pagination({ className, ...props }: React.ComponentProps<"nav">) {
	return (
		<nav
			aria-label="Pagination"
			className={cn("mx-auto flex w-full justify-center", className)}
			data-slot="pagination"
			{...props}
		/>
	);
}

function PaginationContent({
	className,
	...props
}: React.ComponentProps<"ul">) {
	return (
		<ul
			className={cn("flex flex-row items-center gap-1", className)}
			data-slot="pagination-content"
			{...props}
		/>
	);
}

function PaginationItem(props: React.ComponentProps<"li">) {
	return <li data-slot="pagination-item" {...props} />;
}

type PaginationLinkProps = {
	isActive?: boolean;
} & Pick<React.ComponentProps<typeof Button>, "size"> &
	React.ComponentProps<"button">;

function PaginationLink({
	className,
	isActive,
	size = "icon-sm",
	...props
}: PaginationLinkProps) {
	return (
		<button
			className={cn(
				buttonVariants({
					size,
					variant: isActive ? "outline" : "ghost",
				}),
				className
			)}
			data-active={isActive}
			data-slot="pagination-link"
			{...props}
		/>
	);
}

function PaginationPrevious(
	props: React.ComponentProps<typeof PaginationLink>
) {
	return (
		<PaginationLink aria-label="Go to previous page" size="default" {...props}>
			<ChevronLeftIcon />
			<span>Previous</span>
		</PaginationLink>
	);
}

function PaginationNext(props: React.ComponentProps<typeof PaginationLink>) {
	return (
		<PaginationLink aria-label="Go to next page" size="default" {...props}>
			<span>Next</span>
			<ChevronRightIcon />
		</PaginationLink>
	);
}

function PaginationEllipsis({
	className,
	...props
}: React.ComponentProps<"span">) {
	return (
		<span
			aria-hidden
			className={cn("flex size-9 items-center justify-center", className)}
			data-slot="pagination-ellipsis"
			{...props}
		>
			<MoreHorizontalIcon className="size-4" />
			<span className="sr-only">More pages</span>
		</span>
	);
}

export {
	Pagination,
	PaginationContent,
	PaginationEllipsis,
	PaginationItem,
	PaginationLink,
	PaginationNext,
	PaginationPrevious,
};
