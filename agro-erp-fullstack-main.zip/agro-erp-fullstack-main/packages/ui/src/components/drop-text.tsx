"use client";

import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";

export interface DropTextOption {
	label: string;
	value: string;
}

interface DropTextProps {
	className?: string;
	disabled?: boolean;
	inputId?: string;
	inputMax?: number | string;
	inputMin?: number | string;
	inputName?: string;
	inputPlaceholder?: string;
	inputStep?: number | string;
	inputType?: React.ComponentProps<"input">["type"];
	inputValue: string;
	onInputBlur?: React.ComponentProps<"input">["onBlur"];
	onInputChange: (value: string) => void;
	onSelectChange: (value: string) => void;
	options: readonly DropTextOption[];
	selectId?: string;
	selectValue: string;
}

export function DropText({
	className,
	disabled,
	inputId,
	inputMax,
	inputMin,
	inputName,
	inputPlaceholder,
	inputStep,
	inputType = "text",
	inputValue,
	onInputBlur,
	onInputChange,
	onSelectChange,
	options,
	selectId,
	selectValue,
}: DropTextProps) {
	return (
		<div
			className={cn(
				"flex h-9 w-full min-w-0 items-center overflow-hidden rounded-3xl bg-input/50 ring-1 ring-transparent transition-[box-shadow,border-color] focus-within:ring-ring/30",
				disabled && "pointer-events-none opacity-50",
				className
			)}
		>
			<Input
				className="h-9 rounded-none border-0 bg-transparent shadow-none focus-visible:ring-0"
				disabled={disabled}
				id={inputId}
				max={inputMax}
				min={inputMin}
				name={inputName}
				onBlur={onInputBlur}
				onChange={(event) => onInputChange(event.target.value)}
				placeholder={inputPlaceholder}
				step={inputStep}
				type={inputType}
				value={inputValue}
			/>
			<div className="border-border/80 border-l pl-1">
				<Select
					disabled={disabled}
					onValueChange={(value) => onSelectChange(value ?? "")}
					value={selectValue}
				>
					<SelectTrigger
						className="h-9 min-w-[88px] rounded-2xl border-0 bg-background/80 px-3 shadow-none focus-visible:ring-0"
						id={selectId}
					>
						<SelectValue />
					</SelectTrigger>
					<SelectContent align="end">
						{options.map((option) => (
							<SelectItem key={option.value} value={option.value}>
								{option.label}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
			</div>
		</div>
	);
}
