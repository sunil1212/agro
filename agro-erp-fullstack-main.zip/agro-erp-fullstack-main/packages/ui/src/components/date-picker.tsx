"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Calendar } from "@agro-erp-fullstack/ui/components/calendar";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@agro-erp-fullstack/ui/components/popover";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import * as React from "react";

interface DatePickerProps {
	"aria-invalid"?: boolean;
	className?: string;
	disabled?: boolean;
	displayFormat?: string;
	id?: string;
	onChange?: (date?: Date) => void;
	placeholder?: string;
	value?: Date | null;
}

export function DatePicker({
	"aria-invalid": ariaInvalid,
	className,
	disabled = false,
	displayFormat = "PPP",
	id,
	onChange,
	placeholder = "Pick a date",
	value,
}: DatePickerProps = {}) {
	const [uncontrolledDate, setUncontrolledDate] = React.useState<Date>();
	const [isOpen, setIsOpen] = React.useState(false);
	const [visibleMonth, setVisibleMonth] = React.useState<Date>(new Date());
	const date = value === undefined ? uncontrolledDate : (value ?? undefined);

	React.useEffect(() => {
		if (isOpen) {
			setVisibleMonth(date ?? new Date());
		}
	}, [date, isOpen]);

	const handleSelect = (nextDate?: Date) => {
		if (value === undefined) {
			setUncontrolledDate(nextDate);
		}

		onChange?.(nextDate);
		setIsOpen(false);
	};

	return (
		<Popover onOpenChange={setIsOpen} open={isOpen}>
			<PopoverTrigger
				render={
					<Button
						aria-invalid={ariaInvalid}
						className={cn(
							"w-full justify-start text-left font-normal data-[empty=true]:text-muted-foreground",
							className
						)}
						data-empty={!date}
						disabled={disabled}
						id={id}
						variant="outline"
					/>
				}
			>
				<CalendarIcon />
				{date ? format(date, displayFormat) : <span>{placeholder}</span>}
			</PopoverTrigger>
			<PopoverContent className="w-auto p-0">
				<Calendar
					mode="single"
					month={visibleMonth}
					onMonthChange={setVisibleMonth}
					onSelect={handleSelect}
					selected={date}
				/>
			</PopoverContent>
		</Popover>
	);
}
