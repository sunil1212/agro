"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { Dialog as DialogPrimitive } from "@base-ui/react/dialog";
import { XIcon } from "lucide-react";
import type * as React from "react";

function Sheet({ ...props }: DialogPrimitive.Root.Props) {
	return <DialogPrimitive.Root data-slot="sheet" {...props} />;
}

function SheetTrigger({ ...props }: DialogPrimitive.Trigger.Props) {
	return <DialogPrimitive.Trigger data-slot="sheet-trigger" {...props} />;
}

function SheetPortal({ ...props }: DialogPrimitive.Portal.Props) {
	return <DialogPrimitive.Portal data-slot="sheet-portal" {...props} />;
}

function SheetClose({ ...props }: DialogPrimitive.Close.Props) {
	return <DialogPrimitive.Close data-slot="sheet-close" {...props} />;
}

function SheetOverlay({ className, ...props }: DialogPrimitive.Backdrop.Props) {
	return (
		<DialogPrimitive.Backdrop
			className={cn(
				"data-closed:fade-out-0 data-open:fade-in-0 fixed inset-0 z-50 bg-black/28 duration-150 data-closed:animate-out data-open:animate-in supports-backdrop-filter:backdrop-blur-sm",
				className
			)}
			data-slot="sheet-overlay"
			{...props}
		/>
	);
}

interface SheetContentProps extends DialogPrimitive.Popup.Props {
	showCloseButton?: boolean;
	side?: "right" | "left";
}

function SheetContent({
	children,
	className,
	showCloseButton = true,
	side = "right",
	...props
}: SheetContentProps) {
	return (
		<SheetPortal>
			<SheetOverlay />
			<DialogPrimitive.Popup
				className={cn(
					"fixed top-0 z-50 flex h-dvh w-full max-w-[28rem] flex-col bg-card text-card-foreground shadow-2xl outline-none ring-1 ring-foreground/5 duration-200 data-closed:animate-out data-open:animate-in dark:ring-foreground/10",
					side === "right" &&
						"data-closed:slide-out-to-right-full data-open:slide-in-from-right-full right-0 rounded-l-4xl border-border border-l",
					side === "left" &&
						"data-closed:slide-out-to-left-full data-open:slide-in-from-left-full left-0 rounded-r-4xl border-border border-r",
					className
				)}
				data-slot="sheet-content"
				{...props}
			>
				{children}
				{showCloseButton ? (
					<DialogPrimitive.Close
						data-slot="sheet-close"
						render={
							<Button
								className="absolute top-5 right-5"
								size="icon-sm"
								variant="ghost"
							/>
						}
					>
						<XIcon className="size-4" />
						<span className="sr-only">Close</span>
					</DialogPrimitive.Close>
				) : null}
			</DialogPrimitive.Popup>
		</SheetPortal>
	);
}

function SheetHeader({ className, ...props }: React.ComponentProps<"div">) {
	return (
		<div
			className={cn(
				"flex flex-col gap-1.5 border-border/70 border-b px-6 py-5",
				className
			)}
			data-slot="sheet-header"
			{...props}
		/>
	);
}

function SheetFooter({ className, ...props }: React.ComponentProps<"div">) {
	return (
		<div
			className={cn("mt-auto border-border/70 border-t px-6 py-5", className)}
			data-slot="sheet-footer"
			{...props}
		/>
	);
}

function SheetTitle({ className, ...props }: DialogPrimitive.Title.Props) {
	return (
		<DialogPrimitive.Title
			className={cn("font-heading font-semibold text-lg", className)}
			data-slot="sheet-title"
			{...props}
		/>
	);
}

function SheetDescription({
	className,
	...props
}: DialogPrimitive.Description.Props) {
	return (
		<DialogPrimitive.Description
			className={cn("text-muted-foreground text-sm", className)}
			data-slot="sheet-description"
			{...props}
		/>
	);
}

export {
	Sheet,
	SheetClose,
	SheetContent,
	SheetDescription,
	SheetFooter,
	SheetHeader,
	SheetOverlay,
	SheetPortal,
	SheetTitle,
	SheetTrigger,
};
