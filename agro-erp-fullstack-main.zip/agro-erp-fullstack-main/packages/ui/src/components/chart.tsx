"use client";

import * as React from "react";
import * as RechartsPrimitive from "recharts";
import { cn } from "../lib/utils";

export interface ChartConfig {
	[key: string]: {
		color?: string;
		label?: React.ReactNode;
	};
}

const ChartContext = React.createContext<{ config: ChartConfig } | null>(null);

interface ChartPayloadItem {
	color?: string;
	dataKey?: number | string;
	name?: number | string;
	value?: number | string;
}

type ChartTooltipContentProps = React.ComponentProps<"div"> & {
	active?: boolean;
	formatter?: (
		value: ChartPayloadItem["value"],
		name: number | string,
		item: ChartPayloadItem,
		index: number,
		payload: ChartPayloadItem[]
	) => React.ReactNode;
	hideLabel?: boolean;
	label?: React.ReactNode;
	labelFormatter?: (
		label: React.ReactNode,
		payload: ChartPayloadItem[]
	) => React.ReactNode;
	payload?: ChartPayloadItem[];
};

interface ChartLegendPayloadItem {
	color?: string;
	dataKey?: number | string;
	value?: React.ReactNode;
}

function useChart() {
	const context = React.useContext(ChartContext);

	if (!context) {
		throw new Error("useChart must be used within a <ChartContainer />");
	}

	return context;
}

function ChartContainer({
	children,
	className,
	config,
	...props
}: React.ComponentProps<"div"> & {
	children: React.ComponentProps<
		typeof RechartsPrimitive.ResponsiveContainer
	>["children"];
	config: ChartConfig;
}) {
	return (
		<ChartContext.Provider value={{ config }}>
			<div
				className={cn(
					"flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-none [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-sector]:outline-none [&_.recharts-surface]:outline-none",
					className
				)}
				{...props}
			>
				<RechartsPrimitive.ResponsiveContainer>
					{children}
				</RechartsPrimitive.ResponsiveContainer>
			</div>
		</ChartContext.Provider>
	);
}

function ChartTooltipContent({
	active,
	className,
	formatter,
	hideLabel = false,
	label,
	labelFormatter,
	payload,
}: ChartTooltipContentProps) {
	const { config } = useChart();

	if (!(active && payload?.length)) {
		return null;
	}

	return (
		<div
			className={cn(
				"grid min-w-32 gap-1.5 rounded-md border bg-popover px-2.5 py-1.5 text-popover-foreground text-xs shadow-md",
				className
			)}
		>
			{hideLabel ? null : (
				<div className="font-medium">
					{labelFormatter ? labelFormatter(label, payload) : label}
				</div>
			)}
			<div className="grid gap-1.5">
				{payload.map((item) => {
					const key = `${item.dataKey ?? item.name ?? "value"}`;
					const itemConfig = config[key];

					return (
						<div
							className="flex min-w-0 items-center gap-2 text-muted-foreground"
							key={key}
						>
							<span
								className="size-2.5 shrink-0 rounded-[2px]"
								style={{
									backgroundColor: item.color ?? itemConfig?.color,
								}}
							/>
							<span className="truncate">
								{itemConfig?.label ?? item.name ?? key}
							</span>
							<span className="ml-auto font-medium font-mono text-foreground tabular-nums">
								{formatter
									? formatter(
											item.value,
											item.name ?? key,
											item,
											payload.indexOf(item),
											payload
										)
									: item.value?.toLocaleString()}
							</span>
						</div>
					);
				})}
			</div>
		</div>
	);
}

function ChartLegendContent({
	className,
	payload,
}: React.ComponentProps<"div"> & {
	payload?: ChartLegendPayloadItem[];
}) {
	const { config } = useChart();

	if (!payload?.length) {
		return null;
	}

	return (
		<div
			className={cn(
				"flex flex-wrap items-center justify-center gap-4",
				className
			)}
		>
			{payload.map((item) => {
				const key = `${item.dataKey ?? item.value}`;
				const itemConfig = config[key];

				return (
					<div
						className="flex items-center gap-1.5 font-medium text-muted-foreground text-xs"
						key={key}
					>
						<span
							className="size-2.5 shrink-0 rounded-[2px]"
							style={{ backgroundColor: item.color ?? itemConfig?.color }}
						/>
						{itemConfig?.label ?? item.value}
					</div>
				);
			})}
		</div>
	);
}

const ChartTooltip = RechartsPrimitive.Tooltip;
const ChartLegend = RechartsPrimitive.Legend;

export {
	ChartContainer,
	ChartLegend,
	ChartLegendContent,
	ChartTooltip,
	ChartTooltipContent,
};
