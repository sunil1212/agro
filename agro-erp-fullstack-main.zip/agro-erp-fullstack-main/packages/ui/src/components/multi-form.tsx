"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Card,
	CardContent,
	CardFooter,
} from "@agro-erp-fullstack/ui/components/card";
import { Checkbox } from "@agro-erp-fullstack/ui/components/checkbox";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import {
	Field,
	FieldError,
	FieldLabel,
} from "@agro-erp-fullstack/ui/components/field";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { PhoneInput } from "@agro-erp-fullstack/ui/components/phone-input";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@agro-erp-fullstack/ui/components/popover";
import {
	Select,
	SelectContent,
	SelectGroup,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import { Spinner } from "@agro-erp-fullstack/ui/components/spinner";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { CheckIcon, ChevronsUpDown, SearchIcon } from "lucide-react";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { isValidPhoneNumber } from "react-phone-number-input";
import z from "zod";

export interface MultiFormOption {
	id: string;
	name: string;
}

export interface ReferralFarmerOption {
	id: string;
	name: string;
	primaryMobileNumber: string;
}

export interface FarmerStateOption {
	code: string;
	districts: readonly {
		code: string;
		label: string;
		talukas: readonly {
			code: string;
			label: string;
		}[];
	}[];
	label: string;
}

export type CreateFarmerFormResult =
	| {
			success: true;
			farmer: {
				id: string;
				name: string;
				primaryMobileNumber: string;
			};
	  }
	| {
			success: false;
			message: string;
	  };

export interface CreateFarmerFormValues {
	addressAt: string;
	cropSowingDates: Record<string, Date>;
	district: string;
	farmSize: string;
	irrigation: string;
	name: string;
	nearbyLandmark?: string;
	pincode: string;
	post: string;
	primaryMobileNumber: string;
	referralFarmerId?: string;
	secondaryMobileNumber?: string;
	serviceByUserId: string;
	standingCropIds: string[];
	state: string;
	taluka: string;
}

export interface MultiFormProps {
	advisors: MultiFormOption[];
	crops: MultiFormOption[];
	defaultServiceByUserId: string;
	locationOptions: readonly FarmerStateOption[];
	onSubmit: (values: CreateFarmerFormValues) => Promise<CreateFarmerFormResult>;
	referralFarmers: ReferralFarmerOption[];
}

const emptyReferralValue = "__none__";

const formSchema = z
	.object({
		name: z.string().trim().min(1, "Farmer name is required"),
		primaryMobileNumber: z
			.string()
			.min(1, "Primary mobile number is required")
			.refine(isValidPhoneNumber, "Enter a valid primary mobile number"),
		secondaryMobileNumber: z
			.string()
			.optional()
			.refine(
				(value) => !value || isValidPhoneNumber(value),
				"Enter a valid secondary mobile number"
			),
		state: z.string().trim().min(1, "State is required"),
		district: z.string().trim().min(1, "District is required"),
		taluka: z.string().trim().min(1, "Taluka is required"),
		addressAt: z.string().trim().min(1, "Village is required"),
		post: z.string().trim().min(1, "Post is required"),
		pincode: z.string().regex(/^\d{6}$/, "Pincode must be 6 digits"),
		nearbyLandmark: z.string().trim().optional(),
		serviceByUserId: z.string().trim().min(1, "Service By is required"),
		referralFarmerId: z.string().trim().optional(),
		standingCropIds: z
			.array(z.string().trim().min(1))
			.min(1, "Select at least one standing crop"),
		cropSowingDates: z.record(z.string(), z.date().optional()),
		farmSize: z.string().trim().min(1, "Farm size is required"),
		irrigation: z.string().trim().min(1, "Irrigation is required"),
	})
	.superRefine((values, context) => {
		if (
			values.secondaryMobileNumber &&
			values.secondaryMobileNumber === values.primaryMobileNumber
		) {
			context.addIssue({
				code: "custom",
				message: "Secondary mobile number must be different",
				path: ["secondaryMobileNumber"],
			});
		}

		for (const cropId of values.standingCropIds) {
			if (!values.cropSowingDates[cropId]) {
				context.addIssue({
					code: "custom",
					message: "Date of sowing is required",
					path: ["cropSowingDates", cropId],
				});
			}
		}
	});

type FormSchema = z.infer<typeof formSchema>;

const formatReferralLabel = (option: ReferralFarmerOption) =>
	`${option.name} (${option.primaryMobileNumber})`;

function CropMultiSelectField({
	error,
	onChange,
	options,
	value,
}: {
	error?: { message?: string };
	onChange: (nextValue: string[]) => void;
	options: MultiFormOption[];
	value: string[];
}) {
	const [isOpen, setIsOpen] = useState(false);
	const [searchValue, setSearchValue] = useState("");

	const selectedOptions = options.filter((option) => value.includes(option.id));
	const filteredOptions = useMemo(() => {
		const normalizedSearch = searchValue.trim().toLowerCase();

		if (!normalizedSearch) {
			return options;
		}

		return options.filter((option) =>
			option.name.toLowerCase().includes(normalizedSearch)
		);
	}, [options, searchValue]);

	const toggleCrop = (cropId: string) => {
		if (value.includes(cropId)) {
			onChange(value.filter((selectedCropId) => selectedCropId !== cropId));
			return;
		}

		onChange([...value, cropId]);
	};

	return (
		<Field data-invalid={Boolean(error)}>
			<FieldLabel htmlFor="standingCropIds">Crops</FieldLabel>
			<Popover onOpenChange={setIsOpen} open={isOpen}>
				<PopoverTrigger
					render={
						<Button
							aria-invalid={Boolean(error)}
							className="w-full justify-between"
							type="button"
							variant="outline"
						>
							<span className="truncate text-left">
								{selectedOptions.length > 0
									? selectedOptions.map((option) => option.name).join(", ")
									: "Select crops"}
							</span>
							<ChevronsUpDown className="text-muted-foreground" />
						</Button>
					}
				/>
				<PopoverContent align="start" className="w-[22rem] p-3">
					<div className="space-y-3">
						<div className="relative">
							<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
							<Input
								className="pl-9"
								onChange={(event) => setSearchValue(event.target.value)}
								placeholder="Search crops"
								value={searchValue}
							/>
						</div>
						<div className="max-h-60 space-y-2 overflow-y-auto pr-1">
							{filteredOptions.length === 0 ? (
								<p className="py-3 text-center text-muted-foreground text-sm">
									No crops found.
								</p>
							) : (
								filteredOptions.map((option) => {
									const isChecked = value.includes(option.id);

									return (
										<label
											className={cn(
												"flex cursor-pointer items-center gap-3 rounded-2xl border px-3 py-2 text-sm transition",
												isChecked
													? "border-primary/40 bg-primary/5"
													: "border-border bg-background"
											)}
											htmlFor={`crop-${option.id}`}
											key={option.id}
										>
											<Checkbox
												checked={isChecked}
												id={`crop-${option.id}`}
												onCheckedChange={() => toggleCrop(option.id)}
											/>
											<span className="flex-1">{option.name}</span>
											{isChecked ? <CheckIcon className="size-4" /> : null}
										</label>
									);
								})
							)}
						</div>
					</div>
				</PopoverContent>
			</Popover>
			{error ? <FieldError errors={[error]} /> : null}
		</Field>
	);
}

const getOnlyOptionValue = <T extends { label: string }>(
	options: readonly T[]
): string => (options.length === 1 ? (options[0]?.label ?? "") : "");

const getDistrictsForState = (
	options: readonly FarmerStateOption[],
	stateLabel: string
) => {
	const state = options.find((s) => s.label === stateLabel);
	return state?.districts ?? [];
};

const getTalukasForDistrict = (
	options: readonly FarmerStateOption[],
	stateLabel: string,
	districtLabel: string
) => {
	const districts = getDistrictsForState(options, stateLabel);
	const district = districts.find((d) => d.label === districtLabel);
	return district?.talukas ?? [];
};

export function MultiForm({
	advisors,
	crops,
	defaultServiceByUserId,
	locationOptions,
	onSubmit,
	referralFarmers,
}: MultiFormProps) {
	const initialState = getOnlyOptionValue(locationOptions);

	const form = useForm<FormSchema>({
		defaultValues: {
			name: "",
			primaryMobileNumber: "",
			secondaryMobileNumber: "",
			state: initialState,
			district: "",
			taluka: "",
			addressAt: "",
			post: "",
			pincode: "",
			nearbyLandmark: "",
			serviceByUserId: defaultServiceByUserId,
			referralFarmerId: "",
			standingCropIds: [],
			cropSowingDates: {},
			farmSize: "",
			irrigation: "",
		},
		mode: "onChange",
		resolver: zodResolver(formSchema),
	});

	const standingCropIds = form.watch("standingCropIds");
	const selectedState = form.watch("state");
	const selectedDistrict = form.watch("district");

	const advisorLabelById = useMemo(
		() => new Map(advisors.map((option) => [option.id, option.name])),
		[advisors]
	);
	const referralLabelById = useMemo(
		() =>
			new Map(
				referralFarmers.map((option) => [
					option.id,
					formatReferralLabel(option),
				])
			),
		[referralFarmers]
	);

	const availableDistricts = useMemo(
		() => getDistrictsForState(locationOptions, selectedState),
		[locationOptions, selectedState]
	);

	const availableTalukas = useMemo(
		() =>
			getTalukasForDistrict(locationOptions, selectedState, selectedDistrict),
		[locationOptions, selectedState, selectedDistrict]
	);

	const handleStateChange = (nextState: string | null) => {
		form.setValue("state", nextState ?? "", { shouldValidate: true });

		const districts = getDistrictsForState(locationOptions, nextState ?? "");
		const nextDistrict = getOnlyOptionValue(districts);
		form.setValue("district", nextDistrict, { shouldValidate: true });

		const talukas = nextDistrict
			? getTalukasForDistrict(locationOptions, nextState ?? "", nextDistrict)
			: [];
		form.setValue("taluka", getOnlyOptionValue(talukas), {
			shouldValidate: true,
		});
	};

	const handleDistrictChange = (nextDistrict: string | null) => {
		form.setValue("district", nextDistrict ?? "", { shouldValidate: true });
		const talukas = getTalukasForDistrict(
			locationOptions,
			selectedState,
			nextDistrict ?? ""
		);
		form.setValue("taluka", getOnlyOptionValue(talukas), {
			shouldValidate: true,
		});
	};

	const handleSubmit = async (values: FormSchema) => {
		const cropSowingDates = Object.fromEntries(
			values.standingCropIds.map((cropId) => [
				cropId,
				values.cropSowingDates[cropId] as Date,
			])
		);

		const result = await onSubmit({
			...values,
			cropSowingDates,
			nearbyLandmark: values.nearbyLandmark || undefined,
			referralFarmerId: values.referralFarmerId || undefined,
			secondaryMobileNumber: values.secondaryMobileNumber || undefined,
		});

		if (!result.success) {
			form.setError("root", {
				message: result.message,
				type: "server",
			});
			return;
		}

		form.reset({
			name: "",
			primaryMobileNumber: "",
			secondaryMobileNumber: "",
			state: initialState,
			district: "",
			taluka: "",
			addressAt: "",
			post: "",
			pincode: "",
			nearbyLandmark: "",
			serviceByUserId: defaultServiceByUserId,
			referralFarmerId: "",
			standingCropIds: [],
			cropSowingDates: {},
			farmSize: "",
			irrigation: "",
		});
	};

	return (
		<Card className="rounded-[2rem] border-border/70 shadow-sm">
			<CardContent>
				<form
					className="space-y-6"
					id="farmer-create-form"
					onSubmit={form.handleSubmit(handleSubmit)}
				>
					<FormSection title="Basic information">
						<div className="grid gap-6 md:grid-cols-2">
							<Controller
								control={form.control}
								name="name"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="name">Name</FieldLabel>
										<Input
											{...field}
											aria-invalid={fieldState.invalid}
											id="name"
											placeholder="Farmer name"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="primaryMobileNumber"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="primaryMobileNumber">
											Mobile
										</FieldLabel>
										<PhoneInput
											{...field}
											aria-invalid={fieldState.invalid}
											id="primaryMobileNumber"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="secondaryMobileNumber"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="secondaryMobileNumber">
											Alternate mobile
										</FieldLabel>
										<PhoneInput
											{...field}
											aria-invalid={fieldState.invalid}
											id="secondaryMobileNumber"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="serviceByUserId"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="serviceByUserId">
											Service By
										</FieldLabel>
										<Select
											name={field.name}
											onValueChange={field.onChange}
											value={field.value}
										>
											<SelectTrigger
												aria-invalid={fieldState.invalid}
												className="w-full"
												id="serviceByUserId"
											>
												<SelectValue placeholder="Select advisor">
													{advisorLabelById.get(field.value) ?? ""}
												</SelectValue>
											</SelectTrigger>
											<SelectContent>
												<SelectGroup>
													{advisors.map((option) => (
														<SelectItem key={option.id} value={option.id}>
															{option.name}
														</SelectItem>
													))}
												</SelectGroup>
											</SelectContent>
										</Select>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="referralFarmerId"
								render={({ field, fieldState }) => (
									<Field
										className="md:col-span-2"
										data-invalid={fieldState.invalid}
									>
										<FieldLabel htmlFor="referralFarmerId">
											Referral Farmer
										</FieldLabel>
										<Select
											name={field.name}
											onValueChange={(value) =>
												field.onChange(
													value === emptyReferralValue ? "" : value
												)
											}
											value={field.value || emptyReferralValue}
										>
											<SelectTrigger
												aria-invalid={fieldState.invalid}
												className="w-full"
												id="referralFarmerId"
											>
												<SelectValue placeholder="Select referral farmer">
													{field.value
														? (referralLabelById.get(field.value) ?? "")
														: ""}
												</SelectValue>
											</SelectTrigger>
											<SelectContent>
												<SelectGroup>
													<SelectItem value={emptyReferralValue}>
														None
													</SelectItem>
													{referralFarmers.map((option) => (
														<SelectItem key={option.id} value={option.id}>
															{formatReferralLabel(option)}
														</SelectItem>
													))}
												</SelectGroup>
											</SelectContent>
										</Select>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
						</div>
					</FormSection>

					<FormSection title="Location details">
						<div className="grid gap-6 md:grid-cols-2">
							<Controller
								control={form.control}
								name="state"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="state">State</FieldLabel>
										<Select
											name={field.name}
											onValueChange={handleStateChange}
											value={field.value}
										>
											<SelectTrigger
												aria-invalid={fieldState.invalid}
												className="w-full"
												id="state"
											>
												<SelectValue placeholder="Select state" />
											</SelectTrigger>
											<SelectContent>
												{locationOptions.map((state) => (
													<SelectItem key={state.code} value={state.label}>
														{state.label}
													</SelectItem>
												))}
											</SelectContent>
										</Select>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="district"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="district">District</FieldLabel>
										<Select
											disabled={!selectedState}
											name={field.name}
											onValueChange={handleDistrictChange}
											value={field.value}
										>
											<SelectTrigger
												aria-invalid={fieldState.invalid}
												className="w-full"
												id="district"
											>
												<SelectValue
													placeholder={
														selectedState
															? "Select district"
															: "Select state first"
													}
												/>
											</SelectTrigger>
											<SelectContent>
												{availableDistricts.map((district) => (
													<SelectItem
														key={district.code}
														value={district.label}
													>
														{district.label}
													</SelectItem>
												))}
											</SelectContent>
										</Select>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="taluka"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="taluka">Taluka</FieldLabel>
										<Select
											disabled={!selectedDistrict}
											name={field.name}
											onValueChange={field.onChange}
											value={field.value}
										>
											<SelectTrigger
												aria-invalid={fieldState.invalid}
												className="w-full"
												id="taluka"
											>
												<SelectValue
													placeholder={
														selectedDistrict
															? "Select taluka"
															: "Select district first"
													}
												/>
											</SelectTrigger>
											<SelectContent>
												{availableTalukas.map((taluka) => (
													<SelectItem key={taluka.code} value={taluka.label}>
														{taluka.label}
													</SelectItem>
												))}
											</SelectContent>
										</Select>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="addressAt"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="addressAt">Village</FieldLabel>
										<Input
											{...field}
											aria-invalid={fieldState.invalid}
											id="addressAt"
											placeholder="Village"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="post"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="post">Post</FieldLabel>
										<Input
											{...field}
											aria-invalid={fieldState.invalid}
											id="post"
											placeholder="Post"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="pincode"
								render={({ field, fieldState }) => (
									<Field data-invalid={fieldState.invalid}>
										<FieldLabel htmlFor="pincode">Pincode</FieldLabel>
										<Input
											{...field}
											aria-invalid={fieldState.invalid}
											id="pincode"
											inputMode="numeric"
											maxLength={6}
											placeholder="Pincode"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
							<Controller
								control={form.control}
								name="nearbyLandmark"
								render={({ field, fieldState }) => (
									<Field
										className="md:col-span-2"
										data-invalid={fieldState.invalid}
									>
										<FieldLabel htmlFor="nearbyLandmark">
											Nearby Landmark
										</FieldLabel>
										<Input
											{...field}
											aria-invalid={fieldState.invalid}
											id="nearbyLandmark"
											placeholder="Nearby landmark"
										/>
										{fieldState.invalid ? (
											<FieldError errors={[fieldState.error]} />
										) : null}
									</Field>
								)}
							/>
						</div>
					</FormSection>

					<FormSection title="Farm details">
						<div className="grid gap-6 md:grid-cols-2">
							<Controller
								control={form.control}
								name="standingCropIds"
								render={({ field, fieldState }) => (
									<div className="md:col-span-2">
										<CropMultiSelectField
											error={fieldState.error}
											onChange={(nextCropIds) => {
												const currentDates = form.getValues("cropSowingDates");
												const nextCropIdSet = new Set(nextCropIds);
												const nextDates = Object.fromEntries(
													Object.entries(currentDates).filter(([cropId]) =>
														nextCropIdSet.has(cropId)
													)
												);

												field.onChange(nextCropIds);
												form.setValue("cropSowingDates", nextDates);
											}}
											options={crops}
											value={field.value}
										/>
									</div>
								)}
							/>
							<div className="space-y-4 md:col-span-2">
								{standingCropIds.map((cropId) => {
									const cropFieldState = form.getFieldState(
										`cropSowingDates.${cropId}`
									);
									const cropName =
										crops.find((option) => option.id === cropId)?.name ??
										"Crop";

									return (
										<Controller
											control={form.control}
											key={cropId}
											name="cropSowingDates"
											render={({ field }) => (
												<Field data-invalid={cropFieldState.invalid}>
													<div className="grid gap-3 md:grid-cols-[minmax(16rem,22rem)_minmax(0,28rem)] md:items-center">
														<FieldLabel
															className="mb-0"
															htmlFor={`sowing-${cropId}`}
														>
															{cropName}
														</FieldLabel>
														<div className="space-y-2">
															<DatePicker
																aria-invalid={cropFieldState.invalid}
																id={`sowing-${cropId}`}
																onChange={(date) =>
																	field.onChange({
																		...field.value,
																		[cropId]: date,
																	})
																}
																placeholder="Pick a sowing date"
																value={field.value[cropId]}
															/>
															{cropFieldState.error ? (
																<FieldError errors={[cropFieldState.error]} />
															) : null}
														</div>
													</div>
												</Field>
											)}
										/>
									);
								})}
							</div>
							<div className="grid gap-6 md:grid-cols-2">
								<Controller
									control={form.control}
									name="farmSize"
									render={({ field, fieldState }) => (
										<Field data-invalid={fieldState.invalid}>
											<FieldLabel htmlFor="farmSize">Farm size</FieldLabel>
											<Input
												{...field}
												aria-invalid={fieldState.invalid}
												id="farmSize"
												placeholder="e.g. 2 acres"
											/>
											{fieldState.invalid ? (
												<FieldError errors={[fieldState.error]} />
											) : null}
										</Field>
									)}
								/>
								<Controller
									control={form.control}
									name="irrigation"
									render={({ field, fieldState }) => (
										<Field data-invalid={fieldState.invalid}>
											<FieldLabel htmlFor="irrigation">Irrigation</FieldLabel>
											<Input
												{...field}
												aria-invalid={fieldState.invalid}
												id="irrigation"
												placeholder="e.g. drip irrigation"
											/>
											{fieldState.invalid ? (
												<FieldError errors={[fieldState.error]} />
											) : null}
										</Field>
									)}
								/>
							</div>
						</div>
					</FormSection>

					{form.formState.errors.root?.message ? (
						<div className="pt-2">
							<FieldError>{form.formState.errors.root.message}</FieldError>
						</div>
					) : null}
				</form>
			</CardContent>
			<CardFooter className="border-border/70 border-t">
				<div className="flex w-full justify-end">
					<Button
						className="min-w-36"
						disabled={form.formState.isSubmitting}
						form="farmer-create-form"
						type="submit"
					>
						{form.formState.isSubmitting ? <Spinner /> : "Create farmer"}
					</Button>
				</div>
			</CardFooter>
		</Card>
	);
}

function FormSection({
	children,
	title,
}: {
	children: ReactNode;
	title: string;
}) {
	return (
		<section className="overflow-hidden rounded-[1.75rem] border border-border/70 bg-card">
			<div className="border-border/70 border-b bg-muted/35 px-5 py-3">
				<h2 className="font-semibold text-muted-foreground text-sm uppercase tracking-[0.16em]">
					{title}
				</h2>
			</div>
			<div className="p-5 sm:p-6">{children}</div>
		</section>
	);
}
