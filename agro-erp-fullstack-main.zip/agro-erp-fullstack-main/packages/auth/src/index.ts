import { createDb } from "@agro-erp-fullstack/db";
import {
	account,
	session,
	user,
	userRoleValues,
	verification,
} from "@agro-erp-fullstack/db/schema/auth";
import { env } from "@agro-erp-fullstack/env/server";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import z from "zod";

const isSecureAuthUrl = env.BETTER_AUTH_URL.startsWith("https://");

export function createAuth() {
	const db = createDb();

	return betterAuth({
		database: drizzleAdapter(db, {
			provider: "pg",
			schema: {
				account,
				session,
				user,
				verification,
			},
		}),
		trustedOrigins: env.CORS_ORIGIN,
		emailAndPassword: {
			enabled: true,
		},
		user: {
			additionalFields: {
				role: {
					type: "string",
					required: false,
					defaultValue: "advisor",
					validator: {
						input: z.enum(userRoleValues),
					},
				},
				title: {
					type: "string",
					required: false,
				},
			},
		},
		secret: env.BETTER_AUTH_SECRET,
		baseURL: env.BETTER_AUTH_URL,
		advanced: {
			defaultCookieAttributes: {
				sameSite: isSecureAuthUrl ? "none" : "lax",
				secure: isSecureAuthUrl,
				httpOnly: true,
			},
		},
		plugins: [],
	});
}

export const auth = createAuth();
