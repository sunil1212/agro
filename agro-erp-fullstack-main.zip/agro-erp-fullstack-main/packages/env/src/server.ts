import "dotenv/config";
import { createEnv } from "@t3-oss/env-core";
import { z } from "zod";

const commaSeparatedUrlsSchema = z
	.string()
	.transform((value) =>
		value
			.split(",")
			.map((origin) => origin.trim())
			.filter(Boolean)
	)
	.pipe(z.array(z.url()).min(1));

export const env = createEnv({
	server: {
		DATABASE_URL: z.string().min(1),
		DATABASE_DRIVER: z.enum(["neon", "postgres"]).default("postgres"),
		BETTER_AUTH_SECRET: z.string().min(32),
		BETTER_AUTH_URL: z.url(),
		CORS_ORIGIN: commaSeparatedUrlsSchema,
		CROP_FILE_SAVE_PATH: z.string().min(1),
		NODE_ENV: z
			.enum(["development", "production", "test"])
			.default("development"),
	},
	runtimeEnv: process.env,
	emptyStringAsUndefined: true,
});
