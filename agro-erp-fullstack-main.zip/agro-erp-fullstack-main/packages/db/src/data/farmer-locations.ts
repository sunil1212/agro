export interface TalukaOption {
	code: string;
	label: string;
}

export interface DistrictOption {
	code: string;
	label: string;
	talukas: readonly TalukaOption[];
}

export interface StateOption {
	code: string;
	districts: readonly DistrictOption[];
	label: string;
}

/**
 * Maharashtra district and taluka mapping.
 * Districts use codes derived from labels for stable selection.
 * Labels include parenthetical renamed names exactly as supplied.
 */
export const FARMER_LOCATION_MAP = [
	{
		code: "MH",
		label: "Maharashtra",
		districts: [
			{
				code: "AHMEDNAGAR_AHILYANAGAR",
				label: "Ahmednagar (Ahilyanagar)",
				talukas: [
					{ code: "AKOLE", label: "Akole" },
					{ code: "SANGAMNER", label: "Sangamner" },
					{ code: "KOPARGAON", label: "Kopargaon" },
					{ code: "RAHATA", label: "Rahata" },
					{ code: "SHRIRAMPUR", label: "Shrirampur" },
					{ code: "NEVASA", label: "Nevasa" },
					{ code: "SHEVGAON", label: "Shevgaon" },
					{ code: "PATHARDI", label: "Pathardi" },
					{ code: "NAGAR", label: "Nagar" },
					{ code: "RAHURI", label: "Rahuri" },
					{ code: "PARNER", label: "Parner" },
					{ code: "SHRIGONDA", label: "Shrigonda" },
					{ code: "KARJAT", label: "Karjat" },
					{ code: "JAMKHED", label: "Jamkhed" },
				],
			},
			{
				code: "AKOLA",
				label: "Akola",
				talukas: [
					{ code: "AKOLA", label: "Akola" },
					{ code: "AKOT", label: "Akot" },
					{ code: "BALAPUR", label: "Balapur" },
					{ code: "BARSHITAKLI", label: "Barshitakli" },
					{ code: "MURTIJAPUR", label: "Murtijapur" },
					{ code: "PATUR", label: "Patur" },
					{ code: "TELHARA", label: "Telhara" },
				],
			},
			{
				code: "AMRAVATI",
				label: "Amravati",
				talukas: [
					{ code: "AMRAVATI", label: "Amravati" },
					{ code: "ANJANGAON_SURJI", label: "Anjangaon Surji" },
					{ code: "ACHALPUR", label: "Achalpur" },
					{ code: "CHANDUR_RAILWAY", label: "Chandur Railway" },
					{ code: "CHANDUR_BAZAR", label: "Chandur Bazar" },
					{ code: "DARYAPUR", label: "Daryapur" },
					{ code: "DHARNI", label: "Dharni" },
					{ code: "MORSHI", label: "Morshi" },
					{ code: "NANDGAON_KHANDESHWAR", label: "Nandgaon Khandeshwar" },
					{ code: "TEOSA", label: "Teosa" },
					{ code: "WARUD", label: "Warud" },
					{ code: "BHATKULI", label: "Bhatkuli" },
				],
			},
			{
				code: "BEED",
				label: "Beed",
				talukas: [
					{ code: "BEED", label: "Beed" },
					{ code: "ASHTI", label: "Ashti" },
					{ code: "GEORAI", label: "Georai" },
					{ code: "KAIJ", label: "Kaij" },
					{ code: "MAJALGAON", label: "Majalgaon" },
					{ code: "PARLI", label: "Parli" },
					{ code: "PATODA", label: "Patoda" },
					{ code: "SHIRUR_KASAR", label: "Shirur Kasar" },
					{ code: "WADWANI", label: "Wadwani" },
					{ code: "AMBAJOGAI", label: "Ambajogai" },
					{ code: "DHARUR", label: "Dharur" },
				],
			},
			{
				code: "BHANDARA",
				label: "Bhandara",
				talukas: [
					{ code: "BHANDARA", label: "Bhandara" },
					{ code: "MOHADI", label: "Mohadi" },
					{ code: "TUMSAR", label: "Tumsar" },
					{ code: "PAUNI", label: "Pauni" },
					{ code: "LAKHANDUR", label: "Lakhandur" },
					{ code: "SAKOLI", label: "Sakoli" },
					{ code: "LAKHANI", label: "Lakhani" },
				],
			},
			{
				code: "BULDHANA",
				label: "Buldhana",
				talukas: [
					{ code: "BULDHANA", label: "Buldhana" },
					{ code: "CHIKHLI", label: "Chikhli" },
					{ code: "DEULGAON_RAJA", label: "Deulgaon Raja" },
					{ code: "JALGAON_JAMOD", label: "Jalgaon Jamod" },
					{ code: "KHAMGAON", label: "Khamgaon" },
					{ code: "LONAR", label: "Lonar" },
					{ code: "MALKAPUR", label: "Malkapur" },
					{ code: "MEHKAR", label: "Mehkar" },
					{ code: "MOTALA", label: "Motala" },
					{ code: "NANDURA", label: "Nandura" },
					{ code: "SANGRAMPUR", label: "Sangrampur" },
					{ code: "SHEGAON", label: "Shegaon" },
					{ code: "SINDKHED_RAJA", label: "Sindkhed Raja" },
				],
			},
			{
				code: "CHANDRAPUR",
				label: "Chandrapur",
				talukas: [
					{ code: "BALLARPUR", label: "Ballarpur" },
					{ code: "BHADRAVATI", label: "Bhadravati" },
					{ code: "BRAHMAPURI", label: "Brahmapuri" },
					{ code: "CHANDRAPUR", label: "Chandrapur" },
					{ code: "CHIMUR", label: "Chimur" },
					{ code: "GONDPIPRI", label: "Gondpipri" },
					{ code: "JIWATI", label: "Jiwati" },
					{ code: "KORPANA", label: "Korpana" },
					{ code: "MUL", label: "Mul" },
					{ code: "NAGBHID", label: "Nagbhid" },
					{ code: "POMBHURNA", label: "Pombhurna" },
					{ code: "RAJURA", label: "Rajura" },
					{ code: "SAWALI", label: "Sawali" },
					{ code: "SINDEWAHI", label: "Sindewahi" },
					{ code: "WARORA", label: "Warora" },
				],
			},
			{
				code: "DHULE",
				label: "Dhule",
				talukas: [
					{ code: "DHULE", label: "Dhule" },
					{ code: "SAKRI", label: "Sakri" },
					{ code: "SHIRPUR", label: "Shirpur" },
					{ code: "SINDKHEDA", label: "Sindkheda" },
				],
			},
			{
				code: "GADCHIROLI",
				label: "Gadchiroli",
				talukas: [
					{ code: "AHERI", label: "Aheri" },
					{ code: "ARMORI", label: "Armori" },
					{ code: "BHAMRAGAD", label: "Bhamragad" },
					{ code: "CHAMORSHI", label: "Chamorshi" },
					{ code: "DHANORA", label: "Dhanora" },
					{ code: "ETAPALLI", label: "Etapalli" },
					{ code: "GADCHIROLI", label: "Gadchiroli" },
					{ code: "KORCHI", label: "Korchi" },
					{ code: "KURKHEDA", label: "Kurkheda" },
					{ code: "MULCHERA", label: "Mulchera" },
					{ code: "SIRONCHA", label: "Sironcha" },
					{ code: "DESAIGANJ_WADSA", label: "Desaiganj (Wadsa)" },
				],
			},
			{
				code: "GONDIA",
				label: "Gondia",
				talukas: [
					{ code: "GONDIA", label: "Gondia" },
					{ code: "AMGAON", label: "Amgaon" },
					{ code: "ARJUNI_MORGAON", label: "Arjuni Morgaon" },
					{ code: "DEORI", label: "Deori" },
					{ code: "GOREGAON", label: "Goregaon" },
					{ code: "SADAK_ARJUNI", label: "Sadak Arjuni" },
					{ code: "SALEKASA", label: "Salekasa" },
					{ code: "TIRORA", label: "Tirora" },
				],
			},
			{
				code: "HINGOLI",
				label: "Hingoli",
				talukas: [
					{ code: "HINGOLI", label: "Hingoli" },
					{ code: "AUNDHA_NAGNATH", label: "Aundha Nagnath" },
					{ code: "BASMATH", label: "Basmath" },
					{ code: "KALAMNURI", label: "Kalamnuri" },
					{ code: "SENGAON", label: "Sengaon" },
				],
			},
			{
				code: "JALGAON",
				label: "Jalgaon",
				talukas: [
					{ code: "JALGAON", label: "Jalgaon" },
					{ code: "AMALNER", label: "Amalner" },
					{ code: "BHADGAON", label: "Bhadgaon" },
					{ code: "BODWAD", label: "Bodwad" },
					{ code: "CHALISGAON", label: "Chalisgaon" },
					{ code: "CHOPDA", label: "Chopda" },
					{ code: "DHARANGAON", label: "Dharangaon" },
					{ code: "ERANDOL", label: "Erandol" },
					{ code: "JAMNER", label: "Jamner" },
					{ code: "MUKTAINAGAR", label: "Muktainagar" },
					{ code: "PACHORA", label: "Pachora" },
					{ code: "PAROLA", label: "Parola" },
					{ code: "RAVER", label: "Raver" },
					{ code: "YAWAL", label: "Yawal" },
					{ code: "BHUSAWAL", label: "Bhusawal" },
				],
			},
			{
				code: "JALNA",
				label: "Jalna",
				talukas: [
					{ code: "JALNA", label: "Jalna" },
					{ code: "AMBAD", label: "Ambad" },
					{ code: "BADNAPUR", label: "Badnapur" },
					{ code: "BHOKARDAN", label: "Bhokardan" },
					{ code: "GHANSAWANGI", label: "Ghansawangi" },
					{ code: "JAFRABAD", label: "Jafrabad" },
					{ code: "MANTHA", label: "Mantha" },
					{ code: "PARTUR", label: "Partur" },
				],
			},
			{
				code: "KOLHAPUR",
				label: "Kolhapur",
				talukas: [
					{ code: "AJRA", label: "Ajra" },
					{ code: "BHUDARGAD", label: "Bhudargad" },
					{ code: "CHANDGAD", label: "Chandgad" },
					{ code: "GADHINGLAJ", label: "Gadhinglaj" },
					{ code: "GAGANBAWADA", label: "Gaganbawada" },
					{ code: "HATKANANGALE", label: "Hatkanangale" },
					{ code: "KAGAL", label: "Kagal" },
					{ code: "KARVIR", label: "Karvir" },
					{ code: "PANHALA", label: "Panhala" },
					{ code: "RADHANAGARI", label: "Radhanagari" },
					{ code: "SHAHUWADI", label: "Shahuwadi" },
					{ code: "SHIROL", label: "Shirol" },
				],
			},
			{
				code: "LATUR",
				label: "Latur",
				talukas: [
					{ code: "LATUR", label: "Latur" },
					{ code: "AHMEDPUR", label: "Ahmedpur" },
					{ code: "AUSA", label: "Ausa" },
					{ code: "CHAKUR", label: "Chakur" },
					{ code: "DEONI", label: "Deoni" },
					{ code: "JALKOT", label: "Jalkot" },
					{ code: "NILANGA", label: "Nilanga" },
					{ code: "RENAPUR", label: "Renapur" },
					{ code: "SHIRUR_ANANTPAL", label: "Shirur Anantpal" },
					{ code: "UDGIR", label: "Udgir" },
				],
			},
			{
				code: "MUMBAI_CITY",
				label: "Mumbai City",
				talukas: [{ code: "MUMBAI_CITY", label: "Mumbai City" }],
			},
			{
				code: "MUMBAI_SUBURBAN",
				label: "Mumbai Suburban",
				talukas: [
					{ code: "ANDHERI", label: "Andheri" },
					{ code: "BORIVALI", label: "Borivali" },
					{ code: "KURLA", label: "Kurla" },
				],
			},
			{
				code: "NAGPUR",
				label: "Nagpur",
				talukas: [
					{ code: "NAGPUR_URBAN", label: "Nagpur Urban" },
					{ code: "NAGPUR_RURAL", label: "Nagpur Rural" },
					{ code: "HINGNA", label: "Hingna" },
					{ code: "KAMPTEE", label: "Kamptee" },
					{ code: "KATOL", label: "Katol" },
					{ code: "KALMESHWAR", label: "Kalmeshwar" },
					{ code: "KUHI", label: "Kuhi" },
					{ code: "MAUDA", label: "Mauda" },
					{ code: "NARKHED", label: "Narkhed" },
					{ code: "PARSEONI", label: "Parseoni" },
					{ code: "RAMTEK", label: "Ramtek" },
					{ code: "SAVNER", label: "Savner" },
					{ code: "UMRED", label: "Umred" },
					{ code: "BHIWAPUR", label: "Bhiwapur" },
				],
			},
			{
				code: "NANDED",
				label: "Nanded",
				talukas: [
					{ code: "NANDED", label: "Nanded" },
					{ code: "ARDHAPUR", label: "Ardhapur" },
					{ code: "BHOKAR", label: "Bhokar" },
					{ code: "BILOLI", label: "Biloli" },
					{ code: "DEGLUR", label: "Deglur" },
					{ code: "DHARMABAD", label: "Dharmabad" },
					{ code: "HADGAON", label: "Hadgaon" },
					{ code: "HIMAYATNAGAR", label: "Himayatnagar" },
					{ code: "KANDHAR", label: "Kandhar" },
					{ code: "KINWAT", label: "Kinwat" },
					{ code: "LOHA", label: "Loha" },
					{ code: "MAHUR", label: "Mahur" },
					{ code: "MUDKHED", label: "Mudkhed" },
					{ code: "MUKHED", label: "Mukhed" },
					{ code: "NAIGAON", label: "Naigaon" },
					{ code: "UMRI", label: "Umri" },
				],
			},
			{
				code: "NANDURBAR",
				label: "Nandurbar",
				talukas: [
					{ code: "NANDURBAR", label: "Nandurbar" },
					{ code: "AKKALKUWA", label: "Akkalkuwa" },
					{ code: "AKRANI", label: "Akrani" },
					{ code: "SHAHADA", label: "Shahada" },
					{ code: "TALODA", label: "Taloda" },
					{ code: "NAVAPUR", label: "Navapur" },
				],
			},
			{
				code: "NASHIK",
				label: "Nashik",
				talukas: [
					{ code: "NASHIK", label: "Nashik" },
					{ code: "BAGLAN", label: "Baglan" },
					{ code: "CHANDWAD", label: "Chandwad" },
					{ code: "DEOLA", label: "Deola" },
					{ code: "DINDORI", label: "Dindori" },
					{ code: "IGATPURI", label: "Igatpuri" },
					{ code: "KALWAN", label: "Kalwan" },
					{ code: "MALEGAON", label: "Malegaon" },
					{ code: "NANDGAON", label: "Nandgaon" },
					{ code: "NIPHAD", label: "Niphad" },
					{ code: "PETH", label: "Peth" },
					{ code: "SINNAR", label: "Sinnar" },
					{ code: "SURGANA", label: "Surgana" },
					{ code: "TRIMBAKESHWAR", label: "Trimbakeshwar" },
					{ code: "YEOLA", label: "Yeola" },
				],
			},
			{
				code: "DHARASHIV_OSMANABAD",
				label: "Dharashiv (Osmanabad)",
				talukas: [
					{ code: "DHARASHIV", label: "Dharashiv" },
					{ code: "BHOOM", label: "Bhoom" },
					{ code: "KALAMB", label: "Kalamb" },
					{ code: "LOHARA", label: "Lohara" },
					{ code: "OMERGA", label: "Omerga" },
					{ code: "PARANDA", label: "Paranda" },
					{ code: "TULJAPUR", label: "Tuljapur" },
					{ code: "WASHI", label: "Washi" },
				],
			},
			{
				code: "PALGHAR",
				label: "Palghar",
				talukas: [
					{ code: "PALGHAR", label: "Palghar" },
					{ code: "DAHANU", label: "Dahanu" },
					{ code: "TALASARI", label: "Talasari" },
					{ code: "VIKRAMGAD", label: "Vikramgad" },
					{ code: "WADA", label: "Wada" },
					{ code: "VASAI", label: "Vasai" },
					{ code: "JAWHAR", label: "Jawhar" },
					{ code: "MOKHADA", label: "Mokhada" },
				],
			},
			{
				code: "PARBHANI",
				label: "Parbhani",
				talukas: [
					{ code: "PARBHANI", label: "Parbhani" },
					{ code: "GANGAKHED", label: "Gangakhed" },
					{ code: "JINTUR", label: "Jintur" },
					{ code: "MANWATH", label: "Manwath" },
					{ code: "PALAM", label: "Palam" },
					{ code: "PATHRI", label: "Pathri" },
					{ code: "PURNA", label: "Purna" },
					{ code: "SELU", label: "Selu" },
					{ code: "SONPETH", label: "Sonpeth" },
				],
			},
			{
				code: "PUNE",
				label: "Pune",
				talukas: [
					{ code: "AMBEGAON", label: "Ambegaon" },
					{ code: "BARAMATI", label: "Baramati" },
					{ code: "BHOR", label: "Bhor" },
					{ code: "DAUND", label: "Daund" },
					{ code: "HAVELI", label: "Haveli" },
					{ code: "INDAPUR", label: "Indapur" },
					{ code: "JUNNAR", label: "Junnar" },
					{ code: "KHED", label: "Khed" },
					{ code: "MAVAL", label: "Maval" },
					{ code: "MULSHI", label: "Mulshi" },
					{ code: "PUNE_CITY", label: "Pune City" },
					{ code: "PURANDAR", label: "Purandar" },
					{ code: "SHIRUR", label: "Shirur" },
					{ code: "VELHE", label: "Velhe" },
				],
			},
			{
				code: "RAIGAD",
				label: "Raigad",
				talukas: [
					{ code: "ALIBAG", label: "Alibag" },
					{ code: "KARJAT", label: "Karjat" },
					{ code: "KHALAPUR", label: "Khalapur" },
					{ code: "MAHAD", label: "Mahad" },
					{ code: "MANGAON", label: "Mangaon" },
					{ code: "MHASALA", label: "Mhasala" },
					{ code: "MURUD", label: "Murud" },
					{ code: "PANVEL", label: "Panvel" },
					{ code: "PEN", label: "Pen" },
					{ code: "POLADPUR", label: "Poladpur" },
					{ code: "ROHA", label: "Roha" },
					{ code: "SHRIVARDHAN", label: "Shrivardhan" },
					{ code: "SUDHAGAD", label: "Sudhagad" },
					{ code: "TALA", label: "Tala" },
					{ code: "URAN", label: "Uran" },
				],
			},
			{
				code: "RATNAGIRI",
				label: "Ratnagiri",
				talukas: [
					{ code: "RATNAGIRI", label: "Ratnagiri" },
					{ code: "CHIPLUN", label: "Chiplun" },
					{ code: "DAPOLI", label: "Dapoli" },
					{ code: "GUHAGAR", label: "Guhagar" },
					{ code: "KHED", label: "Khed" },
					{ code: "LANJA", label: "Lanja" },
					{ code: "MANDANGAD", label: "Mandangad" },
					{ code: "RAJAPUR", label: "Rajapur" },
					{ code: "SANGAMESHWAR", label: "Sangameshwar" },
				],
			},
			{
				code: "SANGLI",
				label: "Sangli",
				talukas: [
					{ code: "ATPADI", label: "Atpadi" },
					{ code: "JAT", label: "Jat" },
					{ code: "KADEGAON", label: "Kadegaon" },
					{ code: "KAVATHE_MAHANKAL", label: "Kavathe Mahankal" },
					{ code: "KHANAPUR", label: "Khanapur" },
					{ code: "MIRAJ", label: "Miraj" },
					{ code: "PALUS", label: "Palus" },
					{ code: "SHIRALA", label: "Shirala" },
					{ code: "TASGAON", label: "Tasgaon" },
					{ code: "WALWA", label: "Walwa" },
				],
			},
			{
				code: "SATARA",
				label: "Satara",
				talukas: [
					{ code: "SATARA", label: "Satara" },
					{ code: "KARAD", label: "Karad" },
					{ code: "KOREGAON", label: "Koregaon" },
					{ code: "KHATAV", label: "Khatav" },
					{ code: "MAHABALESHWAR", label: "Mahabaleshwar" },
					{ code: "MAN", label: "Man" },
					{ code: "PATAN", label: "Patan" },
					{ code: "PHALTAN", label: "Phaltan" },
					{ code: "JAOLI", label: "Jaoli" },
					{ code: "WAI", label: "Wai" },
					{ code: "KHANDALA", label: "Khandala" },
				],
			},
			{
				code: "SINDHUDURG",
				label: "Sindhudurg",
				talukas: [
					{ code: "DEVGAD", label: "Devgad" },
					{ code: "DODAMARG", label: "Dodamarg" },
					{ code: "KANKAVLI", label: "Kankavli" },
					{ code: "KUDAL", label: "Kudal" },
					{ code: "MALVAN", label: "Malvan" },
					{ code: "SAWANTWADI", label: "Sawantwadi" },
					{ code: "VAIBHAVWADI", label: "Vaibhavwadi" },
					{ code: "VENGRURLA", label: "Vengurla" },
				],
			},
			{
				code: "SOLAPUR",
				label: "Solapur",
				talukas: [
					{ code: "AKKALKOT", label: "Akkalkot" },
					{ code: "BARSHI", label: "Barshi" },
					{ code: "KARMALA", label: "Karmala" },
					{ code: "MADHA", label: "Madha" },
					{ code: "MALSHIRAS", label: "Malshiras" },
					{ code: "MANGALWEDHA", label: "Mangalwedha" },
					{ code: "MOHOL", label: "Mohol" },
					{ code: "NORTH_SOLAPUR", label: "North Solapur" },
					{ code: "PANDHARPUR", label: "Pandharpur" },
					{ code: "SANGOLA", label: "Sangola" },
					{ code: "SOUTH_SOLAPUR", label: "South Solapur" },
				],
			},
			{
				code: "THANE",
				label: "Thane",
				talukas: [
					{ code: "THANE", label: "Thane" },
					{ code: "BHIWANDI", label: "Bhiwandi" },
					{ code: "KALYAN", label: "Kalyan" },
					{ code: "MURBAD", label: "Murbad" },
					{ code: "SHAHAPUR", label: "Shahapur" },
					{ code: "ULHASNAGAR", label: "Ulhasnagar" },
					{ code: "AMBARNATH", label: "Ambarnath" },
				],
			},
			{
				code: "WARDHA",
				label: "Wardha",
				talukas: [
					{ code: "WARDHA", label: "Wardha" },
					{ code: "ARVI", label: "Arvi" },
					{ code: "ASHTI", label: "Ashti" },
					{ code: "DEOLI", label: "Deoli" },
					{ code: "HINGANGHAT", label: "Hinganghat" },
					{ code: "KARANJA", label: "Karanja" },
					{ code: "SAMUDRAPUR", label: "Samudrapur" },
					{ code: "SELOO", label: "Seloo" },
				],
			},
			{
				code: "WASHIM",
				label: "Washim",
				talukas: [
					{ code: "WASHIM", label: "Washim" },
					{ code: "KARANJA", label: "Karanja" },
					{ code: "MALEGAON", label: "Malegaon" },
					{ code: "MANGRULPIR", label: "Mangrulpir" },
					{ code: "MANORA", label: "Manora" },
					{ code: "RISOD", label: "Risod" },
				],
			},
			{
				code: "YAVATMAL",
				label: "Yavatmal",
				talukas: [
					{ code: "YAVATMAL", label: "Yavatmal" },
					{ code: "ARNI", label: "Arni" },
					{ code: "BABULGAON", label: "Babulgaon" },
					{ code: "DARWHA", label: "Darwha" },
					{ code: "DIGRAS", label: "Digras" },
					{ code: "GHATANJI", label: "Ghatanji" },
					{ code: "KALAMB", label: "Kalamb" },
					{ code: "KELAPUR", label: "Kelapur" },
					{ code: "MAHAGAON", label: "Mahagaon" },
					{ code: "MAREGAON", label: "Maregaon" },
					{ code: "NER", label: "Ner" },
					{ code: "PANDHARKAWADA", label: "Pandharkawada" },
					{ code: "PUSAD", label: "Pusad" },
					{ code: "RALEGAON", label: "Ralegaon" },
					{ code: "UMARKHED", label: "Umarkhed" },
					{ code: "WANI", label: "Wani" },
					{ code: "ZARI_JAMNI", label: "Zari Jamni" },
				],
			},
			{
				code: "CHHATRAPATI_SAMBHAJINAGAR_AURANGABAD",
				label: "Chhatrapati Sambhajinagar (Aurangabad)",
				talukas: [
					{ code: "AURANGABAD", label: "Aurangabad" },
					{ code: "GANGAPUR", label: "Gangapur" },
					{ code: "KANNAD", label: "Kannad" },
					{ code: "KHULDABAD", label: "Khuldabad" },
					{ code: "PAITHAN", label: "Paithan" },
					{ code: "PHULAMBRI", label: "Phulambri" },
					{ code: "SILLOD", label: "Sillod" },
					{ code: "SOEGAON", label: "Soegaon" },
					{ code: "VAIJAPUR", label: "Vaijapur" },
				],
			},
		],
	},
] as const satisfies readonly StateOption[];

export const isValidFarmerLocation = (input: {
	district: string;
	state: string;
	taluka: string;
}): boolean => {
	const state = FARMER_LOCATION_MAP.find(
		(option) => option.label === input.state
	);
	const district = state?.districts.find(
		(option) => option.label === input.district
	);

	return Boolean(
		district?.talukas.some((option) => option.label === input.taluka)
	);
};

/**
 * Validate the location map integrity at module load time (dev only).
 */
if (typeof process !== "undefined" && process.env.NODE_ENV !== "production") {
	for (const state of FARMER_LOCATION_MAP) {
		const districtCodes = new Set<string>();
		for (const district of state.districts) {
			if (districtCodes.has(district.code)) {
				throw new Error(
					`Duplicate district code: ${district.code} in state ${state.code}`
				);
			}
			districtCodes.add(district.code);

			const talukaCodes = new Set<string>();
			for (const taluka of district.talukas) {
				if (talukaCodes.has(taluka.code)) {
					throw new Error(
						`Duplicate taluka code: ${taluka.code} in district ${district.code}`
					);
				}
				talukaCodes.add(taluka.code);
			}
		}
	}
}
