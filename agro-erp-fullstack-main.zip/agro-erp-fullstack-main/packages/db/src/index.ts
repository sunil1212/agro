import { env } from "@agro-erp-fullstack/env/server";
import { Pool as NeonPool } from "@neondatabase/serverless";
import { drizzle as drizzleNeon } from "drizzle-orm/neon-serverless";
import {
	drizzle as drizzlePostgres,
	type NodePgDatabase,
} from "drizzle-orm/node-postgres";
import { Pool as PostgresPool } from "pg";

import * as schema from "./schema";

type Database = NodePgDatabase<typeof schema>;

export function createDb() {
	if (env.DATABASE_DRIVER === "neon") {
		const pool = new NeonPool({ connectionString: env.DATABASE_URL });
		return drizzleNeon(pool, { schema }) as unknown as Database;
	}

	const pool = new PostgresPool({ connectionString: env.DATABASE_URL });
	return drizzlePostgres(pool, { schema });
}

export const db = createDb();
