ALTER TABLE "user" ADD COLUMN "manager_code" text;
CREATE UNIQUE INDEX "user_manager_code_uidx" ON "user" USING btree ("manager_code") WHERE "role" = 'manager';
