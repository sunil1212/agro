ALTER TABLE "irrigation_type" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "land_type" DISABLE ROW LEVEL SECURITY;--> statement-breakpoint
DROP TABLE "irrigation_type" CASCADE;--> statement-breakpoint
DROP TABLE "land_type" CASCADE;--> statement-breakpoint
ALTER TABLE "farmer" RENAME COLUMN "land_type_id" TO "farm_size";--> statement-breakpoint
ALTER TABLE "farmer" RENAME COLUMN "irrigation_type_id" TO "irrigation";--> statement-breakpoint
ALTER TABLE "farmer" DROP CONSTRAINT "farmer_irrigation_type_id_irrigation_type_id_fk";
--> statement-breakpoint
ALTER TABLE "farmer" DROP CONSTRAINT "farmer_land_type_id_land_type_id_fk";
--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DEFAULT 'advisor'::text;--> statement-breakpoint
DROP TYPE "public"."user_roles";--> statement-breakpoint
CREATE TYPE "public"."user_roles" AS ENUM('manager', 'advisor', 'warehouse', 'logistics');--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DEFAULT 'advisor'::"public"."user_roles";--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DATA TYPE "public"."user_roles" USING "role"::"public"."user_roles";--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "transaction_utr" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "transaction_screenshot_base64" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "cancellation_undone_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "cancellation_undone_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_primary_mobile_number" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_secondary_mobile_number" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_address_at" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_nearby_landmark" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_post" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_taluka" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_district" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_pincode" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_updated_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "pending_farmer_updated_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "tracking_link" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_1_text" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_1_status" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_1_updated_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_1_updated_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_1_updated_by_role" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_2_text" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_2_status" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_2_updated_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_2_updated_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_2_updated_by_role" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_3_text" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_3_status" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_3_updated_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_3_updated_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_3_updated_by_role" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_4_text" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_4_status" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_4_updated_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_4_updated_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "follow_up_4_updated_by_role" text;--> statement-breakpoint
ALTER TABLE "order_item" ADD COLUMN "unit_price_per_unit" numeric(12, 2) NOT NULL;--> statement-breakpoint
ALTER TABLE "order_item" ADD COLUMN "selling_price_per_unit" numeric(12, 2) NOT NULL;--> statement-breakpoint
ALTER TABLE "order_item" ADD COLUMN "line_total_amount" numeric(12, 2) NOT NULL;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_cancellation_undone_by_user_id_user_id_fk" FOREIGN KEY ("cancellation_undone_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_pending_farmer_updated_by_user_id_user_id_fk" FOREIGN KEY ("pending_farmer_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_follow_up_1_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_1_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_follow_up_2_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_2_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_follow_up_3_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_3_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_follow_up_4_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_4_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;