DROP INDEX IF EXISTS "user_manager_code_manager_code_uidx";

CREATE INDEX IF NOT EXISTS "user_manager_code_manager_code_idx"
	ON "user_manager_code" ("manager_code");

INSERT INTO "user_manager_code" ("user_id", "manager_code")
SELECT staff."id", creator_code."manager_code"
FROM "user" staff
INNER JOIN "user_manager_code" creator_code
	ON creator_code."user_id" = staff."created_by_user_id"
WHERE staff."role" IN ('advisor', 'logistics', 'warehouse', 'team_leader')
ON CONFLICT ("user_id")
DO NOTHING;
