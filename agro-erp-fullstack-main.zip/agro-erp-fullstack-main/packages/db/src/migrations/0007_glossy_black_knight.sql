ALTER TABLE "product" ADD COLUMN "category_code" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "product_code" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "packing_code" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "package_quantity" numeric(12, 3);--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "package_unit" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "packaging_type" text;--> statement-breakpoint
CREATE INDEX "product_category_code_idx" ON "product" USING btree ("category_code");
