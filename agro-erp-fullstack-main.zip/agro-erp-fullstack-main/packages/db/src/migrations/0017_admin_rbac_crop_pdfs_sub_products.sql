ALTER TABLE "crop" ADD COLUMN "pdf_file_name" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_original_name" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_mime_type" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_size_bytes" integer;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_uploaded_at" timestamp;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN IF NOT EXISTS "is_active" boolean DEFAULT true NOT NULL;--> statement-breakpoint
CREATE TABLE "sub_product" (
	"id" text PRIMARY KEY NOT NULL,
	"product_id" text NOT NULL,
	"packing_code" text,
	"package_quantity" numeric(12, 3),
	"package_unit" text,
	"packaging_type" text,
	"sku_code" text,
	"quantity" integer NOT NULL,
	"reserved_quantity" integer DEFAULT 0 NOT NULL,
	"minimum_stock_level" integer DEFAULT 0 NOT NULL,
	"batch_number" text,
	"expiry_date" date,
	"warehouse_location" text,
	"cost_per_unit" numeric(12, 2) NOT NULL,
	"total_amount" numeric(12, 2) NOT NULL,
	"discount" numeric(12, 2) NOT NULL,
	"offer_price" numeric(12, 2) NOT NULL,
	"points_added" integer NOT NULL,
	"points_reason" text NOT NULL,
	"additional_notes" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"last_inventory_updated_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);--> statement-breakpoint
INSERT INTO "sub_product" (
	"id",
	"product_id",
	"packing_code",
	"package_quantity",
	"package_unit",
	"packaging_type",
	"sku_code",
	"quantity",
	"reserved_quantity",
	"minimum_stock_level",
	"batch_number",
	"expiry_date",
	"warehouse_location",
	"cost_per_unit",
	"total_amount",
	"discount",
	"offer_price",
	"points_added",
	"points_reason",
	"additional_notes",
	"is_active",
	"last_inventory_updated_at",
	"created_at",
	"updated_at"
)
SELECT
	"id",
	"id",
	"packing_code",
	"package_quantity",
	"package_unit",
	"packaging_type",
	"sku_code",
	"quantity",
	"reserved_quantity",
	"minimum_stock_level",
	"batch_number",
	"expiry_date",
	"warehouse_location",
	"cost_per_unit",
	"total_amount",
	"discount",
	"offer_price",
	"points_added",
	"points_reason",
	"additional_notes",
	true,
	"last_inventory_updated_at",
	"created_at",
	"updated_at"
FROM "product";--> statement-breakpoint
ALTER TABLE "sub_product" ADD CONSTRAINT "sub_product_product_id_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_alert" DROP CONSTRAINT IF EXISTS "inventory_alert_product_id_product_id_fk";--> statement-breakpoint
ALTER TABLE "inventory_event" DROP CONSTRAINT IF EXISTS "inventory_event_product_id_product_id_fk";--> statement-breakpoint
ALTER TABLE "order_item" DROP CONSTRAINT IF EXISTS "order_item_product_id_product_id_fk";--> statement-breakpoint
ALTER TABLE "inventory_alert" ADD CONSTRAINT "inventory_alert_product_id_sub_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."sub_product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_event" ADD CONSTRAINT "inventory_event_product_id_sub_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."sub_product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_item" ADD CONSTRAINT "order_item_product_id_sub_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."sub_product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "product_product_code_idx" ON "product" USING btree ("product_code");--> statement-breakpoint
CREATE INDEX "sub_product_product_id_idx" ON "sub_product" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "sub_product_sku_code_idx" ON "sub_product" USING btree ("sku_code");--> statement-breakpoint
CREATE UNIQUE INDEX "sub_product_sku_code_uidx" ON "sub_product" USING btree ("sku_code");
