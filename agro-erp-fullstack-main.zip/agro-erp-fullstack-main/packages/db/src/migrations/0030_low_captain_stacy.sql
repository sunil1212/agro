CREATE TABLE "team_leader_advisor" (
	"team_leader_id" text NOT NULL,
	"advisor_id" text PRIMARY KEY NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_manager_code" (
	"user_id" text PRIMARY KEY NOT NULL,
	"manager_code" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_sales_target" (
	"user_id" text PRIMARY KEY NOT NULL,
	"daily_sales_target" numeric(12, 2),
	"monthly_sales_target" numeric(12, 2),
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "branch_order_sequence" (
	"admin_user_id" text PRIMARY KEY NOT NULL,
	"last_value" integer DEFAULT 0 NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "consignment" (
	"id" text PRIMARY KEY NOT NULL,
	"consignment_number" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"added_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_consignment" (
	"id" text PRIMARY KEY NOT NULL,
	"order_id" text NOT NULL,
	"consignment_id" text NOT NULL,
	"order_number" text NOT NULL,
	"consignment_number" text NOT NULL,
	"assigned_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_discount" (
	"order_id" text PRIMARY KEY NOT NULL,
	"promo_discount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"points_used" integer DEFAULT 0 NOT NULL,
	"points_discount_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"coupon_discount_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"total_discount_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"cashback_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"coupon_code" text,
	"coupon_id" text
);
--> statement-breakpoint
CREATE TABLE "order_payment_transaction" (
	"order_id" text PRIMARY KEY NOT NULL,
	"transaction_utr" text,
	"transaction_screenshot_base64" text
);
--> statement-breakpoint
CREATE TABLE "order_pending_farmer_update" (
	"order_id" text PRIMARY KEY NOT NULL,
	"primary_mobile_number" text,
	"secondary_mobile_number" text,
	"address_at" text,
	"nearby_landmark" text,
	"post" text,
	"taluka" text,
	"district" text,
	"pincode" text,
	"updated_by_user_id" text,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "post_order_follow_up" (
	"order_id" text PRIMARY KEY NOT NULL,
	"follow_up_1_text" text,
	"follow_up_1_updated_at" timestamp,
	"follow_up_1_updated_by_user_id" text,
	"follow_up_2_text" text,
	"follow_up_2_updated_at" timestamp,
	"follow_up_2_updated_by_user_id" text,
	"follow_up_3_text" text,
	"follow_up_3_updated_at" timestamp,
	"follow_up_3_updated_by_user_id" text,
	"follow_up_4_text" text,
	"follow_up_4_updated_at" timestamp,
	"follow_up_4_updated_by_user_id" text
);
--> statement-breakpoint
CREATE TABLE "pre_order_confirmation_follow_up" (
	"order_id" text PRIMARY KEY NOT NULL,
	"follow_up_1_text" text,
	"follow_up_1_updated_at" timestamp,
	"follow_up_1_updated_by_user_id" text,
	"follow_up_2_text" text,
	"follow_up_2_updated_at" timestamp,
	"follow_up_2_updated_by_user_id" text,
	"follow_up_3_text" text,
	"follow_up_3_updated_at" timestamp,
	"follow_up_3_updated_by_user_id" text,
	"follow_up_4_text" text,
	"follow_up_4_updated_at" timestamp,
	"follow_up_4_updated_by_user_id" text
);
--> statement-breakpoint
CREATE TABLE "product_inventory" (
	"product_id" text PRIMARY KEY NOT NULL,
	"points_added" integer NOT NULL,
	"points_reason" text NOT NULL,
	"quantity" integer NOT NULL,
	"reserved_quantity" integer DEFAULT 0 NOT NULL,
	"minimum_stock_level" integer DEFAULT 0 NOT NULL,
	"batch_number" text,
	"expiry_date" date,
	"warehouse_location" text,
	"last_inventory_updated_at" timestamp
);
--> statement-breakpoint
ALTER TABLE "order" RENAME COLUMN "order_number" TO "order_id";--> statement-breakpoint
ALTER TABLE "order_item" RENAME COLUMN "product_id" TO "product_sku";--> statement-breakpoint
ALTER TABLE "product" RENAME COLUMN "additional_notes" TO "product_notes";--> statement-breakpoint
ALTER TABLE "order" DROP CONSTRAINT "order_coupon_id_coupon_id_fk";
--> statement-breakpoint
ALTER TABLE "order" DROP CONSTRAINT "order_pending_farmer_updated_by_user_id_user_id_fk";
--> statement-breakpoint
ALTER TABLE "order" DROP CONSTRAINT "order_follow_up_1_updated_by_user_id_user_id_fk";
--> statement-breakpoint
ALTER TABLE "order" DROP CONSTRAINT "order_follow_up_2_updated_by_user_id_user_id_fk";
--> statement-breakpoint
ALTER TABLE "order" DROP CONSTRAINT "order_follow_up_3_updated_by_user_id_user_id_fk";
--> statement-breakpoint
ALTER TABLE "order" DROP CONSTRAINT "order_follow_up_4_updated_by_user_id_user_id_fk";
--> statement-breakpoint
ALTER TABLE "order_item" DROP CONSTRAINT "order_item_product_id_product_id_fk";
--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DEFAULT 'advisor'::text;--> statement-breakpoint
DROP TYPE "public"."user_roles";--> statement-breakpoint
CREATE TYPE "public"."user_roles" AS ENUM('superadmin', 'admin', 'team_leader', 'advisor', 'logistics', 'warehouse');--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DEFAULT 'advisor'::"public"."user_roles";--> statement-breakpoint
ALTER TABLE "user" ALTER COLUMN "role" SET DATA TYPE "public"."user_roles" USING "role"::"public"."user_roles";--> statement-breakpoint
ALTER TABLE "order" ALTER COLUMN "status" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "order" ALTER COLUMN "status" SET DEFAULT 'created'::text;--> statement-breakpoint
DROP TYPE "public"."order_status";--> statement-breakpoint
CREATE TYPE "public"."order_status" AS ENUM('created', 'confirmed', 'dispatched', 'delivered', 'return_in_transit', 'return_in_warehouse', 'cancelled');--> statement-breakpoint
ALTER TABLE "order" ALTER COLUMN "status" SET DEFAULT 'created'::"public"."order_status";--> statement-breakpoint
ALTER TABLE "order" ALTER COLUMN "status" SET DATA TYPE "public"."order_status" USING "status"::"public"."order_status";--> statement-breakpoint
DROP INDEX "farmer_crop_farmer_id_crop_id_uidx";--> statement-breakpoint
DROP INDEX "order_order_number_uidx";--> statement-breakpoint
DROP INDEX "order_item_product_id_idx";--> statement-breakpoint
DROP INDEX "product_sku_code_uidx";--> statement-breakpoint
ALTER TABLE "farmer_crop" ALTER COLUMN "current_stage" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "product" ALTER COLUMN "sku_code" SET NOT NULL;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "title" text DEFAULT 'Advisor' NOT NULL;--> statement-breakpoint
ALTER TABLE "user" ADD COLUMN "created_by_user_id" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_file_name" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_original_name" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_mime_type" text;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_size_bytes" integer;--> statement-breakpoint
ALTER TABLE "crop" ADD COLUMN "pdf_uploaded_at" timestamp;--> statement-breakpoint
ALTER TABLE "crop_schedule" ADD COLUMN "is_active" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ADD COLUMN "state" text DEFAULT 'Maharashtra' NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer_crop_notification" ADD COLUMN "task_remark" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "is_active" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "team_leader_advisor" ADD CONSTRAINT "team_leader_advisor_team_leader_id_user_id_fk" FOREIGN KEY ("team_leader_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "team_leader_advisor" ADD CONSTRAINT "team_leader_advisor_advisor_id_user_id_fk" FOREIGN KEY ("advisor_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_manager_code" ADD CONSTRAINT "user_manager_code_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user_sales_target" ADD CONSTRAINT "user_sales_target_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "branch_order_sequence" ADD CONSTRAINT "branch_order_sequence_admin_user_id_user_id_fk" FOREIGN KEY ("admin_user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_consignment" ADD CONSTRAINT "order_consignment_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_consignment" ADD CONSTRAINT "order_consignment_consignment_id_consignment_id_fk" FOREIGN KEY ("consignment_id") REFERENCES "public"."consignment"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_discount" ADD CONSTRAINT "order_discount_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_discount" ADD CONSTRAINT "order_discount_coupon_id_coupon_id_fk" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupon"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_payment_transaction" ADD CONSTRAINT "order_payment_transaction_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_pending_farmer_update" ADD CONSTRAINT "order_pending_farmer_update_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_pending_farmer_update" ADD CONSTRAINT "order_pending_farmer_update_updated_by_user_id_user_id_fk" FOREIGN KEY ("updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "post_order_follow_up" ADD CONSTRAINT "post_order_follow_up_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "post_order_follow_up" ADD CONSTRAINT "post_order_follow_up_follow_up_1_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_1_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "post_order_follow_up" ADD CONSTRAINT "post_order_follow_up_follow_up_2_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_2_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "post_order_follow_up" ADD CONSTRAINT "post_order_follow_up_follow_up_3_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_3_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "post_order_follow_up" ADD CONSTRAINT "post_order_follow_up_follow_up_4_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_4_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pre_order_confirmation_follow_up" ADD CONSTRAINT "pre_order_confirmation_follow_up_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pre_order_confirmation_follow_up" ADD CONSTRAINT "pre_order_confirmation_follow_up_follow_up_1_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_1_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pre_order_confirmation_follow_up" ADD CONSTRAINT "pre_order_confirmation_follow_up_follow_up_2_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_2_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pre_order_confirmation_follow_up" ADD CONSTRAINT "pre_order_confirmation_follow_up_follow_up_3_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_3_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pre_order_confirmation_follow_up" ADD CONSTRAINT "pre_order_confirmation_follow_up_follow_up_4_updated_by_user_id_user_id_fk" FOREIGN KEY ("follow_up_4_updated_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "product_inventory" ADD CONSTRAINT "product_inventory_product_id_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "team_leader_advisor_team_leader_id_idx" ON "team_leader_advisor" USING btree ("team_leader_id");--> statement-breakpoint
CREATE INDEX "user_manager_code_manager_code_idx" ON "user_manager_code" USING btree ("manager_code");--> statement-breakpoint
CREATE UNIQUE INDEX "consignment_consignment_number_uidx" ON "consignment" USING btree ("consignment_number");--> statement-breakpoint
CREATE INDEX "consignment_active_added_at_idx" ON "consignment" USING btree ("is_active","added_at");--> statement-breakpoint
CREATE UNIQUE INDEX "order_consignment_order_id_uidx" ON "order_consignment" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "order_consignment_consignment_id_idx" ON "order_consignment" USING btree ("consignment_id");--> statement-breakpoint
CREATE INDEX "order_consignment_order_number_idx" ON "order_consignment" USING btree ("order_number");--> statement-breakpoint
ALTER TABLE "user" ADD CONSTRAINT "user_created_by_user_id_user_id_fk" FOREIGN KEY ("created_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_item" ADD CONSTRAINT "order_item_product_sku_product_sku_code_fk" FOREIGN KEY ("product_sku") REFERENCES "public"."product"("sku_code") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "farmer_crop_farmer_id_crop_id_date_of_sowing_uidx" ON "farmer_crop" USING btree ("farmer_id","crop_id","date_of_sowing");--> statement-breakpoint
CREATE UNIQUE INDEX "order_order_id_uidx" ON "order" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "order_item_product_sku_idx" ON "order_item" USING btree ("product_sku");--> statement-breakpoint
CREATE UNIQUE INDEX "order_item_order_id_product_sku_unit_price_uidx" ON "order_item" USING btree ("order_id","product_sku","unit_price_per_unit");--> statement-breakpoint
CREATE INDEX "product_product_code_idx" ON "product" USING btree ("product_code");--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "promo_discount";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "points_used";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "points_discount_amount";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "coupon_discount_amount";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "total_discount_amount";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "cashback_amount";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "estimated_delivery_tat";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "coupon_code";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "transaction_utr";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "transaction_screenshot_base64";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "coupon_id";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_primary_mobile_number";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_secondary_mobile_number";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_address_at";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_nearby_landmark";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_post";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_taluka";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_district";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_pincode";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_updated_by_user_id";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "pending_farmer_updated_at";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "tracking_link";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_1_text";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_1_updated_at";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_1_updated_by_user_id";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_1_updated_by_role";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_2_text";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_2_updated_at";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_2_updated_by_user_id";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_2_updated_by_role";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_3_text";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_3_updated_at";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_3_updated_by_user_id";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_3_updated_by_role";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_4_text";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_4_updated_at";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_4_updated_by_user_id";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_4_updated_by_role";--> statement-breakpoint
ALTER TABLE "order_item" DROP COLUMN "product_name";--> statement-breakpoint
ALTER TABLE "order_item" DROP COLUMN "cost_per_unit";--> statement-breakpoint
ALTER TABLE "order_item" DROP COLUMN "total_amount";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "quantity";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "reserved_quantity";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "minimum_stock_level";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "batch_number";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "expiry_date";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "warehouse_location";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "total_amount";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "points_added";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "points_reason";--> statement-breakpoint
ALTER TABLE "product" DROP COLUMN "last_inventory_updated_at";--> statement-breakpoint
ALTER TABLE "product" ADD CONSTRAINT "product_sku_code_unique" UNIQUE("sku_code");