ALTER TABLE "farmer" ALTER COLUMN "address_at" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ALTER COLUMN "post" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ALTER COLUMN "taluka" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ALTER COLUMN "district" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ALTER COLUMN "state" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ALTER COLUMN "pincode" DROP NOT NULL;