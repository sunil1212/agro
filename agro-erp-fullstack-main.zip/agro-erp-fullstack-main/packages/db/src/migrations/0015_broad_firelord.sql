ALTER TABLE "order" ADD COLUMN "approved_at" timestamp;--> statement-breakpoint
ALTER TABLE "order" ADD COLUMN "approved_by_user_id" text;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_approved_by_user_id_user_id_fk" FOREIGN KEY ("approved_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_1_status";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_2_status";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_3_status";--> statement-breakpoint
ALTER TABLE "order" DROP COLUMN "follow_up_4_status";