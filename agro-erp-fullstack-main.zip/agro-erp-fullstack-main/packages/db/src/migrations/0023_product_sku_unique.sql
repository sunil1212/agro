ALTER TABLE "product"
ADD CONSTRAINT "product_sku_code_unique" UNIQUE ("sku_code");
