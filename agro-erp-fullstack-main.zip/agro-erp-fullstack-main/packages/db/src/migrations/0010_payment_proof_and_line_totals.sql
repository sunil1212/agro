ALTER TABLE "order" ADD COLUMN "transaction_utr" text;
ALTER TABLE "order" ADD COLUMN "transaction_screenshot_base64" text;

ALTER TABLE "order_item" ADD COLUMN "unit_price_per_unit" numeric(12, 2);
ALTER TABLE "order_item" ADD COLUMN "selling_price_per_unit" numeric(12, 2);
ALTER TABLE "order_item" ADD COLUMN "line_total_amount" numeric(12, 2);

UPDATE "order_item"
SET
	"unit_price_per_unit" = "cost_per_unit",
	"selling_price_per_unit" = "cost_per_unit",
	"line_total_amount" = "total_amount";

ALTER TABLE "order_item" ALTER COLUMN "unit_price_per_unit" SET NOT NULL;
ALTER TABLE "order_item" ALTER COLUMN "selling_price_per_unit" SET NOT NULL;
ALTER TABLE "order_item" ALTER COLUMN "line_total_amount" SET NOT NULL;
