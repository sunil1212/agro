ALTER TABLE "order" ADD COLUMN "tracking_link" text;
