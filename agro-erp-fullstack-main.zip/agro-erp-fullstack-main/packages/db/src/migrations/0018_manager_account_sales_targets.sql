ALTER TABLE "user" ADD COLUMN "created_by_user_id" text;
ALTER TABLE "user" ADD COLUMN "weekly_sales_target" numeric(12, 2);
ALTER TABLE "user" ADD CONSTRAINT "user_created_by_user_id_user_id_fk" FOREIGN KEY ("created_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;
