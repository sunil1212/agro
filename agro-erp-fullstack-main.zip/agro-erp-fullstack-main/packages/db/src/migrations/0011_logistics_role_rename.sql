ALTER TYPE "public"."user_roles" RENAME VALUE 'orders' TO 'logistics';--> statement-breakpoint
UPDATE "user" SET "role" = 'logistics' WHERE "role"::text = 'orders';
