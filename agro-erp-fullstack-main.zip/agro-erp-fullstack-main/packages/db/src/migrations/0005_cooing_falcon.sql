CREATE TYPE "public"."inventory_alert_status" AS ENUM('active', 'resolved');--> statement-breakpoint
CREATE TYPE "public"."inventory_alert_type" AS ENUM('low_stock', 'expiring_product');--> statement-breakpoint
CREATE TYPE "public"."inventory_category" AS ENUM('raw_material', 'packing_material', 'finished_good');--> statement-breakpoint
CREATE TYPE "public"."inventory_event_type" AS ENUM('inward', 'outward', 'order_reservation', 'order_cancellation', 'order_dispatch', 'manual_adjustment', 'alert_opened', 'alert_resolved');--> statement-breakpoint
CREATE TABLE "inventory_alert" (
	"id" text PRIMARY KEY NOT NULL,
	"alert_type" "inventory_alert_type" NOT NULL,
	"status" "inventory_alert_status" DEFAULT 'active' NOT NULL,
	"category" "inventory_category" NOT NULL,
	"inventory_item_id" text,
	"product_id" text,
	"message" text NOT NULL,
	"triggered_value" numeric(12, 3) NOT NULL,
	"threshold_value" numeric(12, 3) NOT NULL,
	"opened_event_id" text,
	"resolved_event_id" text,
	"active_at" timestamp DEFAULT now() NOT NULL,
	"resolved_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "inventory_event" (
	"id" text PRIMARY KEY NOT NULL,
	"event_type" "inventory_event_type" NOT NULL,
	"category" "inventory_category" NOT NULL,
	"inventory_item_id" text,
	"product_id" text,
	"quantity_delta" numeric(12, 3) NOT NULL,
	"quantity_before" numeric(12, 3) NOT NULL,
	"quantity_after" numeric(12, 3) NOT NULL,
	"reserved_before" numeric(12, 3),
	"reserved_after" numeric(12, 3),
	"reference_order_id" text,
	"manual_order_number" text,
	"batch_number" text,
	"supplier_name" text,
	"reason" text,
	"remarks" text,
	"approved_by_user_id" text,
	"actor_user_id" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "inventory_item" (
	"id" text PRIMARY KEY NOT NULL,
	"category" "inventory_category" NOT NULL,
	"name" text NOT NULL,
	"item_code" text NOT NULL,
	"unit" text NOT NULL,
	"current_stock" numeric(12, 3) DEFAULT '0.000' NOT NULL,
	"low_stock_threshold" numeric(12, 3) DEFAULT '0.000' NOT NULL,
	"supplier_name" text,
	"last_inventory_updated_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "sku_code" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "minimum_stock_level" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "batch_number" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "expiry_date" date;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "warehouse_location" text;--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "last_inventory_updated_at" timestamp;--> statement-breakpoint
ALTER TABLE "inventory_alert" ADD CONSTRAINT "inventory_alert_inventory_item_id_inventory_item_id_fk" FOREIGN KEY ("inventory_item_id") REFERENCES "public"."inventory_item"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_alert" ADD CONSTRAINT "inventory_alert_product_id_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_alert" ADD CONSTRAINT "inventory_alert_opened_event_id_inventory_event_id_fk" FOREIGN KEY ("opened_event_id") REFERENCES "public"."inventory_event"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_alert" ADD CONSTRAINT "inventory_alert_resolved_event_id_inventory_event_id_fk" FOREIGN KEY ("resolved_event_id") REFERENCES "public"."inventory_event"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_event" ADD CONSTRAINT "inventory_event_inventory_item_id_inventory_item_id_fk" FOREIGN KEY ("inventory_item_id") REFERENCES "public"."inventory_item"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_event" ADD CONSTRAINT "inventory_event_product_id_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_event" ADD CONSTRAINT "inventory_event_reference_order_id_order_id_fk" FOREIGN KEY ("reference_order_id") REFERENCES "public"."order"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_event" ADD CONSTRAINT "inventory_event_approved_by_user_id_user_id_fk" FOREIGN KEY ("approved_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "inventory_event" ADD CONSTRAINT "inventory_event_actor_user_id_user_id_fk" FOREIGN KEY ("actor_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "inventory_alert_status_idx" ON "inventory_alert" USING btree ("status");--> statement-breakpoint
CREATE INDEX "inventory_alert_product_id_idx" ON "inventory_alert" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "inventory_alert_inventory_item_id_idx" ON "inventory_alert" USING btree ("inventory_item_id");--> statement-breakpoint
CREATE INDEX "inventory_event_category_created_at_idx" ON "inventory_event" USING btree ("category","created_at");--> statement-breakpoint
CREATE INDEX "inventory_event_product_id_idx" ON "inventory_event" USING btree ("product_id");--> statement-breakpoint
CREATE INDEX "inventory_event_inventory_item_id_idx" ON "inventory_event" USING btree ("inventory_item_id");--> statement-breakpoint
CREATE INDEX "inventory_item_category_idx" ON "inventory_item" USING btree ("category");--> statement-breakpoint
CREATE UNIQUE INDEX "inventory_item_item_code_uidx" ON "inventory_item" USING btree ("item_code");--> statement-breakpoint
CREATE UNIQUE INDEX "product_sku_code_uidx" ON "product" USING btree ("sku_code");