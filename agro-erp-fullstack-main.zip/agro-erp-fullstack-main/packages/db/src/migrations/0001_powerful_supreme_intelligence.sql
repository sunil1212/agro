CREATE TABLE "crop" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "farmer" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"primary_mobile_number" text NOT NULL,
	"secondary_mobile_number" text,
	"address_at" text NOT NULL,
	"nearby_landmark" text,
	"post" text NOT NULL,
	"taluka" text NOT NULL,
	"district" text NOT NULL,
	"pincode" text NOT NULL,
	"service_by_user_id" text NOT NULL,
	"created_by_user_id" text NOT NULL,
	"referral_farmer_id" text,
	"irrigation_type_id" text NOT NULL,
	"land_type_id" text NOT NULL,
	"last_order_date" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "farmer_crop" (
	"id" text PRIMARY KEY NOT NULL,
	"farmer_id" text NOT NULL,
	"crop_id" text NOT NULL,
	"date_of_sowing" date NOT NULL,
	"current_stage" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "irrigation_type" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "land_type" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "farmer" ADD CONSTRAINT "farmer_service_by_user_id_user_id_fk" FOREIGN KEY ("service_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer" ADD CONSTRAINT "farmer_created_by_user_id_user_id_fk" FOREIGN KEY ("created_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer" ADD CONSTRAINT "farmer_irrigation_type_id_irrigation_type_id_fk" FOREIGN KEY ("irrigation_type_id") REFERENCES "public"."irrigation_type"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer" ADD CONSTRAINT "farmer_land_type_id_land_type_id_fk" FOREIGN KEY ("land_type_id") REFERENCES "public"."land_type"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop" ADD CONSTRAINT "farmer_crop_farmer_id_farmer_id_fk" FOREIGN KEY ("farmer_id") REFERENCES "public"."farmer"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop" ADD CONSTRAINT "farmer_crop_crop_id_crop_id_fk" FOREIGN KEY ("crop_id") REFERENCES "public"."crop"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "crop_name_uidx" ON "crop" USING btree ("name");--> statement-breakpoint
CREATE UNIQUE INDEX "farmer_primary_mobile_number_uidx" ON "farmer" USING btree ("primary_mobile_number");--> statement-breakpoint
CREATE INDEX "farmer_crop_farmer_id_idx" ON "farmer_crop" USING btree ("farmer_id");--> statement-breakpoint
CREATE INDEX "farmer_crop_crop_id_idx" ON "farmer_crop" USING btree ("crop_id");--> statement-breakpoint
CREATE UNIQUE INDEX "farmer_crop_farmer_id_crop_id_uidx" ON "farmer_crop" USING btree ("farmer_id","crop_id");--> statement-breakpoint
CREATE UNIQUE INDEX "irrigation_type_name_uidx" ON "irrigation_type" USING btree ("name");--> statement-breakpoint
CREATE UNIQUE INDEX "land_type_name_uidx" ON "land_type" USING btree ("name");