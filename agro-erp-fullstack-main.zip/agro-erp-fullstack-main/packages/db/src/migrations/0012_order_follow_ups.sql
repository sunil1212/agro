ALTER TABLE "order"
ADD COLUMN "follow_up_1_text" text,
ADD COLUMN "follow_up_1_status" text,
ADD COLUMN "follow_up_1_updated_at" timestamp,
ADD COLUMN "follow_up_1_updated_by_user_id" text,
ADD COLUMN "follow_up_1_updated_by_role" text,
ADD COLUMN "follow_up_2_text" text,
ADD COLUMN "follow_up_2_status" text,
ADD COLUMN "follow_up_2_updated_at" timestamp,
ADD COLUMN "follow_up_2_updated_by_user_id" text,
ADD COLUMN "follow_up_2_updated_by_role" text,
ADD COLUMN "follow_up_3_text" text,
ADD COLUMN "follow_up_3_status" text,
ADD COLUMN "follow_up_3_updated_at" timestamp,
ADD COLUMN "follow_up_3_updated_by_user_id" text,
ADD COLUMN "follow_up_3_updated_by_role" text,
ADD COLUMN "follow_up_4_text" text,
ADD COLUMN "follow_up_4_status" text,
ADD COLUMN "follow_up_4_updated_at" timestamp,
ADD COLUMN "follow_up_4_updated_by_user_id" text,
ADD COLUMN "follow_up_4_updated_by_role" text;

ALTER TABLE "order"
ADD CONSTRAINT "order_follow_up_1_updated_by_user_id_user_id_fk"
FOREIGN KEY ("follow_up_1_updated_by_user_id")
REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "order"
ADD CONSTRAINT "order_follow_up_2_updated_by_user_id_user_id_fk"
FOREIGN KEY ("follow_up_2_updated_by_user_id")
REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "order"
ADD CONSTRAINT "order_follow_up_3_updated_by_user_id_user_id_fk"
FOREIGN KEY ("follow_up_3_updated_by_user_id")
REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;

ALTER TABLE "order"
ADD CONSTRAINT "order_follow_up_4_updated_by_user_id_user_id_fk"
FOREIGN KEY ("follow_up_4_updated_by_user_id")
REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;
