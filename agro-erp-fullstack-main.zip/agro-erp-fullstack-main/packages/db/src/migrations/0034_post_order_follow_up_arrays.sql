ALTER TABLE "post_order_follow_up"
ALTER COLUMN "follow_up_1_text" TYPE text[] USING CASE
	WHEN "follow_up_1_text" IS NULL THEN NULL
	ELSE ARRAY["follow_up_1_text"]
END,
ALTER COLUMN "follow_up_2_text" TYPE text[] USING CASE
	WHEN "follow_up_2_text" IS NULL THEN NULL
	ELSE ARRAY["follow_up_2_text"]
END,
ALTER COLUMN "follow_up_3_text" TYPE text[] USING CASE
	WHEN "follow_up_3_text" IS NULL THEN NULL
	ELSE ARRAY["follow_up_3_text"]
END,
ALTER COLUMN "follow_up_4_text" TYPE text[] USING CASE
	WHEN "follow_up_4_text" IS NULL THEN NULL
	ELSE ARRAY["follow_up_4_text"]
END;
