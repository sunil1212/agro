UPDATE "order"
SET "status" = 'confirmed'
WHERE "status"::text IN ('picked', 'packed', 'rtd');
--> statement-breakpoint
UPDATE "order"
SET "status" = 'return_in_warehouse'
WHERE "status"::text = 'returned';
--> statement-breakpoint
INSERT INTO "branch_order_sequence" ("admin_user_id", "last_value", "updated_at")
SELECT
	"admin_user"."id",
	MAX(RIGHT("order"."order_id", 6)::integer),
	now()
FROM "order"
INNER JOIN "user" AS "order_creator"
	ON "order_creator"."id" = "order"."created_by_user_id"
INNER JOIN "user_manager_code" AS "creator_code"
	ON "creator_code"."user_id" = "order_creator"."id"
INNER JOIN "user_manager_code" AS "admin_code"
	ON "admin_code"."manager_code" = "creator_code"."manager_code"
INNER JOIN "user" AS "admin_user"
	ON "admin_user"."id" = "admin_code"."user_id"
	AND "admin_user"."role" = 'admin'
WHERE "order"."order_id" ~ '-[0-9]{6}$'
GROUP BY "admin_user"."id"
ON CONFLICT ("admin_user_id")
DO UPDATE SET
	"last_value" = GREATEST(
		"branch_order_sequence"."last_value",
		EXCLUDED."last_value"
	),
	"updated_at" = now();
