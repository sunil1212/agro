ALTER TABLE "consignment" ADD COLUMN "serial_number" integer;--> statement-breakpoint
WITH numbered_consignments AS (
	SELECT
		"id",
		row_number() OVER (
			ORDER BY "added_at" ASC, "created_at" ASC, "consignment_number" ASC
		) AS "serial_number"
	FROM "consignment"
)
UPDATE "consignment"
SET "serial_number" = numbered_consignments."serial_number"
FROM numbered_consignments
WHERE "consignment"."id" = numbered_consignments."id";--> statement-breakpoint
ALTER TABLE "consignment" ALTER COLUMN "serial_number" SET NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "consignment_serial_number_uidx" ON "consignment" USING btree ("serial_number");--> statement-breakpoint
CREATE INDEX "consignment_active_serial_number_idx" ON "consignment" USING btree ("is_active","serial_number");--> statement-breakpoint
DROP INDEX "consignment_active_added_at_idx";--> statement-breakpoint
