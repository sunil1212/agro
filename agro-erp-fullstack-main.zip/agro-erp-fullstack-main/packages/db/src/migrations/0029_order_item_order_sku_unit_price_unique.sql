DROP INDEX IF EXISTS "order_item_order_id_product_sku_uidx";
DROP INDEX IF EXISTS "order_item_order_id_product_sku_unit_price_uidx";

WITH duplicate_order_items AS (
	SELECT
		id,
		ROW_NUMBER() OVER (
			PARTITION BY order_id, product_sku, unit_price_per_unit
			ORDER BY created_at ASC, id ASC
		) AS row_number
	FROM "order_item"
)
DELETE FROM "order_item"
WHERE "id" IN (
	SELECT "id"
	FROM duplicate_order_items
	WHERE row_number > 1
);

CREATE UNIQUE INDEX "order_item_order_id_product_sku_unit_price_uidx"
ON "order_item" USING btree ("order_id", "product_sku", "unit_price_per_unit");
