UPDATE "crop"
SET
	"pdf_original_name" = convert_from(
		convert_to("pdf_original_name", 'LATIN1'),
		'UTF8'
	),
	"updated_at" = now()
WHERE "pdf_original_name" IS NOT NULL
	AND "pdf_original_name" ~ '(Ã|Â|à¤|à¥)';
