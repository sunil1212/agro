ALTER TYPE "public"."order_status" ADD VALUE IF NOT EXISTS 'return_in_transit';--> statement-breakpoint
ALTER TYPE "public"."order_status" ADD VALUE IF NOT EXISTS 'return_in_warehouse';
