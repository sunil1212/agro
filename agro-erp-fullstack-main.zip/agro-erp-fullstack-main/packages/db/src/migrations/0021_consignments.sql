CREATE TABLE "consignment" (
	"id" text PRIMARY KEY NOT NULL,
	"consignment_number" text NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"added_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_consignment" (
	"id" text PRIMARY KEY NOT NULL,
	"order_id" text NOT NULL,
	"consignment_id" text NOT NULL,
	"order_number" text NOT NULL,
	"consignment_number" text NOT NULL,
	"assigned_at" timestamp DEFAULT now() NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "order_consignment" ADD CONSTRAINT "order_consignment_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;
--> statement-breakpoint
ALTER TABLE "order_consignment" ADD CONSTRAINT "order_consignment_consignment_id_consignment_id_fk" FOREIGN KEY ("consignment_id") REFERENCES "public"."consignment"("id") ON DELETE no action ON UPDATE no action;
--> statement-breakpoint
CREATE UNIQUE INDEX "consignment_consignment_number_uidx" ON "consignment" USING btree ("consignment_number");
--> statement-breakpoint
CREATE INDEX "consignment_active_added_at_idx" ON "consignment" USING btree ("is_active","added_at");
--> statement-breakpoint
CREATE UNIQUE INDEX "order_consignment_order_id_uidx" ON "order_consignment" USING btree ("order_id");
--> statement-breakpoint
CREATE INDEX "order_consignment_consignment_id_idx" ON "order_consignment" USING btree ("consignment_id");
--> statement-breakpoint
CREATE INDEX "order_consignment_order_number_idx" ON "order_consignment" USING btree ("order_number");
