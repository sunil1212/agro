CREATE TYPE "public"."order_status" AS ENUM('created', 'picked', 'packed', 'rtd', 'dispatched', 'delivered', 'returned', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."payment_mode" AS ENUM('cod', 'partial_payment', 'prepaid');--> statement-breakpoint
CREATE TABLE "coupon" (
	"id" text PRIMARY KEY NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order" (
	"id" text PRIMARY KEY NOT NULL,
	"order_number" text NOT NULL,
	"farmer_id" text NOT NULL,
	"created_by_user_id" text NOT NULL,
	"status" "order_status" DEFAULT 'created' NOT NULL,
	"payment_mode" "payment_mode" NOT NULL,
	"subtotal_amount" numeric(12, 2) NOT NULL,
	"promo_discount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"points_used" integer DEFAULT 0 NOT NULL,
	"points_discount_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"coupon_discount_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"total_discount_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"cashback_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"shipping_charges" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"grand_total_amount" numeric(12, 2) NOT NULL,
	"paid_amount" numeric(12, 2) DEFAULT '0.00' NOT NULL,
	"total_cod_amount" numeric(12, 2) NOT NULL,
	"estimated_delivery_tat" text,
	"coupon_code" text,
	"coupon_id" text,
	"cancelled_at" timestamp,
	"cancelled_by_user_id" text,
	"dispatched_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "order_item" (
	"id" text PRIMARY KEY NOT NULL,
	"order_id" text NOT NULL,
	"product_id" text NOT NULL,
	"product_name" text NOT NULL,
	"quantity" integer NOT NULL,
	"cost_per_unit" numeric(12, 2) NOT NULL,
	"total_amount" numeric(12, 2) NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "product" ADD COLUMN "reserved_quantity" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_farmer_id_farmer_id_fk" FOREIGN KEY ("farmer_id") REFERENCES "public"."farmer"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_created_by_user_id_user_id_fk" FOREIGN KEY ("created_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_coupon_id_coupon_id_fk" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupon"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order" ADD CONSTRAINT "order_cancelled_by_user_id_user_id_fk" FOREIGN KEY ("cancelled_by_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_item" ADD CONSTRAINT "order_item_order_id_order_id_fk" FOREIGN KEY ("order_id") REFERENCES "public"."order"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_item" ADD CONSTRAINT "order_item_product_id_product_id_fk" FOREIGN KEY ("product_id") REFERENCES "public"."product"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "coupon_code_uidx" ON "coupon" USING btree ("code");--> statement-breakpoint
CREATE INDEX "order_farmer_id_idx" ON "order" USING btree ("farmer_id");--> statement-breakpoint
CREATE INDEX "order_created_by_user_id_idx" ON "order" USING btree ("created_by_user_id");--> statement-breakpoint
CREATE INDEX "order_status_idx" ON "order" USING btree ("status");--> statement-breakpoint
CREATE UNIQUE INDEX "order_order_number_uidx" ON "order" USING btree ("order_number");--> statement-breakpoint
CREATE INDEX "order_item_order_id_idx" ON "order_item" USING btree ("order_id");--> statement-breakpoint
CREATE INDEX "order_item_product_id_idx" ON "order_item" USING btree ("product_id");