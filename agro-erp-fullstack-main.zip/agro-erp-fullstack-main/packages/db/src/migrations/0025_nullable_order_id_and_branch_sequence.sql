ALTER TABLE "order" ALTER COLUMN "order_id" DROP NOT NULL;

CREATE TABLE IF NOT EXISTS "branch_order_sequence" (
	"admin_user_id" text PRIMARY KEY REFERENCES "user"("id") ON DELETE CASCADE,
	"last_value" integer DEFAULT 0 NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
