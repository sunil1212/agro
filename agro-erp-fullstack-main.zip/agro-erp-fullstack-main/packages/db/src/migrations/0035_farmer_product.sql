CREATE TABLE IF NOT EXISTS "farmer_product" (
	"farmer_id" text PRIMARY KEY NOT NULL,
	"product_sku" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

DO $$ BEGIN
 ALTER TABLE "farmer_product" ADD CONSTRAINT "farmer_product_farmer_id_farmer_id_fk" FOREIGN KEY ("farmer_id") REFERENCES "public"."farmer"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
 ALTER TABLE "farmer_product" ADD CONSTRAINT "farmer_product_product_sku_product_sku_fk" FOREIGN KEY ("product_sku") REFERENCES "public"."product"("sku_code") ON DELETE no action ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;

CREATE INDEX IF NOT EXISTS "farmer_product_product_sku_idx" ON "farmer_product" USING btree ("product_sku");

INSERT INTO "farmer_product" ("farmer_id", "product_sku")
SELECT DISTINCT ON (o."farmer_id")
	o."farmer_id",
	oi."product_sku"
FROM "order" o
INNER JOIN "order_item" oi ON oi."order_id" = o."id"
INNER JOIN "product" p ON p."sku_code" = oi."product_sku"
WHERE o."status" = 'delivered'
	AND oi."selling_price_per_unit" <> '0.00'
	AND coalesce(p."category_code", '') <> 'FR'
ORDER BY o."farmer_id", o."created_at" DESC, oi."created_at" ASC
ON CONFLICT ("farmer_id") DO NOTHING;
