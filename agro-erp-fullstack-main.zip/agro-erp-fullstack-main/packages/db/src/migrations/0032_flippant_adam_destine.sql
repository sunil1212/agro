ALTER TABLE "farmer" ALTER COLUMN "farm_size" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ALTER COLUMN "irrigation" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "farmer" ADD COLUMN "crop" text;