CREATE TABLE "crop_schedule" (
	"id" text PRIMARY KEY NOT NULL,
	"crop_id" text NOT NULL,
	"start_day" integer NOT NULL,
	"end_day" integer NOT NULL,
	"instruction" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "farmer_crop_notification" (
	"id" text PRIMARY KEY NOT NULL,
	"farmer_id" text NOT NULL,
	"advisor_user_id" text NOT NULL,
	"crop_id" text NOT NULL,
	"farmer_crop_id" text NOT NULL,
	"crop_schedule_id" text NOT NULL,
	"scheduled_for" date NOT NULL,
	"instruction" text NOT NULL,
	"is_completed" boolean DEFAULT false NOT NULL,
	"completed_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "crop_schedule" ADD CONSTRAINT "crop_schedule_crop_id_crop_id_fk" FOREIGN KEY ("crop_id") REFERENCES "public"."crop"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop_notification" ADD CONSTRAINT "farmer_crop_notification_farmer_id_farmer_id_fk" FOREIGN KEY ("farmer_id") REFERENCES "public"."farmer"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop_notification" ADD CONSTRAINT "farmer_crop_notification_advisor_user_id_user_id_fk" FOREIGN KEY ("advisor_user_id") REFERENCES "public"."user"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop_notification" ADD CONSTRAINT "farmer_crop_notification_crop_id_crop_id_fk" FOREIGN KEY ("crop_id") REFERENCES "public"."crop"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop_notification" ADD CONSTRAINT "farmer_crop_notification_farmer_crop_id_farmer_crop_id_fk" FOREIGN KEY ("farmer_crop_id") REFERENCES "public"."farmer_crop"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "farmer_crop_notification" ADD CONSTRAINT "farmer_crop_notification_crop_schedule_id_crop_schedule_id_fk" FOREIGN KEY ("crop_schedule_id") REFERENCES "public"."crop_schedule"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "crop_schedule_crop_id_idx" ON "crop_schedule" USING btree ("crop_id");--> statement-breakpoint
CREATE INDEX "farmer_crop_notification_farmer_id_idx" ON "farmer_crop_notification" USING btree ("farmer_id");--> statement-breakpoint
CREATE INDEX "farmer_crop_notification_advisor_user_id_idx" ON "farmer_crop_notification" USING btree ("advisor_user_id");--> statement-breakpoint
CREATE INDEX "farmer_crop_notification_scheduled_for_idx" ON "farmer_crop_notification" USING btree ("scheduled_for");--> statement-breakpoint
CREATE INDEX "farmer_crop_notification_is_completed_idx" ON "farmer_crop_notification" USING btree ("is_completed");