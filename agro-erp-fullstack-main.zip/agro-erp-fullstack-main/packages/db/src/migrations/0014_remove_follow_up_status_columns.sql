ALTER TABLE "order"
DROP COLUMN IF EXISTS "follow_up_1_status",
DROP COLUMN IF EXISTS "follow_up_2_status",
DROP COLUMN IF EXISTS "follow_up_3_status",
DROP COLUMN IF EXISTS "follow_up_4_status";
