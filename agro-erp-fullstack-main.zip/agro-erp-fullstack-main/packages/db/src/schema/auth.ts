import { relations } from "drizzle-orm";
import {
	type AnyPgColumn,
	boolean,
	index,
	numeric,
	pgEnum,
	pgTable,
	text,
	timestamp,
} from "drizzle-orm/pg-core";

import roleTitleMapJson from "./role-title-map.json";

export const adminAssignableRoles = [
	"team_leader",
	"advisor",
	"logistics",
] as const;

export const superAdminAssignableRoles = [
	"admin",
	...adminAssignableRoles,
	"warehouse",
] as const;

export const userRoleValues = [
	"superadmin",
	...superAdminAssignableRoles,
] as const;

export type UserRole = (typeof userRoleValues)[number];

export const roleTitleMap = roleTitleMapJson satisfies Record<UserRole, string>;

export const getDefaultTitleForRole = (role: UserRole): string =>
	roleTitleMap[role];

export const userRoles = pgEnum("user_roles", userRoleValues);

export const user = pgTable("user", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	email: text("email").notNull().unique(),
	emailVerified: boolean("email_verified").default(false).notNull(),
	image: text("image"),
	role: userRoles("role").notNull().default("advisor"),
	title: text("title").notNull().default(roleTitleMap.advisor),
	createdByUserId: text("created_by_user_id").references(
		(): AnyPgColumn => user.id
	),
	createdAt: timestamp("created_at").defaultNow().notNull(),
	updatedAt: timestamp("updated_at")
		.defaultNow()
		.$onUpdate(() => /* @__PURE__ */ new Date())
		.notNull(),
});

export const userManagerCode = pgTable(
	"user_manager_code",
	{
		userId: text("user_id")
			.primaryKey()
			.references(() => user.id, { onDelete: "cascade" }),
		managerCode: text("manager_code").notNull(),
	},
	(table) => [index("user_manager_code_manager_code_idx").on(table.managerCode)]
);

export const userSalesTarget = pgTable("user_sales_target", {
	userId: text("user_id")
		.primaryKey()
		.references(() => user.id, { onDelete: "cascade" }),
	dailySalesTarget: numeric("daily_sales_target", {
		precision: 12,
		scale: 2,
	}),
	monthlySalesTarget: numeric("monthly_sales_target", {
		precision: 12,
		scale: 2,
	}),
	createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const teamLeaderAdvisor = pgTable(
	"team_leader_advisor",
	{
		teamLeaderId: text("team_leader_id")
			.notNull()
			.references(() => user.id, { onDelete: "cascade" }),
		advisorId: text("advisor_id")
			.primaryKey()
			.references(() => user.id, { onDelete: "cascade" }),
	},
	(table) => [
		index("team_leader_advisor_team_leader_id_idx").on(table.teamLeaderId),
	]
);

export const session = pgTable(
	"session",
	{
		id: text("id").primaryKey(),
		expiresAt: timestamp("expires_at").notNull(),
		token: text("token").notNull().unique(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
		ipAddress: text("ip_address"),
		userAgent: text("user_agent"),
		userId: text("user_id")
			.notNull()
			.references(() => user.id, { onDelete: "cascade" }),
	},
	(table) => [index("session_userId_idx").on(table.userId)]
);

export const account = pgTable(
	"account",
	{
		id: text("id").primaryKey(),
		accountId: text("account_id").notNull(),
		providerId: text("provider_id").notNull(),
		userId: text("user_id")
			.notNull()
			.references(() => user.id, { onDelete: "cascade" }),
		accessToken: text("access_token"),
		refreshToken: text("refresh_token"),
		idToken: text("id_token"),
		accessTokenExpiresAt: timestamp("access_token_expires_at"),
		refreshTokenExpiresAt: timestamp("refresh_token_expires_at"),
		scope: text("scope"),
		password: text("password"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [index("account_userId_idx").on(table.userId)]
);

export const verification = pgTable(
	"verification",
	{
		id: text("id").primaryKey(),
		identifier: text("identifier").notNull(),
		value: text("value").notNull(),
		expiresAt: timestamp("expires_at").notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [index("verification_identifier_idx").on(table.identifier)]
);

export const userRelations = relations(user, ({ many, one }) => ({
	sessions: many(session),
	accounts: many(account),
	managerCode: one(userManagerCode),
	salesTarget: one(userSalesTarget),
	advisorAssignments: many(teamLeaderAdvisor, {
		relationName: "teamLeader",
	}),
	teamLeaderAssignments: many(teamLeaderAdvisor, {
		relationName: "advisor",
	}),
}));

export const userManagerCodeRelations = relations(
	userManagerCode,
	({ one }) => ({
		user: one(user, {
			fields: [userManagerCode.userId],
			references: [user.id],
		}),
	})
);

export const userSalesTargetRelations = relations(
	userSalesTarget,
	({ one }) => ({
		user: one(user, {
			fields: [userSalesTarget.userId],
			references: [user.id],
		}),
	})
);

export const teamLeaderAdvisorRelations = relations(
	teamLeaderAdvisor,
	({ one }) => ({
		teamLeader: one(user, {
			fields: [teamLeaderAdvisor.teamLeaderId],
			references: [user.id],
			relationName: "teamLeader",
		}),
		advisor: one(user, {
			fields: [teamLeaderAdvisor.advisorId],
			references: [user.id],
			relationName: "advisor",
		}),
	})
);

export const sessionRelations = relations(session, ({ one }) => ({
	user: one(user, {
		fields: [session.userId],
		references: [user.id],
	}),
}));

export const accountRelations = relations(account, ({ one }) => ({
	user: one(user, {
		fields: [account.userId],
		references: [user.id],
	}),
}));
