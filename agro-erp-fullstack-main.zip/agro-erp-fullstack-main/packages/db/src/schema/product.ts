import { relations } from "drizzle-orm";
import {
	boolean,
	date,
	index,
	integer,
	numeric,
	pgTable,
	text,
	timestamp,
} from "drizzle-orm/pg-core";

export const product = pgTable(
	"product",
	{
		id: text("id").primaryKey(),
		categoryCode: text("category_code"),
		productCode: text("product_code"),
		packingCode: text("packing_code"),
		skuCode: text("sku_code").notNull().unique(),
		name: text("name").notNull(),
		packageQuantity: numeric("package_quantity", {
			precision: 12,
			scale: 3,
		}),
		packageUnit: text("package_unit"),
		packagingType: text("packaging_type"),
		costPerUnit: numeric("cost_per_unit", {
			precision: 12,
			scale: 2,
		}).notNull(),
		discount: numeric("discount", {
			precision: 12,
			scale: 2,
		}).notNull(),
		offerPrice: numeric("offer_price", {
			precision: 12,
			scale: 2,
		}).notNull(),
		productNotes: text("product_notes"),
		isActive: boolean("is_active").default(true).notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("product_category_code_idx").on(table.categoryCode),
		index("product_name_idx").on(table.name),
		index("product_product_code_idx").on(table.productCode),
	]
);

export const productInventory = pgTable("product_inventory", {
	productId: text("product_id")
		.primaryKey()
		.references(() => product.id, { onDelete: "cascade" }),
	pointsAdded: integer("points_added").notNull(),
	pointsReason: text("points_reason").notNull(),
	quantity: integer("quantity").notNull(),
	reservedQuantity: integer("reserved_quantity").default(0).notNull(),
	minimumStockLevel: integer("minimum_stock_level").default(0).notNull(),
	batchNumber: text("batch_number"),
	expiryDate: date("expiry_date"),
	warehouseLocation: text("warehouse_location"),
	lastInventoryUpdatedAt: timestamp("last_inventory_updated_at"),
});

export const productRelations = relations(product, ({ one }) => ({
	inventory: one(productInventory),
}));

export const productInventoryRelations = relations(
	productInventory,
	({ one }) => ({
		product: one(product, {
			fields: [productInventory.productId],
			references: [product.id],
		}),
	})
);
