import { relations } from "drizzle-orm";
import {
	index,
	numeric,
	pgEnum,
	pgTable,
	text,
	timestamp,
	uniqueIndex,
} from "drizzle-orm/pg-core";

import { user } from "./auth";
import { order } from "./order";
import { product } from "./product";

export const inventoryCategoryEnum = pgEnum("inventory_category", [
	"raw_material",
	"packing_material",
	"finished_good",
]);

export const inventoryEventTypeEnum = pgEnum("inventory_event_type", [
	"inward",
	"outward",
	"order_reservation",
	"order_cancellation",
	"order_dispatch",
	"manual_adjustment",
	"alert_opened",
	"alert_resolved",
]);

export const inventoryAlertTypeEnum = pgEnum("inventory_alert_type", [
	"low_stock",
	"expiring_product",
]);

export const inventoryAlertStatusEnum = pgEnum("inventory_alert_status", [
	"active",
	"resolved",
]);

export const inventoryItem = pgTable(
	"inventory_item",
	{
		id: text("id").primaryKey(),
		category: inventoryCategoryEnum("category").notNull(),
		name: text("name").notNull(),
		itemCode: text("item_code").notNull(),
		unit: text("unit").notNull(),
		currentStock: numeric("current_stock", {
			precision: 12,
			scale: 3,
		})
			.default("0.000")
			.notNull(),
		lowStockThreshold: numeric("low_stock_threshold", {
			precision: 12,
			scale: 3,
		})
			.default("0.000")
			.notNull(),
		supplierName: text("supplier_name"),
		lastInventoryUpdatedAt: timestamp("last_inventory_updated_at"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("inventory_item_category_idx").on(table.category),
		uniqueIndex("inventory_item_item_code_uidx").on(table.itemCode),
	]
);

export const inventoryEvent = pgTable(
	"inventory_event",
	{
		id: text("id").primaryKey(),
		eventType: inventoryEventTypeEnum("event_type").notNull(),
		category: inventoryCategoryEnum("category").notNull(),
		inventoryItemId: text("inventory_item_id").references(
			() => inventoryItem.id
		),
		productId: text("product_id").references(() => product.id),
		quantityDelta: numeric("quantity_delta", {
			precision: 12,
			scale: 3,
		}).notNull(),
		quantityBefore: numeric("quantity_before", {
			precision: 12,
			scale: 3,
		}).notNull(),
		quantityAfter: numeric("quantity_after", {
			precision: 12,
			scale: 3,
		}).notNull(),
		reservedBefore: numeric("reserved_before", {
			precision: 12,
			scale: 3,
		}),
		reservedAfter: numeric("reserved_after", {
			precision: 12,
			scale: 3,
		}),
		referenceOrderId: text("reference_order_id").references(() => order.id),
		manualOrderNumber: text("manual_order_number"),
		batchNumber: text("batch_number"),
		supplierName: text("supplier_name"),
		reason: text("reason"),
		remarks: text("remarks"),
		approvedByUserId: text("approved_by_user_id").references(() => user.id),
		actorUserId: text("actor_user_id")
			.notNull()
			.references(() => user.id),
		createdAt: timestamp("created_at").defaultNow().notNull(),
	},
	(table) => [
		index("inventory_event_category_created_at_idx").on(
			table.category,
			table.createdAt
		),
		index("inventory_event_product_id_idx").on(table.productId),
		index("inventory_event_inventory_item_id_idx").on(table.inventoryItemId),
	]
);

export const inventoryAlert = pgTable(
	"inventory_alert",
	{
		id: text("id").primaryKey(),
		alertType: inventoryAlertTypeEnum("alert_type").notNull(),
		status: inventoryAlertStatusEnum("status").default("active").notNull(),
		category: inventoryCategoryEnum("category").notNull(),
		inventoryItemId: text("inventory_item_id").references(
			() => inventoryItem.id
		),
		productId: text("product_id").references(() => product.id),
		message: text("message").notNull(),
		triggeredValue: numeric("triggered_value", {
			precision: 12,
			scale: 3,
		}).notNull(),
		thresholdValue: numeric("threshold_value", {
			precision: 12,
			scale: 3,
		}).notNull(),
		openedEventId: text("opened_event_id").references(() => inventoryEvent.id),
		resolvedEventId: text("resolved_event_id").references(
			() => inventoryEvent.id
		),
		activeAt: timestamp("active_at").defaultNow().notNull(),
		resolvedAt: timestamp("resolved_at"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("inventory_alert_status_idx").on(table.status),
		index("inventory_alert_product_id_idx").on(table.productId),
		index("inventory_alert_inventory_item_id_idx").on(table.inventoryItemId),
	]
);

export const inventoryItemRelations = relations(inventoryItem, ({ many }) => ({
	alerts: many(inventoryAlert),
	events: many(inventoryEvent),
}));

export const inventoryEventRelations = relations(inventoryEvent, ({ one }) => ({
	actor: one(user, {
		fields: [inventoryEvent.actorUserId],
		references: [user.id],
		relationName: "inventory_event_actor",
	}),
	approvedBy: one(user, {
		fields: [inventoryEvent.approvedByUserId],
		references: [user.id],
		relationName: "inventory_event_approved_by",
	}),
	inventoryItem: one(inventoryItem, {
		fields: [inventoryEvent.inventoryItemId],
		references: [inventoryItem.id],
	}),
	order: one(order, {
		fields: [inventoryEvent.referenceOrderId],
		references: [order.id],
	}),
	product: one(product, {
		fields: [inventoryEvent.productId],
		references: [product.id],
	}),
}));

export const inventoryAlertRelations = relations(inventoryAlert, ({ one }) => ({
	inventoryItem: one(inventoryItem, {
		fields: [inventoryAlert.inventoryItemId],
		references: [inventoryItem.id],
	}),
	openedEvent: one(inventoryEvent, {
		fields: [inventoryAlert.openedEventId],
		references: [inventoryEvent.id],
		relationName: "inventory_alert_opened_event",
	}),
	product: one(product, {
		fields: [inventoryAlert.productId],
		references: [product.id],
	}),
	resolvedEvent: one(inventoryEvent, {
		fields: [inventoryAlert.resolvedEventId],
		references: [inventoryEvent.id],
		relationName: "inventory_alert_resolved_event",
	}),
}));
