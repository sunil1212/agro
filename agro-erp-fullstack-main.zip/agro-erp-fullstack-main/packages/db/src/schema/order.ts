import { relations } from "drizzle-orm";
import {
	boolean,
	index,
	integer,
	numeric,
	pgEnum,
	pgTable,
	text,
	timestamp,
	uniqueIndex,
} from "drizzle-orm/pg-core";

import { user } from "./auth";
import { farmer } from "./farmer";
import { product } from "./product";

export const orderStatusEnum = pgEnum("order_status", [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
]);

export const paymentModeEnum = pgEnum("payment_mode", [
	"cod",
	"partial_payment",
	"prepaid",
]);

export const coupon = pgTable(
	"coupon",
	{
		id: text("id").primaryKey(),
		code: text("code").notNull(),
		name: text("name").notNull(),
		description: text("description"),
		isActive: boolean("is_active").default(true).notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [uniqueIndex("coupon_code_uidx").on(table.code)]
);

export const order = pgTable(
	"order",
	{
		id: text("id").primaryKey(),
		orderId: text("order_id"),
		farmerId: text("farmer_id")
			.notNull()
			.references(() => farmer.id),
		createdByUserId: text("created_by_user_id")
			.notNull()
			.references(() => user.id),
		status: orderStatusEnum("status").default("created").notNull(),
		paymentMode: paymentModeEnum("payment_mode").notNull(),
		subtotalAmount: numeric("subtotal_amount", {
			precision: 12,
			scale: 2,
		}).notNull(),
		shippingCharges: numeric("shipping_charges", {
			precision: 12,
			scale: 2,
		})
			.default("0.00")
			.notNull(),
		grandTotalAmount: numeric("grand_total_amount", {
			precision: 12,
			scale: 2,
		}).notNull(),
		paidAmount: numeric("paid_amount", {
			precision: 12,
			scale: 2,
		})
			.default("0.00")
			.notNull(),
		totalCodAmount: numeric("total_cod_amount", {
			precision: 12,
			scale: 2,
		}).notNull(),
		cancelledAt: timestamp("cancelled_at"),
		cancelledByUserId: text("cancelled_by_user_id").references(() => user.id),
		cancelledReason: text("cancelled_reason"),
		cancellationUndoneAt: timestamp("cancellation_undone_at"),
		cancellationUndoneByUserId: text(
			"cancellation_undone_by_user_id"
		).references(() => user.id),
		approvedAt: timestamp("approved_at"),
		approvedByUserId: text("approved_by_user_id").references(() => user.id),
		dispatchedAt: timestamp("dispatched_at"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("order_farmer_id_idx").on(table.farmerId),
		index("order_created_by_user_id_idx").on(table.createdByUserId),
		index("order_status_idx").on(table.status),
		uniqueIndex("order_order_id_uidx").on(table.orderId),
	]
);

export const orderDiscount = pgTable("order_discount", {
	orderId: text("order_id")
		.primaryKey()
		.references(() => order.id, { onDelete: "cascade" }),
	promoDiscount: numeric("promo_discount", {
		precision: 12,
		scale: 2,
	})
		.default("0.00")
		.notNull(),
	pointsUsed: integer("points_used").default(0).notNull(),
	pointsDiscountAmount: numeric("points_discount_amount", {
		precision: 12,
		scale: 2,
	})
		.default("0.00")
		.notNull(),
	couponDiscountAmount: numeric("coupon_discount_amount", {
		precision: 12,
		scale: 2,
	})
		.default("0.00")
		.notNull(),
	totalDiscountAmount: numeric("total_discount_amount", {
		precision: 12,
		scale: 2,
	})
		.default("0.00")
		.notNull(),
	cashbackAmount: numeric("cashback_amount", {
		precision: 12,
		scale: 2,
	})
		.default("0.00")
		.notNull(),
	couponCode: text("coupon_code"),
	couponId: text("coupon_id").references(() => coupon.id),
});

export const orderPaymentTransaction = pgTable("order_payment_transaction", {
	orderId: text("order_id")
		.primaryKey()
		.references(() => order.id, { onDelete: "cascade" }),
	transactionUtr: text("transaction_utr"),
	transactionScreenshotBase64: text("transaction_screenshot_base64"),
});

export const orderPendingFarmerUpdate = pgTable("order_pending_farmer_update", {
	orderId: text("order_id")
		.primaryKey()
		.references(() => order.id, { onDelete: "cascade" }),
	primaryMobileNumber: text("primary_mobile_number"),
	secondaryMobileNumber: text("secondary_mobile_number"),
	addressAt: text("address_at"),
	nearbyLandmark: text("nearby_landmark"),
	post: text("post"),
	taluka: text("taluka"),
	district: text("district"),
	pincode: text("pincode"),
	updatedByUserId: text("updated_by_user_id").references(() => user.id),
	updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const preOrderConfirmationFollowUp = pgTable(
	"pre_order_confirmation_follow_up",
	{
		orderId: text("order_id")
			.primaryKey()
			.references(() => order.id, { onDelete: "cascade" }),
		followUp1Text: text("follow_up_1_text"),
		followUp1UpdatedAt: timestamp("follow_up_1_updated_at"),
		followUp1UpdatedByUserId: text("follow_up_1_updated_by_user_id").references(
			() => user.id
		),
		followUp2Text: text("follow_up_2_text"),
		followUp2UpdatedAt: timestamp("follow_up_2_updated_at"),
		followUp2UpdatedByUserId: text("follow_up_2_updated_by_user_id").references(
			() => user.id
		),
		followUp3Text: text("follow_up_3_text"),
		followUp3UpdatedAt: timestamp("follow_up_3_updated_at"),
		followUp3UpdatedByUserId: text("follow_up_3_updated_by_user_id").references(
			() => user.id
		),
		followUp4Text: text("follow_up_4_text"),
		followUp4UpdatedAt: timestamp("follow_up_4_updated_at"),
		followUp4UpdatedByUserId: text("follow_up_4_updated_by_user_id").references(
			() => user.id
		),
	}
);

export const postOrderFollowUp = pgTable("post_order_follow_up", {
	orderId: text("order_id")
		.primaryKey()
		.references(() => order.id, { onDelete: "cascade" }),
	followUp1Text: text("follow_up_1_text").array(),
	followUp1UpdatedAt: timestamp("follow_up_1_updated_at"),
	followUp1UpdatedByUserId: text("follow_up_1_updated_by_user_id").references(
		() => user.id
	),
	followUp2Text: text("follow_up_2_text").array(),
	followUp2UpdatedAt: timestamp("follow_up_2_updated_at"),
	followUp2UpdatedByUserId: text("follow_up_2_updated_by_user_id").references(
		() => user.id
	),
	followUp3Text: text("follow_up_3_text").array(),
	followUp3UpdatedAt: timestamp("follow_up_3_updated_at"),
	followUp3UpdatedByUserId: text("follow_up_3_updated_by_user_id").references(
		() => user.id
	),
	followUp4Text: text("follow_up_4_text").array(),
	followUp4UpdatedAt: timestamp("follow_up_4_updated_at"),
	followUp4UpdatedByUserId: text("follow_up_4_updated_by_user_id").references(
		() => user.id
	),
});

export const branchOrderSequence = pgTable("branch_order_sequence", {
	adminUserId: text("admin_user_id")
		.primaryKey()
		.references(() => user.id, { onDelete: "cascade" }),
	lastValue: integer("last_value").default(0).notNull(),
	updatedAt: timestamp("updated_at")
		.defaultNow()
		.$onUpdate(() => new Date())
		.notNull(),
});

export const orderItem = pgTable(
	"order_item",
	{
		id: text("id").primaryKey(),
		orderId: text("order_id")
			.notNull()
			.references(() => order.id, { onDelete: "cascade" }),
		productSku: text("product_sku")
			.notNull()
			.references(() => product.skuCode),
		quantity: integer("quantity").notNull(),
		unitPricePerUnit: numeric("unit_price_per_unit", {
			precision: 12,
			scale: 2,
		}).notNull(),
		sellingPricePerUnit: numeric("selling_price_per_unit", {
			precision: 12,
			scale: 2,
		}).notNull(),
		lineTotalAmount: numeric("line_total_amount", {
			precision: 12,
			scale: 2,
		}).notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("order_item_order_id_idx").on(table.orderId),
		index("order_item_product_sku_idx").on(table.productSku),
		uniqueIndex("order_item_order_id_product_sku_unit_price_uidx").on(
			table.orderId,
			table.productSku,
			table.unitPricePerUnit
		),
	]
);

export const consignment = pgTable(
	"consignment",
	{
		id: text("id").primaryKey(),
		consignmentNumber: text("consignment_number").notNull(),
		serialNumber: integer("serial_number").notNull(),
		isActive: boolean("is_active").default(true).notNull(),
		addedAt: timestamp("added_at").defaultNow().notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		uniqueIndex("consignment_consignment_number_uidx").on(
			table.consignmentNumber
		),
		uniqueIndex("consignment_serial_number_uidx").on(table.serialNumber),
		index("consignment_active_serial_number_idx").on(
			table.isActive,
			table.serialNumber
		),
	]
);

export const orderConsignment = pgTable(
	"order_consignment",
	{
		id: text("id").primaryKey(),
		orderId: text("order_id")
			.notNull()
			.references(() => order.id, { onDelete: "cascade" }),
		consignmentId: text("consignment_id")
			.notNull()
			.references(() => consignment.id),
		orderNumber: text("order_number").notNull(),
		consignmentNumber: text("consignment_number").notNull(),
		assignedAt: timestamp("assigned_at").defaultNow().notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
	},
	(table) => [
		uniqueIndex("order_consignment_order_id_uidx").on(table.orderId),
		index("order_consignment_consignment_id_idx").on(table.consignmentId),
		index("order_consignment_order_number_idx").on(table.orderNumber),
	]
);

export const orderRelations = relations(order, ({ one, many }) => ({
	farmer: one(farmer, {
		fields: [order.farmerId],
		references: [farmer.id],
	}),
	createdByUser: one(user, {
		fields: [order.createdByUserId],
		references: [user.id],
	}),
	cancelledByUser: one(user, {
		fields: [order.cancelledByUserId],
		references: [user.id],
		relationName: "order_cancelled_by_user",
	}),
	cancellationUndoneByUser: one(user, {
		fields: [order.cancellationUndoneByUserId],
		references: [user.id],
		relationName: "order_cancellation_undone_by_user",
	}),
	discount: one(orderDiscount),
	paymentTransaction: one(orderPaymentTransaction),
	pendingFarmerUpdate: one(orderPendingFarmerUpdate),
	preOrderConfirmationFollowUp: one(preOrderConfirmationFollowUp),
	postOrderFollowUp: one(postOrderFollowUp),
	items: many(orderItem),
	consignments: many(orderConsignment),
}));

export const orderDiscountRelations = relations(orderDiscount, ({ one }) => ({
	order: one(order, {
		fields: [orderDiscount.orderId],
		references: [order.id],
	}),
	coupon: one(coupon, {
		fields: [orderDiscount.couponId],
		references: [coupon.id],
	}),
}));

export const orderPaymentTransactionRelations = relations(
	orderPaymentTransaction,
	({ one }) => ({
		order: one(order, {
			fields: [orderPaymentTransaction.orderId],
			references: [order.id],
		}),
	})
);

export const orderPendingFarmerUpdateRelations = relations(
	orderPendingFarmerUpdate,
	({ one }) => ({
		order: one(order, {
			fields: [orderPendingFarmerUpdate.orderId],
			references: [order.id],
		}),
		updatedByUser: one(user, {
			fields: [orderPendingFarmerUpdate.updatedByUserId],
			references: [user.id],
		}),
	})
);

export const preOrderConfirmationFollowUpRelations = relations(
	preOrderConfirmationFollowUp,
	({ one }) => ({
		order: one(order, {
			fields: [preOrderConfirmationFollowUp.orderId],
			references: [order.id],
		}),
	})
);

export const postOrderFollowUpRelations = relations(
	postOrderFollowUp,
	({ one }) => ({
		order: one(order, {
			fields: [postOrderFollowUp.orderId],
			references: [order.id],
		}),
	})
);

export const orderItemRelations = relations(orderItem, ({ one }) => ({
	order: one(order, {
		fields: [orderItem.orderId],
		references: [order.id],
	}),
	product: one(product, {
		fields: [orderItem.productSku],
		references: [product.skuCode],
	}),
}));

export const consignmentRelations = relations(consignment, ({ many }) => ({
	orderConsignments: many(orderConsignment),
}));

export const orderConsignmentRelations = relations(
	orderConsignment,
	({ one }) => ({
		consignment: one(consignment, {
			fields: [orderConsignment.consignmentId],
			references: [consignment.id],
		}),
		order: one(order, {
			fields: [orderConsignment.orderId],
			references: [order.id],
		}),
	})
);
