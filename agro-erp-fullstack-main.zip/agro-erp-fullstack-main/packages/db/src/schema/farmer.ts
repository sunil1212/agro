import { relations } from "drizzle-orm";
import {
	boolean,
	date,
	foreignKey,
	index,
	integer,
	pgTable,
	text,
	timestamp,
	uniqueIndex,
} from "drizzle-orm/pg-core";

import { user } from "./auth";
import { product } from "./product";

export const crop = pgTable(
	"crop",
	{
		id: text("id").primaryKey(),
		name: text("name").notNull(),
		isActive: boolean("is_active").default(true).notNull(),
		pdfFileName: text("pdf_file_name"),
		pdfOriginalName: text("pdf_original_name"),
		pdfMimeType: text("pdf_mime_type"),
		pdfSizeBytes: integer("pdf_size_bytes"),
		pdfUploadedAt: timestamp("pdf_uploaded_at"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [uniqueIndex("crop_name_uidx").on(table.name)]
);

export const cropSchedule = pgTable(
	"crop_schedule",
	{
		id: text("id").primaryKey(),
		cropId: text("crop_id")
			.notNull()
			.references(() => crop.id, { onDelete: "cascade" }),
		startDay: integer("start_day").notNull(),
		endDay: integer("end_day").notNull(),
		instruction: text("instruction").notNull(),
		isActive: boolean("is_active").default(true).notNull(),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [index("crop_schedule_crop_id_idx").on(table.cropId)]
);

export const farmer = pgTable(
	"farmer",
	{
		id: text("id").primaryKey(),
		name: text("name").notNull(),
		primaryMobileNumber: text("primary_mobile_number").notNull(),
		secondaryMobileNumber: text("secondary_mobile_number"),
		addressAt: text("address_at"),
		nearbyLandmark: text("nearby_landmark"),
		post: text("post"),
		taluka: text("taluka"),
		district: text("district"),

		state: text("state").default("Maharashtra"),

		pincode: text("pincode"),
		serviceByUserId: text("service_by_user_id")
			.notNull()
			.references(() => user.id),
		createdByUserId: text("created_by_user_id")
			.notNull()
			.references(() => user.id),
		referralFarmerId: text("referral_farmer_id"),
		farmSize: text("farm_size"),
		irrigation: text("irrigation"),
		cropText: text("crop"),
		lastOrderDate: timestamp("last_order_date"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		uniqueIndex("farmer_primary_mobile_number_uidx").on(
			table.primaryMobileNumber
		),
		foreignKey({
			columns: [table.referralFarmerId],
			foreignColumns: [table.id],
			name: "farmer_referral_farmer_id_farmer_id_fk",
		}),
	]
);

export const farmerCrop = pgTable(
	"farmer_crop",
	{
		id: text("id").primaryKey(),
		farmerId: text("farmer_id")
			.notNull()
			.references(() => farmer.id, { onDelete: "cascade" }),
		cropId: text("crop_id")
			.notNull()
			.references(() => crop.id),
		dateOfSowing: date("date_of_sowing").notNull(),
		currentStage: text("current_stage"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("farmer_crop_farmer_id_idx").on(table.farmerId),
		index("farmer_crop_crop_id_idx").on(table.cropId),
		uniqueIndex("farmer_crop_farmer_id_crop_id_date_of_sowing_uidx").on(
			table.farmerId,
			table.cropId,
			table.dateOfSowing
		),
	]
);

export const farmerCropNotification = pgTable(
	"farmer_crop_notification",
	{
		id: text("id").primaryKey(),
		farmerId: text("farmer_id")
			.notNull()
			.references(() => farmer.id, { onDelete: "cascade" }),
		advisorUserId: text("advisor_user_id")
			.notNull()
			.references(() => user.id),
		cropId: text("crop_id")
			.notNull()
			.references(() => crop.id),
		farmerCropId: text("farmer_crop_id")
			.notNull()
			.references(() => farmerCrop.id, { onDelete: "cascade" }),
		cropScheduleId: text("crop_schedule_id")
			.notNull()
			.references(() => cropSchedule.id, { onDelete: "cascade" }),
		scheduledFor: date("scheduled_for").notNull(),
		instruction: text("instruction").notNull(),
		isCompleted: boolean("is_completed").default(false).notNull(),
		completedAt: timestamp("completed_at"),
		taskRemark: text("task_remark"),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [
		index("farmer_crop_notification_farmer_id_idx").on(table.farmerId),
		index("farmer_crop_notification_advisor_user_id_idx").on(
			table.advisorUserId
		),
		index("farmer_crop_notification_scheduled_for_idx").on(table.scheduledFor),
		index("farmer_crop_notification_is_completed_idx").on(table.isCompleted),
	]
);

export const farmerProduct = pgTable(
	"farmer_product",
	{
		farmerId: text("farmer_id")
			.primaryKey()
			.references(() => farmer.id, { onDelete: "cascade" }),
		productSku: text("product_sku")
			.notNull()
			.references(() => product.skuCode),
		createdAt: timestamp("created_at").defaultNow().notNull(),
		updatedAt: timestamp("updated_at")
			.defaultNow()
			.$onUpdate(() => /* @__PURE__ */ new Date())
			.notNull(),
	},
	(table) => [index("farmer_product_product_sku_idx").on(table.productSku)]
);

export const farmerRelations = relations(farmer, ({ one, many }) => ({
	serviceByUser: one(user, {
		fields: [farmer.serviceByUserId],
		references: [user.id],
		relationName: "farmer_service_by_user",
	}),
	createdByUser: one(user, {
		fields: [farmer.createdByUserId],
		references: [user.id],
		relationName: "farmer_created_by_user",
	}),
	referralFarmer: one(farmer, {
		fields: [farmer.referralFarmerId],
		references: [farmer.id],
		relationName: "farmer_referral_farmer",
	}),
	referredFarmers: many(farmer, {
		relationName: "farmer_referral_farmer",
	}),
	crops: many(farmerCrop),
	cropNotifications: many(farmerCropNotification),
	product: one(farmerProduct),
}));

export const cropRelations = relations(crop, ({ many }) => ({
	farmerCrops: many(farmerCrop),
	schedules: many(cropSchedule),
	notifications: many(farmerCropNotification),
}));

export const cropScheduleRelations = relations(
	cropSchedule,
	({ one, many }) => ({
		crop: one(crop, {
			fields: [cropSchedule.cropId],
			references: [crop.id],
		}),
		notifications: many(farmerCropNotification),
	})
);

export const farmerCropRelations = relations(farmerCrop, ({ one }) => ({
	farmer: one(farmer, {
		fields: [farmerCrop.farmerId],
		references: [farmer.id],
	}),
	crop: one(crop, {
		fields: [farmerCrop.cropId],
		references: [crop.id],
	}),
}));

export const farmerCropNotificationRelations = relations(
	farmerCropNotification,
	({ one }) => ({
		farmer: one(farmer, {
			fields: [farmerCropNotification.farmerId],
			references: [farmer.id],
		}),
		advisor: one(user, {
			fields: [farmerCropNotification.advisorUserId],
			references: [user.id],
		}),
		crop: one(crop, {
			fields: [farmerCropNotification.cropId],
			references: [crop.id],
		}),
		farmerCrop: one(farmerCrop, {
			fields: [farmerCropNotification.farmerCropId],
			references: [farmerCrop.id],
		}),
		cropSchedule: one(cropSchedule, {
			fields: [farmerCropNotification.cropScheduleId],
			references: [cropSchedule.id],
		}),
	})
);

export const farmerProductRelations = relations(farmerProduct, ({ one }) => ({
	farmer: one(farmer, {
		fields: [farmerProduct.farmerId],
		references: [farmer.id],
	}),
	product: one(product, {
		fields: [farmerProduct.productSku],
		references: [product.skuCode],
	}),
}));
