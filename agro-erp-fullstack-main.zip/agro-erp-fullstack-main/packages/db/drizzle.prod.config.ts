import { createDrizzleConfig } from "./drizzle.config.shared";

export default createDrizzleConfig({
	envFileName: ".env.production",
	expectedDriver: "postgres",
});
