import { createDrizzleConfig } from "./drizzle.config.shared";

export default createDrizzleConfig({
	envFileName: ".env.development.neon",
	expectedDriver: "neon",
	preferDirectUrl: true,
});
