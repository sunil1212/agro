import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import { defineConfig } from "drizzle-kit";

type DatabaseDriver = "neon" | "postgres";

interface CreateDrizzleConfigOptions {
	envFileName: string;
	expectedDriver: DatabaseDriver;
	preferDirectUrl?: boolean;
}

const configDirectory = dirname(fileURLToPath(import.meta.url));
const serverDirectory = join(configDirectory, "../../apps/server");

export const createDrizzleConfig = ({
	envFileName,
	expectedDriver,
	preferDirectUrl = false,
}: CreateDrizzleConfigOptions) => {
	const envFilePath = join(serverDirectory, envFileName);
	const loadResult = dotenv.config({
		path: envFilePath,
		override: true,
	});

	if (loadResult.error) {
		throw new Error(
			`Unable to load database environment file: ${envFilePath}`,
			{ cause: loadResult.error }
		);
	}

	const configuredDriver = process.env.DATABASE_DRIVER;
	if (configuredDriver !== expectedDriver) {
		throw new Error(
			`Expected DATABASE_DRIVER=${expectedDriver} in ${envFilePath}, received ${configuredDriver ?? "undefined"}`
		);
	}

	const databaseUrl =
		(preferDirectUrl ? process.env.DATABASE_URL_DIRECT : undefined) ??
		process.env.DATABASE_URL;

	if (!databaseUrl) {
		throw new Error(
			`DATABASE_URL is required in database environment file: ${envFilePath}`
		);
	}

	return defineConfig({
		// Drizzle's metadata scanner expects project-relative paths here.
		schema: "./src/schema/**/*.ts",
		out: "./src/migrations",
		dialect: "postgresql",
		dbCredentials: {
			url: databaseUrl,
		},
		verbose: true,
	});
};
