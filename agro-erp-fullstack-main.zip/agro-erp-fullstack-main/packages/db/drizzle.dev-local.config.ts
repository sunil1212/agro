import { createDrizzleConfig } from "./drizzle.config.shared";

export default createDrizzleConfig({
	envFileName: ".env.development.local",
	expectedDriver: "postgres",
});
