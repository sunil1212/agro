---
name: Agro ERP
description: Fast, clean, snappy ERP/CRM workspace for agro-product operations.
colors:
  background: "oklch(0.969399 0.005879 59.652)"
  foreground: "oklch(0.147 0.004 49.3)"
  card: "oklch(1 0 0)"
  card-foreground: "oklch(0.147 0.004 49.3)"
  primary: "oklch(0.527 0.154 150.069)"
  primary-foreground: "oklch(0.982 0.018 155.826)"
  secondary: "oklch(0.952 0.006 48.2)"
  secondary-foreground: "oklch(0.21 0.006 285.885)"
  muted: "oklch(0.946 0.006 48.5)"
  muted-foreground: "oklch(0.547 0.021 43.1)"
  accent: "oklch(0.527 0.154 150.069)"
  accent-foreground: "oklch(0.982 0.018 155.826)"
  destructive: "oklch(0.577 0.245 27.325)"
  border: "oklch(0.922 0.005 34.3)"
  input: "oklch(0.94 0.005 40.1)"
  ring: "oklch(0.714 0.014 41.2)"
  sidebar: "oklch(0.986 0.002 67.8)"
typography:
  display:
    fontFamily: "Geist, system-ui, sans-serif"
    fontSize: "2.25rem"
    fontWeight: 600
    lineHeight: 1.1
    letterSpacing: "-0.025em"
  headline:
    fontFamily: "Geist, system-ui, sans-serif"
    fontSize: "1.5rem"
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: "-0.025em"
  title:
    fontFamily: "Geist, system-ui, sans-serif"
    fontSize: "1.25rem"
    fontWeight: 600
    lineHeight: 1.25
  body:
    fontFamily: "Geist, system-ui, sans-serif"
    fontSize: "0.875rem"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "Geist, system-ui, sans-serif"
    fontSize: "0.75rem"
    fontWeight: 500
    lineHeight: 1.25
rounded:
  sm: "0.375rem"
  md: "0.5rem"
  lg: "0.625rem"
  xl: "0.875rem"
  "2xl": "1.125rem"
  "3xl": "1.375rem"
  "4xl": "1.625rem"
  full: "9999px"
spacing:
  xs: "0.25rem"
  sm: "0.5rem"
  md: "0.75rem"
  lg: "1rem"
  xl: "1.5rem"
  "2xl": "2rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.primary-foreground}"
    rounded: "{rounded.full}"
    height: "2.25rem"
    padding: "0 0.75rem"
    typography: "{typography.body}"
  button-secondary:
    backgroundColor: "{colors.secondary}"
    textColor: "{colors.secondary-foreground}"
    rounded: "{rounded.full}"
    height: "2.25rem"
    padding: "0 0.75rem"
    typography: "{typography.body}"
  input-default:
    backgroundColor: "{colors.input}"
    textColor: "{colors.foreground}"
    rounded: "{rounded.3xl}"
    height: "2.25rem"
    padding: "0 0.75rem"
    typography: "{typography.body}"
  card-surface:
    backgroundColor: "{colors.card}"
    textColor: "{colors.card-foreground}"
    rounded: "{rounded.4xl}"
    padding: "1.5rem"
---

# Design System: Agro ERP

## 1. Overview

**Creative North Star: "The Fast Field Desk"**

Agro ERP is a fast, clean, snappy operational workspace that combines the speed of a branch desk, the status clarity of a control room, and the directness of a field console. The UI should feel lightweight and tactile: surfaces are calm at rest, controls respond quickly, and role-specific workflows stay immediately scannable.

This is a product UI, so consistency beats surprise. The established shadcn-style primitives, OKLCH token palette, Geist typography, light dashboard direction, pill controls, and compact page shells are the identity. Polish should sharpen hierarchy, empty states, table ergonomics, inventory flows, and status handling without replacing the system.

The system explicitly rejects sluggish, complicated, or clunky UI patterns that make routine work take longer than necessary. It also rejects flashy SaaS decoration, unnecessary motion, agriculture clichés, and dense screens that obscure the next action.

**Key Characteristics:**
- Fast role-based workflows for admin, manager, advisor, logistics, and warehouse users.
- Restrained green accent used for primary actions, active states, success-adjacent cues, and small icon containers.
- Light operational surfaces with subtle borders, soft shadows, and tactile hover movement.
- Rounded controls and containers, but with density appropriate for repeated ERP work.
- Predictable shadcn component vocabulary across forms, tables, navigation, dialogs, and cards.

## 2. Colors

The palette is restrained and operational: warm-tinted neutrals carry the workspace, while the green primary marks action, selection, and productive status.

### Primary
- **Crop Action Green**: The primary and accent token. Use it for main CTAs, active intent, selected productive states, focused icon containers, and success-adjacent operational cues. It should stay rare enough that it continues to mean "act here" or "this is current."

### Neutral
- **Warm Workspace Background**: The page background. It keeps the app light without becoming pure white and supports long operational sessions.
- **White Work Surface**: The card, popover, and table-container surface. Use it for discrete work areas, not as decorative floating panels.
- **Ink Foreground**: The primary text color. Use it for titles, values, table body text, and anything required for fast reading.
- **Muted Field Neutral**: The secondary and muted surface family. Use for inactive controls, table hover rows, empty-state icon wells, and soft grouping.
- **Operational Border**: The low-chroma divider and ring family. Use it for table edges, cards, active nav pills, and field boundaries.
- **Muted Metadata**: The secondary text color. Use for descriptions, helper text, captions, timestamps, and non-critical metadata.

### Tertiary
- **Destructive Red**: Reserved for destructive actions, invalid fields, and error states. It should not be used as decoration or as a generic warning color.
- **Warehouse Amber**: Used sparingly through status pills for warning states. Keep it semantic and local.

### Named Rules
**The Accent Rarity Rule.** Primary green is for action, selection, and state. Do not use it as page decoration or as a broad background wash.

**The Warm Neutral Rule.** The app may use warm-tinted neutrals because they already exist in the token system, but text must stay ink-forward and high-contrast. Muted text is for secondary information only.

## 3. Typography

**Display Font:** Geist with system-ui fallback.
**Body Font:** Geist with system-ui fallback.
**Label/Mono Font:** Geist Mono only for technical identifiers if needed.

**Character:** The typography is compact, plainspoken, and operational. It should read like a fast internal tool: clear labels, tight headings, tabular numeric rhythm, and no decorative display treatment.

### Hierarchy
- **Display** (600, 2.25rem, 1.1): Dashboard welcome headings and rare top-level moments. Keep this fixed and restrained; product screens do not need fluid hero type.
- **Headline** (600, 1.5rem, 1.2): Page titles and major workflow headers.
- **Title** (600, 1.25rem, 1.25): Section headers, card titles, empty-state titles, and panel headings.
- **Body** (400, 0.875rem, 1.5): Form text, table text, descriptions, and operational copy. Keep prose lines around 65-75ch when the content is explanatory.
- **Label** (500, 0.75rem, 1.25): Metadata, compact labels, status text, helper labels, and metric captions. Uppercase tracking is allowed only for compact labels where it improves scanning.

### Named Rules
**The Product Type Rule.** Use one sans family for the interface. Do not introduce display fonts, decorative pairings, or oversized marketing type inside operational screens.

**The Scan First Rule.** Tables, forms, and workflow pages should make names, statuses, dates, quantities, and next actions easier to scan than surrounding prose.

## 4. Elevation

Agro ERP uses a softly layered system: borders and tonal surface changes define most structure, while small shadows add tactile feedback to cards, active navigation, popovers, and quick-action tiles. Depth should feel responsive, not decorative. The strongest elevation currently belongs to overlays and select popups; ordinary surfaces should stay light.

### Shadow Vocabulary
- **Resting Surface** (`shadow-sm`): Use on app-specific surfaces and quick-action cards where a slight lift helps separate a work area from the page.
- **Base Card** (`shadow-md`): Used by the shared card primitive. Apply carefully; if a card also has a strong border, keep the shadow subtle.
- **Overlay Surface** (`shadow-lg`): Use for popovers, dropdowns, and floating menus that must sit above the workspace.

### Named Rules
**The Lightweight Tactility Rule.** Hover lift may move a quick-action card by 2-4px and transition in about 200ms. Do not use large blurred shadows or dramatic elevation for ordinary ERP surfaces.

**The Border Before Shadow Rule.** Structure should usually come from spacing, border, and surface color. Add shadow only when the element is interactive, selected, or floating above content.

## 5. Components

### Buttons
- **Shape:** Full-pill controls built from `rounded-4xl` / rounded-full behavior. Icon-only buttons stay square by size but keep the same pill language.
- **Primary:** Crop Action Green background with primary foreground text, medium weight, 0.875rem type, 2.25rem default height, and compact horizontal padding.
- **Hover / Focus:** Hover darkens or softens the background token; focus uses a 3px ring from the ring token at 30% opacity. Active non-popup buttons translate down by 1px.
- **Secondary / Ghost / Link:** Secondary uses muted neutral fills. Ghost stays transparent until hover. Link uses green text and underline-on-hover only when it is truly navigational.

### Chips
- **Style:** Status pills are small, full-pill, medium-weight labels with tonal backgrounds and a 1px ring.
- **State:** Neutral uses muted fill and foreground text. Success uses green tint. Warning uses amber tint. Danger uses destructive tint. Pills should describe state, not become decorative badges.

### Cards / Containers
- **Corner Style:** Shared cards use highly rounded corners from `rounded-4xl`; app surfaces often use `rounded-[2rem]`. This is part of the current identity, but polish should avoid stacking rounded cards inside rounded cards.
- **Background:** White Work Surface on Warm Workspace Background.
- **Shadow Strategy:** Resting surfaces may use `shadow-sm` or `shadow-md`; hoverable quick actions can add a small upward translation.
- **Border:** Use the border token at partial opacity, commonly `border-border/60` or `border-border/70`.
- **Internal Padding:** Standard surface padding is 1.25rem on mobile and 1.5rem at larger breakpoints. Dense metric cards can use 1rem.

### Inputs / Fields
- **Style:** Inputs and select triggers use rounded-3xl, transparent border, input-toned background at 50%, compact 2.25rem height, and 0.875rem text on desktop.
- **Focus:** Focus changes the border to the ring token and adds a 3px soft ring at 30% opacity.
- **Error / Disabled:** Invalid fields use destructive border and ring tint. Disabled controls reduce opacity and block pointer interaction.

### Navigation
- **Style:** The top navigation is sticky, lightly translucent, and backed by the workspace background with blur. Links are horizontal pills with muted default text.
- **Active State:** Active routes use a card-colored pill, foreground text, medium weight, subtle shadow, and a border ring.
- **Mobile Treatment:** Navigation scrolls horizontally instead of wrapping into a bulky menu. Keep labels short and role-specific.

### Tables
- **Style:** Tables are compact, full-width, and horizontally scrollable by default. Headers use muted text and medium weight; rows use thin borders and muted hover fill.
- **Density:** ERP tables may be dense, but long farmer names, task descriptions, product names, and order identifiers must wrap or truncate intentionally.
- **State:** Selected rows use the muted background token. Empty rows should teach the next action instead of only saying that nothing exists.

### Quick Action Cards
- **Style:** Large role-entry cards use white surfaces, rounded containers, green-tinted icon wells, clear title hierarchy, short descriptive copy, and a primary action link.
- **Behavior:** Hover lift is allowed because these are launch points. Keep the motion short and purposeful.

## 6. Do's and Don'ts

### Do:
- **Do** preserve the existing shadcn-style component system, OKLCH token palette, Geist typography, and light operational dashboard direction.
- **Do** optimize every workflow for task speed: clear next action, short labels, visible status, and minimal navigation friction.
- **Do** use primary green for primary actions, active states, and productive status cues.
- **Do** keep warehouse, inventory, shipping, and order-status screens especially direct, scannable, and tolerant of repeated daily use.
- **Do** use skeletons, empty states, and inline validation that help users recover quickly.
- **Do** keep motion in the 150-250ms range for ordinary state changes, with reduced-motion alternatives.

### Don't:
- **Don't** introduce sluggish, complicated, or clunky UI patterns that make routine work take longer than necessary.
- **Don't** drift away from the existing shadcn-style component system, OKLCH token palette, or current light operational dashboard direction.
- **Don't** add flashy SaaS decoration, unnecessary motion, agriculture clichés, or dense screens that obscure the next action.
- **Don't** use gradient text, side-stripe accent borders, decorative glassmorphism, repeating stripe backgrounds, or hand-drawn agriculture illustrations.
- **Don't** make inactive states heavy green or full-saturation. Inactive means neutral.
- **Don't** solve every workflow with a modal. Use inline flow, progressive disclosure, or a dedicated page when the task has real complexity.
