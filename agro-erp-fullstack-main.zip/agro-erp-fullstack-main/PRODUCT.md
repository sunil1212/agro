# Product

## Register

product

## Users

Agro ERP serves the internal team of an agri-product company. Admins create managers, branch structures, crop listings, and product listings. Managers create advisors and logistics users for their branch. Advisors onboard farmers, place orders, and manage farmer relationships. Logistics users verify orders and monitor status movement. Warehouse users work across all branches, primarily handling order shipping, inventory management, and product creation.

## Product Purpose

The product is an ERP/CRM workspace for running agro-product operations from farmer onboarding through product setup, ordering, logistics verification, shipping, inventory, and reporting. Success means each role can complete frequent operational tasks quickly, with clear status visibility and minimal navigation friction.

## Brand Personality

Fast, clean, and snappy. The interface should feel operationally sharp rather than decorative: familiar enough for repeated daily use, direct enough for branch and field teams, and polished enough that important workflows feel trustworthy.

## Anti-references

Avoid sluggish, complicated, or clunky UI patterns that make routine work take longer than necessary. Do not drift away from the existing shadcn-style component system, OKLCH token palette, or current light operational dashboard direction. Avoid flashy SaaS decoration, unnecessary motion, agriculture clichés, and dense screens that obscure the next action.

## Design Principles

1. Optimize for task speed: every screen should make the next operational action obvious and cheap.
2. Preserve the existing visual system: polish should improve hierarchy, spacing, states, and ergonomics without replacing the established shadcn styling guide.
3. Keep role workflows distinct: admin, manager, advisor, logistics, and warehouse surfaces should foreground the work that role actually performs.
4. Prefer clarity over cleverness: standard controls, predictable navigation, and readable tables beat custom affordances.
5. Polish the rough edges: warehouse, inventory, shipping, and order-status workflows should receive special attention because ease of use is central to adoption.

## Accessibility & Inclusion

Maintain accessible product UI patterns aligned with WCAG AA expectations where practical: readable contrast, keyboard-accessible controls, clear focus states, semantic navigation, and reduced-motion alternatives. Future polish should account for fast use in operational environments, including clear labels, resilient responsive layouts, and low-friction workflows for users who may be switching between desk, branch, and field contexts.
