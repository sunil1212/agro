const email = process.env.SEED_ADMIN_EMAIL ?? process.argv[2];
const password = process.env.SEED_ADMIN_PASSWORD ?? process.argv[3];
const name = process.env.SEED_ADMIN_NAME ?? process.argv[4] ?? "Admin";

export {};

if (!(email && password)) {
	throw new Error(
		"Provide SEED_ADMIN_EMAIL and SEED_ADMIN_PASSWORD, or run: bun run seed:admin email password [name]"
	);
}

const [{ auth }, { db }, { user }, { eq }] = await Promise.all([
	import("@agro-erp-fullstack/auth"),
	import("@agro-erp-fullstack/db"),
	import("@agro-erp-fullstack/db/schema/auth"),
	import("drizzle-orm"),
]);

const [existingUser] = await db
	.select({ id: user.id, role: user.role })
	.from(user)
	.where(eq(user.email, email))
	.limit(1);

if (existingUser) {
	await db
		.update(user)
		.set({ role: "superadmin" })
		.where(eq(user.id, existingUser.id));
	console.info(`Admin already exists. Ensured admin role for ${email}.`);
	process.exit(0);
}

await auth.api.signUpEmail({
	body: {
		email,
		name,
		password,
		role: "superadmin",
	},
	headers: new Headers(),
});

console.info(`Created admin user ${email}.`);
