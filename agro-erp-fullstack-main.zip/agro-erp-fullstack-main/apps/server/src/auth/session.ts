import { auth } from "@agro-erp-fullstack/auth";
import type { Request, Response } from "express";
import { type AppAction, roleCan } from "./permissions";
import { type AppRole, isAppRole } from "./roles";

const signInRequiredMessage = "You must sign in first";

export type AppSession = NonNullable<
	Awaited<ReturnType<typeof auth.api.getSession>>
> & {
	user: NonNullable<Awaited<ReturnType<typeof auth.api.getSession>>>["user"] & {
		role: AppRole | "";
	};
};

interface RequireRoleSessionOptions {
	allowedRoles: readonly AppRole[];
	authFailureSuccess?: boolean;
	forbiddenMessage: string;
	forbiddenSuccess?: boolean;
}

interface RequireActionSessionOptions {
	action: AppAction;
	authFailureSuccess?: boolean;
	forbiddenMessage?: string;
	forbiddenSuccess?: boolean;
}

export const getRequestHeaders = (request: Request) => {
	const headers = new Headers();

	for (const [key, value] of Object.entries(request.headers ?? {})) {
		if (Array.isArray(value)) {
			for (const item of value) {
				headers.append(key, item);
			}
			continue;
		}

		if (typeof value === "string") {
			headers.set(key, value);
		}
	}

	return headers;
};

const getSessionRole = (role: unknown): AppRole | "" =>
	isAppRole(role) ? role : "";

const sendAuthError = (
	response: Response,
	status: 401 | 403,
	message: string,
	success?: boolean
) => {
	const payload =
		typeof success === "boolean" ? { message, success } : { message };
	response.status(status).json(payload);
};

export const requireSession = async (
	request: Request,
	response: Response,
	success?: boolean
) => {
	const session = await auth.api.getSession({
		headers: getRequestHeaders(request),
	});

	if (!session?.user) {
		sendAuthError(response, 401, signInRequiredMessage, success);
		return null;
	}

	return {
		...session,
		user: {
			...session.user,
			role: getSessionRole(session.user.role),
		},
	} satisfies AppSession;
};

export const requireRoleSession = async (
	request: Request,
	response: Response,
	options: RequireRoleSessionOptions
) => {
	const session = await requireSession(
		request,
		response,
		options.authFailureSuccess
	);

	if (!session) {
		return null;
	}

	if (
		!options.allowedRoles.some(
			(allowedRole) => allowedRole === session.user.role
		)
	) {
		sendAuthError(
			response,
			403,
			options.forbiddenMessage,
			options.forbiddenSuccess
		);
		return null;
	}

	return session;
};

export const requireActionSession = async (
	request: Request,
	response: Response,
	options: RequireActionSessionOptions
) => {
	const session = await requireSession(
		request,
		response,
		options.authFailureSuccess
	);

	if (!session) {
		return null;
	}

	if (!roleCan(session.user.role, options.action)) {
		sendAuthError(
			response,
			403,
			options.forbiddenMessage ?? "You do not have access to this action",
			options.forbiddenSuccess
		);
		return null;
	}

	return session;
};
