export const appRoles = [
	"superadmin",
	"admin",
	"team_leader",
	"advisor",
	"warehouse",
	"logistics",
] as const;

export type AppRole = (typeof appRoles)[number];

export const isAppRole = (role: unknown): role is AppRole =>
	appRoles.some((appRole) => appRole === role);
