import type { AppRole } from "./roles";

export const appActions = [
	"account:create_manager",
	"account:create_staff",
	"account:list",
	"account:assign_team_leader",
	"account:reset_password",
	"account:update_targets",
	"consignment:manage",
	"manager_stats:read",
	"crop:list",
	"crop:read",
	"crop:create",
	"crop:update",
	"crop:deactivate",
	"crop:reactivate",
	"crop:read_pdf",
	"product:list",
	"product:read",
	"product:create",
	"product:update",
	"product:deactivate",
	"product:reactivate",
	"inventory:read",
	"inventory:manage",
	"inventory:read_finished_goods",
	"farmer:manage",
	"advisor_order:manage",
	"advisor_order:edit",
	"logistics_order:verify",
] as const;

export type AppAction = (typeof appActions)[number];
export type PermissionMap = Record<AppRole, readonly AppAction[]>;

const productReadActions = ["product:list", "product:read"] as const;
const productWriteActions = [
	"product:create",
	"product:update",
	"product:deactivate",
	"product:reactivate",
] as const;
const cropReadActions = ["crop:list", "crop:read", "crop:read_pdf"] as const;
const cropWriteActions = [
	"crop:create",
	"crop:update",
	"crop:deactivate",
	"crop:reactivate",
] as const;

export const permissions = {
	superadmin: [
		"account:create_manager",
		"account:create_staff",
		"account:list",
		"consignment:manage",
		...cropReadActions,
		...cropWriteActions,
		...productReadActions,
		...productWriteActions,
		"inventory:read",
		"inventory:manage",
		"inventory:read_finished_goods",
	],
	advisor: [
		...cropReadActions,
		"product:list",
		"product:read",
		"farmer:manage",
		"advisor_order:manage",
	],
	logistics: ["crop:read_pdf", "logistics_order:verify", "advisor_order:edit"],
	admin: [
		"account:create_staff",
		"account:list",
		"account:assign_team_leader",
		"account:reset_password",
		"account:update_targets",
		...cropReadActions,
		"farmer:manage",
		"advisor_order:manage",
		"advisor_order:edit",
		"logistics_order:verify",
		"manager_stats:read",
		"inventory:read",
	],
	team_leader: [
		...cropReadActions,
		"product:list",
		"product:read",
		"farmer:manage",
		"advisor_order:manage",
		"advisor_order:edit",
		"manager_stats:read",
	],
	warehouse: [
		"crop:read_pdf",
		...productReadActions,
		"inventory:read",
		"inventory:manage",
		"inventory:read_finished_goods",
	],
} as const satisfies PermissionMap;

export function roleCan(role: AppRole | "", action: AppAction): boolean {
	if (!role) {
		return false;
	}

	return (permissions[role] as readonly AppAction[]).includes(action);
}

export function roleCanAny(
	role: AppRole | "",
	actions: readonly AppAction[]
): boolean {
	return actions.some((action) => roleCan(role, action));
}

export function getAllowedRolesForAction(action: AppAction): AppRole[] {
	return (Object.keys(permissions) as AppRole[]).filter((role) =>
		roleCan(role, action)
	);
}
