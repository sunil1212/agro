import { db } from "@agro-erp-fullstack/db";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { and, asc, desc, eq, getTableColumns } from "drizzle-orm";

export const listProductGroups = async () => {
	const rows = await db
		.select({
			...getTableColumns(product),
			...getTableColumns(productInventory),
			additionalNotes: product.productNotes,
			id: product.id,
		})
		.from(product)
		.innerJoin(productInventory, eq(productInventory.productId, product.id))
		.orderBy(desc(product.createdAt));
	const productGroups = new Map<string, typeof rows>();
	for (const row of rows) {
		const groupKey = `${row.categoryCode ?? ""}:${row.productCode ?? ""}:${row.name}`;
		const variants = productGroups.get(groupKey) ?? [];
		variants.push(row);
		productGroups.set(groupKey, variants);
	}

	return Array.from(productGroups.values()).map((variants) => ({
		...variants[0],
		variants,
	}));
};

export const findProductWithVariants = async (productId: string) => {
	const [currentProduct] = await db
		.select({
			...getTableColumns(product),
			additionalNotes: product.productNotes,
		})
		.from(product)
		.where(eq(product.id, productId))
		.limit(1);

	if (!currentProduct) {
		return null;
	}
	const { categoryCode, productCode } = currentProduct;
	if (!(categoryCode && productCode)) {
		return { ...currentProduct, variants: [] };
	}

	const variants = await db
		.select({
			...getTableColumns(product),
			...getTableColumns(productInventory),
			additionalNotes: product.productNotes,
			id: product.id,
		})
		.from(product)
		.innerJoin(productInventory, eq(productInventory.productId, product.id))
		.where(
			and(
				eq(product.categoryCode, categoryCode),
				eq(product.productCode, productCode)
			)
		)
		.orderBy(asc(product.packageQuantity), asc(product.skuCode));

	return { ...currentProduct, variants };
};
