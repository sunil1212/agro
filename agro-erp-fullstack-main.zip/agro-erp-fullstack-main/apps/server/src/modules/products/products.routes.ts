import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import { requireActionSession } from "../../auth/session";
import { importProductsSchema } from "../../lib/admin";
import { sendErrorResponse } from "../../lib/http";
import {
	createProductSchema,
	getManagerSafeErrorMessage,
	logManagerProductError,
	productIdSchema,
	updateProductSchema,
} from "../../lib/manager";
import { importProducts } from "../../services/products";
import {
	findProductWithVariants,
	listProductGroups,
} from "./products.repository";
import {
	createProduct,
	setProductActive,
	updateProduct,
} from "./products.service";

export const productsRouter: Router = createRouter();

productsRouter.post("/import", async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "product:create",
			forbiddenMessage: "You do not have access to import products",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}

		const values = importProductsSchema.parse(request.body);
		const result = await importProducts(values.products);
		response.status(200).json({ ...result, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

productsRouter.get("/", async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "product:list",
			forbiddenMessage: "You do not have access to products",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}
		response
			.status(200)
			.json({ products: await listProductGroups(), success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

productsRouter.get(
	"/:productId",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "product:read",
				forbiddenMessage: "You do not have access to products",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			const productId = productIdSchema.parse(request.params.productId);
			const currentProduct = await findProductWithVariants(productId);
			if (!currentProduct) {
				response
					.status(404)
					.json({ message: "Product not found", success: false });
				return;
			}
			response.status(200).json({ product: currentProduct, success: true });
		} catch (error) {
			logManagerProductError("update", error, {
				body: request.body,
				productId: request.params.productId,
			});
			response.status(400).json({
				message: getManagerSafeErrorMessage(error),
				success: false,
			});
		}
	}
);

productsRouter.post("/", async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "product:create",
			forbiddenMessage: "You do not have access to create products",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}
		const values = createProductSchema.parse(request.body);
		const createdProduct = await createProduct(values, session.user.id);
		response.status(201).json({ product: createdProduct, success: true });
	} catch (error) {
		logManagerProductError("create", error, { body: request.body });
		response.status(400).json({
			message: getManagerSafeErrorMessage(error),
			success: false,
		});
	}
});

productsRouter.patch(
	"/:productId",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "product:update",
				forbiddenMessage: "You do not have access to update products",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			const productId = productIdSchema.parse(request.params.productId);
			const values = updateProductSchema.parse(request.body);
			const updatedProduct = await updateProduct(
				productId,
				values,
				session.user.id
			);
			if (!updatedProduct) {
				response
					.status(404)
					.json({ message: "Product not found", success: false });
				return;
			}
			response.status(200).json({ product: updatedProduct, success: true });
		} catch (error) {
			logManagerProductError("update", error, {
				body: request.body,
				productId: request.params.productId,
			});
			response.status(400).json({
				message: getManagerSafeErrorMessage(error),
				success: false,
			});
		}
	}
);

productsRouter.post(
	"/:productId/deactivate",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "product:deactivate",
				forbiddenMessage: "You do not have access to deactivate products",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			await setProductActive(
				productIdSchema.parse(request.params.productId),
				false
			);
			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

productsRouter.post(
	"/:productId/reactivate",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "product:reactivate",
				forbiddenMessage: "You do not have access to reactivate products",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			await setProductActive(
				productIdSchema.parse(request.params.productId),
				true
			);
			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);
