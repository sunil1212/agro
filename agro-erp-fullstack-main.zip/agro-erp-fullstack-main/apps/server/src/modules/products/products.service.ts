import { db } from "@agro-erp-fullstack/db";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { and, asc, eq, inArray, notInArray } from "drizzle-orm";
import {
	insertInventoryEvent,
	reconcileProductInventoryAlerts,
} from "../../lib/inventory";
import {
	type createProductSchema,
	getProductVariantInputs,
	normalizeProductCatalogValues,
	normalizeProductVariantValues,
	type updateProductSchema,
} from "../../lib/manager";
import { findProductWithVariants } from "./products.repository";

type ProductMutationValues =
	| ReturnType<(typeof createProductSchema)["parse"]>
	| ReturnType<(typeof updateProductSchema)["parse"]>;

export const createProduct = async (
	values: ProductMutationValues,
	actorUserId: string
) => {
	const catalogValues = normalizeProductCatalogValues(values);
	const variants = getProductVariantInputs(values);
	let productId = "";

	await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;
		for (const variant of variants) {
			const variantId = crypto.randomUUID();
			productId ||= variantId;
			const variantValues = normalizeProductVariantValues(
				variant,
				catalogValues
			);
			await database.insert(product).values({
				id: variantId,
				...catalogValues,
				...variantValues,
				isActive: true,
			});
			await database.insert(productInventory).values({
				lastInventoryUpdatedAt: variant.quantity > 0 ? new Date() : null,
				pointsAdded: 0,
				pointsReason: "Catalog product",
				productId: variantId,
				quantity: variant.quantity,
			});
			if (variant.quantity > 0) {
				await insertInventoryEvent(database, {
					actorUserId,
					category: "finished_good",
					eventType: "inward",
					productId: variantId,
					quantityAfter: variant.quantity,
					quantityBefore: 0,
					quantityDelta: variant.quantity,
					remarks: "Opening stock recorded during product creation",
				});
			}
			await reconcileProductInventoryAlerts(database, {
				actorUserId,
				productId: variantId,
			});
		}
	});

	const createdProduct = await findProductWithVariants(productId);
	if (!createdProduct) {
		throw new Error("Failed to create product");
	}
	return createdProduct;
};

export const updateProduct = async (
	productId: string,
	values: ProductMutationValues,
	actorUserId: string
) => {
	const catalogValues = normalizeProductCatalogValues(values);
	const variants = getProductVariantInputs(values);

	await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;
		const [currentProduct] = await database
			.select({
				categoryCode: product.categoryCode,
				productCode: product.productCode,
			})
			.from(product)
			.where(eq(product.id, productId))
			.limit(1);
		if (!(currentProduct?.categoryCode && currentProduct.productCode)) {
			throw new Error("Product not found");
		}
		const existingVariants = await database
			.select({ id: product.id, quantity: productInventory.quantity })
			.from(product)
			.innerJoin(productInventory, eq(productInventory.productId, product.id))
			.where(
				and(
					eq(product.categoryCode, currentProduct.categoryCode),
					eq(product.productCode, currentProduct.productCode)
				)
			)
			.orderBy(asc(product.createdAt));
		const existingVariantById = new Map(
			existingVariants.map((entry) => [entry.id, entry])
		);
		const seenVariantIds: string[] = [];
		for (const [variantIndex, variant] of variants.entries()) {
			const variantValues = normalizeProductVariantValues(
				variant,
				catalogValues
			);
			const variantId =
				variant.id || existingVariants[variantIndex]?.id || crypto.randomUUID();
			seenVariantIds.push(variantId);
			if (existingVariantById.has(variantId)) {
				await database
					.update(product)
					.set({
						...catalogValues,
						...variantValues,
						isActive: variant.isActive ?? true,
					})
					.where(eq(product.id, variantId));
				await reconcileProductInventoryAlerts(database, {
					actorUserId,
					productId: variantId,
				});
				continue;
			}
			const openingStock = variant.quantity ?? 0;
			await database.insert(product).values({
				id: variantId,
				...catalogValues,
				...variantValues,
				isActive: variant.isActive ?? true,
			});
			await database.insert(productInventory).values({
				lastInventoryUpdatedAt: openingStock > 0 ? new Date() : null,
				pointsAdded: 0,
				pointsReason: "Catalog product",
				productId: variantId,
				quantity: openingStock,
			});
		}
		if (seenVariantIds.length > 0) {
			await database
				.update(product)
				.set({ isActive: false })
				.where(
					and(
						inArray(
							product.id,
							existingVariants.map((entry) => entry.id)
						),
						notInArray(product.id, seenVariantIds)
					)
				);
		}
	});

	return findProductWithVariants(productId);
};

export const setProductActive = async (
	productId: string,
	isActive: boolean
) => {
	const currentProduct = await findProductWithVariants(productId);
	const productIds = currentProduct?.variants.map((variant) => variant.id) ?? [
		productId,
	];
	await db
		.update(product)
		.set({ isActive })
		.where(inArray(product.id, productIds));
};
