import { mkdir, unlink } from "node:fs/promises";
import path from "node:path";
import { env } from "@agro-erp-fullstack/env/server";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import multer from "multer";
import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import {
	findCropPdf,
	findCropWithSchedules,
	listCrops,
} from "./crops.repository";
import { createCropSchema } from "./crops.schemas";
import {
	changeCropActiveState,
	createCrop,
	removeCropPdf,
	updateCrop,
} from "./crops.service";

const maxPdfFileSizeBytes = 50 * 1024 * 1024;
const mojibakeFilenamePattern = /(?:Ã|Â|à¤|à¥)/;

const normalizeUploadedFileName = (fileName: string) => {
	if (!mojibakeFilenamePattern.test(fileName)) {
		return fileName;
	}
	return Buffer.from(fileName, "latin1").toString("utf8");
};

const upload = multer({
	limits: { fileSize: maxPdfFileSizeBytes },
	storage: multer.diskStorage({
		destination: async (_request, _file, callback) => {
			await mkdir(env.CROP_FILE_SAVE_PATH, { recursive: true });
			callback(null, env.CROP_FILE_SAVE_PATH);
		},
		filename: (_request, file, callback) => {
			const originalName = normalizeUploadedFileName(file.originalname);
			callback(null, `${crypto.randomUUID()}${path.extname(originalName)}`);
		},
	}),
	fileFilter: (_request, file, callback) => {
		if (file.mimetype !== "application/pdf") {
			callback(new Error("Only PDF files are allowed"));
			return;
		}
		callback(null, true);
	},
});

const getUploadedPdf = (request: Request) =>
	"file" in request
		? (request.file as Express.Multer.File | undefined)
		: undefined;

const getUploadedPdfOriginalName = (
	uploadedPdf: Express.Multer.File | undefined
) => (uploadedPdf ? normalizeUploadedFileName(uploadedPdf.originalname) : null);

const deletePdfIfPresent = async (fileName: null | string | undefined) => {
	if (!fileName) {
		return;
	}
	await unlink(path.join(env.CROP_FILE_SAVE_PATH, fileName)).catch(
		() => undefined
	);
};

const parseMaybeJson = (value: unknown) => {
	if (typeof value !== "string") {
		return value;
	}
	try {
		return JSON.parse(value) as unknown;
	} catch {
		return value;
	}
};

const getCropBody = (request: Request) => ({
	...request.body,
	schedules: parseMaybeJson(request.body?.schedules),
});

export const cropsRouter: Router = createRouter();

cropsRouter.get("/", async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "crop:list",
			forbiddenMessage: "You do not have access to crops",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}
		const rows = await listCrops(session.user.role === "superadmin");
		response.status(200).json({
			crops: rows.map((row) => ({
				...row,
				updatedAt: row.updatedAt.toISOString(),
			})),
			success: true,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

cropsRouter.get("/:cropId", async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "crop:read",
			forbiddenMessage: "You do not have access to crops",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}
		const { cropId } = request.params as { cropId: string };
		const currentCrop = await findCropWithSchedules(
			cropId,
			session.user.role === "superadmin"
		);
		if (!currentCrop) {
			response.status(404).json({ message: "Crop not found", success: false });
			return;
		}
		response.status(200).json({ crop: currentCrop, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

cropsRouter.post(
	"/",
	upload.single("pdf"),
	async (request: Request, response: Response) => {
		const uploadedPdf = getUploadedPdf(request);
		try {
			const session = await requireActionSession(request, response, {
				action: "crop:create",
				forbiddenMessage: "You do not have access to create crops",
				forbiddenSuccess: false,
			});
			if (!session) {
				await deletePdfIfPresent(uploadedPdf?.filename);
				return;
			}
			const values = createCropSchema.parse(getCropBody(request));
			const createdCrop = await createCrop({
				name: values.name.trim(),
				pdf: uploadedPdf
					? {
							fileName: uploadedPdf.filename,
							mimeType: uploadedPdf.mimetype,
							originalName: getUploadedPdfOriginalName(uploadedPdf),
							sizeBytes: uploadedPdf.size,
						}
					: undefined,
				schedules: values.schedules,
			});
			response.status(201).json({
				crop: createdCrop,
				success: true,
			});
		} catch (error) {
			await deletePdfIfPresent(uploadedPdf?.filename);
			sendErrorResponse(response, error, { success: false });
		}
	}
);

cropsRouter.patch(
	"/:cropId",
	upload.single("pdf"),
	async (request: Request, response: Response) => {
		const uploadedPdf = getUploadedPdf(request);
		try {
			const session = await requireActionSession(request, response, {
				action: "crop:update",
				forbiddenMessage: "You do not have access to update crops",
				forbiddenSuccess: false,
			});
			if (!session) {
				await deletePdfIfPresent(uploadedPdf?.filename);
				return;
			}
			const { cropId } = request.params as { cropId: string };
			const values = createCropSchema.parse(getCropBody(request));
			const currentCrop = await updateCrop(cropId, {
				name: values.name.trim(),
				pdf: uploadedPdf
					? {
							fileName: uploadedPdf.filename,
							mimeType: uploadedPdf.mimetype,
							originalName: getUploadedPdfOriginalName(uploadedPdf),
							sizeBytes: uploadedPdf.size,
						}
					: undefined,
				schedules: values.schedules,
			});
			if (!currentCrop) {
				await deletePdfIfPresent(uploadedPdf?.filename);
				response
					.status(404)
					.json({ message: "Crop not found", success: false });
				return;
			}
			if (uploadedPdf) {
				await deletePdfIfPresent(currentCrop.pdfFileName);
			}
			response.status(200).json({ success: true });
		} catch (error) {
			await deletePdfIfPresent(uploadedPdf?.filename);
			sendErrorResponse(response, error, { success: false });
		}
	}
);

cropsRouter.get(
	"/:cropId/pdf",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "crop:read_pdf",
				forbiddenMessage: "You do not have access to this crop PDF",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			const { cropId } = request.params as { cropId: string };
			const currentCrop = await findCropPdf(
				cropId,
				session.user.role === "superadmin"
			);
			if (!currentCrop?.pdfFileName) {
				response
					.status(404)
					.json({ message: "Crop PDF not found", success: false });
				return;
			}
			response.setHeader(
				"Content-Type",
				currentCrop.pdfMimeType ?? "application/pdf"
			);
			const originalName = normalizeUploadedFileName(
				path.basename(currentCrop.pdfOriginalName ?? "crop.pdf")
			);
			const safeOriginalName = originalName.replaceAll(/[\r\n"]/g, "_");
			const fallbackFileName = safeOriginalName.replace(/[^\x20-\x7E]/g, "_");
			response.setHeader(
				"Content-Disposition",
				`inline; filename="${fallbackFileName}"; filename*=UTF-8''${encodeURIComponent(safeOriginalName)}`
			);
			response.sendFile(
				path.join(env.CROP_FILE_SAVE_PATH, currentCrop.pdfFileName)
			);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

cropsRouter.delete(
	"/:cropId/pdf",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "crop:update",
				forbiddenMessage: "You do not have access to update crops",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			const { cropId } = request.params as { cropId: string };
			const currentCrop = await removeCropPdf(cropId);
			if (!currentCrop) {
				response
					.status(404)
					.json({ message: "Crop not found", success: false });
				return;
			}
			await deletePdfIfPresent(currentCrop.pdfFileName);
			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

const setCropActiveHandler =
	(isActive: boolean) => async (request: Request, response: Response) => {
		try {
			const action = isActive ? "crop:reactivate" : "crop:deactivate";
			const session = await requireActionSession(request, response, {
				action,
				forbiddenMessage: `You do not have access to ${isActive ? "reactivate" : "deactivate"} crops`,
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			const { cropId } = request.params as { cropId: string };
			await changeCropActiveState(cropId, isActive);
			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	};

cropsRouter.post("/:cropId/deactivate", setCropActiveHandler(false));
cropsRouter.post("/:cropId/reactivate", setCropActiveHandler(true));
