import type { CropScheduleInput } from "./crops.repository";
import {
	clearCropPdf,
	createCropRecord,
	setCropActive,
	updateCropRecord,
} from "./crops.repository";

interface CropWriteInput {
	name: string;
	pdf?: {
		fileName: string;
		mimeType: string;
		originalName: null | string;
		sizeBytes: number;
	};
	schedules: CropScheduleInput[];
}

export const createCrop = (input: CropWriteInput) => createCropRecord(input);

export const updateCrop = (cropId: string, input: CropWriteInput) =>
	updateCropRecord(cropId, input);

export const removeCropPdf = (cropId: string) => clearCropPdf(cropId);

export const changeCropActiveState = (cropId: string, isActive: boolean) =>
	setCropActive(cropId, isActive);
