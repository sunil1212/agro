import { db } from "@agro-erp-fullstack/db";
import { crop, cropSchedule } from "@agro-erp-fullstack/db/schema/farmer";
import { and, asc, count, eq, sql } from "drizzle-orm";

export const listCrops = (includeInactive: boolean) => {
	const scheduleCount = db
		.select({ count: count() })
		.from(cropSchedule)
		.where(
			and(eq(cropSchedule.cropId, crop.id), eq(cropSchedule.isActive, true))
		)
		.limit(1);
	return db
		.select({
			id: crop.id,
			name: crop.name,
			isActive: crop.isActive,
			hasPdf: crop.pdfFileName ? sql<boolean>`true` : sql<boolean>`false`,
			pdfOriginalName: crop.pdfOriginalName,
			scheduleCount: sql<number>`coalesce((${scheduleCount}), 0)`,
			updatedAt: crop.updatedAt,
		})
		.from(crop)
		.where(includeInactive ? undefined : eq(crop.isActive, true))
		.orderBy(asc(crop.name));
};

export const findCropWithSchedules = async (
	cropId: string,
	includeInactive: boolean
) => {
	const [currentCrop] = await db
		.select()
		.from(crop)
		.where(
			and(
				eq(crop.id, cropId),
				includeInactive ? undefined : eq(crop.isActive, true)
			)
		)
		.limit(1);
	if (!currentCrop) {
		return null;
	}
	const schedules = await db
		.select()
		.from(cropSchedule)
		.where(
			and(eq(cropSchedule.cropId, cropId), eq(cropSchedule.isActive, true))
		)
		.orderBy(asc(cropSchedule.startDay));
	return { ...currentCrop, schedules };
};

export const findCropPdf = async (cropId: string, includeInactive = true) => {
	const [record] = await db
		.select({
			pdfFileName: crop.pdfFileName,
			pdfMimeType: crop.pdfMimeType,
			pdfOriginalName: crop.pdfOriginalName,
		})
		.from(crop)
		.where(
			and(
				eq(crop.id, cropId),
				includeInactive ? undefined : eq(crop.isActive, true)
			)
		)
		.limit(1);
	return record ?? null;
};

export interface CropScheduleInput {
	endDay: number;
	instruction: string;
	startDay: number;
}

interface CropWriteInput {
	name: string;
	pdf?: {
		fileName: string;
		mimeType: string;
		originalName: null | string;
		sizeBytes: number;
	};
	schedules: CropScheduleInput[];
}

export const createCropRecord = async (input: CropWriteInput) => {
	const cropId = crypto.randomUUID();
	await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;
		await database.insert(crop).values({
			id: cropId,
			isActive: true,
			name: input.name,
			pdfFileName: input.pdf?.fileName ?? null,
			pdfMimeType: input.pdf?.mimeType ?? null,
			pdfOriginalName: input.pdf?.originalName ?? null,
			pdfSizeBytes: input.pdf?.sizeBytes ?? null,
			pdfUploadedAt: input.pdf ? new Date() : null,
		});
		await database.insert(cropSchedule).values(
			input.schedules.map((schedule) => ({
				...schedule,
				id: crypto.randomUUID(),
				cropId,
				instruction: schedule.instruction.trim(),
			}))
		);
	});
	return { id: cropId, name: input.name };
};

export const updateCropRecord = async (
	cropId: string,
	input: CropWriteInput
) => {
	const currentPdf = await findCropPdf(cropId);
	if (!currentPdf) {
		return null;
	}
	await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;
		await database
			.update(crop)
			.set({
				name: input.name,
				...(input.pdf
					? {
							pdfFileName: input.pdf.fileName,
							pdfMimeType: input.pdf.mimeType,
							pdfOriginalName: input.pdf.originalName,
							pdfSizeBytes: input.pdf.sizeBytes,
							pdfUploadedAt: new Date(),
						}
					: {}),
			})
			.where(eq(crop.id, cropId));
		await database
			.update(cropSchedule)
			.set({ isActive: false })
			.where(
				and(eq(cropSchedule.cropId, cropId), eq(cropSchedule.isActive, true))
			);
		await database.insert(cropSchedule).values(
			input.schedules.map((schedule) => ({
				...schedule,
				id: crypto.randomUUID(),
				cropId,
				isActive: true,
				instruction: schedule.instruction.trim(),
			}))
		);
	});
	return currentPdf;
};

export const clearCropPdf = async (cropId: string) => {
	const currentPdf = await findCropPdf(cropId);
	if (!currentPdf) {
		return null;
	}
	await db
		.update(crop)
		.set({
			pdfFileName: null,
			pdfMimeType: null,
			pdfOriginalName: null,
			pdfSizeBytes: null,
			pdfUploadedAt: null,
		})
		.where(eq(crop.id, cropId));
	return currentPdf;
};

export const setCropActive = async (cropId: string, isActive: boolean) => {
	await db.update(crop).set({ isActive }).where(eq(crop.id, cropId));
};
