import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";

import { requireActionSession } from "../../auth/session";
import { importConsignmentsSchema } from "../../lib/admin";
import { sendErrorResponse } from "../../lib/http";
import {
	deleteUnusedConsignment,
	importConsignments,
	listConsignments,
} from "../../services/consignments";

export const consignmentsRouter: Router = createRouter();

const requireConsignmentSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "consignment:manage",
		forbiddenMessage: "You do not have access to manage consignments",
		forbiddenSuccess: false,
	});

consignmentsRouter.get("/", async (request: Request, response: Response) => {
	try {
		if (!(await requireConsignmentSession(request, response))) {
			return;
		}

		const consignments = await listConsignments();
		response.status(200).json({ consignments, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

consignmentsRouter.post(
	"/import",
	async (request: Request, response: Response) => {
		try {
			if (!(await requireConsignmentSession(request, response))) {
				return;
			}

			const values = importConsignmentsSchema.parse(request.body);
			const result = await importConsignments(values.consignments);
			response.status(200).json({ ...result, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

consignmentsRouter.delete(
	"/:consignmentId",
	async (request: Request, response: Response) => {
		try {
			if (!(await requireConsignmentSession(request, response))) {
				return;
			}

			const { consignmentId } = request.params as { consignmentId: string };
			const result = await deleteUnusedConsignment(consignmentId);

			if (result === "has_order_history") {
				response.status(409).json({
					message: "Consignment has order history and cannot be deleted",
					success: false,
				});
				return;
			}

			if (result === "not_found") {
				response
					.status(404)
					.json({ message: "Consignment not found", success: false });
				return;
			}

			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);
