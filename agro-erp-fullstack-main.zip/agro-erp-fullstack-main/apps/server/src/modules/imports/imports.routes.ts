import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import { getUserManagerCode } from "../../services/accounts";
import { importFarmers } from "../../services/farmer-import";
import { importOrders } from "../../services/order-import";
import {
	importFarmerRowsSchema,
	importOrderRowsSchema,
} from "./imports.schemas";

export const importsRouter: Router = createRouter();

const requireAdminImportSession = async (
	request: Request,
	response: Response,
	resource: "farmers" | "orders"
) => {
	const session = await requireActionSession(request, response, {
		action: "farmer:manage",
		forbiddenMessage: `Only admins can import ${resource}`,
		forbiddenSuccess: false,
	});
	if (!session) {
		return null;
	}
	if (session.user.role !== "admin") {
		response.status(403).json({
			message: `Only admins can import ${resource}`,
			success: false,
		});
		return null;
	}
	return session;
};

importsRouter.post(
	"/farmers/import",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAdminImportSession(
				request,
				response,
				"farmers"
			);
			if (!session) {
				return;
			}
			const managerCode = await getUserManagerCode(session.user.id);
			if (!managerCode) {
				response.status(409).json({
					message: "Admin account does not have a manager code",
					success: false,
				});
				return;
			}
			const { rows } = importFarmerRowsSchema.parse(request.body);
			const result = await importFarmers(rows, managerCode);
			response.status(200).json({ ...result, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

importsRouter.post(
	"/orders/import",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAdminImportSession(
				request,
				response,
				"orders"
			);
			if (!session) {
				return;
			}
			const managerCode = await getUserManagerCode(session.user.id);
			if (!managerCode) {
				response.status(409).json({
					message: "Admin account does not have a manager code",
					success: false,
				});
				return;
			}
			const { rows } = importOrderRowsSchema.parse(request.body);
			const result = await importOrders({
				adminUserId: session.user.id,
				managerCode,
				rows,
			});
			response.status(200).json({ ...result, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);
