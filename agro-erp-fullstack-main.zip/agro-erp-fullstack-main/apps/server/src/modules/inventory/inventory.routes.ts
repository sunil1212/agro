import { db } from "@agro-erp-fullstack/db";
import { user } from "@agro-erp-fullstack/db/schema/auth";
import {
	inventoryAlert,
	inventoryEvent,
	inventoryItem,
} from "@agro-erp-fullstack/db/schema/inventory";
import {
	order,
	orderConsignment,
	orderItem,
	postOrderFollowUp,
} from "@agro-erp-fullstack/db/schema/order";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { and, asc, desc, eq, gte, inArray, sql } from "drizzle-orm";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";

import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import {
	dispatchStatuses,
	getDispatchableQuantity,
	getNextDispatchStatus,
	insertInventoryEvent,
	inventoryAlertStatuses,
	reconcileInventoryItemLowStockAlert,
	reconcileProductInventoryAlerts,
} from "../../lib/inventory";
import {
	createFollowUpUserNameMap,
	createInventoryItemSchema,
	dispatchStatusSchema,
	type FollowUpSlot,
	followUpUpdateSchema,
	formatInventoryQuantity,
	getFollowUps,
	getFollowUpUserIds,
	getStartOfToday,
	getUserNameById,
	normalizeFollowUpInput,
	type StockInwardValues,
	type StockOutwardValues,
	stockInwardSchema,
	stockOutwardSchema,
	updateFinishedGoodInventorySchema,
	updateInventoryItemSchema,
} from "../../lib/inventory-routes";
import {
	getBookingExport,
	getPackingExport,
} from "../../services/order-exports";
import {
	getBranchByManagerCode,
	listBranches,
} from "../branches/branches.repository";

const inventoryRouter: Router = createRouter();

const postOrderFollowUpSelection = {
	followUp1Text: postOrderFollowUp.followUp1Text,
	followUp1UpdatedAt: postOrderFollowUp.followUp1UpdatedAt,
	followUp1UpdatedByUserId: postOrderFollowUp.followUp1UpdatedByUserId,
	followUp2Text: postOrderFollowUp.followUp2Text,
	followUp2UpdatedAt: postOrderFollowUp.followUp2UpdatedAt,
	followUp2UpdatedByUserId: postOrderFollowUp.followUp2UpdatedByUserId,
	followUp3Text: postOrderFollowUp.followUp3Text,
	followUp3UpdatedAt: postOrderFollowUp.followUp3UpdatedAt,
	followUp3UpdatedByUserId: postOrderFollowUp.followUp3UpdatedByUserId,
	followUp4Text: postOrderFollowUp.followUp4Text,
	followUp4UpdatedAt: postOrderFollowUp.followUp4UpdatedAt,
	followUp4UpdatedByUserId: postOrderFollowUp.followUp4UpdatedByUserId,
} as const;

const requireInventoryManagerSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "inventory:manage",
		forbiddenMessage: "Only admins and warehouse team can perform this action",
		forbiddenSuccess: false,
	});

const requireFinishedGoodsReadSession = (
	request: Request,
	response: Response
) =>
	requireActionSession(request, response, {
		action: "inventory:read_finished_goods",
		forbiddenMessage: "You do not have access to inventory",
		forbiddenSuccess: false,
	});

const getItemDisplayName = (category: string) =>
	category === "raw_material" ? "Raw material" : "Packing material";

type InventoryDb = typeof db;

interface BranchStatusCount {
	count: number;
	managerCode: string;
	status: typeof order.$inferSelect.status;
}

const getBranchStatusCounts = (
	managerCode: string,
	statusCounts: BranchStatusCount[]
) => {
	const counts = {
		confirmed: 0,
		dispatched: 0,
		returnInTransit: 0,
		returnInWarehouse: 0,
	};

	for (const row of statusCounts) {
		if (row.managerCode !== managerCode) {
			continue;
		}

		switch (row.status) {
			case "confirmed":
				counts.confirmed = row.count;
				break;
			case "dispatched":
				counts.dispatched = row.count;
				break;
			case "return_in_transit":
				counts.returnInTransit = row.count;
				break;
			case "return_in_warehouse":
				counts.returnInWarehouse = row.count;
				break;
			default:
				break;
		}
	}

	return counts;
};

async function deductConfirmedOrderStock(
	database: InventoryDb,
	values: {
		actorUserId: string;
		orderId: string;
	}
) {
	const items = await database
		.select({
			productId: product.id,
			quantity: orderItem.quantity,
		})
		.from(orderItem)
		.innerJoin(product, eq(product.skuCode, orderItem.productSku))
		.where(eq(orderItem.orderId, values.orderId));

	for (const item of items) {
		const currentRows = await database
			.select({
				quantity: productInventory.quantity,
				reservedQuantity: productInventory.reservedQuantity,
			})
			.from(productInventory)
			.where(eq(productInventory.productId, item.productId))
			.limit(1);
		const currentProduct = currentRows[0];

		if (!currentProduct) {
			throw new Error("Product inventory not found for SKU");
		}

		if (currentProduct.quantity < item.quantity) {
			throw new Error("Insufficient stock for product");
		}

		const [updatedProduct] = await database
			.update(productInventory)
			.set({
				lastInventoryUpdatedAt: new Date(),
				quantity: sql`${productInventory.quantity} - ${item.quantity}`,
			})
			.where(
				and(
					eq(productInventory.productId, item.productId),
					sql`${productInventory.quantity} >= ${item.quantity}`
				)
			)
			.returning({
				quantity: productInventory.quantity,
				reservedQuantity: productInventory.reservedQuantity,
			});

		if (!updatedProduct) {
			throw new Error("Insufficient stock for product");
		}

		await insertInventoryEvent(database, {
			actorUserId: values.actorUserId,
			category: "finished_good",
			eventType: "order_dispatch",
			productId: item.productId,
			quantityAfter: updatedProduct.quantity,
			quantityBefore: currentProduct.quantity,
			quantityDelta: -item.quantity,
			referenceOrderId: values.orderId,
			reservedAfter: updatedProduct.reservedQuantity,
			reservedBefore: currentProduct.reservedQuantity,
		});
		await reconcileProductInventoryAlerts(database, {
			actorUserId: values.actorUserId,
			productId: item.productId,
		});
	}
}

async function recordFinishedGoodsInward(
	database: InventoryDb,
	values: StockInwardValues,
	actorUserId: string
) {
	if (!values.productId) {
		throw new Error("Product is required for finished goods inward");
	}

	const currentRows = await database
		.select({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		})
		.from(productInventory)
		.where(eq(productInventory.productId, values.productId))
		.limit(1);
	const currentProduct = currentRows[0];
	if (!currentProduct) {
		throw new Error("Finished good not found");
	}

	const [updatedProduct] = await database
		.update(productInventory)
		.set({
			lastInventoryUpdatedAt: new Date(),
			quantity: sql`${productInventory.quantity} + ${values.quantityAdded}`,
		})
		.where(eq(productInventory.productId, values.productId))
		.returning({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		});
	if (!updatedProduct) {
		throw new Error("Failed to add finished goods stock");
	}

	await insertInventoryEvent(database, {
		actorUserId,
		batchNumber: values.batchNumber?.trim() || null,
		category: values.category,
		eventType: "inward",
		manualOrderNumber: values.manualOrderNumber?.trim() || null,
		productId: values.productId,
		quantityAfter: updatedProduct.quantity,
		quantityBefore: currentProduct.quantity,
		quantityDelta: values.quantityAdded,
		remarks: values.remarks?.trim() || null,
		reservedAfter: updatedProduct.reservedQuantity,
		reservedBefore: currentProduct.reservedQuantity,
		supplierName: values.supplierName?.trim() || null,
	});
	await reconcileProductInventoryAlerts(database, {
		actorUserId,
		productId: values.productId,
	});
}

async function recordMaterialInward(
	database: InventoryDb,
	values: StockInwardValues,
	actorUserId: string
) {
	if (!values.inventoryItemId) {
		throw new Error(`${getItemDisplayName(values.category)} is required`);
	}

	const currentRows = await database
		.select({ currentStock: inventoryItem.currentStock })
		.from(inventoryItem)
		.where(
			and(
				eq(inventoryItem.id, values.inventoryItemId),
				eq(inventoryItem.category, values.category)
			)
		)
		.limit(1);
	const currentItem = currentRows[0];
	if (!currentItem) {
		throw new Error("Inventory item not found");
	}

	const [updatedItem] = await database
		.update(inventoryItem)
		.set({
			currentStock: sql`${inventoryItem.currentStock} + ${values.quantityAdded}`,
			lastInventoryUpdatedAt: new Date(),
		})
		.where(eq(inventoryItem.id, values.inventoryItemId))
		.returning({ currentStock: inventoryItem.currentStock });
	if (!updatedItem) {
		throw new Error("Failed to add inventory stock");
	}

	await insertInventoryEvent(database, {
		actorUserId,
		batchNumber: values.batchNumber?.trim() || null,
		category: values.category,
		eventType: "inward",
		inventoryItemId: values.inventoryItemId,
		manualOrderNumber: values.manualOrderNumber?.trim() || null,
		quantityAfter: Number(updatedItem.currentStock),
		quantityBefore: Number(currentItem.currentStock),
		quantityDelta: values.quantityAdded,
		remarks: values.remarks?.trim() || null,
		supplierName: values.supplierName?.trim() || null,
	});
	await reconcileInventoryItemLowStockAlert(database, {
		actorUserId,
		inventoryItemId: values.inventoryItemId,
	});
}

async function recordFinishedGoodsOutward(
	database: InventoryDb,
	values: StockOutwardValues,
	actorUserId: string
) {
	if (!values.productId) {
		throw new Error("Product is required for finished goods outward");
	}

	const currentRows = await database
		.select({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		})
		.from(productInventory)
		.where(eq(productInventory.productId, values.productId))
		.limit(1);
	const currentProduct = currentRows[0];
	if (!currentProduct) {
		throw new Error("Finished good not found");
	}
	if (currentProduct.quantity < values.quantityReduced) {
		throw new Error("Outward quantity exceeds available stock");
	}

	const [updatedProduct] = await database
		.update(productInventory)
		.set({
			lastInventoryUpdatedAt: new Date(),
			quantity: sql`${productInventory.quantity} - ${values.quantityReduced}`,
		})
		.where(
			and(
				eq(productInventory.productId, values.productId),
				sql`${productInventory.quantity} >= ${values.quantityReduced}`
			)
		)
		.returning({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		});
	if (!updatedProduct) {
		throw new Error("Outward quantity exceeds available stock");
	}

	await insertInventoryEvent(database, {
		actorUserId,
		approvedByUserId: values.approvedByUserId,
		category: values.category,
		eventType: "outward",
		productId: values.productId,
		quantityAfter: updatedProduct.quantity,
		quantityBefore: currentProduct.quantity,
		quantityDelta: -values.quantityReduced,
		reason: values.reason.trim(),
		remarks: values.remarks?.trim() || null,
		reservedAfter: updatedProduct.reservedQuantity,
		reservedBefore: currentProduct.reservedQuantity,
	});
	await reconcileProductInventoryAlerts(database, {
		actorUserId,
		productId: values.productId,
	});
}

async function recordMaterialOutward(
	database: InventoryDb,
	values: StockOutwardValues,
	actorUserId: string
) {
	if (!values.inventoryItemId) {
		throw new Error(`${getItemDisplayName(values.category)} is required`);
	}

	const currentRows = await database
		.select({ currentStock: inventoryItem.currentStock })
		.from(inventoryItem)
		.where(
			and(
				eq(inventoryItem.id, values.inventoryItemId),
				eq(inventoryItem.category, values.category)
			)
		)
		.limit(1);
	const currentItem = currentRows[0];
	if (!currentItem) {
		throw new Error("Inventory item not found");
	}
	if (Number(currentItem.currentStock) < values.quantityReduced) {
		throw new Error("Outward quantity exceeds current stock");
	}

	const [updatedItem] = await database
		.update(inventoryItem)
		.set({
			currentStock: sql`${inventoryItem.currentStock} - ${values.quantityReduced}`,
			lastInventoryUpdatedAt: new Date(),
		})
		.where(
			and(
				eq(inventoryItem.id, values.inventoryItemId),
				sql`${inventoryItem.currentStock} >= ${values.quantityReduced}`
			)
		)
		.returning({ currentStock: inventoryItem.currentStock });
	if (!updatedItem) {
		throw new Error("Outward quantity exceeds current stock");
	}

	await insertInventoryEvent(database, {
		actorUserId,
		approvedByUserId: values.approvedByUserId,
		category: values.category,
		eventType: "outward",
		inventoryItemId: values.inventoryItemId,
		quantityAfter: Number(updatedItem.currentStock),
		quantityBefore: Number(currentItem.currentStock),
		quantityDelta: -values.quantityReduced,
		reason: values.reason.trim(),
		remarks: values.remarks?.trim() || null,
	});
	await reconcileInventoryItemLowStockAlert(database, {
		actorUserId,
		inventoryItemId: values.inventoryItemId,
	});
}

inventoryRouter.get(
	"/summary",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const [items, products, alerts, todayEvents] = await Promise.all([
				db
					.select({
						category: inventoryItem.category,
						currentStock: inventoryItem.currentStock,
					})
					.from(inventoryItem),
				db
					.select({
						minimumStockLevel: productInventory.minimumStockLevel,
						quantity: productInventory.quantity,
						reservedQuantity: productInventory.reservedQuantity,
					})
					.from(productInventory),
				db
					.select({
						alertType: inventoryAlert.alertType,
						id: inventoryAlert.id,
						message: inventoryAlert.message,
						status: inventoryAlert.status,
					})
					.from(inventoryAlert)
					.where(eq(inventoryAlert.status, "active"))
					.orderBy(desc(inventoryAlert.activeAt))
					.limit(8),
				db
					.select({
						eventType: inventoryEvent.eventType,
						quantityDelta: inventoryEvent.quantityDelta,
					})
					.from(inventoryEvent)
					.where(gte(inventoryEvent.createdAt, getStartOfToday())),
			]);

			const rawStock = items
				.filter((item) => item.category === "raw_material")
				.reduce((sum, item) => sum + Number(item.currentStock), 0);
			const packingStock = items
				.filter((item) => item.category === "packing_material")
				.reduce((sum, item) => sum + Number(item.currentStock), 0);
			const finishedStock = products.reduce(
				(sum, item) => sum + getDispatchableQuantity(item.quantity),
				0
			);
			const reservedStock = products.reduce(
				(sum, item) => sum + item.reservedQuantity,
				0
			);
			const stockInToday = todayEvents
				.filter((event) => event.eventType === "inward")
				.reduce((sum, event) => sum + Number(event.quantityDelta), 0);
			const stockOutToday = todayEvents
				.filter((event) => event.eventType === "outward")
				.reduce((sum, event) => sum + Math.abs(Number(event.quantityDelta)), 0);
			const reservedToday = todayEvents
				.filter((event) => event.eventType === "order_reservation")
				.reduce((sum, event) => sum + Math.abs(Number(event.quantityDelta)), 0);

			response.status(200).json({
				alerts,
				success: true,
				summary: {
					activeExpiryAlerts: alerts.filter(
						(alert) => alert.alertType === "expiring_product"
					).length,
					activeLowStockAlerts: alerts.filter(
						(alert) => alert.alertType === "low_stock"
					).length,
					finishedStock,
					packingStock,
					rawStock,
					reservedStock,
					stockInToday,
					stockOutToday,
					reservedToday,
				},
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.get("/items", async (request: Request, response: Response) => {
	try {
		const session = await requireInventoryManagerSession(request, response);
		if (!session) {
			return;
		}

		const category = request.query.category?.toString();
		const whereClause =
			category === "raw_material" || category === "packing_material"
				? eq(inventoryItem.category, category)
				: undefined;
		const items = await db
			.select()
			.from(inventoryItem)
			.where(whereClause)
			.orderBy(asc(inventoryItem.name));

		response.status(200).json({ items, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

inventoryRouter.post("/items", async (request: Request, response: Response) => {
	try {
		const session = await requireInventoryManagerSession(request, response);
		if (!session) {
			return;
		}

		const values = createInventoryItemSchema.parse(request.body);
		let createdItem: typeof inventoryItem.$inferSelect | undefined;
		await db.transaction(async (tx) => {
			const database = tx as unknown as typeof db;
			const [newItem] = await database
				.insert(inventoryItem)
				.values({
					id: crypto.randomUUID(),
					category: values.category,
					currentStock: formatInventoryQuantity(values.currentStock),
					itemCode: values.itemCode.trim(),
					lastInventoryUpdatedAt: new Date(),
					lowStockThreshold: formatInventoryQuantity(values.lowStockThreshold),
					name: values.name.trim(),
					supplierName: values.supplierName?.trim() || null,
					unit: values.unit.trim(),
				})
				.returning();

			if (!newItem) {
				throw new Error("Failed to create inventory item");
			}

			createdItem = newItem;
			await reconcileInventoryItemLowStockAlert(database, {
				actorUserId: session.user.id,
				inventoryItemId: newItem.id,
			});
		});

		if (!createdItem) {
			throw new Error("Failed to create inventory item");
		}

		response.status(201).json({ item: createdItem, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

inventoryRouter.patch(
	"/items/:itemId",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const { itemId } = request.params as { itemId: string };
			const values = updateInventoryItemSchema.parse(request.body);
			let updatedItem: typeof inventoryItem.$inferSelect | undefined;
			await db.transaction(async (tx) => {
				const database = tx as unknown as typeof db;
				const [nextItem] = await database
					.update(inventoryItem)
					.set({
						...(values.category ? { category: values.category } : {}),
						...(typeof values.currentStock === "number"
							? { currentStock: formatInventoryQuantity(values.currentStock) }
							: {}),
						...(values.itemCode ? { itemCode: values.itemCode.trim() } : {}),
						lastInventoryUpdatedAt: new Date(),
						...(typeof values.lowStockThreshold === "number"
							? {
									lowStockThreshold: formatInventoryQuantity(
										values.lowStockThreshold
									),
								}
							: {}),
						...(values.name ? { name: values.name.trim() } : {}),
						...(typeof values.supplierName === "string"
							? { supplierName: values.supplierName.trim() || null }
							: {}),
						...(values.unit ? { unit: values.unit.trim() } : {}),
					})
					.where(eq(inventoryItem.id, itemId))
					.returning();

				if (!nextItem) {
					return;
				}

				updatedItem = nextItem;
				await reconcileInventoryItemLowStockAlert(database, {
					actorUserId: session.user.id,
					inventoryItemId: itemId,
				});
			});

			if (!updatedItem) {
				response
					.status(404)
					.json({ message: "Inventory item not found", success: false });
				return;
			}

			response.status(200).json({ item: updatedItem, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.get(
	"/finished-goods",
	async (request: Request, response: Response) => {
		try {
			const session = await requireFinishedGoodsReadSession(request, response);
			if (!session) {
				return;
			}

			const products = await db
				.select({
					batchNumber: productInventory.batchNumber,
					dispatchableQuantity: productInventory.quantity,
					expiryDate: productInventory.expiryDate,
					id: product.id,
					lastInventoryUpdatedAt: productInventory.lastInventoryUpdatedAt,
					minimumStockLevel: productInventory.minimumStockLevel,
					name: product.name,
					packageQuantity: product.packageQuantity,
					packageUnit: product.packageUnit,
					packagingType: product.packagingType,
					quantity: productInventory.quantity,
					reservedQuantity: productInventory.reservedQuantity,
					skuCode: product.skuCode,
					warehouseLocation: productInventory.warehouseLocation,
				})
				.from(product)
				.innerJoin(productInventory, eq(productInventory.productId, product.id))
				.orderBy(asc(product.name), asc(product.packageQuantity));

			response.status(200).json({ products, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.patch(
	"/finished-goods/:productId",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const { productId } = request.params as { productId: string };
			const values = updateFinishedGoodInventorySchema.parse(request.body);
			let updatedProduct: typeof productInventory.$inferSelect | undefined;
			await db.transaction(async (tx) => {
				const database = tx as unknown as typeof db;
				if (typeof values.skuCode === "string") {
					await database
						.update(product)
						.set({ skuCode: values.skuCode.trim() })
						.where(eq(product.id, productId));
				}

				const [nextProduct] = await database
					.update(productInventory)
					.set({
						...(typeof values.batchNumber === "string"
							? { batchNumber: values.batchNumber.trim() || null }
							: {}),
						...(values.expiryDate === undefined
							? {}
							: { expiryDate: values.expiryDate || null }),
						lastInventoryUpdatedAt: new Date(),
						...(typeof values.minimumStockLevel === "number"
							? { minimumStockLevel: values.minimumStockLevel }
							: {}),
						...(typeof values.warehouseLocation === "string"
							? { warehouseLocation: values.warehouseLocation.trim() || null }
							: {}),
					})
					.where(eq(productInventory.productId, productId))
					.returning();

				if (!nextProduct) {
					return;
				}

				updatedProduct = nextProduct;
				await reconcileProductInventoryAlerts(database, {
					actorUserId: session.user.id,
					productId,
				});
			});

			if (!updatedProduct) {
				response
					.status(404)
					.json({ message: "Finished good not found", success: false });
				return;
			}

			response.status(200).json({ product: updatedProduct, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.post(
	"/inward",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const values = stockInwardSchema.parse(request.body);

			await db.transaction(async (tx) => {
				const database = tx as unknown as typeof db;
				if (values.category === "finished_good") {
					await recordFinishedGoodsInward(database, values, session.user.id);
					return;
				}

				await recordMaterialInward(database, values, session.user.id);
			});

			response.status(201).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.post(
	"/outward",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const values = stockOutwardSchema.parse(request.body);
			await db.transaction(async (tx) => {
				const database = tx as unknown as typeof db;
				if (values.category === "finished_good") {
					await recordFinishedGoodsOutward(database, values, session.user.id);
					return;
				}

				await recordMaterialOutward(database, values, session.user.id);
			});

			response.status(201).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.get("/events", async (request: Request, response: Response) => {
	try {
		const session = await requireInventoryManagerSession(request, response);
		if (!session) {
			return;
		}

		const events = await db
			.select({
				actorName: user.name,
				category: inventoryEvent.category,
				createdAt: inventoryEvent.createdAt,
				eventType: inventoryEvent.eventType,
				id: inventoryEvent.id,
				inventoryItemId: inventoryEvent.inventoryItemId,
				productId: inventoryEvent.productId,
				quantityAfter: inventoryEvent.quantityAfter,
				quantityBefore: inventoryEvent.quantityBefore,
				quantityDelta: inventoryEvent.quantityDelta,
				reason: inventoryEvent.reason,
				remarks: inventoryEvent.remarks,
			})
			.from(inventoryEvent)
			.innerJoin(user, eq(user.id, inventoryEvent.actorUserId))
			.orderBy(desc(inventoryEvent.createdAt))
			.limit(100);

		response.status(200).json({ events, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

inventoryRouter.get("/alerts", async (request: Request, response: Response) => {
	try {
		const session = await requireInventoryManagerSession(request, response);
		if (!session) {
			return;
		}

		const status = request.query.status?.toString();
		const whereClause = inventoryAlertStatuses.includes(
			status as (typeof inventoryAlertStatuses)[number]
		)
			? eq(
					inventoryAlert.status,
					status as (typeof inventoryAlertStatuses)[number]
				)
			: undefined;
		const alerts = await db
			.select({
				activeAt: inventoryAlert.activeAt,
				alertType: inventoryAlert.alertType,
				category: inventoryAlert.category,
				id: inventoryAlert.id,
				inventoryItemId: inventoryAlert.inventoryItemId,
				message: inventoryAlert.message,
				productId: inventoryAlert.productId,
				resolvedAt: inventoryAlert.resolvedAt,
				status: inventoryAlert.status,
				thresholdValue: inventoryAlert.thresholdValue,
				triggeredValue: inventoryAlert.triggeredValue,
			})
			.from(inventoryAlert)
			.where(whereClause)
			.orderBy(desc(inventoryAlert.activeAt));

		response.status(200).json({ alerts, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

inventoryRouter.get(
	"/branches",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const branches = await listBranches(db);

			const statusCounts: BranchStatusCount[] = await db
				.select({
					count: sql<number>`count(*)::int`,
					managerCode: sql<string>`user_manager_code.manager_code`,
					status: order.status,
				})
				.from(order)
				.innerJoin(user, eq(user.id, order.createdByUserId))
				.innerJoin(
					sql`user_manager_code`,
					sql`user_manager_code.user_id = ${user.id}`
				)
				.where(
					inArray(order.status, [
						"confirmed",
						"dispatched",
						"return_in_transit",
						"return_in_warehouse",
					])
				)
				.groupBy(sql`user_manager_code.manager_code`, order.status);

			const branchSummaries = branches.map((branch) => ({
				adminName: branch.adminName,
				adminUserId: branch.adminUserId,
				counts: getBranchStatusCounts(branch.managerCode, statusCounts),
				managerCode: branch.managerCode,
			}));

			response.status(200).json({ branches: branchSummaries, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.get(
	"/branches/:managerCode/orders",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const { managerCode } = request.params as { managerCode: string };
			const branch = await getBranchByManagerCode(db, managerCode);

			if (!branch) {
				response
					.status(404)
					.json({ message: "Branch not found", success: false });
				return;
			}

			const statusFilter = request.query.status?.toString();
			const warehouseStatuses =
				statusFilter &&
				[
					"confirmed",
					"dispatched",
					"return_in_transit",
					"return_in_warehouse",
				].includes(statusFilter)
					? [
							statusFilter as
								| "confirmed"
								| "dispatched"
								| "return_in_transit"
								| "return_in_warehouse",
						]
					: [
							"confirmed" as const,
							"dispatched" as const,
							"return_in_transit" as const,
							"return_in_warehouse" as const,
						];

			const dispatchOrders = await db
				.select({
					approvedAt: order.approvedAt,
					approvedByUserId: order.approvedByUserId,
					consignmentNumber: orderConsignment.consignmentNumber,
					createdAt: order.createdAt,
					dispatchedAt: order.dispatchedAt,
					...postOrderFollowUpSelection,
					id: order.id,
					orderId: order.orderId,
					status: order.status,
				})
				.from(order)
				.innerJoin(user, eq(user.id, order.createdByUserId))
				.innerJoin(
					sql`user_manager_code`,
					sql`user_manager_code.user_id = ${user.id}`
				)
				.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
				.leftJoin(postOrderFollowUp, eq(postOrderFollowUp.orderId, order.id))
				.where(
					and(
						sql`user_manager_code.manager_code = ${managerCode}`,
						inArray(order.status, warehouseStatuses)
					)
				)
				.orderBy(asc(order.createdAt));

			const items = dispatchOrders.length
				? await db
						.select({
							orderId: orderItem.orderId,
							productId: product.id,
							productName: product.name,
							productSku: orderItem.productSku,
							quantity: orderItem.quantity,
						})
						.from(orderItem)
						.innerJoin(product, eq(product.skuCode, orderItem.productSku))
						.where(
							inArray(
								orderItem.orderId,
								dispatchOrders.map((currentOrder) => currentOrder.id)
							)
						)
				: [];
			const userNameById = await getUserNameById(
				dispatchOrders.flatMap((currentOrder) => [
					...getFollowUpUserIds(currentOrder),
					...(currentOrder.approvedByUserId
						? [currentOrder.approvedByUserId]
						: []),
				])
			);

			response.status(200).json({
				orders: dispatchOrders.map((currentOrder) => ({
					...currentOrder,
					approvedByName: currentOrder.approvedByUserId
						? (userNameById.get(currentOrder.approvedByUserId) ?? null)
						: null,
					followUps: getFollowUps(currentOrder, session.user.id, userNameById),
					items: items.filter((item) => item.orderId === currentOrder.id),
					nextStatus: getNextDispatchStatus(
						currentOrder.status as (typeof dispatchStatuses)[number]
					),
				})),
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.patch(
	"/dispatch/orders/:orderId/follow-up",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			if (session.user.role !== "warehouse") {
				response.status(403).json({
					message: "Only warehouse team can update warehouse follow-ups",
					success: false,
				});
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const values = followUpUpdateSchema.parse(request.body);
			const text = normalizeFollowUpInput(values.text);

			if (!text) {
				response.status(400).json({
					message: "Provide follow-up text",
					success: false,
				});
				return;
			}

			const slot = values.slot as FollowUpSlot;
			const updatedByUserField =
				postOrderFollowUp[`followUp${slot}UpdatedByUserId`];
			const currentRows = await db
				.select({
					status: order.status,
					updatedByUserId: updatedByUserField,
				})
				.from(order)
				.leftJoin(postOrderFollowUp, eq(postOrderFollowUp.orderId, order.id))
				.where(eq(order.id, orderId))
				.limit(1);
			const currentOrder = currentRows[0];

			if (!currentOrder) {
				throw new Error("Order not found");
			}

			if (
				!dispatchStatuses.includes(
					currentOrder.status as (typeof dispatchStatuses)[number]
				)
			) {
				throw new Error("Order is not in the warehouse dispatch queue");
			}

			if (
				currentOrder.updatedByUserId &&
				currentOrder.updatedByUserId !== session.user.id
			) {
				response.status(403).json({
					message: "Only the original follow-up owner can edit this slot",
					success: false,
				});
				return;
			}

			await db
				.insert(postOrderFollowUp)
				.values({
					orderId,
					[`followUp${slot}Text`]: [text],
					[`followUp${slot}UpdatedAt`]: new Date(),
					[`followUp${slot}UpdatedByUserId`]: session.user.id,
				})
				.onConflictDoUpdate({
					set: {
						[`followUp${slot}Text`]: [text],
						[`followUp${slot}UpdatedAt`]: new Date(),
						[`followUp${slot}UpdatedByUserId`]: session.user.id,
					},
					target: postOrderFollowUp.orderId,
				});

			const [updatedOrder] = await db
				.select()
				.from(postOrderFollowUp)
				.where(eq(postOrderFollowUp.orderId, orderId))
				.limit(1);

			if (!updatedOrder) {
				throw new Error("Failed to update follow-up");
			}
			const followUpUserNameById = await createFollowUpUserNameMap(
				getFollowUpUserIds(updatedOrder)
			);

			response.status(200).json({
				followUps: getFollowUps(
					updatedOrder,
					session.user.id,
					followUpUserNameById
				),
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.patch(
	"/dispatch/orders/:orderId/status",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const values = dispatchStatusSchema.parse(request.body);

			await db.transaction(async (tx) => {
				const database = tx as unknown as typeof db;
				const currentRows = await database
					.select({
						dispatchedAt: order.dispatchedAt,
						status: order.status,
					})
					.from(order)
					.where(eq(order.id, orderId))
					.limit(1);
				const currentOrder = currentRows[0];

				if (!currentOrder) {
					throw new Error("Order not found");
				}

				if (
					!dispatchStatuses.includes(
						currentOrder.status as (typeof dispatchStatuses)[number]
					)
				) {
					throw new Error("Order is not in the warehouse queue");
				}

				const nextStatus = getNextDispatchStatus(
					currentOrder.status as (typeof dispatchStatuses)[number]
				);
				if (values.status !== nextStatus) {
					throw new Error(
						`Invalid transition from ${currentOrder.status} to ${values.status}`
					);
				}

				if (values.status === "dispatched") {
					await deductConfirmedOrderStock(database, {
						actorUserId: session.user.id,
						orderId,
					});
				}

				const [updatedOrder] = await database
					.update(order)
					.set({
						dispatchedAt:
							values.status === "dispatched"
								? new Date()
								: currentOrder.dispatchedAt,
						status: values.status,
					})
					.where(
						and(eq(order.id, orderId), eq(order.status, currentOrder.status))
					)
					.returning({ id: order.id });

				if (!updatedOrder) {
					throw new Error(
						"Order status changed while the warehouse action was running"
					);
				}
			});

			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.get(
	"/branches/:managerCode/order-exports/packing.csv",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const { managerCode } = request.params as { managerCode: string };
			const { from, to } = request.query as { from?: string; to?: string };
			const branch = await getBranchByManagerCode(db, managerCode);
			if (!branch) {
				response
					.status(404)
					.json({ message: "Branch not found", success: false });
				return;
			}

			const csv = await getPackingExport({
				fromDate: from,
				managerCode,
				toDate: to,
			});
			const fileName = `packing-sheet-${managerCode}-${new Date().toISOString().slice(0, 10)}.csv`;
			response
				.status(200)
				.setHeader("Content-Type", "text/csv; charset=utf-8")
				.setHeader("Content-Disposition", `attachment; filename="${fileName}"`)
				.send(csv);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

inventoryRouter.get(
	"/branches/:managerCode/order-exports/booking.csv",
	async (request: Request, response: Response) => {
		try {
			const session = await requireInventoryManagerSession(request, response);
			if (!session) {
				return;
			}

			const { managerCode } = request.params as { managerCode: string };
			const { from, to } = request.query as { from?: string; to?: string };
			const branch = await getBranchByManagerCode(db, managerCode);
			if (!branch) {
				response
					.status(404)
					.json({ message: "Branch not found", success: false });
				return;
			}

			const csv = await getBookingExport({
				fromDate: from,
				managerCode,
				toDate: to,
			});
			if (!csv) {
				response.status(409).json({
					message:
						"No orders available for export. Orders may need consignment numbers assigned.",
					success: false,
				});
				return;
			}

			const fileName = `booking-sheet-${managerCode}-${new Date().toISOString().slice(0, 10)}.csv`;
			response
				.status(200)
				.setHeader("Content-Type", "text/csv; charset=utf-8")
				.setHeader("Content-Disposition", `attachment; filename="${fileName}"`)
				.send(csv);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

export default inventoryRouter satisfies Router;
