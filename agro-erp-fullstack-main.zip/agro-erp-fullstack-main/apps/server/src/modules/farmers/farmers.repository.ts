import type { db } from "@agro-erp-fullstack/db";
import { user } from "@agro-erp-fullstack/db/schema/auth";
import {
	crop,
	farmer,
	farmerCrop,
	farmerCropNotification,
	farmerProduct,
} from "@agro-erp-fullstack/db/schema/farmer";
import { order, orderConsignment } from "@agro-erp-fullstack/db/schema/order";
import { product } from "@agro-erp-fullstack/db/schema/product";
import { and, asc, desc, eq, inArray, or, sql } from "drizzle-orm";

import { generateNotifications } from "../../services/farmer-crops";
import type { CreateFarmerInput } from "./farmers.schemas";

const advisorAccessCondition = (userId: string) =>
	or(eq(farmer.createdByUserId, userId), eq(farmer.serviceByUserId, userId));

const branchAccessCondition = (managerCode: string) => sql`exists (
	select 1
	from user_manager_code branch_code
	where branch_code.manager_code = ${managerCode}
		and branch_code.user_id in (${farmer.serviceByUserId}, ${farmer.createdByUserId})
)`;

export const getFarmerCreateOptions = async (
	database: typeof db,
	userId: string,
	managerCode: null | string
) => {
	const advisorsQuery = managerCode
		? database
				.select({ id: user.id, name: user.name })
				.from(user)
				.where(
					and(
						eq(user.role, "advisor"),
						sql`exists (
							select 1 from user_manager_code branch_code
							where branch_code.manager_code = ${managerCode}
								and branch_code.user_id = ${user.id}
						)`
					)
				)
				.orderBy(asc(user.name))
		: database
				.select({ id: user.id, name: user.name })
				.from(user)
				.where(eq(user.id, userId))
				.orderBy(asc(user.name));

	const [advisors, crops, referralFarmers] = await Promise.all([
		advisorsQuery,
		database
			.select({ id: crop.id, name: crop.name })
			.from(crop)
			.where(eq(crop.isActive, true))
			.orderBy(asc(crop.name)),
		database
			.select({
				id: farmer.id,
				name: farmer.name,
				pincode: farmer.pincode,
				primaryMobileNumber: farmer.primaryMobileNumber,
			})
			.from(farmer)
			.where(
				managerCode
					? branchAccessCondition(managerCode)
					: advisorAccessCondition(userId)
			)
			.orderBy(asc(farmer.name)),
	]);

	return { advisors, crops, referralFarmers };
};

export const listAccessibleFarmers = async (
	database: typeof db,
	userId: string,
	managerCode: null | string
) => {
	const farmers = await database
		.select({
			id: farmer.id,
			lastOrderDate: farmer.lastOrderDate,
			name: farmer.name,
		})
		.from(farmer)
		.where(
			managerCode
				? branchAccessCondition(managerCode)
				: advisorAccessCondition(userId)
		)
		.orderBy(asc(farmer.name));
	const farmerIds = farmers.map((item) => item.id);
	if (farmerIds.length === 0) {
		return { farmers, notifications: [], orders: [] };
	}

	const [notifications, orders] = await Promise.all([
		database
			.select({ farmerId: farmerCropNotification.farmerId })
			.from(farmerCropNotification)
			.where(
				and(
					eq(farmerCropNotification.advisorUserId, userId),
					inArray(farmerCropNotification.farmerId, farmerIds)
				)
			),
		database
			.select({
				farmerId: order.farmerId,
				grandTotalAmount: order.grandTotalAmount,
			})
			.from(order)
			.where(inArray(order.farmerId, farmerIds)),
	]);

	return { farmers, notifications, orders };
};

export const listFarmerDirectory = (database: typeof db) =>
	database
		.select({
			addressAt: farmer.addressAt,
			district: farmer.district,
			id: farmer.id,
			name: farmer.name,
			nearbyLandmark: farmer.nearbyLandmark,
			pincode: farmer.pincode,
			post: farmer.post,
			productName: product.name,
			productSku: farmerProduct.productSku,
			state: farmer.state,
			taluka: farmer.taluka,
		})
		.from(farmer)
		.leftJoin(farmerProduct, eq(farmerProduct.farmerId, farmer.id))
		.leftJoin(product, eq(product.skuCode, farmerProduct.productSku))
		.orderBy(asc(farmer.name));

export const farmerIsAccessible = async (
	database: typeof db,
	farmerId: string,
	userId: string
) => {
	const [row] = await database
		.select({ id: farmer.id })
		.from(farmer)
		.where(and(eq(farmer.id, farmerId), advisorAccessCondition(userId)))
		.limit(1);
	return Boolean(row);
};

export const getFarmerDetails = async (
	database: typeof db,
	farmerId: string
) => {
	const [details] = await database
		.select({
			addressAt: farmer.addressAt,
			createdByUserId: farmer.createdByUserId,
			district: farmer.district,
			farmSize: farmer.farmSize,
			id: farmer.id,
			irrigation: farmer.irrigation,
			lastOrderDate: farmer.lastOrderDate,
			name: farmer.name,
			nearbyLandmark: farmer.nearbyLandmark,
			pincode: farmer.pincode,
			post: farmer.post,
			primaryMobileNumber: farmer.primaryMobileNumber,
			secondaryMobileNumber: farmer.secondaryMobileNumber,
			state: farmer.state,
			taluka: farmer.taluka,
		})
		.from(farmer)
		.where(eq(farmer.id, farmerId))
		.limit(1);
	return details ?? null;
};

export const getFarmerOrderHistory = (database: typeof db, farmerId: string) =>
	database
		.select({
			consignmentNumber: orderConsignment.consignmentNumber,
			createdAt: order.createdAt,
			createdByName: user.name,
			id: order.id,
			orderId: order.orderId,
			status: order.status,
			totalAmount: order.grandTotalAmount,
		})
		.from(order)
		.innerJoin(user, eq(user.id, order.createdByUserId))
		.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
		.where(eq(order.farmerId, farmerId))
		.orderBy(desc(order.createdAt));

export const getFarmerForCrop = async (
	database: typeof db,
	farmerId: string
) => {
	const [row] = await database
		.select({ id: farmer.id, serviceByUserId: farmer.serviceByUserId })
		.from(farmer)
		.where(eq(farmer.id, farmerId))
		.limit(1);
	return row ?? null;
};

export const farmerCropExists = async (
	database: typeof db,
	farmerId: string,
	cropId: string,
	dateOfSowing: string
) => {
	const [row] = await database
		.select({ id: farmerCrop.id })
		.from(farmerCrop)
		.where(
			and(
				eq(farmerCrop.farmerId, farmerId),
				eq(farmerCrop.cropId, cropId),
				eq(farmerCrop.dateOfSowing, dateOfSowing)
			)
		)
		.limit(1);
	return Boolean(row);
};

export const activeCropExists = async (database: typeof db, cropId: string) => {
	const [row] = await database
		.select({ id: crop.id })
		.from(crop)
		.where(and(eq(crop.id, cropId), eq(crop.isActive, true)))
		.limit(1);
	return Boolean(row);
};

export const insertFarmerCrop = async (
	database: typeof db,
	params: {
		cropId: string;
		dateOfSowing: string;
		farmerId: string;
		serviceByUserId: string;
	}
) => {
	const { cropId, dateOfSowing, farmerId, serviceByUserId } = params;
	const farmerCropId = crypto.randomUUID();
	await database.transaction(async (transaction) => {
		const tx = transaction as unknown as typeof db;
		await tx.insert(farmerCrop).values({
			cropId,
			currentStage: null,
			dateOfSowing,
			farmerId,
			id: farmerCropId,
		});
		await generateNotifications(tx, farmerId, serviceByUserId, [
			{ cropId, dateOfSowing, farmerCropId },
		]);
	});
};

export const getFarmerCropHistory = (database: typeof db, farmerId: string) =>
	database
		.select({
			createdAt: farmerCrop.createdAt,
			cropId: farmerCrop.cropId,
			cropName: crop.name,
			currentStage: farmerCrop.currentStage,
			dateOfSowing: farmerCrop.dateOfSowing,
			id: farmerCrop.id,
			taskCount: sql<number>`(
				select count(*)::int
				from ${farmerCropNotification}
				where ${farmerCropNotification.farmerCropId} = ${farmerCrop.id}
			)`,
		})
		.from(farmerCrop)
		.innerJoin(crop, eq(crop.id, farmerCrop.cropId))
		.where(eq(farmerCrop.farmerId, farmerId))
		.orderBy(farmerCrop.dateOfSowing);

export const primaryMobileExists = async (
	database: typeof db,
	primaryMobileNumber: string
) => {
	const [row] = await database
		.select({ id: farmer.id })
		.from(farmer)
		.where(eq(farmer.primaryMobileNumber, primaryMobileNumber))
		.limit(1);
	return Boolean(row);
};

export const referralFarmerIsAccessible = async (
	database: typeof db,
	referralFarmerId: string,
	userId: string,
	managerCode: null | string
) => {
	const [row] = await database
		.select({ id: farmer.id })
		.from(farmer)
		.where(
			and(
				eq(farmer.id, referralFarmerId),
				managerCode
					? branchAccessCondition(managerCode)
					: advisorAccessCondition(userId)
			)
		)
		.limit(1);
	return Boolean(row);
};

export const listActiveCropIds = async (database: typeof db) => {
	const rows = await database
		.select({ id: crop.id })
		.from(crop)
		.where(eq(crop.isActive, true));
	return rows.map((item) => item.id);
};

export const insertFarmer = async (
	database: typeof db,
	params: {
		createdByUserId: string;
		farmerId: string;
		input: CreateFarmerInput;
		primaryMobileNumber: string;
		secondaryMobileNumber?: string;
	}
) => {
	const {
		createdByUserId,
		farmerId,
		input,
		primaryMobileNumber,
		secondaryMobileNumber,
	} = params;
	await database.transaction(async (transaction) => {
		const tx = transaction as unknown as typeof db;
		await tx.insert(farmer).values({
			addressAt: input.addressAt.trim(),
			createdByUserId,
			district: input.district.trim(),
			farmSize: input.farmSize.trim(),
			id: farmerId,
			irrigation: input.irrigation.trim(),
			lastOrderDate: null,
			name: input.name.trim(),
			nearbyLandmark: input.nearbyLandmark?.trim() || null,
			pincode: input.pincode.trim(),
			post: input.post.trim(),
			primaryMobileNumber,
			referralFarmerId: input.referralFarmerId || null,
			secondaryMobileNumber: secondaryMobileNumber ?? null,
			serviceByUserId: input.serviceByUserId,
			state: input.state.trim(),
			taluka: input.taluka.trim(),
		});

		const cropRows = input.crops.map((item) => ({
			cropId: item.cropId,
			currentStage: item.currentStage?.trim() || null,
			dateOfSowing: item.dateOfSowing,
			farmerId,
			id: crypto.randomUUID(),
		}));
		await tx.insert(farmerCrop).values(cropRows);
		await generateNotifications(
			tx,
			farmerId,
			input.serviceByUserId,
			cropRows.map((row) => ({
				cropId: row.cropId,
				dateOfSowing: row.dateOfSowing,
				farmerCropId: row.id,
			}))
		);
	});
};
