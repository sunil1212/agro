import { db } from "@agro-erp-fullstack/db";
import { FARMER_LOCATION_MAP } from "@agro-erp-fullstack/db/data/farmer-locations";

import type { AppSession } from "../../auth/session";
import { HttpError } from "../../lib/http";
import {
	getTaskSummary,
	getTasks,
} from "../advisor-tasks/advisor-tasks.service";
import {
	requireFarmerInBranch,
	requireUserManagerCode,
} from "../branches/branches.service";
import {
	activeCropExists,
	farmerCropExists,
	farmerIsAccessible,
	getFarmerCreateOptions,
	getFarmerCropHistory,
	getFarmerDetails,
	getFarmerForCrop,
	getFarmerOrderHistory,
	insertFarmer,
	insertFarmerCrop,
	listAccessibleFarmers,
	listActiveCropIds,
	listFarmerDirectory,
	primaryMobileExists,
	referralFarmerIsAccessible,
} from "./farmers.repository";
import type { AddFarmerCropInput, CreateFarmerInput } from "./farmers.schemas";
import { phoneNumberPattern } from "./farmers.schemas";

const normalizePhoneNumber = (value: string) => value.replace(/\s+/g, "");
const toMoney = (value: number) => value.toFixed(2);

const getManagerCode = async (session: AppSession) =>
	session.user.role === "admin"
		? await requireUserManagerCode(db, session.user.id)
		: null;

const requireFarmerAccess = async (
	session: AppSession,
	farmerId: string
): Promise<void> => {
	if (session.user.role === "admin") {
		const managerCode = await requireUserManagerCode(db, session.user.id);
		await requireFarmerInBranch(db, farmerId, managerCode);
		return;
	}

	if (!(await farmerIsAccessible(db, farmerId, session.user.id))) {
		throw new HttpError(404, "Farmer not found");
	}
};

export const loadFarmerCreateOptions = async (session: AppSession) => {
	const managerCode = await getManagerCode(session);
	const options = await getFarmerCreateOptions(
		db,
		session.user.id,
		managerCode
	);
	return {
		...options,
		currentAdvisor: { id: session.user.id, name: session.user.name },
		locationOptions: FARMER_LOCATION_MAP,
	};
};

export const loadFarmers = async (session: AppSession) => {
	const managerCode = await getManagerCode(session);
	const { farmers, notifications, orders } = await listAccessibleFarmers(
		db,
		session.user.id,
		managerCode
	);
	const notificationCounts = new Map<string, number>();
	for (const notification of notifications) {
		notificationCounts.set(
			notification.farmerId,
			(notificationCounts.get(notification.farmerId) ?? 0) + 1
		);
	}
	const purchaseTotals = new Map<string, number>();
	for (const farmerOrder of orders) {
		purchaseTotals.set(
			farmerOrder.farmerId,
			(purchaseTotals.get(farmerOrder.farmerId) ?? 0) +
				Number(farmerOrder.grandTotalAmount)
		);
	}
	return farmers.map((item) => ({
		id: item.id,
		lastOrderDate: item.lastOrderDate,
		name: item.name,
		notificationCount: notificationCounts.get(item.id) ?? 0,
		totalPurchaseToDate: toMoney(purchaseTotals.get(item.id) ?? 0),
	}));
};

const joinAddressParts = (parts: Array<null | string>) =>
	parts
		.map((part) => part?.trim())
		.filter((part): part is string => Boolean(part))
		.join(", ");

export const loadFarmerDirectory = async () => {
	const rows = await listFarmerDirectory(db);
	return rows.map((item) => ({
		address: joinAddressParts([
			item.addressAt,
			item.nearbyLandmark,
			item.post,
			item.taluka,
			item.district,
			item.state,
			item.pincode,
		]),
		id: item.id,
		name: item.name,
		pincode: item.pincode,
		productName: item.productName,
		productSku: item.productSku,
	}));
};

export const loadFarmer = async (session: AppSession, farmerId: string) => {
	await requireFarmerAccess(session, farmerId);
	const currentFarmer = await getFarmerDetails(db, farmerId);
	if (!currentFarmer) {
		throw new HttpError(404, "Farmer not found");
	}

	const [orderHistory, tasks, cropHistory, taskSummary] = await Promise.all([
		getFarmerOrderHistory(db, farmerId),
		getTasks(db, [session.user.id], "all", farmerId),
		getFarmerCropHistory(db, farmerId),
		getTaskSummary(db, farmerId, [session.user.id]),
	]);
	const canViewPhoneNumber =
		currentFarmer.createdByUserId === session.user.id ||
		session.user.role === "admin";

	return {
		cropHistory,
		farmer: {
			...currentFarmer,
			canViewPhoneNumber,
			primaryMobileNumber: canViewPhoneNumber
				? currentFarmer.primaryMobileNumber
				: null,
			secondaryMobileNumber: canViewPhoneNumber
				? currentFarmer.secondaryMobileNumber
				: null,
		},
		orderHistory,
		tasks,
		taskSummary,
	};
};

export const createFarmerCrop = async (
	session: AppSession,
	farmerId: string,
	input: AddFarmerCropInput
): Promise<void> => {
	await requireFarmerAccess(session, farmerId);
	if (!(await activeCropExists(db, input.cropId))) {
		throw new HttpError(400, "Selected crop is not active");
	}
	const targetFarmer = await getFarmerForCrop(db, farmerId);
	if (!targetFarmer) {
		throw new HttpError(404, "Farmer not found");
	}
	if (await farmerCropExists(db, farmerId, input.cropId, input.dateOfSowing)) {
		throw new HttpError(
			409,
			"This crop with the same sowing date already exists for this farmer"
		);
	}
	await insertFarmerCrop(db, {
		cropId: input.cropId,
		dateOfSowing: input.dateOfSowing,
		farmerId,
		serviceByUserId: targetFarmer.serviceByUserId,
	});
};

export const createFarmer = async (
	session: AppSession,
	input: CreateFarmerInput
) => {
	const primaryMobileNumber = normalizePhoneNumber(input.primaryMobileNumber);
	const secondaryMobileNumber = input.secondaryMobileNumber
		? normalizePhoneNumber(input.secondaryMobileNumber)
		: undefined;
	if (!phoneNumberPattern.test(primaryMobileNumber)) {
		throw new HttpError(400, "Primary mobile number is invalid");
	}
	if (
		secondaryMobileNumber &&
		!phoneNumberPattern.test(secondaryMobileNumber)
	) {
		throw new HttpError(400, "Secondary mobile number is invalid");
	}
	if (secondaryMobileNumber === primaryMobileNumber) {
		throw new HttpError(400, "Secondary mobile number must be different");
	}
	if (await primaryMobileExists(db, primaryMobileNumber)) {
		throw new HttpError(
			409,
			"A farmer with this primary mobile number already exists"
		);
	}

	const effectiveInput = { ...input, serviceByUserId: session.user.id };
	if (input.referralFarmerId) {
		const managerCode = await getManagerCode(session);
		if (
			!(await referralFarmerIsAccessible(
				db,
				input.referralFarmerId,
				session.user.id,
				managerCode
			))
		) {
			throw new HttpError(400, "Selected referral farmer is invalid");
		}
	}
	const cropIds = [...new Set(input.crops.map((item) => item.cropId))];
	if (cropIds.length !== input.crops.length) {
		throw new HttpError(400, "Each crop can only be selected once");
	}
	const activeCropIds = new Set(await listActiveCropIds(db));
	if (cropIds.some((cropId) => !activeCropIds.has(cropId))) {
		throw new HttpError(400, "One or more selected crops are invalid");
	}

	const farmerId = crypto.randomUUID();
	await insertFarmer(db, {
		createdByUserId: session.user.id,
		farmerId,
		input: effectiveInput,
		primaryMobileNumber,
		secondaryMobileNumber,
	});
	return { id: farmerId, name: input.name.trim(), primaryMobileNumber };
};
