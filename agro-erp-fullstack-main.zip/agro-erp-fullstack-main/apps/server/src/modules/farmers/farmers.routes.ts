import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";

import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import { addFarmerCropSchema, createFarmerSchema } from "./farmers.schemas";
import {
	createFarmer,
	createFarmerCrop,
	loadFarmer,
	loadFarmerCreateOptions,
	loadFarmerDirectory,
	loadFarmers,
} from "./farmers.service";

const farmersRouter: Router = createRouter();

const requireFarmerSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "farmer:manage",
		forbiddenMessage: "Only advisors can manage farmers",
		forbiddenSuccess: false,
	});

farmersRouter.get("/create-options", async (request, response) => {
	try {
		const session = await requireFarmerSession(request, response);
		if (!session) {
			return;
		}
		response.status(200).json({
			...(await loadFarmerCreateOptions(session)),
			success: true,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

farmersRouter.get("/directory", async (request, response) => {
	try {
		const session = await requireFarmerSession(request, response);
		if (!session) {
			return;
		}
		response.status(200).json({
			farmers: await loadFarmerDirectory(),
			success: true,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

farmersRouter.get("/", async (request, response) => {
	try {
		const session = await requireFarmerSession(request, response);
		if (!session) {
			return;
		}
		response
			.status(200)
			.json({ farmers: await loadFarmers(session), success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

farmersRouter.get("/:farmerId", async (request, response) => {
	try {
		const session = await requireFarmerSession(request, response);
		if (!session) {
			return;
		}
		const { farmerId } = request.params as { farmerId: string };
		response
			.status(200)
			.json({ ...(await loadFarmer(session, farmerId)), success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

farmersRouter.post("/:farmerId/crops", async (request, response) => {
	try {
		const session = await requireFarmerSession(request, response);
		if (!session) {
			return;
		}
		const { farmerId } = request.params as { farmerId: string };
		await createFarmerCrop(
			session,
			farmerId,
			addFarmerCropSchema.parse(request.body)
		);
		response.status(201).json({ success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

farmersRouter.post("/", async (request, response) => {
	try {
		const session = await requireFarmerSession(request, response);
		if (!session) {
			return;
		}
		const farmer = await createFarmer(
			session,
			createFarmerSchema.parse(request.body)
		);
		response.status(201).json({ farmer, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

export default farmersRouter;
