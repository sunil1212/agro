import { isValidFarmerLocation } from "@agro-erp-fullstack/db/data/farmer-locations";
import z from "zod";

export const phoneNumberPattern = /^\+[1-9]\d{7,14}$/;
const pincodePattern = /^\d{6}$/;

export const createFarmerSchema = z
	.object({
		name: z.string().trim().min(1, "Name is required"),
		primaryMobileNumber: z.string().trim().min(1, "Primary mobile is required"),
		secondaryMobileNumber: z.string().trim().optional(),
		addressAt: z.string().trim().min(1, "At / Village is required"),
		nearbyLandmark: z.string().trim().optional(),
		post: z.string().trim().min(1, "Post is required"),
		state: z.string().trim().min(1, "State is required"),
		taluka: z.string().trim().min(1, "Taluka is required"),
		district: z.string().trim().min(1, "District is required"),
		pincode: z
			.string()
			.trim()
			.regex(pincodePattern, "Pincode must be 6 digits"),
		serviceByUserId: z.string().trim().min(1, "Service By is required"),
		referralFarmerId: z.string().trim().optional(),
		farmSize: z.string().trim().min(1, "Farm size is required"),
		irrigation: z.string().trim().min(1, "Irrigation is required"),
		crops: z
			.array(
				z.object({
					cropId: z.string().trim().min(1, "Crop is required"),
					dateOfSowing: z.iso.date("Date of sowing is required"),
					currentStage: z.string().trim().optional(),
				})
			)
			.min(1, "At least one crop is required"),
	})
	.superRefine((values, context) => {
		if (!isValidFarmerLocation(values)) {
			context.addIssue({
				code: "custom",
				message: "Select a valid state, district, and taluka",
				path: ["taluka"],
			});
		}
	});

export const addFarmerCropSchema = z.object({
	cropId: z.string().trim().min(1, "Crop is required"),
	dateOfSowing: z.iso.date("Date of sowing is required"),
});

export type CreateFarmerInput = z.infer<typeof createFarmerSchema>;
export type AddFarmerCropInput = z.infer<typeof addFarmerCropSchema>;
