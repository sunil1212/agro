import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import {
	createAccount,
	getUserManagerCode,
	importAdvisorAccounts,
	listAccounts,
	managerCodeExists,
	normalizeManagerCode,
} from "../../services/accounts";
import {
	adminAssignableRoles,
	assignAdvisorTeamLeaderSchema,
	createAccountSchema,
	importAdvisorAccountsSchema,
	resetAccountPasswordSchema,
	superAdminAssignableRoles,
	updateAdvisorTargetsSchema,
} from "./accounts.schemas";
import {
	assignAdvisorTeamLeaderInBranch,
	isAdvisorRole,
	isTeamLeaderInBranch,
	promoteAdvisorInBranch,
	resetManagedAccountPassword,
	updateAdvisorTargetsInBranch,
} from "./accounts.service";
import advisorAccountsRouter from "./advisor-accounts.routes";

export const accountsRouter: Router = createRouter();
accountsRouter.use(advisorAccountsRouter);
const branchStaffRoles = ["team_leader", "advisor", "logistics"] as const;

const isBranchStaffRole = (role: string) =>
	branchStaffRoles.some((branchStaffRole) => branchStaffRole === role);

const requireAction = (
	request: Request,
	response: Response,
	action: Parameters<typeof requireActionSession>[2]["action"],
	forbiddenMessage: string
) =>
	requireActionSession(request, response, {
		action,
		forbiddenMessage,
		forbiddenSuccess: false,
	});

type CreateAccountValues = ReturnType<(typeof createAccountSchema)["parse"]>;

const getManagerCodeForCreatedAccount = async (
	values: CreateAccountValues,
	sessionUser: { id: string; role: string }
) => {
	if (values.role === "admin" && !values.managerCode) {
		return {
			message: "Branch code is required when creating an admin",
			status: 400,
		} as const;
	}

	const managerCode =
		values.role === "admin" && values.managerCode
			? normalizeManagerCode(values.managerCode)
			: null;

	if (managerCode) {
		const isManagerCodeTaken = await managerCodeExists(managerCode);
		if (isManagerCodeTaken) {
			return {
				message: "Branch code is already in use",
				status: 409,
			} as const;
		}

		return { managerCode } as const;
	}

	if (sessionUser.role === "admin" && isBranchStaffRole(values.role)) {
		const creatorManagerCode = await getUserManagerCode(sessionUser.id);

		if (!creatorManagerCode) {
			return {
				message: "Your admin account needs a branch code first",
				status: 400,
			} as const;
		}

		return { managerCode: creatorManagerCode } as const;
	}

	return { managerCode: null } as const;
};

const isTeamLeaderAssignableToAccount = (
	values: CreateAccountValues,
	managerCode: null | string
) => {
	if (!(isAdvisorRole(values.role) && values.teamLeaderId)) {
		return true;
	}

	return isTeamLeaderInBranch(values.teamLeaderId, managerCode);
};

accountsRouter.get("/", async (request: Request, response: Response) => {
	try {
		const session = await requireAction(
			request,
			response,
			"account:list",
			"You do not have access to accounts"
		);

		if (!session) {
			return;
		}

		const accounts = await listAccounts({
			createdByUserId:
				session.user.role === "admin" ? session.user.id : undefined,
		});

		response.status(200).json({ accounts, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

accountsRouter.post("/", async (request: Request, response: Response) => {
	try {
		const values = createAccountSchema.parse(request.body);
		const action =
			values.role === "admin"
				? "account:create_manager"
				: "account:create_staff";
		const session = await requireAction(
			request,
			response,
			action,
			"You do not have access to create this account type"
		);

		if (!session) {
			return;
		}

		if (
			session.user.role === "admin" &&
			!adminAssignableRoles.some((role) => role === values.role)
		) {
			response.status(403).json({
				message:
					"Admins can only create team leader, advisor, or logistics users",
				success: false,
			});
			return;
		}
		if (
			session.user.role === "superadmin" &&
			!superAdminAssignableRoles.some((role) => role === values.role)
		) {
			response.status(403).json({
				message: "Super admin can only create admin or warehouse accounts",
				success: false,
			});
			return;
		}

		const managerCodeResult = await getManagerCodeForCreatedAccount(
			values,
			session.user
		);
		if ("message" in managerCodeResult) {
			response.status(managerCodeResult.status ?? 400).json({
				message: managerCodeResult.message,
				success: false,
			});
			return;
		}

		if (
			!(await isTeamLeaderAssignableToAccount(
				values,
				managerCodeResult.managerCode
			))
		) {
			response.status(404).json({
				message: "Team leader account not found",
				success: false,
			});
			return;
		}

		const isAdvisorAccount = isAdvisorRole(values.role);
		const createdAccount = await createAccount({
			createdByUserId: session.user.id,
			dailySalesTarget: isAdvisorAccount
				? (values.dailySalesTarget ?? null)
				: null,
			email: values.email,
			managerCode:
				values.role === "admin" || isBranchStaffRole(values.role)
					? managerCodeResult.managerCode
					: null,
			monthlySalesTarget: isAdvisorAccount
				? (values.monthlySalesTarget ?? null)
				: null,
			name: values.name,
			password: values.password,
			role: values.role,
			teamLeaderId: isAdvisorAccount ? (values.teamLeaderId ?? null) : null,
			title: values.title ?? null,
		});

		response.status(201).json({
			account: createdAccount,
			success: true,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

accountsRouter.post(
	"/import-advisors",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAction(
				request,
				response,
				"account:create_staff",
				"Only admins can import advisor accounts"
			);

			if (!session) {
				return;
			}

			if (session.user.role !== "admin") {
				response.status(403).json({
					message: "Only admins can import advisor accounts",
					success: false,
				});
				return;
			}

			const { names } = importAdvisorAccountsSchema.parse(request.body);
			const managerCode = await getUserManagerCode(session.user.id);

			if (!managerCode) {
				response.status(400).json({
					message: "Your admin account needs a manager code first",
					success: false,
				});
				return;
			}

			const result = await importAdvisorAccounts({
				createdByUserId: session.user.id,
				managerCode,
				names,
			});

			response.status(200).json({ ...result, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

accountsRouter.patch(
	"/:accountId/targets",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAction(
				request,
				response,
				"account:update_targets",
				"Only branch admins can update targets"
			);

			if (!session) {
				return;
			}

			if (session.user.role !== "admin") {
				response.status(403).json({
					role: session.user.role,
					message: "Only branch admins can update targets",
					success: false,
				});
				return;
			}

			const { accountId } = request.params as { accountId: string };
			const body = updateAdvisorTargetsSchema.parse(request.body);

			const account = await updateAdvisorTargetsInBranch({
				accountId,
				actorUserId: session.user.id,
				dailySalesTarget: body.dailySalesTarget,
				monthlySalesTarget: body.monthlySalesTarget,
			});
			if (!account) {
				response.status(404).json({
					message: "Advisor account not found",
					success: false,
				});
				return;
			}

			response.status(200).json({
				account,
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

accountsRouter.patch(
	"/:accountId/team-leader",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAction(
				request,
				response,
				"account:assign_team_leader",
				"Only branch admins can assign team leaders"
			);

			if (!session) {
				return;
			}

			if (session.user.role !== "admin") {
				response.status(403).json({
					message: "Only branch admins can assign team leaders",
					success: false,
				});
				return;
			}

			const { accountId } = request.params as { accountId: string };
			const body = assignAdvisorTeamLeaderSchema.parse(request.body);

			const assignment = await assignAdvisorTeamLeaderInBranch({
				actorUserId: session.user.id,
				advisorId: accountId,
				teamLeaderId: body.teamLeaderId,
			});
			if (!assignment) {
				response.status(404).json({
					message: "Advisor account not found",
					success: false,
				});
				return;
			}

			response.status(200).json({
				assignment,
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

accountsRouter.patch(
	"/:accountId/promote-senior",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAction(
				request,
				response,
				"account:update_targets",
				"Only branch admins can promote advisors"
			);

			if (!session) {
				return;
			}

			if (session.user.role !== "admin") {
				response.status(403).json({
					message: "Only branch admins can promote advisors",
					success: false,
				});
				return;
			}

			const { accountId } = request.params as { accountId: string };
			const account = await promoteAdvisorInBranch(session.user.id, accountId);
			if (!account) {
				response.status(404).json({
					message: "Advisor account not found",
					success: false,
				});
				return;
			}

			response.status(200).json({
				account,
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

accountsRouter.patch(
	"/:accountId/password",
	async (request: Request, response: Response) => {
		try {
			const session = await requireAction(
				request,
				response,
				"account:reset_password",
				"You do not have access to reset passwords"
			);

			if (!session) {
				return;
			}

			const { accountId } = request.params as { accountId: string };
			const body = resetAccountPasswordSchema.parse(request.body);

			const account = await resetManagedAccountPassword({
				accountId,
				actorRole: session.user.role,
				actorUserId: session.user.id,
				password: body.password,
			});
			if (!account) {
				response.status(404).json({
					message: "Branch member account not found",
					success: false,
				});
				return;
			}

			response.status(200).json({
				account,
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

export default accountsRouter satisfies Router;
