import { db } from "@agro-erp-fullstack/db";
import {
	assignAdvisorTeamLeader,
	promoteAdvisorToSeniorAdvisor,
	resetAccountPassword,
	updateAdvisorTargets,
} from "../../services/accounts";
import { getUserManagerCode } from "../branches/branches.repository";
import { findAccountRole } from "./accounts.repository";

const advisorRoles = ["advisor"] as const;
const passwordResettableRoles = [
	"advisor",
	"team_leader",
	"logistics",
] as const;

export const isAdvisorRole = (role: string) =>
	advisorRoles.some((advisorRole) => advisorRole === role);

export const isTeamLeaderInBranch = async (
	teamLeaderId: string,
	managerCode: null | string
) => {
	const teamLeaderManagerCode = await getUserManagerCode(db, teamLeaderId);
	return Boolean(
		teamLeaderManagerCode && teamLeaderManagerCode === managerCode
	);
};

const accountsShareBranch = async (
	firstAccountId: string,
	secondAccountId: string
) => {
	const [firstManagerCode, secondManagerCode] = await Promise.all([
		getUserManagerCode(db, firstAccountId),
		getUserManagerCode(db, secondAccountId),
	]);
	return Boolean(
		firstManagerCode &&
			secondManagerCode &&
			firstManagerCode === secondManagerCode
	);
};

export const updateAdvisorTargetsInBranch = async (input: {
	accountId: string;
	actorUserId: string;
	dailySalesTarget: null | number;
	monthlySalesTarget: null | number;
}) => {
	const targetAccount = await findAccountRole(input.accountId);
	if (
		!(
			targetAccount &&
			isAdvisorRole(targetAccount.role) &&
			(await accountsShareBranch(input.actorUserId, input.accountId))
		)
	) {
		return null;
	}
	return updateAdvisorTargets(input);
};

export const assignAdvisorTeamLeaderInBranch = async (input: {
	actorUserId: string;
	advisorId: string;
	teamLeaderId: null | string;
}) => {
	const targetAccount = await findAccountRole(input.advisorId);
	if (
		!(
			targetAccount &&
			isAdvisorRole(targetAccount.role) &&
			(await accountsShareBranch(input.actorUserId, input.advisorId))
		)
	) {
		return null;
	}
	if (
		input.teamLeaderId &&
		!(await accountsShareBranch(input.actorUserId, input.teamLeaderId))
	) {
		return null;
	}
	return assignAdvisorTeamLeader(input);
};

export const promoteAdvisorInBranch = async (
	actorUserId: string,
	accountId: string
) => {
	if (!(await accountsShareBranch(actorUserId, accountId))) {
		return null;
	}
	return promoteAdvisorToSeniorAdvisor(accountId);
};

export const resetManagedAccountPassword = async (input: {
	accountId: string;
	actorRole: string;
	actorUserId: string;
	password: string;
}) => {
	const targetAccount = await findAccountRole(input.accountId);
	const isSuperAdminTarget =
		targetAccount?.role === "admin" || targetAccount?.role === "warehouse";
	const isBranchAdminTarget = targetAccount
		? passwordResettableRoles.some((role) => role === targetAccount.role)
		: false;
	const canResetTarget =
		input.actorRole === "superadmin"
			? isSuperAdminTarget
			: input.actorRole === "admin" &&
				isBranchAdminTarget &&
				(await accountsShareBranch(input.actorUserId, input.accountId));
	if (!canResetTarget) {
		return null;
	}
	return resetAccountPassword(input);
};
