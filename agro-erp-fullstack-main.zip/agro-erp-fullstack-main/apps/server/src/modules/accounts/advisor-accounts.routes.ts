import { db } from "@agro-erp-fullstack/db";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";

import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import { findAssignedAdvisorAccounts } from "./advisor-accounts.repository";

const advisorAccountsRouter: Router = createRouter();

advisorAccountsRouter.get(
	"/advisors",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "advisor_order:manage",
				forbiddenMessage: "Only advisors can manage orders",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}

			if (session.user.role !== "team_leader") {
				response.status(403).json({
					message: "Only team leaders can view assigned advisors",
					success: false,
				});
				return;
			}

			const accounts = await findAssignedAdvisorAccounts(db, session.user.id);
			response.status(200).json({ accounts, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

export default advisorAccountsRouter;
