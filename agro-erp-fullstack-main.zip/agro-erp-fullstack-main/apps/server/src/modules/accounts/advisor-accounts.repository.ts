import type { db } from "@agro-erp-fullstack/db";
import {
	teamLeaderAdvisor,
	user,
	userManagerCode,
	userSalesTarget,
} from "@agro-erp-fullstack/db/schema/auth";
import { asc, eq, sql } from "drizzle-orm";

export const findAssignedAdvisorAccounts = async (
	database: typeof db,
	teamLeaderId: string
) =>
	database
		.select({
			createdAt: user.createdAt,
			dailySalesTarget: userSalesTarget.dailySalesTarget,
			email: user.email,
			id: user.id,
			managerCode: userManagerCode.managerCode,
			monthlySalesTarget: userSalesTarget.monthlySalesTarget,
			name: user.name,
			role: user.role,
			teamLeaderId: teamLeaderAdvisor.teamLeaderId,
			teamLeaderName: sql<null | string>`(
				select team_leader.name
				from "user" team_leader
				where team_leader.id = ${teamLeaderAdvisor.teamLeaderId}
			)`,
			title: user.title,
		})
		.from(teamLeaderAdvisor)
		.innerJoin(user, eq(user.id, teamLeaderAdvisor.advisorId))
		.leftJoin(userSalesTarget, eq(userSalesTarget.userId, user.id))
		.leftJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(eq(teamLeaderAdvisor.teamLeaderId, teamLeaderId))
		.orderBy(asc(user.name));
