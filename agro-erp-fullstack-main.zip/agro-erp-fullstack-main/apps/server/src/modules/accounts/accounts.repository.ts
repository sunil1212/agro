import { db } from "@agro-erp-fullstack/db";
import { user } from "@agro-erp-fullstack/db/schema/auth";
import { eq } from "drizzle-orm";

export const findAccountRole = async (accountId: string) => {
	const [account] = await db
		.select({ id: user.id, role: user.role })
		.from(user)
		.where(eq(user.id, accountId))
		.limit(1);

	return account ?? null;
};
