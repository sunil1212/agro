import type { db } from "@agro-erp-fullstack/db";
import { user, userManagerCode } from "@agro-erp-fullstack/db/schema/auth";
import { farmer } from "@agro-erp-fullstack/db/schema/farmer";
import { order } from "@agro-erp-fullstack/db/schema/order";
import { and, eq, sql } from "drizzle-orm";

export interface BranchContext {
	adminUserId: string;
	managerCode: string;
}

export async function getUserManagerCode(
	database: typeof db,
	userId: string
): Promise<string | null> {
	const rows = await database.execute<{ manager_code: string }>(sql`
		select coalesce(direct_code.manager_code, creator_code.manager_code) as manager_code
		from "user" current_account
		left join user_manager_code direct_code
			on direct_code.user_id = current_account.id
		left join user_manager_code creator_code
			on creator_code.user_id = current_account.created_by_user_id
		where current_account.id = ${userId}
		limit 1
	`);

	return rows.rows[0]?.manager_code ?? null;
}

export async function getBranchContextForUser(
	database: typeof db,
	userId: string
): Promise<BranchContext | null> {
	const managerCode = await getUserManagerCode(database, userId);
	if (!managerCode) {
		return null;
	}

	const adminRows = await database
		.select({ id: user.id })
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(
			and(eq(userManagerCode.managerCode, managerCode), eq(user.role, "admin"))
		)
		.limit(1);

	if (!adminRows[0]) {
		return null;
	}

	return {
		adminUserId: adminRows[0].id,
		managerCode,
	};
}

export function listBranches(database: typeof db) {
	return database
		.select({
			adminUserId: user.id,
			adminName: user.name,
			managerCode: userManagerCode.managerCode,
		})
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(eq(user.role, "admin"))
		.orderBy(userManagerCode.managerCode);
}

export async function getBranchByManagerCode(
	database: typeof db,
	managerCode: string
) {
	const rows = await database
		.select({
			adminUserId: user.id,
			adminName: user.name,
			managerCode: userManagerCode.managerCode,
		})
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(
			and(eq(userManagerCode.managerCode, managerCode), eq(user.role, "admin"))
		)
		.limit(1);

	return rows[0] ?? null;
}

export async function isUserInBranch(
	database: typeof db,
	userId: string,
	managerCode: string
): Promise<boolean> {
	const rows = await database.execute<{ user_id: string }>(sql`
		select current_account.id as user_id
		from "user" current_account
		left join user_manager_code direct_code
			on direct_code.user_id = current_account.id
		left join user_manager_code creator_code
			on creator_code.user_id = current_account.created_by_user_id
		where current_account.id = ${userId}
			and coalesce(direct_code.manager_code, creator_code.manager_code) = ${managerCode}
		limit 1
	`);

	return rows.rows.length > 0;
}

export async function farmerExistsInBranch(
	database: typeof db,
	farmerId: string,
	managerCode: string
): Promise<boolean> {
	const rows = await database.execute<{ farmer_id: string }>(sql`
		select f.id as farmer_id
		from ${farmer} f
		where f.id = ${farmerId}
			and exists (
				select 1
				from user_manager_code branch_code
				where branch_code.manager_code = ${managerCode}
					and branch_code.user_id in (f.service_by_user_id, f.created_by_user_id)
			)
		limit 1
	`);

	return rows.rows.length > 0;
}

export async function orderExistsInBranch(
	database: typeof db,
	orderId: string,
	managerCode: string
): Promise<boolean> {
	const rows = await database.execute<{ order_id: string }>(sql`
		select o.id as order_id
		from ${order} o
		where o.id = ${orderId}
			and exists (
				select 1
				from "user" order_creator
				left join user_manager_code direct_code
					on direct_code.user_id = order_creator.id
				left join user_manager_code creator_code
					on creator_code.user_id = order_creator.created_by_user_id
				where order_creator.id = o.created_by_user_id
					and coalesce(direct_code.manager_code, creator_code.manager_code) = ${managerCode}
			)
		limit 1
	`);

	return rows.rows.length > 0;
}
