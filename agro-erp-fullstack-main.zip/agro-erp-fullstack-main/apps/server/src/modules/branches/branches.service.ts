import type { db } from "@agro-erp-fullstack/db";

import { HttpError } from "../../lib/http";
import {
	farmerExistsInBranch,
	getUserManagerCode,
	orderExistsInBranch,
} from "./branches.repository";

export const requireUserManagerCode = async (
	database: typeof db,
	userId: string
): Promise<string> => {
	const branchCode = await getUserManagerCode(database, userId);

	if (!branchCode) {
		throw new Error("User does not have a branch code assigned");
	}

	return branchCode;
};

export const requireFarmerInBranch = async (
	database: typeof db,
	farmerId: string,
	branchCode: string
): Promise<void> => {
	if (!(await farmerExistsInBranch(database, farmerId, branchCode))) {
		throw new HttpError(404, "Farmer not found");
	}
};

export const requireOrderInBranch = async (
	database: typeof db,
	orderId: string,
	branchCode: string
): Promise<void> => {
	if (!(await orderExistsInBranch(database, orderId, branchCode))) {
		throw new HttpError(404, "Order not found");
	}
};
