import type { db } from "@agro-erp-fullstack/db";
import {
	crop,
	cropSchedule,
	farmer,
	farmerCropNotification,
} from "@agro-erp-fullstack/db/schema/farmer";
import { desc, eq, sql } from "drizzle-orm";

export const findAdvisorTaskNotifications = async (
	database: typeof db,
	advisorUserId: string,
	managerCode: null | string
) =>
	database
		.select({
			completedAt: farmerCropNotification.completedAt,
			createdAt: farmerCropNotification.createdAt,
			cropName: crop.name,
			cropScheduleEndDay: cropSchedule.endDay,
			cropScheduleStartDay: cropSchedule.startDay,
			farmerCropId: farmerCropNotification.farmerCropId,
			farmerId: farmer.id,
			farmerName: farmer.name,
			id: farmerCropNotification.id,
			instruction: farmerCropNotification.instruction,
			isCompleted: farmerCropNotification.isCompleted,
			scheduledFor: farmerCropNotification.scheduledFor,
		})
		.from(farmerCropNotification)
		.innerJoin(farmer, eq(farmer.id, farmerCropNotification.farmerId))
		.innerJoin(crop, eq(crop.id, farmerCropNotification.cropId))
		.innerJoin(
			cropSchedule,
			eq(cropSchedule.id, farmerCropNotification.cropScheduleId)
		)
		.where(
			managerCode
				? sql`exists (
						select 1
						from user_manager_code branch_code
						where branch_code.manager_code = ${managerCode}
							and branch_code.user_id = ${farmerCropNotification.advisorUserId}
					)`
				: eq(farmerCropNotification.advisorUserId, advisorUserId)
		)
		.orderBy(desc(farmerCropNotification.scheduledFor));
