import { db } from "@agro-erp-fullstack/db";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";

import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import { requireUserManagerCode } from "../branches/branches.service";
import { findAdvisorTaskNotifications } from "./advisor-tasks.repository";
import type { TaskCategory } from "./advisor-tasks.service";
import {
	completeTask,
	getTasks,
	taskCategoryValues,
} from "./advisor-tasks.service";

const advisorTasksRouter: Router = createRouter();

const requireTaskSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "farmer:manage",
		forbiddenMessage: "Only advisors can manage farmers",
		forbiddenSuccess: false,
	});

advisorTasksRouter.get(
	"/tasks",
	async (request: Request, response: Response) => {
		try {
			const session = await requireTaskSession(request, response);
			if (!session) {
				return;
			}

			const categoryParam = request.query.category?.toString();
			const category =
				categoryParam && taskCategoryValues.includes(categoryParam as never)
					? (categoryParam as TaskCategory)
					: "current";
			const farmerId = request.query.farmerId?.toString();
			const tasks = await getTasks(db, [session.user.id], category, farmerId);

			response.status(200).json({ tasks, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

advisorTasksRouter.patch(
	"/tasks/:taskId/complete",
	async (request: Request, response: Response) => {
		try {
			const session = await requireTaskSession(request, response);
			if (!session) {
				return;
			}

			const { taskId } = request.params as { taskId: string };
			const { remark } = request.body as { remark?: string };
			const result = await completeTask(db, taskId, [session.user.id], remark);

			if (result.status === "completed") {
				response.status(200).json({ success: true, task: result.task });
				return;
			}
			if (result.status === "already_completed") {
				response.status(409).json({
					message: "This task has already been completed",
					success: false,
				});
				return;
			}

			response.status(404).json({ message: "Task not found", success: false });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

const handleNotifications = async (request: Request, response: Response) => {
	try {
		const session = await requireTaskSession(request, response);
		if (!session) {
			return;
		}

		const managerCode =
			session.user.role === "admin"
				? await requireUserManagerCode(db, session.user.id)
				: null;
		const notifications = await findAdvisorTaskNotifications(
			db,
			session.user.id,
			managerCode
		);

		response.status(200).json({ notifications, success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

advisorTasksRouter.get("/notifications", handleNotifications);

export default advisorTasksRouter;
