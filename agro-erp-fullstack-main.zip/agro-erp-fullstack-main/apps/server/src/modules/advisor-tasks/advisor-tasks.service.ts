import type { db } from "@agro-erp-fullstack/db";
import {
	crop,
	cropSchedule,
	farmer,
	farmerCropNotification,
} from "@agro-erp-fullstack/db/schema/farmer";
import { and, desc, eq, inArray, lte } from "drizzle-orm";

import { addDaysToIsoDate } from "../../shared/date";

export const taskCategoryValues = ["current", "backlog", "all"] as const;

export type TaskCategory = (typeof taskCategoryValues)[number];

interface TaskWindow {
	taskEnd: string;
	taskStart: string;
}

function getTaskWindow(
	scheduledFor: string,
	startDay: number,
	endDay: number
): TaskWindow {
	return {
		taskStart: scheduledFor,
		taskEnd: addDaysToIsoDate(scheduledFor, endDay - startDay),
	};
}

function getTodayIstDate(): string {
	const now = new Date();
	const istOffset = 5.5 * 60 * 60 * 1000;
	const istDate = new Date(now.getTime() + istOffset);
	const year = istDate.getUTCFullYear();
	const month = String(istDate.getUTCMonth() + 1).padStart(2, "0");
	const day = String(istDate.getUTCDate()).padStart(2, "0");

	return `${year}-${month}-${day}`;
}

export interface TaskRow {
	completedAt: Date | null;
	createdAt: Date;
	cropName: string;
	cropScheduleEndDay: number;
	cropScheduleStartDay: number;
	farmerCropId: string;
	farmerId: string;
	farmerName: string;
	id: string;
	instruction: string;
	isCompleted: boolean;
	scheduledFor: string;
	taskRemark: string | null;
}

export interface CategorizedTask extends TaskRow {
	taskEnd: string;
	taskStart: string;
}

function categorizeTask(row: TaskRow, today: string): CategorizedTask | null {
	const { taskStart, taskEnd } = getTaskWindow(
		row.scheduledFor,
		row.cropScheduleStartDay,
		row.cropScheduleEndDay
	);

	// Future tasks are never returned
	if (taskStart > today) {
		return null;
	}

	return {
		...row,
		taskStart,
		taskEnd,
	};
}

function matchesCategory(
	task: CategorizedTask,
	category: TaskCategory,
	today: string
): boolean {
	switch (category) {
		case "current": {
			return (
				!task.isCompleted && task.taskStart <= today && today <= task.taskEnd
			);
		}
		case "backlog": {
			return !task.isCompleted && task.taskEnd < today;
		}
		case "all": {
			return true; // All eligible tasks (already filtered by taskStart <= today)
		}
		default: {
			return false;
		}
	}
}

export async function getTasks(
	database: typeof db,
	advisorUserId: string | string[],
	category: TaskCategory = "current",
	farmerId?: string
): Promise<CategorizedTask[]> {
	const today = getTodayIstDate();
	const advisorUserIds = Array.isArray(advisorUserId)
		? advisorUserId
		: [advisorUserId];

	const rows = await database
		.select({
			id: farmerCropNotification.id,
			scheduledFor: farmerCropNotification.scheduledFor,
			instruction: farmerCropNotification.instruction,
			isCompleted: farmerCropNotification.isCompleted,
			completedAt: farmerCropNotification.completedAt,
			taskRemark: farmerCropNotification.taskRemark,
			createdAt: farmerCropNotification.createdAt,
			farmerName: farmer.name,
			farmerId: farmer.id,
			cropName: crop.name,
			cropScheduleStartDay: cropSchedule.startDay,
			cropScheduleEndDay: cropSchedule.endDay,
			farmerCropId: farmerCropNotification.farmerCropId,
		})
		.from(farmerCropNotification)
		.innerJoin(farmer, eq(farmer.id, farmerCropNotification.farmerId))
		.innerJoin(crop, eq(crop.id, farmerCropNotification.cropId))
		.innerJoin(
			cropSchedule,
			eq(cropSchedule.id, farmerCropNotification.cropScheduleId)
		)
		.where(
			and(
				inArray(farmerCropNotification.advisorUserId, advisorUserIds),
				farmerId ? eq(farmerCropNotification.farmerId, farmerId) : undefined,
				lte(farmerCropNotification.scheduledFor, today)
			)
		)
		.orderBy(desc(farmerCropNotification.scheduledFor));

	const categorizedTasks: CategorizedTask[] = [];

	for (const row of rows) {
		const task = categorizeTask(row, today);
		if (task && matchesCategory(task, category, today)) {
			categorizedTasks.push(task);
		}
	}

	return categorizedTasks;
}

export async function getCurrentDashboardTasks(
	database: typeof db,
	advisorUserIds: string[]
): Promise<CategorizedTask[]> {
	const today = getTodayIstDate();

	const rows = await database
		.select({
			id: farmerCropNotification.id,
			scheduledFor: farmerCropNotification.scheduledFor,
			instruction: farmerCropNotification.instruction,
			isCompleted: farmerCropNotification.isCompleted,
			completedAt: farmerCropNotification.completedAt,
			taskRemark: farmerCropNotification.taskRemark,
			createdAt: farmerCropNotification.createdAt,
			farmerName: farmer.name,
			farmerId: farmer.id,
			cropName: crop.name,
			cropScheduleStartDay: cropSchedule.startDay,
			cropScheduleEndDay: cropSchedule.endDay,
			farmerCropId: farmerCropNotification.farmerCropId,
		})
		.from(farmerCropNotification)
		.innerJoin(farmer, eq(farmer.id, farmerCropNotification.farmerId))
		.innerJoin(crop, eq(crop.id, farmerCropNotification.cropId))
		.innerJoin(
			cropSchedule,
			eq(cropSchedule.id, farmerCropNotification.cropScheduleId)
		)
		.where(
			and(
				inArray(farmerCropNotification.advisorUserId, advisorUserIds),
				lte(farmerCropNotification.scheduledFor, today)
			)
		)
		.orderBy(farmerCropNotification.scheduledFor)
		.limit(50);

	const currentTasks: CategorizedTask[] = [];

	for (const row of rows) {
		const task = categorizeTask(row, today);
		if (task && matchesCategory(task, "current", today)) {
			currentTasks.push(task);
		}
	}

	return currentTasks.slice(0, 5);
}

export interface CompleteTaskResult {
	status: "completed" | "already_completed" | "not_found";
	task?: {
		id: string;
		isCompleted: true;
		completedAt: string;
		taskRemark: string | null;
	};
}

export async function completeTask(
	database: typeof db,
	taskId: string,
	advisorUserIds: string[],
	remark?: string
): Promise<CompleteTaskResult> {
	const normalizedRemark = remark?.trim() || null;

	const [completedTask] = await database
		.update(farmerCropNotification)
		.set({
			isCompleted: true,
			completedAt: new Date(),
			taskRemark: normalizedRemark,
		})
		.where(
			and(
				eq(farmerCropNotification.id, taskId),
				eq(farmerCropNotification.isCompleted, false),
				inArray(farmerCropNotification.advisorUserId, advisorUserIds)
			)
		)
		.returning({
			id: farmerCropNotification.id,
			isCompleted: farmerCropNotification.isCompleted,
			completedAt: farmerCropNotification.completedAt,
			taskRemark: farmerCropNotification.taskRemark,
		});

	if (completedTask) {
		return {
			status: "completed",
			task: {
				id: completedTask.id,
				isCompleted: true as const,
				completedAt: completedTask.completedAt?.toISOString() ?? "",
				taskRemark: completedTask.taskRemark,
			},
		};
	}

	// Check if task exists at all (for 404 vs 409 distinction)
	const existingTask = await database
		.select({
			id: farmerCropNotification.id,
			isCompleted: farmerCropNotification.isCompleted,
		})
		.from(farmerCropNotification)
		.where(
			and(
				eq(farmerCropNotification.id, taskId),
				inArray(farmerCropNotification.advisorUserId, advisorUserIds)
			)
		)
		.limit(1);

	if (existingTask.length === 0) {
		return { status: "not_found" };
	}

	return { status: "already_completed" };
}

export async function getTaskSummary(
	database: typeof db,
	farmerId: string,
	advisorUserIds?: string[]
): Promise<{ total: number; completed: number }> {
	const rows = await database
		.select({
			isCompleted: farmerCropNotification.isCompleted,
		})
		.from(farmerCropNotification)
		.where(
			and(
				eq(farmerCropNotification.farmerId, farmerId),
				advisorUserIds
					? inArray(farmerCropNotification.advisorUserId, advisorUserIds)
					: undefined
			)
		);

	const total = rows.length;
	const completed = rows.filter((row) => row.isCompleted).length;

	return { total, completed };
}
