import { CANONICAL_ORDER_STATUSES } from "./order-lifecycle";

export const phoneNumberPattern = /^\+[1-9]\d{7,14}$/;
export const orderStatuses = CANONICAL_ORDER_STATUSES;
export const queueStatuses = CANONICAL_ORDER_STATUSES;
export const followUpSlots = [1, 2, 3, 4] as const;
export type FollowUpSlot = (typeof followUpSlots)[number];

export const calculateTotalCodAmount = (
	paymentMode: "cod" | "partial_payment" | "prepaid",
	orderTotal: number,
	paidAmount: number
): number => {
	if (paymentMode === "cod") {
		return orderTotal;
	}
	if (paymentMode === "partial_payment") {
		return orderTotal - paidAmount;
	}
	return 0;
};

export const normalizePhoneNumber = (value: string): string =>
	value.replace(/\s+/g, "");

export const getEffectiveFarmerDetails = (currentOrder: {
	farmerAddressAt: null | string;
	farmerDistrict: null | string;
	farmerNearbyLandmark: null | string;
	farmerPincode: null | string;
	farmerPost: null | string;
	farmerPrimaryMobileNumber: string;
	farmerSecondaryMobileNumber: null | string;
	farmerTaluka: null | string;
	pendingFarmerAddressAt: null | string;
	pendingFarmerDistrict: null | string;
	pendingFarmerNearbyLandmark: null | string;
	pendingFarmerPincode: null | string;
	pendingFarmerPost: null | string;
	pendingFarmerPrimaryMobileNumber: null | string;
	pendingFarmerSecondaryMobileNumber: null | string;
	pendingFarmerTaluka: null | string;
}) => ({
	addressAt:
		currentOrder.pendingFarmerAddressAt ?? currentOrder.farmerAddressAt ?? "",
	district:
		currentOrder.pendingFarmerDistrict ?? currentOrder.farmerDistrict ?? "",
	nearbyLandmark:
		currentOrder.pendingFarmerNearbyLandmark ??
		currentOrder.farmerNearbyLandmark,
	pincode:
		currentOrder.pendingFarmerPincode ?? currentOrder.farmerPincode ?? "",
	post: currentOrder.pendingFarmerPost ?? currentOrder.farmerPost ?? "",
	primaryMobileNumber:
		currentOrder.pendingFarmerPrimaryMobileNumber ??
		currentOrder.farmerPrimaryMobileNumber,
	secondaryMobileNumber:
		currentOrder.pendingFarmerSecondaryMobileNumber ??
		currentOrder.farmerSecondaryMobileNumber,
	taluka: currentOrder.pendingFarmerTaluka ?? currentOrder.farmerTaluka ?? "",
});

export const getPendingFarmerDetails = (currentOrder: {
	pendingFarmerAddressAt: null | string;
	pendingFarmerDistrict: null | string;
	pendingFarmerNearbyLandmark: null | string;
	pendingFarmerPincode: null | string;
	pendingFarmerPost: null | string;
	pendingFarmerPrimaryMobileNumber: null | string;
	pendingFarmerSecondaryMobileNumber: null | string;
	pendingFarmerTaluka: null | string;
	pendingFarmerUpdatedAt: Date | null;
	pendingFarmerUpdatedByUserId: null | string;
}) => ({
	addressAt: currentOrder.pendingFarmerAddressAt,
	district: currentOrder.pendingFarmerDistrict,
	nearbyLandmark: currentOrder.pendingFarmerNearbyLandmark,
	pincode: currentOrder.pendingFarmerPincode,
	post: currentOrder.pendingFarmerPost,
	primaryMobileNumber: currentOrder.pendingFarmerPrimaryMobileNumber,
	secondaryMobileNumber: currentOrder.pendingFarmerSecondaryMobileNumber,
	taluka: currentOrder.pendingFarmerTaluka,
	updatedAt: currentOrder.pendingFarmerUpdatedAt,
	updatedByUserId: currentOrder.pendingFarmerUpdatedByUserId,
});

interface FollowUpOrderColumns {
	followUp1Text: null | string | string[];
	followUp1UpdatedAt: Date | null;
	followUp1UpdatedByUserId: null | string;
	followUp2Text: null | string | string[];
	followUp2UpdatedAt: Date | null;
	followUp2UpdatedByUserId: null | string;
	followUp3Text: null | string | string[];
	followUp3UpdatedAt: Date | null;
	followUp3UpdatedByUserId: null | string;
	followUp4Text: null | string | string[];
	followUp4UpdatedAt: Date | null;
	followUp4UpdatedByUserId: null | string;
}

export const normalizeFollowUpInput = (value: undefined | string) => {
	const trimmed = value?.trim();
	return trimmed ? trimmed : null;
};

const formatFollowUpText = (value: null | string | string[]) => {
	if (Array.isArray(value)) {
		const text = value.filter(Boolean).join(", ");
		return text || null;
	}

	return value;
};

export const getFollowUps = (
	currentOrder: FollowUpOrderColumns,
	currentUserId: string,
	userNameById: Map<string, string>
) =>
	followUpSlots.map((slot) => {
		const text = formatFollowUpText(currentOrder[`followUp${slot}Text`]);
		const updatedAt = currentOrder[`followUp${slot}UpdatedAt`];
		const updatedByUserId = currentOrder[`followUp${slot}UpdatedByUserId`];
		const hasValue = Boolean(text);

		return {
			canEdit: !hasValue || updatedByUserId === currentUserId,
			slot,
			text,
			updatedAt,
			updatedByName: updatedByUserId
				? (userNameById.get(updatedByUserId) ?? null)
				: null,
			updatedByUserId,
		};
	});

export const getFollowUpUserIds = (currentOrder: FollowUpOrderColumns) =>
	followUpSlots
		.map((slot) => currentOrder[`followUp${slot}UpdatedByUserId`])
		.filter((value): value is string => Boolean(value));

type VerificationOrderStatus = (typeof CANONICAL_ORDER_STATUSES)[number];

export const isVerificationOrderStatus = (
	status: string
): status is VerificationOrderStatus =>
	CANONICAL_ORDER_STATUSES.some((currentStatus) => currentStatus === status);

export const toVerificationOrder = (
	currentOrder: {
		approvedAt: Date | null;
		cancelledAt: Date | null;
		cancelledReason: null | string;
		consignmentNumber: null | string;
		createdAt: Date;
		createdByName: string;
		farmerAddressAt: null | string;
		farmerDistrict: null | string;
		farmerId: string;
		farmerName: string;
		farmerNearbyLandmark: null | string;
		farmerPincode: null | string;
		farmerPost: null | string;
		farmerPrimaryMobileNumber: string;
		farmerSecondaryMobileNumber: null | string;
		farmerTaluka: null | string;
		grandTotalAmount: string;
		id: string;
		orderId: string | null;
		paidAmount: string;
		paymentMode: "cod" | "partial_payment" | "prepaid";
		pendingFarmerAddressAt: null | string;
		pendingFarmerDistrict: null | string;
		pendingFarmerNearbyLandmark: null | string;
		pendingFarmerPincode: null | string;
		pendingFarmerPost: null | string;
		pendingFarmerPrimaryMobileNumber: null | string;
		pendingFarmerSecondaryMobileNumber: null | string;
		pendingFarmerTaluka: null | string;
		pendingFarmerUpdatedAt: Date | null;
		pendingFarmerUpdatedByUserId: null | string;
		shippingCharges: string;
		status: VerificationOrderStatus;
		subtotalAmount: string;
		totalCodAmount: string;
		totalDiscountAmount: string;
	} & FollowUpOrderColumns,
	currentUserId: string,
	userNameById: Map<string, string>,
	itemsByOrderId: Map<
		string,
		Array<{
			id: string;
			lineTotalAmount: string;
			orderId: string;
			productName: string;
			productSku: string;
			quantity: number;
			sellingPricePerUnit: string;
		}>
	>
) => ({
	approvedAt: currentOrder.approvedAt,
	cancelledAt: currentOrder.cancelledAt,
	cancelledReason: currentOrder.cancelledReason,
	consignmentNumber: currentOrder.consignmentNumber,
	createdAt: currentOrder.createdAt,
	createdByName: currentOrder.createdByName,
	effectiveFarmerDetails: getEffectiveFarmerDetails(currentOrder),
	farmerDetails: {
		addressAt: currentOrder.farmerAddressAt ?? "",
		district: currentOrder.farmerDistrict ?? "",
		nearbyLandmark: currentOrder.farmerNearbyLandmark,
		pincode: currentOrder.farmerPincode ?? "",
		post: currentOrder.farmerPost ?? "",
		primaryMobileNumber: currentOrder.farmerPrimaryMobileNumber,
		secondaryMobileNumber: currentOrder.farmerSecondaryMobileNumber,
		taluka: currentOrder.farmerTaluka ?? "",
	},
	farmerId: currentOrder.farmerId,
	farmerName: currentOrder.farmerName,
	grandTotalAmount: currentOrder.grandTotalAmount,
	id: currentOrder.id,
	items: itemsByOrderId.get(currentOrder.id) ?? [],
	orderId: currentOrder.orderId,
	paidAmount: currentOrder.paidAmount,
	paymentMode: currentOrder.paymentMode,
	pendingFarmerDetails: getPendingFarmerDetails(currentOrder),
	followUps: getFollowUps(currentOrder, currentUserId, userNameById),
	shippingCharges: currentOrder.shippingCharges,
	status: currentOrder.status,
	subtotalAmount: currentOrder.subtotalAmount,
	totalCodAmount: currentOrder.totalCodAmount,
	totalDiscountAmount: currentOrder.totalDiscountAmount,
});

export const createItemsByOrderId = (
	items: Array<{
		id: string;
		lineTotalAmount: string;
		orderId: string;
		productName: string;
		productSku: string;
		quantity: number;
		unitPricePerUnit: string;
		sellingPricePerUnit: string;
	}>
) => {
	const itemsByOrderId = new Map<string, typeof items>();

	for (const currentItem of items) {
		const existingItems = itemsByOrderId.get(currentItem.orderId);
		if (existingItems) {
			existingItems.push(currentItem);
			continue;
		}
		itemsByOrderId.set(currentItem.orderId, [currentItem]);
	}

	return itemsByOrderId;
};
