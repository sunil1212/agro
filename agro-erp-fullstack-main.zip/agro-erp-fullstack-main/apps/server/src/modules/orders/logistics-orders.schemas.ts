import z from "zod";

const pincodePattern = /^\d{6}$/;

export const cancellationSchema = z.object({
	reason: z.string().trim().max(1000).optional(),
});

export const pendingFarmerUpdateSchema = z.object({
	addressAt: z.string().trim().min(1, "At / Village is required"),
	district: z.string().trim().min(1, "District is required"),
	nearbyLandmark: z.string().trim().optional(),
	pincode: z.string().trim().regex(pincodePattern, "Pincode must be 6 digits"),
	post: z.string().trim().min(1, "Post is required"),
	primaryMobileNumber: z.string().trim().min(1, "Primary mobile is required"),
	secondaryMobileNumber: z.string().trim().optional(),
	taluka: z.string().trim().min(1, "Taluka is required"),
});

export const followUpUpdateSchema = z.object({
	slot: z.number().int().min(1).max(4),
	text: z.string().trim().max(1000),
});

export const logisticsStatusUpdateSchema = z.object({
	status: z.enum(["delivered", "return_in_transit"]),
});

export const orderWriteSchema = z.object({
	farmerId: z.string().uuid(),
	items: z
		.array(
			z.object({
				lineTotalAmount: z.number().finite().nonnegative(),
				productId: z.string().min(1),
				quantity: z.number().int().positive(),
				sellingPricePerUnit: z.number().finite().nonnegative(),
				unitPricePerUnit: z.number().finite().nonnegative(),
			})
		)
		.min(1),
	paidAmount: z.number().finite().nonnegative().optional(),
	paymentMode: z.enum(["cod", "partial_payment", "prepaid"]),
	shippingCharges: z.number().finite().nonnegative(),
	transactionScreenshotBase64: z.string().optional(),
	transactionUtr: z.string().trim().optional(),
});
