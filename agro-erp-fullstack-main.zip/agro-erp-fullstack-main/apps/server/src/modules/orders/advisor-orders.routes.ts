import type { Router } from "express";
import { Router as createRouter } from "express";

import {
	cancelAdvisorOrder,
	createAdvisorOrder,
	getAdvisorOrder,
	getAdvisorOrderCreateOptions,
	listAdvisorOrders,
	listAssignedAdvisorOrders,
	rejectAdvisorOrderStatusUpdate,
} from "./advisor-orders.service";

const advisorOrdersRouter: Router = createRouter();

advisorOrdersRouter.get(
	"/advisor/create-options",
	getAdvisorOrderCreateOptions
);
advisorOrdersRouter.get("/advisor/advisors", listAssignedAdvisorOrders);
advisorOrdersRouter.get("/advisor/:orderId", getAdvisorOrder);
advisorOrdersRouter.patch(
	"/advisor/:orderId/status",
	rejectAdvisorOrderStatusUpdate
);
advisorOrdersRouter.post("/advisor/:orderId/cancel", cancelAdvisorOrder);
advisorOrdersRouter.get("/advisor", listAdvisorOrders);
advisorOrdersRouter.post("/advisor", createAdvisorOrder);

export default advisorOrdersRouter;
