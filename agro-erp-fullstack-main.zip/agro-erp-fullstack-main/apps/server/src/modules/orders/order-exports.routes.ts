import { db } from "@agro-erp-fullstack/db";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import {
	getBookingExport,
	getPackingExport,
} from "../../services/order-exports";
import { getUserManagerCode } from "../branches/branches.repository";

export const orderExportsRouter: Router = createRouter();

const getExportContext = async (request: Request, response: Response) => {
	const session = await requireActionSession(request, response, {
		action: "account:create_staff",
		forbiddenMessage: "Only admins can generate exports",
		forbiddenSuccess: false,
	});
	if (!session) {
		return null;
	}
	const managerCode = await getUserManagerCode(db, session.user.id);
	if (!managerCode) {
		response.status(404).json({ message: "Branch not found", success: false });
		return null;
	}
	return { managerCode };
};

const sendCsv = (response: Response, csv: string, fileName: string) =>
	response
		.status(200)
		.setHeader("Content-Type", "text/csv; charset=utf-8")
		.setHeader("Content-Disposition", `attachment; filename="${fileName}"`)
		.send(csv);

orderExportsRouter.get(
	"/packing.csv",
	async (request: Request, response: Response) => {
		try {
			const context = await getExportContext(request, response);
			if (!context) {
				return;
			}
			const { from, to } = request.query as { from?: string; to?: string };
			const csv = await getPackingExport({
				fromDate: from,
				managerCode: context.managerCode,
				toDate: to,
			});
			const date = new Date().toISOString().slice(0, 10);
			sendCsv(
				response,
				csv,
				`packing-sheet-${context.managerCode}-${date}.csv`
			);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

orderExportsRouter.get(
	"/booking.csv",
	async (request: Request, response: Response) => {
		try {
			const context = await getExportContext(request, response);
			if (!context) {
				return;
			}
			const { from, to } = request.query as { from?: string; to?: string };
			const csv = await getBookingExport({
				fromDate: from,
				managerCode: context.managerCode,
				toDate: to,
			});
			if (!csv) {
				response.status(409).json({
					message:
						"No orders available for export. Orders may need consignment numbers assigned.",
					success: false,
				});
				return;
			}
			const date = new Date().toISOString().slice(0, 10);
			sendCsv(
				response,
				csv,
				`booking-sheet-${context.managerCode}-${date}.csv`
			);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);
