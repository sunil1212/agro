import type { Router } from "express";
import { Router as createRouter } from "express";

import logisticsOrdersController from "./logistics-orders.controller";

const ordersRouter: Router = createRouter();

ordersRouter.use(logisticsOrdersController);

export default ordersRouter satisfies Router;
