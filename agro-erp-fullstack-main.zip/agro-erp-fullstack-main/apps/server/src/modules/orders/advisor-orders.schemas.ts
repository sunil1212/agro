import z from "zod";

const advisorOrderStatuses = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;

const paymentModes = ["cod", "partial_payment", "prepaid"] as const;

export const createAdvisorOrderSchema = z.object({
	farmerId: z.string().trim().min(1),
	items: z
		.array(
			z.object({
				productId: z.string().trim().min(1),
				quantity: z.number().int().positive(),
				unitPricePerUnit: z.number().nonnegative(),
				sellingPricePerUnit: z.number().nonnegative(),
				lineTotalAmount: z.number().nonnegative(),
			})
		)
		.min(1),
	paymentMode: z.enum(paymentModes),
	paidAmount: z.number().nonnegative().optional(),
	shippingCharges: z.number().nonnegative(),
	couponCode: z.string().trim().optional(),
	transactionUtr: z.string().trim().optional(),
	transactionScreenshotBase64: z.string().trim().optional(),
});

export const updateAdvisorOrderStatusSchema = z.object({
	status: z.enum(advisorOrderStatuses),
});
