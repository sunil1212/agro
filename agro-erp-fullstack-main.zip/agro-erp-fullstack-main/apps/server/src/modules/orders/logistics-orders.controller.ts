import { teamLeaderAdvisor, user } from "@agro-erp-fullstack/db/schema/auth";
import { farmer, farmerProduct } from "@agro-erp-fullstack/db/schema/farmer";
import {
	branchOrderSequence,
	order,
	orderConsignment,
	orderDiscount,
	orderItem,
	orderPaymentTransaction,
	orderPendingFarmerUpdate,
	postOrderFollowUp,
	preOrderConfirmationFollowUp,
} from "@agro-erp-fullstack/db/schema/order";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import {
	and,
	asc,
	desc,
	eq,
	gte,
	inArray,
	isNull,
	lte,
	ne,
	or,
	sql,
} from "drizzle-orm";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import z from "zod";
import {
	requireActionSession,
	requireRoleSession,
	requireSession,
} from "../../auth/session";
import { toCsvWithBom } from "../../lib/csv";
import { HttpError, sendErrorResponse } from "../../lib/http";
import {
	getBranchByManagerCode,
	getUserManagerCode,
} from "../branches/branches.repository";
import {
	createFollowUpUserNameMap,
	ordersDatabase,
} from "./logistics-orders.repository";
import {
	cancellationSchema,
	followUpUpdateSchema,
	logisticsStatusUpdateSchema,
	orderWriteSchema,
	pendingFarmerUpdateSchema,
} from "./logistics-orders.schemas";
import {
	calculateTotalCodAmount,
	createItemsByOrderId,
	type FollowUpSlot,
	getEffectiveFarmerDetails,
	getFollowUps,
	getFollowUpUserIds,
	getPendingFarmerDetails,
	isVerificationOrderStatus,
	normalizeFollowUpInput,
	normalizePhoneNumber,
	phoneNumberPattern,
	queueStatuses,
	toVerificationOrder,
} from "./logistics-orders.service";
import {
	assertOrderTransitionAllowed,
	editableOrderStatuses,
	formatBranchOrderId,
	getFollowUpPhase,
} from "./order-lifecycle";

const ordersRouter: Router = createRouter();

const followUpSelection = {
	followUp1Text: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp1Text} else null end`,
	followUp1UpdatedAt: sql<Date | null>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp1UpdatedAt} else null end`,
	followUp1UpdatedByUserId: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp1UpdatedByUserId} else null end`,
	followUp2Text: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp2Text} else null end`,
	followUp2UpdatedAt: sql<Date | null>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp2UpdatedAt} else null end`,
	followUp2UpdatedByUserId: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp2UpdatedByUserId} else null end`,
	followUp3Text: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp3Text} else null end`,
	followUp3UpdatedAt: sql<Date | null>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp3UpdatedAt} else null end`,
	followUp3UpdatedByUserId: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp3UpdatedByUserId} else null end`,
	followUp4Text: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp4Text} else null end`,
	followUp4UpdatedAt: sql<Date | null>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp4UpdatedAt} else null end`,
	followUp4UpdatedByUserId: sql<
		null | string
	>`case when ${order.status} in ('created', 'cancelled') then ${preOrderConfirmationFollowUp.followUp4UpdatedByUserId} else null end`,
} as const;

const trackingFollowUpUpdateSchema = z.object({
	slot: z.number().int().min(1).max(4),
	values: z.array(z.string().trim().min(1).max(120)).max(12),
});
const dateOnlyPattern = /^\d{4}-\d{2}-\d{2}$/;
const orderExportQuerySchema = z
	.object({
		from: z.string().regex(dateOnlyPattern, "Start date is required"),
		to: z.string().regex(dateOnlyPattern, "End date is required"),
	})
	.refine((value) => value.from <= value.to, {
		message: "Start date must be before end date",
		path: ["to"],
	});

const ORDER_EXPORT_HEADERS = [
	"Order ID",
	"Created At",
	"Status",
	"Advisor",
	"Farmer",
	"Primary Mobile",
	"Payment Mode",
	"Subtotal",
	"Shipping",
	"Discount",
	"Grand Total",
	"Paid",
	"COD",
	"Items",
] as const;

const toIstDateStart = (value: string) => new Date(`${value}T00:00:00+05:30`);
const toIstDateEnd = (value: string) => new Date(`${value}T23:59:59.999+05:30`);

const joinAddressParts = (parts: Array<null | string>) =>
	parts
		.map((part) => part?.trim())
		.filter((part): part is string => Boolean(part))
		.join(", ");

const pendingFarmerSelection = {
	pendingFarmerAddressAt: orderPendingFarmerUpdate.addressAt,
	pendingFarmerDistrict: orderPendingFarmerUpdate.district,
	pendingFarmerNearbyLandmark: orderPendingFarmerUpdate.nearbyLandmark,
	pendingFarmerPincode: orderPendingFarmerUpdate.pincode,
	pendingFarmerPost: orderPendingFarmerUpdate.post,
	pendingFarmerPrimaryMobileNumber:
		orderPendingFarmerUpdate.primaryMobileNumber,
	pendingFarmerSecondaryMobileNumber:
		orderPendingFarmerUpdate.secondaryMobileNumber,
	pendingFarmerTaluka: orderPendingFarmerUpdate.taluka,
	pendingFarmerUpdatedAt: orderPendingFarmerUpdate.updatedAt,
	pendingFarmerUpdatedByUserId: orderPendingFarmerUpdate.updatedByUserId,
} as const;

const requireOrdersSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "logistics_order:verify",
		forbiddenMessage: "You do not have order verification access",
		forbiddenSuccess: false,
	});

const requireVerificationDashboardSession = async (
	request: Request,
	response: Response
) => {
	const session = await requireSession(request, response, false);
	if (!session) {
		return null;
	}

	if (!["admin", "logistics"].includes(session.user.role)) {
		response.status(403).json({
			message: "You do not have order verification access",
			success: false,
		});
		return null;
	}

	return session;
};

const requireOrderEditSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "advisor_order:edit",
		forbiddenMessage: "You do not have order edit access",
		forbiddenSuccess: false,
	});

const isAssignedTeamLeaderOrder = async (
	teamLeaderId: string,
	advisorId: string
) => {
	const [assignment] = await ordersDatabase
		.select({ advisorId: teamLeaderAdvisor.advisorId })
		.from(teamLeaderAdvisor)
		.where(
			and(
				eq(teamLeaderAdvisor.teamLeaderId, teamLeaderId),
				eq(teamLeaderAdvisor.advisorId, advisorId)
			)
		)
		.limit(1);

	return Boolean(assignment);
};

const canTeamLeaderAccessOrder = async (
	teamLeaderId: string,
	orderCreatorId: string
) =>
	orderCreatorId === teamLeaderId ||
	(await isAssignedTeamLeaderOrder(teamLeaderId, orderCreatorId));

const canCurrentUserEditOrderStatus = (role: string, status: string) =>
	role === "team_leader"
		? status === "created"
		: (editableOrderStatuses as readonly string[]).includes(status);

ordersRouter.get(
	"/export.csv",
	async (request: Request, response: Response) => {
		try {
			const session = await requireRoleSession(request, response, {
				allowedRoles: ["admin"],
				forbiddenMessage: "Only admins can export orders",
			});
			if (!session) {
				return;
			}

			const query = orderExportQuerySchema.parse({
				from: request.query.from,
				to: request.query.to,
			});
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);
			if (!managerCode) {
				throw new HttpError(404, "Branch not found");
			}

			const orderRows = await ordersDatabase
				.select({
					createdAt: order.createdAt,
					createdByName: user.name,
					farmerName: farmer.name,
					grandTotalAmount: order.grandTotalAmount,
					id: order.id,
					orderId: order.orderId,
					paidAmount: order.paidAmount,
					paymentMode: order.paymentMode,
					primaryMobileNumber: farmer.primaryMobileNumber,
					shippingCharges: order.shippingCharges,
					status: order.status,
					subtotalAmount: order.subtotalAmount,
					totalCodAmount: order.totalCodAmount,
					totalDiscountAmount: sql<string>`coalesce(${orderDiscount.totalDiscountAmount}, '0.00')`,
				})
				.from(order)
				.innerJoin(farmer, eq(farmer.id, order.farmerId))
				.innerJoin(user, eq(user.id, order.createdByUserId))
				.leftJoin(orderDiscount, eq(orderDiscount.orderId, order.id))
				.where(
					and(
						gte(order.createdAt, toIstDateStart(query.from)),
						lte(order.createdAt, toIstDateEnd(query.to)),
						sql`exists (
						select 1
						from user_manager_code branch_code
						where branch_code.manager_code = ${managerCode}
							and branch_code.user_id in (
								${user.id},
								${user.createdByUserId}
							)
					)`
					)
				)
				.orderBy(desc(order.createdAt));

			const itemRows = orderRows.length
				? await ordersDatabase
						.select({
							lineTotalAmount: orderItem.lineTotalAmount,
							orderId: orderItem.orderId,
							productName: product.name,
							productSku: orderItem.productSku,
							quantity: orderItem.quantity,
						})
						.from(orderItem)
						.innerJoin(product, eq(product.skuCode, orderItem.productSku))
						.where(
							inArray(
								orderItem.orderId,
								orderRows.map((item) => item.id)
							)
						)
						.orderBy(asc(orderItem.createdAt))
				: [];
			const itemSummaryByOrderId = new Map<string, string[]>();
			for (const itemRow of itemRows) {
				const summary = `${itemRow.productName} (${itemRow.productSku}) x ${itemRow.quantity} = ${itemRow.lineTotalAmount}`;
				const summaries = itemSummaryByOrderId.get(itemRow.orderId) ?? [];
				summaries.push(summary);
				itemSummaryByOrderId.set(itemRow.orderId, summaries);
			}

			const csv = toCsvWithBom(
				orderRows.map((currentOrder) => ({
					COD: currentOrder.totalCodAmount,
					"Created At": currentOrder.createdAt.toISOString(),
					Discount: currentOrder.totalDiscountAmount,
					Advisor: currentOrder.createdByName,
					Farmer: currentOrder.farmerName,
					"Grand Total": currentOrder.grandTotalAmount,
					Items: (itemSummaryByOrderId.get(currentOrder.id) ?? []).join("; "),
					"Order ID": currentOrder.orderId ?? currentOrder.id,
					Paid: currentOrder.paidAmount,
					"Payment Mode": currentOrder.paymentMode,
					"Primary Mobile": currentOrder.primaryMobileNumber,
					Shipping: currentOrder.shippingCharges,
					Status: currentOrder.status,
					Subtotal: currentOrder.subtotalAmount,
				})),
				ORDER_EXPORT_HEADERS
			);
			const fileName = `orders-export-${managerCode}-${query.from}-${query.to}.csv`;
			response
				.status(200)
				.setHeader("Content-Type", "text/csv; charset=utf-8")
				.setHeader("Content-Disposition", `attachment; filename="${fileName}"`)
				.send(csv);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.get(
	"/verification",
	async (request: Request, response: Response) => {
		try {
			const session = await requireVerificationDashboardSession(
				request,
				response
			);
			if (!session) {
				return;
			}

			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);
			if (!managerCode) {
				response.status(200).json({ orders: [], success: true });
				return;
			}

			const queueOrders = await ordersDatabase
				.select({
					approvedAt: order.approvedAt,
					cancelledAt: order.cancelledAt,
					cancelledReason: order.cancelledReason,
					consignmentNumber: orderConsignment.consignmentNumber,
					createdAt: order.createdAt,
					createdByName: user.name,
					farmerAddressAt: farmer.addressAt,
					farmerDistrict: farmer.district,
					farmerId: farmer.id,
					farmerName: farmer.name,
					farmerNearbyLandmark: farmer.nearbyLandmark,
					farmerPincode: farmer.pincode,
					farmerPost: farmer.post,
					farmerPrimaryMobileNumber: farmer.primaryMobileNumber,
					farmerSecondaryMobileNumber: farmer.secondaryMobileNumber,
					farmerTaluka: farmer.taluka,
					grandTotalAmount: order.grandTotalAmount,
					id: order.id,
					orderId: order.orderId,
					paidAmount: order.paidAmount,
					paymentMode: order.paymentMode,
					...followUpSelection,
					...pendingFarmerSelection,
					shippingCharges: order.shippingCharges,
					status: order.status,
					subtotalAmount: order.subtotalAmount,
					totalCodAmount: order.totalCodAmount,
					totalDiscountAmount: sql<string>`coalesce(${orderDiscount.totalDiscountAmount}, '0.00')`,
				})
				.from(order)
				.innerJoin(farmer, eq(farmer.id, order.farmerId))
				.innerJoin(user, eq(user.id, order.createdByUserId))
				.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
				.leftJoin(orderDiscount, eq(orderDiscount.orderId, order.id))
				.leftJoin(
					orderPendingFarmerUpdate,
					eq(orderPendingFarmerUpdate.orderId, order.id)
				)
				.leftJoin(
					preOrderConfirmationFollowUp,
					eq(preOrderConfirmationFollowUp.orderId, order.id)
				)
				.where(
					and(
						inArray(order.status, queueStatuses),
						sql`exists (
							select 1
							from user_manager_code branch_code
							where branch_code.manager_code = ${managerCode}
								and branch_code.user_id in (
									${user.id},
									${user.createdByUserId}
								)
						)`
					)
				)
				.orderBy(desc(order.createdAt));

			const itemRows = queueOrders.length
				? await ordersDatabase
						.select({
							id: orderItem.id,
							lineTotalAmount: orderItem.lineTotalAmount,
							orderId: orderItem.orderId,
							productName: product.name,
							productSku: orderItem.productSku,
							quantity: orderItem.quantity,
							unitPricePerUnit: orderItem.unitPricePerUnit,
							sellingPricePerUnit: orderItem.sellingPricePerUnit,
						})
						.from(orderItem)
						.innerJoin(product, eq(product.skuCode, orderItem.productSku))
						.where(
							inArray(
								orderItem.orderId,
								queueOrders.map((item) => item.id)
							)
						)
						.orderBy(asc(orderItem.createdAt))
				: [];

			const itemsByOrderId = createItemsByOrderId(itemRows);
			const allFollowUpIds = queueOrders.flatMap((o) => getFollowUpUserIds(o));
			const followUpUserNameById =
				await createFollowUpUserNameMap(allFollowUpIds);

			response.status(200).json({
				orders: queueOrders.map((currentOrder) =>
					toVerificationOrder(
						{
							...currentOrder,
							status: isVerificationOrderStatus(currentOrder.status)
								? currentOrder.status
								: "created",
						},
						session.user.id,
						followUpUserNameById,
						itemsByOrderId
					)
				),
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.patch(
	"/verification/:orderId/status",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrdersSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const values = logisticsStatusUpdateSchema.parse(request.body);
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentRows = await ordersDatabase
				.select({
					status: order.status,
					createdByUserId: order.createdByUserId,
				})
				.from(order)
				.where(eq(order.id, orderId))
				.limit(1);
			const currentOrder = currentRows[0];
			if (!currentOrder) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			try {
				assertOrderTransitionAllowed({
					actorRole: "logistics",
					currentStatus: currentOrder.status,
					nextStatus: values.status,
				});
			} catch {
				response.status(400).json({
					message: `Invalid transition from ${currentOrder.status} to ${values.status}`,
					success: false,
				});
				return;
			}

			const [updated] = await ordersDatabase
				.update(order)
				.set({ status: values.status })
				.where(
					and(eq(order.id, orderId), eq(order.status, currentOrder.status))
				)
				.returning({ status: order.status });

			if (!updated) {
				response.status(409).json({
					message: "Order status changed; refresh and try again",
					success: false,
				});
				return;
			}

			if (values.status === "delivered") {
				const [assignmentCandidate] = await ordersDatabase
					.select({
						farmerId: order.farmerId,
						productSku: orderItem.productSku,
					})
					.from(order)
					.innerJoin(orderItem, eq(orderItem.orderId, order.id))
					.innerJoin(product, eq(product.skuCode, orderItem.productSku))
					.where(
						and(
							eq(order.id, orderId),
							ne(orderItem.sellingPricePerUnit, "0.00"),
							or(ne(product.categoryCode, "FR"), isNull(product.categoryCode))
						)
					)
					.orderBy(asc(orderItem.createdAt))
					.limit(1);

				if (assignmentCandidate) {
					await ordersDatabase
						.insert(farmerProduct)
						.values(assignmentCandidate)
						.onConflictDoNothing({ target: farmerProduct.farmerId });
				}
			}

			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.patch(
	"/verification/:orderId/follow-up",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrdersSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const values = followUpUpdateSchema.parse(request.body);
			const text = normalizeFollowUpInput(values.text);

			if (!text) {
				response.status(400).json({
					message: "Provide follow-up text",
					success: false,
				});
				return;
			}

			const slot = values.slot as FollowUpSlot;
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentRows = await ordersDatabase
				.select({
					createdByUserId: order.createdByUserId,
					status: order.status,
				})
				.from(order)
				.where(eq(order.id, orderId))
				.limit(1);
			const currentOrder = currentRows[0];
			if (!currentOrder) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const followUpTable =
				getFollowUpPhase(currentOrder.status) === "pre_confirmation"
					? preOrderConfirmationFollowUp
					: postOrderFollowUp;
			if (followUpTable !== preOrderConfirmationFollowUp) {
				response.status(400).json({
					message: "Post-order follow-ups are managed from order tracking",
					success: false,
				});
				return;
			}
			const updatedByUserField =
				followUpTable[`followUp${slot}UpdatedByUserId`];
			const [currentFollowUp] = await ordersDatabase
				.select({ updatedByUserId: updatedByUserField })
				.from(followUpTable)
				.where(eq(followUpTable.orderId, orderId))
				.limit(1);

			if (
				currentFollowUp?.updatedByUserId &&
				currentFollowUp.updatedByUserId !== session.user.id
			) {
				response.status(403).json({
					message: "Only the original follow-up owner can edit this slot",
					success: false,
				});
				return;
			}

			const followUpValues = {
				orderId,
				[`followUp${slot}Text`]: text,
				[`followUp${slot}UpdatedAt`]: new Date(),
				[`followUp${slot}UpdatedByUserId`]: session.user.id,
			};
			await ordersDatabase
				.insert(followUpTable)
				.values(followUpValues)
				.onConflictDoUpdate({
					set: {
						[`followUp${slot}Text`]: text,
						[`followUp${slot}UpdatedAt`]: new Date(),
						[`followUp${slot}UpdatedByUserId`]: session.user.id,
					},
					target: followUpTable.orderId,
				});

			const [updatedOrder] = await ordersDatabase
				.select()
				.from(followUpTable)
				.where(eq(followUpTable.orderId, orderId))
				.limit(1);

			if (!updatedOrder) {
				throw new Error("Failed to update follow-up");
			}
			const followUpUserNameById = await createFollowUpUserNameMap(
				getFollowUpUserIds(updatedOrder)
			);

			response.status(200).json({
				followUps: getFollowUps(
					updatedOrder,
					session.user.id,
					followUpUserNameById
				),
				phase: getFollowUpPhase(currentOrder.status),
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.get("/tracking", async (request: Request, response: Response) => {
	try {
		const session = await requireOrdersSession(request, response);
		if (!session) {
			return;
		}

		const managerCode = await getUserManagerCode(
			ordersDatabase,
			session.user.id
		);
		if (!managerCode) {
			response.status(200).json({ orders: [], success: true });
			return;
		}

		const trackingOrders = await ordersDatabase
			.select({
				createdAt: order.createdAt,
				consignmentNumber: orderConsignment.consignmentNumber,
				farmerName: farmer.name,
				farmerAddressAt: farmer.addressAt,
				farmerDistrict: farmer.district,
				farmerNearbyLandmark: farmer.nearbyLandmark,
				farmerPincode: farmer.pincode,
				farmerPost: farmer.post,
				farmerPrimaryMobileNumber: farmer.primaryMobileNumber,
				farmerTaluka: farmer.taluka,
				followUp1Text: postOrderFollowUp.followUp1Text,
				followUp1UpdatedAt: postOrderFollowUp.followUp1UpdatedAt,
				followUp2Text: postOrderFollowUp.followUp2Text,
				followUp2UpdatedAt: postOrderFollowUp.followUp2UpdatedAt,
				followUp3Text: postOrderFollowUp.followUp3Text,
				followUp3UpdatedAt: postOrderFollowUp.followUp3UpdatedAt,
				followUp4Text: postOrderFollowUp.followUp4Text,
				followUp4UpdatedAt: postOrderFollowUp.followUp4UpdatedAt,
				id: order.id,
				orderId: order.orderId,
				status: order.status,
			})
			.from(order)
			.innerJoin(farmer, eq(farmer.id, order.farmerId))
			.innerJoin(user, eq(user.id, order.createdByUserId))
			.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
			.leftJoin(postOrderFollowUp, eq(postOrderFollowUp.orderId, order.id))
			.where(sql`exists (
					select 1
					from user_manager_code branch_code
					where branch_code.manager_code = ${managerCode}
						and branch_code.user_id in (
							${user.id},
							${user.createdByUserId}
						)
				) and ${order.status} in ('confirmed', 'dispatched', 'delivered', 'return_in_transit', 'return_in_warehouse', 'cancelled')`)
			.orderBy(desc(order.createdAt));

		response.status(200).json({
			orders: trackingOrders.map((currentOrder) => ({
				...currentOrder,
				farmerAddress: joinAddressParts([
					currentOrder.farmerAddressAt,
					currentOrder.farmerNearbyLandmark,
					currentOrder.farmerPost,
					currentOrder.farmerTaluka,
					currentOrder.farmerDistrict,
					currentOrder.farmerPincode,
				]),
			})),
			success: true,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
});

ordersRouter.patch(
	"/tracking/:orderId/follow-up",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrdersSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const { slot, values } = trackingFollowUpUpdateSchema.parse(request.body);
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const [currentOrder] = await ordersDatabase
				.select({
					createdByUserId: order.createdByUserId,
				})
				.from(order)
				.where(eq(order.id, orderId))
				.limit(1);

			if (!currentOrder) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const uniqueValues = Array.from(
				new Set(values.map((value) => value.trim()).filter(Boolean))
			);
			const now = new Date();

			await ordersDatabase
				.insert(postOrderFollowUp)
				.values({
					orderId,
					[`followUp${slot}Text`]: uniqueValues,
					[`followUp${slot}UpdatedAt`]: now,
					[`followUp${slot}UpdatedByUserId`]: session.user.id,
				})
				.onConflictDoUpdate({
					set: {
						[`followUp${slot}Text`]: uniqueValues,
						[`followUp${slot}UpdatedAt`]: now,
						[`followUp${slot}UpdatedByUserId`]: session.user.id,
					},
					target: postOrderFollowUp.orderId,
				});

			response.status(200).json({
				followUp: uniqueValues,
				slot,
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.patch(
	"/verification/:orderId/farmer",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrdersSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const parsedBody = pendingFarmerUpdateSchema.parse(request.body);
			const primaryMobileNumber = normalizePhoneNumber(
				parsedBody.primaryMobileNumber
			);
			const secondaryMobileNumber = parsedBody.secondaryMobileNumber
				? normalizePhoneNumber(parsedBody.secondaryMobileNumber)
				: null;

			if (!phoneNumberPattern.test(primaryMobileNumber)) {
				response.status(400).json({
					message: "Primary mobile number is invalid",
					success: false,
				});
				return;
			}

			if (
				secondaryMobileNumber &&
				!phoneNumberPattern.test(secondaryMobileNumber)
			) {
				response.status(400).json({
					message: "Secondary mobile number is invalid",
					success: false,
				});
				return;
			}

			if (
				secondaryMobileNumber &&
				secondaryMobileNumber === primaryMobileNumber
			) {
				response.status(400).json({
					message: "Secondary mobile number must be different",
					success: false,
				});
				return;
			}

			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);
			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentRows = await ordersDatabase
				.select({
					createdByUserId: order.createdByUserId,
					farmerAddressAt: farmer.addressAt,
					farmerDistrict: farmer.district,
					farmerId: farmer.id,
					farmerNearbyLandmark: farmer.nearbyLandmark,
					farmerPincode: farmer.pincode,
					farmerPost: farmer.post,
					farmerPrimaryMobileNumber: farmer.primaryMobileNumber,
					farmerSecondaryMobileNumber: farmer.secondaryMobileNumber,
					farmerTaluka: farmer.taluka,
					id: order.id,
					...pendingFarmerSelection,
					status: order.status,
				})
				.from(order)
				.innerJoin(farmer, eq(farmer.id, order.farmerId))
				.leftJoin(
					orderPendingFarmerUpdate,
					eq(orderPendingFarmerUpdate.orderId, order.id)
				)
				.where(eq(order.id, orderId))
				.limit(1);

			const currentOrder = currentRows[0];
			if (!currentOrder) {
				throw new Error("Order not found");
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			if (currentOrder.status !== "created") {
				response.status(400).json({
					message: "Farmer details can only be edited for created orders",
					success: false,
				});
				return;
			}

			const existingFarmer = await ordersDatabase
				.select({ id: farmer.id })
				.from(farmer)
				.where(
					and(
						eq(farmer.primaryMobileNumber, primaryMobileNumber),
						ne(farmer.id, currentOrder.farmerId)
					)
				)
				.limit(1);

			if (existingFarmer.length > 0) {
				response.status(409).json({
					message: "A farmer with this primary mobile number already exists",
					success: false,
				});
				return;
			}

			const [updatedOrder] = await ordersDatabase
				.insert(orderPendingFarmerUpdate)
				.values({
					addressAt: parsedBody.addressAt.trim(),
					district: parsedBody.district.trim(),
					nearbyLandmark: parsedBody.nearbyLandmark?.trim() || null,
					orderId,
					pincode: parsedBody.pincode.trim(),
					post: parsedBody.post.trim(),
					primaryMobileNumber,
					secondaryMobileNumber,
					taluka: parsedBody.taluka.trim(),
					updatedAt: new Date(),
					updatedByUserId: session.user.id,
				})
				.onConflictDoUpdate({
					set: {
						addressAt: parsedBody.addressAt.trim(),
						district: parsedBody.district.trim(),
						nearbyLandmark: parsedBody.nearbyLandmark?.trim() || null,
						pincode: parsedBody.pincode.trim(),
						post: parsedBody.post.trim(),
						primaryMobileNumber,
						secondaryMobileNumber,
						taluka: parsedBody.taluka.trim(),
						updatedAt: new Date(),
						updatedByUserId: session.user.id,
					},
					target: orderPendingFarmerUpdate.orderId,
				})
				.returning({
					pendingFarmerAddressAt: orderPendingFarmerUpdate.addressAt,
					pendingFarmerDistrict: orderPendingFarmerUpdate.district,
					pendingFarmerNearbyLandmark: orderPendingFarmerUpdate.nearbyLandmark,
					pendingFarmerPincode: orderPendingFarmerUpdate.pincode,
					pendingFarmerPost: orderPendingFarmerUpdate.post,
					pendingFarmerPrimaryMobileNumber:
						orderPendingFarmerUpdate.primaryMobileNumber,
					pendingFarmerSecondaryMobileNumber:
						orderPendingFarmerUpdate.secondaryMobileNumber,
					pendingFarmerTaluka: orderPendingFarmerUpdate.taluka,
					pendingFarmerUpdatedAt: orderPendingFarmerUpdate.updatedAt,
					pendingFarmerUpdatedByUserId:
						orderPendingFarmerUpdate.updatedByUserId,
				});

			if (!updatedOrder) {
				throw new Error("Failed to save farmer details");
			}

			response.status(200).json({
				effectiveFarmerDetails: getEffectiveFarmerDetails({
					...currentOrder,
					...updatedOrder,
				}),
				pendingFarmerDetails: getPendingFarmerDetails(updatedOrder),
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.post(
	"/verification/:orderId/approve",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrdersSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const branch = await getBranchByManagerCode(ordersDatabase, managerCode);
			if (!branch) {
				response.status(409).json({
					message: "Branch configuration not found",
					success: false,
				});
				return;
			}

			const result = await ordersDatabase.transaction(
				// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: confirmation deliberately keeps ID, farmer, consignment, and status mutations in one transaction
				async (tx) => {
					const database = tx as unknown as typeof ordersDatabase;

					const currentRows = await database
						.select({
							createdByUserId: order.createdByUserId,
							farmerId: order.farmerId,
							id: order.id,
							orderId: order.orderId,
							...pendingFarmerSelection,
							status: order.status,
						})
						.from(order)
						.leftJoin(
							orderPendingFarmerUpdate,
							eq(orderPendingFarmerUpdate.orderId, order.id)
						)
						.where(eq(order.id, orderId))
						.limit(1);

					const currentOrder = currentRows[0];
					if (!currentOrder) {
						throw new Error("Order not found");
					}

					const orderCreatorCode = await getUserManagerCode(
						database,
						currentOrder.createdByUserId
					);
					if (orderCreatorCode !== managerCode) {
						throw new Error("Order not found");
					}

					if (currentOrder.status !== "created") {
						throw new Error("Only created orders can be confirmed");
					}

					if (currentOrder.orderId) {
						throw new Error("Order already has a business ID assigned");
					}

					if (currentOrder.pendingFarmerPrimaryMobileNumber) {
						await database
							.update(farmer)
							.set({
								addressAt: currentOrder.pendingFarmerAddressAt ?? undefined,
								district: currentOrder.pendingFarmerDistrict ?? undefined,
								nearbyLandmark:
									currentOrder.pendingFarmerNearbyLandmark ?? null,
								pincode: currentOrder.pendingFarmerPincode ?? undefined,
								post: currentOrder.pendingFarmerPost ?? undefined,
								primaryMobileNumber:
									currentOrder.pendingFarmerPrimaryMobileNumber,
								secondaryMobileNumber:
									currentOrder.pendingFarmerSecondaryMobileNumber,
								taluka: currentOrder.pendingFarmerTaluka ?? undefined,
							})
							.where(eq(farmer.id, currentOrder.farmerId));
					}

					const [sequence] = await database
						.insert(branchOrderSequence)
						.values({
							adminUserId: branch.adminUserId,
							lastValue: 1,
						})
						.onConflictDoUpdate({
							set: {
								lastValue: sql`${branchOrderSequence.lastValue} + 1`,
								updatedAt: new Date(),
							},
							target: branchOrderSequence.adminUserId,
						})
						.returning({ lastValue: branchOrderSequence.lastValue });

					if (!sequence) {
						throw new Error("Failed to allocate branch order sequence");
					}

					const businessOrderId = formatBranchOrderId(
						managerCode,
						sequence.lastValue
					);

					const availableConsignmentRows = await database.execute<{
						consignment_number: string;
						id: string;
						serial_number: number;
					}>(sql`
					with next_consignment as (
						select id
						from consignment
						where is_active = true
						order by serial_number asc
						limit 1
						for update
					)
					update consignment
					set is_active = false
					where id = (select id from next_consignment)
						and is_active = true
					returning id, consignment_number, serial_number
				`);
					const availableConsignment = availableConsignmentRows.rows[0];

					if (!availableConsignment) {
						throw new Error("No active consignment numbers are available");
					}

					const [confirmedOrder] = await database
						.update(order)
						.set({
							approvedAt: new Date(),
							approvedByUserId: session.user.id,
							orderId: businessOrderId,
							cancelledAt: null,
							cancelledByUserId: null,
							cancelledReason: null,
							status: "confirmed",
						})
						.where(
							and(
								eq(order.id, orderId),
								eq(order.status, "created"),
								isNull(order.orderId)
							)
						)
						.returning({ id: order.id });

					if (!confirmedOrder) {
						throw new Error(
							"Order status changed while it was being confirmed"
						);
					}

					await database
						.delete(orderPendingFarmerUpdate)
						.where(eq(orderPendingFarmerUpdate.orderId, orderId));

					await database.insert(orderConsignment).values({
						assignedAt: new Date(),
						consignmentId: availableConsignment.id,
						consignmentNumber: availableConsignment.consignment_number,
						id: crypto.randomUUID(),
						orderId,
						orderNumber: businessOrderId,
					});

					return {
						consignmentNumber: availableConsignment.consignment_number,
						orderId: businessOrderId,
					};
				}
			);

			response.status(200).json({
				order: {
					consignmentNumber: result.consignmentNumber,
					id: orderId,
					orderId: result.orderId,
					status: "confirmed",
				},
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.post(
	"/verification/:orderId/cancel",
	async (request: Request, response: Response) => {
		try {
			const session = await requireVerificationDashboardSession(
				request,
				response
			);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const parsedBody = cancellationSchema.parse(request.body);
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentRows = await ordersDatabase
				.select({
					createdByUserId: order.createdByUserId,
					id: order.id,
					status: order.status,
				})
				.from(order)
				.where(eq(order.id, orderId))
				.limit(1);

			if (currentRows.length === 0) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentOrder = currentRows[0];
			if (!currentOrder) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const trimmedReason = parsedBody.reason?.trim() || null;
			const isAdminConfirmedCancellation =
				session.user.role === "admin" && currentOrder.status === "confirmed";
			const isPreConfirmationCancellation =
				currentOrder.status === "created" &&
				(session.user.role === "admin" || session.user.role === "logistics");

			if (!(isAdminConfirmedCancellation || isPreConfirmationCancellation)) {
				response.status(400).json({
					message:
						"Only admin can cancel confirmed orders, and only logistics/admin can cancel created orders",
					success: false,
				});
				return;
			}

			if (isPreConfirmationCancellation && !trimmedReason) {
				response.status(400).json({
					message: "Cancellation reason is required",
					success: false,
				});
				return;
			}

			await ordersDatabase
				.update(order)
				.set({
					cancelledAt: new Date(),
					cancelledByUserId: session.user.id,
					cancelledReason: trimmedReason,
					status: "cancelled",
				})
				.where(eq(order.id, orderId));

			await ordersDatabase
				.delete(orderPendingFarmerUpdate)
				.where(eq(orderPendingFarmerUpdate.orderId, orderId));

			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.post(
	"/verification/:orderId/undo-cancel",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrdersSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentRows = await ordersDatabase
				.select({
					createdByUserId: order.createdByUserId,
					id: order.id,
					orderId: order.orderId,
					status: order.status,
				})
				.from(order)
				.where(eq(order.id, orderId))
				.limit(1);

			if (currentRows.length === 0) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const currentOrder = currentRows[0];
			if (!currentOrder) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			if (currentOrder.status !== "cancelled") {
				response.status(400).json({
					message: "Only cancelled orders can be reopened",
					success: false,
				});
				return;
			}

			if (currentOrder.orderId) {
				response.status(400).json({
					message: "Only pre-confirmation cancellations can be reopened",
					success: false,
				});
				return;
			}

			await ordersDatabase
				.update(order)
				.set({
					cancellationUndoneAt: new Date(),
					cancellationUndoneByUserId: session.user.id,
					cancelledAt: null,
					cancelledByUserId: null,
					cancelledReason: null,
					status: "created",
				})
				.where(eq(order.id, orderId));

			response.status(200).json({ success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.get(
	"/verification/:orderId/edit",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrderEditSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const [currentOrder] = await ordersDatabase
				.select({
					createdByUserId: order.createdByUserId,
					farmerId: order.farmerId,
					grandTotalAmount: order.grandTotalAmount,
					id: order.id,
					orderId: order.orderId,
					paidAmount: order.paidAmount,
					paymentMode: order.paymentMode,
					shippingCharges: order.shippingCharges,
					status: order.status,
					subtotalAmount: order.subtotalAmount,
					totalCodAmount: order.totalCodAmount,
				})
				.from(order)
				.where(eq(order.id, orderId))
				.limit(1);

			if (!currentOrder) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const orderCreatorCode = await getUserManagerCode(
				ordersDatabase,
				currentOrder.createdByUserId
			);
			if (!orderCreatorCode || orderCreatorCode !== managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			if (
				session.user.role === "team_leader" &&
				!(await canTeamLeaderAccessOrder(
					session.user.id,
					currentOrder.createdByUserId
				))
			) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const canEdit = canCurrentUserEditOrderStatus(
				session.user.role,
				currentOrder.status
			);

			const [orderConsignmentRow] = await ordersDatabase
				.select({ consignmentNumber: orderConsignment.consignmentNumber })
				.from(orderConsignment)
				.where(eq(orderConsignment.orderId, orderId))
				.limit(1);

			const items = await ordersDatabase
				.select({
					lineTotalAmount: orderItem.lineTotalAmount,
					productId: orderItem.productSku,
					quantity: orderItem.quantity,
					sellingPricePerUnit: orderItem.sellingPricePerUnit,
					unitPricePerUnit: orderItem.unitPricePerUnit,
				})
				.from(orderItem)
				.where(eq(orderItem.orderId, orderId))
				.orderBy(asc(orderItem.createdAt));

			const [paymentTransaction] = await ordersDatabase
				.select({
					transactionScreenshotBase64:
						orderPaymentTransaction.transactionScreenshotBase64,
					transactionUtr: orderPaymentTransaction.transactionUtr,
				})
				.from(orderPaymentTransaction)
				.where(eq(orderPaymentTransaction.orderId, orderId))
				.limit(1);

			const [farmersResult, productsResult] = await Promise.all([
				ordersDatabase
					.select({
						id: farmer.id,
						name: farmer.name,
						pincode: farmer.pincode,
						primaryMobileNumber: farmer.primaryMobileNumber,
					})
					.from(farmer)
					.where(sql`exists (
						select 1
						from user_manager_code branch_code
						where branch_code.manager_code = ${managerCode}
							and branch_code.user_id in (
								${farmer.serviceByUserId},
								${farmer.createdByUserId}
							)
					)`)
					.orderBy(asc(farmer.name)),
				ordersDatabase
					.select({
						availableQuantity: productInventory.quantity,
						costPerUnit: product.costPerUnit,
						dispatchableQuantity: productInventory.quantity,
						id: product.skuCode,
						name: product.name,
						offerPrice: product.offerPrice,
						quantity: productInventory.quantity,
						reservedQuantity: productInventory.reservedQuantity,
					})
					.from(product)
					.innerJoin(
						productInventory,
						eq(productInventory.productId, product.id)
					)
					.where(eq(product.isActive, true)),
			]);
			const advisorFarmers = await ordersDatabase
				.select({
					id: farmer.id,
					name: farmer.name,
					pincode: farmer.pincode,
					primaryMobileNumber: farmer.primaryMobileNumber,
				})
				.from(farmer)
				.where(
					or(
						eq(farmer.createdByUserId, currentOrder.createdByUserId),
						eq(farmer.serviceByUserId, currentOrder.createdByUserId)
					)
				)
				.orderBy(asc(farmer.name));

			response.status(200).json({
				canEdit,
				order: {
					consignmentNumber: orderConsignmentRow?.consignmentNumber ?? null,
					farmerId: currentOrder.farmerId,
					id: currentOrder.id,
					items,
					orderId: currentOrder.orderId,
					paidAmount: currentOrder.paidAmount ?? "0",
					paymentMode: currentOrder.paymentMode,
					shippingCharges: currentOrder.shippingCharges,
					status: currentOrder.status,
					transactionScreenshotBase64:
						paymentTransaction?.transactionScreenshotBase64 ?? null,
					transactionUtr: paymentTransaction?.transactionUtr ?? null,
				},
				options: {
					farmers:
						session.user.role === "team_leader"
							? advisorFarmers
							: farmersResult,
					primaryFarmers: advisorFarmers,
					products: productsResult.map((p) => ({
						...p,
						availableQuantity: Number(p.availableQuantity),
						dispatchableQuantity: Number(p.dispatchableQuantity),
						quantity: Number(p.quantity),
						reservedQuantity: Number(p.reservedQuantity),
					})),
				},
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

ordersRouter.patch(
	"/verification/:orderId",
	async (request: Request, response: Response) => {
		try {
			const session = await requireOrderEditSession(request, response);
			if (!session) {
				return;
			}

			const { orderId } = request.params as { orderId: string };
			const values = orderWriteSchema.parse(request.body);
			const managerCode = await getUserManagerCode(
				ordersDatabase,
				session.user.id
			);

			if (!managerCode) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}

			const result = await ordersDatabase.transaction(
				// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: edit validation and all order mutations must remain atomic
				async (tx) => {
					const database = tx as unknown as typeof ordersDatabase;

					const [currentOrder] = await database
						.select({
							createdByUserId: order.createdByUserId,
							id: order.id,
							orderId: order.orderId,
							status: order.status,
						})
						.from(order)
						.where(eq(order.id, orderId))
						.limit(1);

					if (!currentOrder) {
						throw new Error("Order not found");
					}

					const orderCreatorCode = await getUserManagerCode(
						database,
						currentOrder.createdByUserId
					);
					if (orderCreatorCode !== managerCode) {
						throw new Error("Order not found");
					}

					if (
						session.user.role === "team_leader" &&
						!(await canTeamLeaderAccessOrder(
							session.user.id,
							currentOrder.createdByUserId
						))
					) {
						throw new Error("Order not found");
					}

					if (
						!canCurrentUserEditOrderStatus(
							session.user.role,
							currentOrder.status
						)
					) {
						throw new Error(
							"Order can no longer be edited because its status changed"
						);
					}

					const uniqueProductIds = new Set(
						values.items.map((i) => i.productId)
					);
					if (uniqueProductIds.size !== values.items.length) {
						throw new Error("Duplicate product IDs are not allowed");
					}

					const totalLineAmount = values.items.reduce(
						(sum, item) => sum + item.lineTotalAmount,
						0
					);

					const subtotalAmount = totalLineAmount.toFixed(2);

					const grandTotal = totalLineAmount + values.shippingCharges;
					const totalCodAmount = calculateTotalCodAmount(
						values.paymentMode,
						grandTotal,
						values.paidAmount ?? 0
					);

					const [validatedFarmer] = await database
						.select({ id: farmer.id })
						.from(farmer)
						.where(
							and(
								eq(farmer.id, values.farmerId),
								session.user.role === "team_leader"
									? or(
											eq(farmer.createdByUserId, currentOrder.createdByUserId),
											eq(farmer.serviceByUserId, currentOrder.createdByUserId)
										)
									: sql`exists (
										select 1
										from user_manager_code branch_code
										where branch_code.manager_code = ${managerCode}
											and branch_code.user_id in (
												${farmer.serviceByUserId},
												${farmer.createdByUserId}
											)
									)`
							)
						)
						.limit(1);

					if (!validatedFarmer) {
						throw new Error("Selected farmer not found");
					}

					const [updatedOrder] = await database
						.update(order)
						.set({
							farmerId: values.farmerId,
							grandTotalAmount: grandTotal.toFixed(2),
							paidAmount:
								values.paymentMode === "cod"
									? "0.00"
									: (values.paidAmount ?? 0).toFixed(2),
							paymentMode: values.paymentMode,
							shippingCharges: values.shippingCharges.toFixed(2),
							subtotalAmount,
							totalCodAmount: totalCodAmount.toFixed(2),
						})
						.where(
							and(
								eq(order.id, orderId),
								inArray(order.status, editableOrderStatuses)
							)
						)
						.returning({ id: order.id });

					if (!updatedOrder) {
						throw new Error(
							"Order status changed while the edit was being saved"
						);
					}

					await database
						.delete(orderItem)
						.where(eq(orderItem.orderId, orderId));

					if (values.items.length > 0) {
						await database.insert(orderItem).values(
							values.items.map((item) => ({
								id: crypto.randomUUID(),
								lineTotalAmount: item.lineTotalAmount.toFixed(2),
								orderId,
								productSku: item.productId,
								quantity: item.quantity,
								sellingPricePerUnit: item.sellingPricePerUnit.toFixed(2),
								unitPricePerUnit: item.unitPricePerUnit.toFixed(2),
							}))
						);
					}

					if (values.transactionUtr || values.transactionScreenshotBase64) {
						await database
							.insert(orderPaymentTransaction)
							.values({
								orderId,
								transactionScreenshotBase64:
									values.transactionScreenshotBase64 ?? null,
								transactionUtr: values.transactionUtr ?? null,
							})
							.onConflictDoUpdate({
								set: {
									transactionScreenshotBase64:
										values.transactionScreenshotBase64 ?? null,
									transactionUtr: values.transactionUtr ?? null,
								},
								target: orderPaymentTransaction.orderId,
							});
					}

					return { success: true };
				}
			);

			response.status(200).json(result);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

export default ordersRouter satisfies Router;
