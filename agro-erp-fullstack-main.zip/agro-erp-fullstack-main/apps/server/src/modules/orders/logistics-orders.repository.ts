import { db } from "@agro-erp-fullstack/db";
import { user } from "@agro-erp-fullstack/db/schema/auth";
import { inArray } from "drizzle-orm";

/** Database boundary for logistics, verification, and tracking workflows. */
export const ordersDatabase: typeof db = db;

export const createFollowUpUserNameMap = async (
	userIds: string[]
): Promise<Map<string, string>> => {
	if (userIds.length === 0) {
		return new Map();
	}

	const rows = await db
		.select({ id: user.id, name: user.name })
		.from(user)
		.where(inArray(user.id, Array.from(new Set(userIds))));

	return new Map(rows.map((row) => [row.id, row.name]));
};
