import { teamLeaderAdvisor } from "@agro-erp-fullstack/db/schema/auth";
import { farmer } from "@agro-erp-fullstack/db/schema/farmer";
import { order } from "@agro-erp-fullstack/db/schema/order";
import { eq, or, sql } from "drizzle-orm";

export const getAdvisorFarmerAccessCondition = (userId: string) =>
	or(eq(farmer.createdByUserId, userId), eq(farmer.serviceByUserId, userId));

export const getAdvisorOrderAccessCondition = (userId: string, role: string) =>
	role === "team_leader"
		? or(
				eq(order.createdByUserId, userId),
				sql`exists (
					select 1
					from ${teamLeaderAdvisor} assigned_advisor
					where assigned_advisor.team_leader_id = ${userId}
						and assigned_advisor.advisor_id = ${order.createdByUserId}
				)`
			)
		: eq(order.createdByUserId, userId);
