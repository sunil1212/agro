// Pure order-state rules shared by order workflows and imports.
export const CANONICAL_ORDER_STATUSES = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;

export type OrderStatus = (typeof CANONICAL_ORDER_STATUSES)[number];

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
	cancelled: "Cancelled",
	confirmed: "Confirmed",
	created: "Created",
	delivered: "Delivered",
	dispatched: "Dispatched",
	return_in_transit: "Return: in transit",
	return_in_warehouse: "Return: in warehouse",
} as const;

export const editableOrderStatuses: readonly OrderStatus[] = [
	"created",
	"confirmed",
] as const;

export const LOGISTICS_STATUS_ORDER: readonly OrderStatus[] = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;

export const WAREHOUSE_STATUSES: readonly OrderStatus[] = [
	"confirmed",
	"dispatched",
	"return_in_transit",
	"return_in_warehouse",
] as const;

export const ORDER_TRANSITIONS = {
	logistics: {
		created: ["confirmed", "cancelled"] satisfies OrderStatus[],
		cancelled: ["created"] satisfies OrderStatus[],
		dispatched: ["delivered", "return_in_transit"] satisfies OrderStatus[],
	},
	warehouse: {
		confirmed: ["dispatched"] satisfies OrderStatus[],
		return_in_transit: ["return_in_warehouse"] satisfies OrderStatus[],
	},
} as const;

export class DomainError extends Error {
	constructor(message: string) {
		super(message);
		this.name = "DomainError";
	}
}

export function assertOrderTransitionAllowed(input: {
	actorRole: "logistics" | "warehouse";
	currentStatus: OrderStatus;
	nextStatus: OrderStatus;
}): void {
	const transitions = ORDER_TRANSITIONS[input.actorRole] as Record<
		string,
		readonly string[]
	>;
	const allowed = (transitions[input.currentStatus] ?? []) as readonly string[];
	if (!allowed.includes(input.nextStatus)) {
		throw new DomainError(
			`Invalid order status transition from "${input.currentStatus}" to "${input.nextStatus}" for ${input.actorRole}`
		);
	}
}

export const getFollowUpPhase = (
	status: OrderStatus
): "pre_confirmation" | "post_confirmation" =>
	status === "created" || status === "cancelled"
		? "pre_confirmation"
		: "post_confirmation";

export function isOrderStatus(value: string): value is OrderStatus {
	return CANONICAL_ORDER_STATUSES.includes(value as OrderStatus);
}

export const ORDER_ID_SEQUENCE_WIDTH = 6;
const numericOrderSequencePattern = /^\d+$/;

export function formatBranchOrderId(
	managerCode: string,
	sequence: number
): string {
	return `${managerCode}-${String(sequence).padStart(ORDER_ID_SEQUENCE_WIDTH, "0")}`;
}

export function parseBranchOrderSequence(
	orderId: string,
	managerCode: string
): number | null {
	const orderIdPrefix = `${managerCode}-`;
	if (!orderId.startsWith(orderIdPrefix)) {
		return null;
	}

	const sequenceText = orderId.slice(orderIdPrefix.length);
	if (!numericOrderSequencePattern.test(sequenceText)) {
		return null;
	}

	const sequence = Number(sequenceText);
	return Number.isSafeInteger(sequence) && sequence > 0 ? sequence : null;
}
