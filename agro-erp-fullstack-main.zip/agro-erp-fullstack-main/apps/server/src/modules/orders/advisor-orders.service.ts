import { db } from "@agro-erp-fullstack/db";
import { teamLeaderAdvisor, user } from "@agro-erp-fullstack/db/schema/auth";
import { farmer } from "@agro-erp-fullstack/db/schema/farmer";
import {
	coupon,
	order,
	orderConsignment,
	orderDiscount,
	orderItem,
	orderPaymentTransaction,
} from "@agro-erp-fullstack/db/schema/order";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import type { Request, Response } from "express";
import { requireActionSession } from "../../auth/session";
import {
	buildVariantLabel,
	cancellableStatuses,
	getProductSnapshot,
	moneySum,
	toMoney,
} from "../../lib/advisor";
import { sendErrorResponse } from "../../lib/http";
import { releaseProductReservation } from "../../lib/inventory";
import {
	requireFarmerInBranch,
	requireOrderInBranch,
	requireUserManagerCode,
} from "../branches/branches.service";
import {
	getAdvisorFarmerAccessCondition,
	getAdvisorOrderAccessCondition,
} from "./advisor-orders.repository";
import {
	createAdvisorOrderSchema,
	updateAdvisorOrderStatusSchema,
} from "./advisor-orders.schemas";

const requireAdvisorOrderSession = (request: Request, response: Response) =>
	requireActionSession(request, response, {
		action: "advisor_order:manage",
		forbiddenMessage: "Only advisors can manage orders",
		forbiddenSuccess: false,
	});

export const getAdvisorOrderCreateOptions = async (
	request: Request,
	response: Response
) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		const managerCode =
			session.user.role === "admin"
				? await requireUserManagerCode(db, session.user.id)
				: null;

		const farmerId = request.query.farmerId?.toString();
		const farmerAccessCondition = managerCode
			? sql`exists (
						select 1
						from user_manager_code branch_code
						where branch_code.manager_code = ${managerCode}
							and branch_code.user_id in (${farmer.serviceByUserId}, ${farmer.createdByUserId})
					)`
			: getAdvisorFarmerAccessCondition(session.user.id);

		const [farmers, products, coupons] = await Promise.all([
			db
				.select({
					id: farmer.id,
					name: farmer.name,
					pincode: farmer.pincode,
					primaryMobileNumber: farmer.primaryMobileNumber,
				})
				.from(farmer)
				.where(farmerAccessCondition)
				.orderBy(asc(farmer.name)),
			db
				.select({
					id: product.id,
					name: product.name,
					packageQuantity: product.packageQuantity,
					packageUnit: product.packageUnit,
					packagingType: product.packagingType,
					quantity: productInventory.quantity,
					reservedQuantity: productInventory.reservedQuantity,
					availableQuantity: productInventory.quantity,
					dispatchableQuantity: productInventory.quantity,
					costPerUnit: product.costPerUnit,
					offerPrice: product.offerPrice,
					skuCode: product.skuCode,
				})
				.from(product)
				.innerJoin(productInventory, eq(productInventory.productId, product.id))
				.where(eq(product.isActive, true))
				.orderBy(asc(product.name), asc(product.packageQuantity)),
			db
				.select({
					id: coupon.id,
					code: coupon.code,
					name: coupon.name,
					description: coupon.description,
				})
				.from(coupon)
				.where(eq(coupon.isActive, true))
				.orderBy(asc(coupon.code)),
		]);

		const selectedFarmer = farmerId
			? (farmers.find((item) => item.id === farmerId) ?? null)
			: null;
		response.status(200).json({
			success: true,
			selectedFarmer,
			farmers,
			primaryFarmers: farmers,
			products: products.map((entry) => ({
				...entry,
				name: buildVariantLabel(entry),
			})),
			coupons,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

export const listAdvisorOrders = async (
	request: Request,
	response: Response
) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		const managerCode =
			session.user.role === "admin"
				? await requireUserManagerCode(db, session.user.id)
				: null;

		const orders = await db
			.select({
				cancelledReason: order.cancelledReason,
				id: order.id,
				orderId: order.orderId,
				consignmentNumber: orderConsignment.consignmentNumber,
				farmerName: farmer.name,
				totalAmount: order.grandTotalAmount,
				status: order.status,
				transactionScreenshotBase64:
					orderPaymentTransaction.transactionScreenshotBase64,
				createdAt: order.createdAt,
			})
			.from(order)
			.innerJoin(farmer, eq(farmer.id, order.farmerId))
			.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
			.leftJoin(
				orderPaymentTransaction,
				eq(orderPaymentTransaction.orderId, order.id)
			)
			.where(
				managerCode
					? sql`exists (
							select 1
							from "user" order_creator
							left join user_manager_code direct_code
								on direct_code.user_id = order_creator.id
							left join user_manager_code creator_code
								on creator_code.user_id = order_creator.created_by_user_id
							where order_creator.id = ${order.createdByUserId}
								and coalesce(direct_code.manager_code, creator_code.manager_code) = ${managerCode}
						)`
					: eq(order.createdByUserId, session.user.id)
			)
			.orderBy(desc(order.createdAt));

		response.status(200).json({ success: true, orders });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

export const listAssignedAdvisorOrders = async (
	request: Request,
	response: Response
) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		if (session.user.role !== "team_leader") {
			response.status(403).json({
				message: "Only team leaders can view advisor orders",
				success: false,
			});
			return;
		}

		const orders = await db
			.select({
				advisorName: user.name,
				cancelledReason: order.cancelledReason,
				consignmentNumber: orderConsignment.consignmentNumber,
				createdAt: order.createdAt,
				farmerName: farmer.name,
				id: order.id,
				orderId: order.orderId,
				status: order.status,
				totalAmount: order.grandTotalAmount,
				transactionScreenshotBase64:
					orderPaymentTransaction.transactionScreenshotBase64,
			})
			.from(order)
			.innerJoin(farmer, eq(farmer.id, order.farmerId))
			.innerJoin(user, eq(user.id, order.createdByUserId))
			.innerJoin(
				teamLeaderAdvisor,
				and(
					eq(teamLeaderAdvisor.advisorId, order.createdByUserId),
					eq(teamLeaderAdvisor.teamLeaderId, session.user.id)
				)
			)
			.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
			.leftJoin(
				orderPaymentTransaction,
				eq(orderPaymentTransaction.orderId, order.id)
			)
			.orderBy(desc(order.createdAt));

		response.status(200).json({ success: true, orders });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

export const getAdvisorOrder = async (request: Request, response: Response) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		const { orderId } = request.params as { orderId: string };

		if (session.user.role === "admin") {
			const managerCode = await requireUserManagerCode(db, session.user.id);
			await requireOrderInBranch(db, orderId, managerCode);
		}

		const orderRows = await db
			.select({
				approvedAt: order.approvedAt,
				approvedByUserId: order.approvedByUserId,
				id: order.id,
				orderId: order.orderId,
				consignmentNumber: orderConsignment.consignmentNumber,
				farmerId: order.farmerId,
				farmerName: farmer.name,
				farmerMobile: farmer.primaryMobileNumber,
				createdByUserId: order.createdByUserId,
				createdByName: user.name,
				status: order.status,
				paymentMode: order.paymentMode,
				subtotalAmount: order.subtotalAmount,
				promoDiscount: orderDiscount.promoDiscount,
				pointsUsed: orderDiscount.pointsUsed,
				pointsDiscountAmount: orderDiscount.pointsDiscountAmount,
				couponDiscountAmount: orderDiscount.couponDiscountAmount,
				totalDiscountAmount: orderDiscount.totalDiscountAmount,
				cashbackAmount: orderDiscount.cashbackAmount,
				shippingCharges: order.shippingCharges,
				grandTotalAmount: order.grandTotalAmount,
				paidAmount: order.paidAmount,
				totalCodAmount: order.totalCodAmount,
				transactionUtr: orderPaymentTransaction.transactionUtr,
				transactionScreenshotBase64:
					orderPaymentTransaction.transactionScreenshotBase64,
				couponCode: orderDiscount.couponCode,
				cancelledAt: order.cancelledAt,
				cancelledByUserId: order.cancelledByUserId,
				dispatchedAt: order.dispatchedAt,
				createdAt: order.createdAt,
			})
			.from(order)
			.innerJoin(farmer, eq(farmer.id, order.farmerId))
			.innerJoin(user, eq(user.id, order.createdByUserId))
			.leftJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
			.leftJoin(orderDiscount, eq(orderDiscount.orderId, order.id))
			.leftJoin(
				orderPaymentTransaction,
				eq(orderPaymentTransaction.orderId, order.id)
			)
			.where(eq(order.id, orderId))
			.limit(1);

		if (orderRows.length === 0) {
			response.status(404).json({ message: "Order not found", success: false });
			return;
		}

		const items = await db
			.select({
				id: orderItem.id,
				productSku: orderItem.productSku,
				productName: product.name,
				quantity: orderItem.quantity,
				unitPricePerUnit: orderItem.unitPricePerUnit,
				sellingPricePerUnit: orderItem.sellingPricePerUnit,
				lineTotalAmount: orderItem.lineTotalAmount,
			})
			.from(orderItem)
			.innerJoin(product, eq(product.skuCode, orderItem.productSku))
			.where(eq(orderItem.orderId, orderId))
			.orderBy(asc(orderItem.createdAt));

		const orderData = orderRows[0];
		if (!orderData) {
			response.status(404).json({ message: "Order not found", success: false });
			return;
		}

		if (session.user.role !== "admin") {
			const [accessRow] = await db
				.select({ id: order.id })
				.from(order)
				.where(
					and(
						eq(order.id, orderId),
						getAdvisorOrderAccessCondition(session.user.id, session.user.role)
					)
				)
				.limit(1);

			if (!accessRow) {
				response
					.status(404)
					.json({ message: "Order not found", success: false });
				return;
			}
		}

		const userIds = [
			orderData.approvedByUserId,
			orderData.cancelledByUserId,
		].filter((value): value is string => Boolean(value));
		const userNameById =
			userIds.length > 0
				? new Map(
						(
							await db
								.select({ id: user.id, name: user.name })
								.from(user)
								.where(inArray(user.id, Array.from(new Set(userIds))))
						).map((row) => [row.id, row.name])
					)
				: new Map<string, string>();

		response.status(200).json({
			canCancel: cancellableStatuses.includes(
				orderData.status as (typeof cancellableStatuses)[number]
			),
			items,
			order: {
				...orderData,
				approvedByName: orderData.approvedByUserId
					? (userNameById.get(orderData.approvedByUserId) ?? null)
					: null,
				cancelledByName: orderData.cancelledByUserId
					? (userNameById.get(orderData.cancelledByUserId) ?? null)
					: null,
			},
			success: true,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

export const createAdvisorOrder = async (
	request: Request,
	response: Response
) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		const parsedValues = createAdvisorOrderSchema.parse(request.body);

		if (session.user.role === "admin") {
			const managerCode = await requireUserManagerCode(db, session.user.id);
			await requireFarmerInBranch(db, parsedValues.farmerId, managerCode);
		}

		const farmerRows = await db
			.select({ id: farmer.id })
			.from(farmer)
			.where(eq(farmer.id, parsedValues.farmerId))
			.limit(1);

		if (farmerRows.length === 0) {
			response
				.status(400)
				.json({ message: "Farmer not found", success: false });
			return;
		}

		const productIds = [
			...new Set(parsedValues.items.map((item) => item.productId)),
		];
		if (productIds.length !== parsedValues.items.length) {
			response.status(400).json({
				message: "Each product can only appear once",
				success: false,
			});
			return;
		}

		const productMap = await getProductSnapshot(productIds);
		if (productMap.size !== productIds.length) {
			response.status(400).json({
				message: "One or more selected products are invalid",
				success: false,
			});
			return;
		}

		const lineItems = parsedValues.items.map((item) => {
			const selectedProduct = productMap.get(item.productId);
			if (!selectedProduct) {
				throw new Error("One or more selected products are invalid");
			}

			if (item.quantity > selectedProduct.quantity) {
				throw new Error(
					`Insufficient available quantity for ${selectedProduct.name}`
				);
			}

			const unitPricePerUnit = item.unitPricePerUnit;
			const sellingPricePerUnit = item.sellingPricePerUnit;
			const lineTotalAmount = item.lineTotalAmount;

			return {
				categoryCode: selectedProduct.categoryCode,
				productSku: selectedProduct.skuCode,
				quantity: item.quantity,
				unitPricePerUnit: toMoney(unitPricePerUnit),
				sellingPricePerUnit: toMoney(sellingPricePerUnit),
				lineTotalAmount: toMoney(lineTotalAmount),
			};
		});

		const subtotalAmount = Number(
			moneySum(lineItems.map((item) => Number(item.lineTotalAmount)))
		);
		const promoDiscount = 0;
		const pointsUsed = 0;
		const pointsDiscountAmount = 0;
		const couponDiscountAmount = 0;
		const totalDiscountAmount =
			promoDiscount + pointsDiscountAmount + couponDiscountAmount;
		const shippingCharges = parsedValues.shippingCharges;
		const grandTotalAmount =
			subtotalAmount - totalDiscountAmount + shippingCharges;

		let paidAmount = 0;
		if (parsedValues.paymentMode === "partial_payment") {
			paidAmount = parsedValues.paidAmount ?? 0;
			if (!(paidAmount > 0 && paidAmount < grandTotalAmount)) {
				response.status(400).json({
					message:
						"Partial payment must be greater than zero and less than grand total",
					success: false,
				});
				return;
			}
		} else if (parsedValues.paymentMode === "prepaid") {
			paidAmount = grandTotalAmount;
		}

		let totalCodAmount = 0;
		if (parsedValues.paymentMode === "cod") {
			totalCodAmount = grandTotalAmount;
		} else if (parsedValues.paymentMode === "partial_payment") {
			totalCodAmount = grandTotalAmount - paidAmount;
		}

		const orderId = crypto.randomUUID();
		const now = new Date();

		await db.transaction(async (tx) => {
			const database = tx as unknown as typeof db;
			await database.insert(order).values({
				id: orderId,
				orderId: null,
				farmerId: parsedValues.farmerId,
				createdByUserId: session.user.id,
				status: "created",
				paymentMode: parsedValues.paymentMode,
				subtotalAmount: toMoney(subtotalAmount),
				shippingCharges: toMoney(shippingCharges),
				grandTotalAmount: toMoney(grandTotalAmount),
				paidAmount: toMoney(paidAmount),
				totalCodAmount: toMoney(totalCodAmount),
				cancelledAt: null,
				cancelledByUserId: null,
				dispatchedAt: null,
			});

			await database.insert(orderDiscount).values({
				cashbackAmount: toMoney(0),
				couponCode: parsedValues.couponCode ?? null,
				couponDiscountAmount: toMoney(couponDiscountAmount),
				couponId: null,
				orderId,
				pointsDiscountAmount: toMoney(pointsDiscountAmount),
				pointsUsed,
				promoDiscount: toMoney(promoDiscount),
				totalDiscountAmount: toMoney(totalDiscountAmount),
			});

			await database.insert(orderPaymentTransaction).values({
				orderId,
				transactionScreenshotBase64:
					parsedValues.transactionScreenshotBase64 ?? null,
				transactionUtr: parsedValues.transactionUtr ?? null,
			});

			await database.insert(orderItem).values(
				lineItems.map((item) => ({
					id: crypto.randomUUID(),
					orderId,
					productSku: item.productSku,
					quantity: item.quantity,
					unitPricePerUnit: item.unitPricePerUnit,
					sellingPricePerUnit: item.sellingPricePerUnit,
					lineTotalAmount: item.lineTotalAmount,
				}))
			);

			await database
				.update(farmer)
				.set({ lastOrderDate: now })
				.where(eq(farmer.id, parsedValues.farmerId));
		});

		response.status(201).json({
			success: true,
			order: {
				id: orderId,
				orderId: null,
				farmerId: parsedValues.farmerId,
				grandTotalAmount: toMoney(grandTotalAmount),
				totalCodAmount: toMoney(totalCodAmount),
				status: "created",
			},
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

export const rejectAdvisorOrderStatusUpdate = async (
	request: Request,
	response: Response
) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		updateAdvisorOrderStatusSchema.parse(request.body);
		response.status(403).json({
			message: "Warehouse team owns fulfillment status updates",
			success: false,
		});
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

export const cancelAdvisorOrder = async (
	request: Request,
	response: Response
) => {
	try {
		const session = await requireAdvisorOrderSession(request, response);
		if (!session) {
			return;
		}

		const { orderId } = request.params as { orderId: string };
		const currentRows = await db
			.select({
				id: order.id,
				status: order.status,
			})
			.from(order)
			.where(eq(order.id, orderId))
			.limit(1);

		if (currentRows.length === 0) {
			response.status(404).json({ message: "Order not found", success: false });
			return;
		}

		const currentOrder = currentRows[0];
		if (!currentOrder) {
			response.status(404).json({ message: "Order not found", success: false });
			return;
		}
		if (
			!cancellableStatuses.includes(
				currentOrder.status as (typeof cancellableStatuses)[number]
			)
		) {
			response.status(400).json({
				message: "This order can no longer be cancelled",
				success: false,
			});
			return;
		}

		await db.transaction(async (tx) => {
			const database = tx as unknown as typeof db;
			if (
				currentOrder.status === "created" ||
				currentOrder.status === "confirmed"
			) {
				const items = await database
					.select({
						productId: product.id,
						quantity: orderItem.quantity,
					})
					.from(orderItem)
					.innerJoin(product, eq(product.skuCode, orderItem.productSku))
					.where(eq(orderItem.orderId, orderId));

				for (const item of items) {
					await releaseProductReservation(database, {
						actorUserId: session.user.id,
						productId: item.productId,
						quantity: item.quantity,
						referenceOrderId: orderId,
					});
				}
			}
			await database
				.update(order)
				.set({
					status: "cancelled",
					cancelledAt: new Date(),
					cancelledByUserId: session.user.id,
				})
				.where(eq(order.id, orderId));
		});

		response.status(200).json({ success: true });
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};
