import { getIstWindowStarts, toMoney } from "../../lib/advisor";
import { isSaleStatus } from "../../lib/sales-analytics";

const IST_TIME_ZONE = "Asia/Kolkata";
const SALES_GLANCE_STATUSES = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;

interface SalesGlanceBucket {
	amountByStatus: Record<string, number>;
	countByStatus: Record<string, number>;
	label: string;
}

interface SalesOrder {
	createdAt: Date;
	id: string;
	status: string;
}

interface SalesItem {
	lineTotalAmount: string;
	orderId: string;
}

const getIstDateKey = (value: Date): string => {
	const parts = new Intl.DateTimeFormat("en-CA", {
		day: "2-digit",
		month: "2-digit",
		timeZone: IST_TIME_ZONE,
		year: "numeric",
	}).formatToParts(value);
	const day = parts.find((part) => part.type === "day")?.value;
	const month = parts.find((part) => part.type === "month")?.value;
	const year = parts.find((part) => part.type === "year")?.value;
	if (!(day && month && year)) {
		throw new Error("Unable to resolve IST date parts");
	}
	return `${year}-${month}-${day}`;
};

const buildBucket = (label: string): SalesGlanceBucket => ({
	amountByStatus: Object.fromEntries(
		SALES_GLANCE_STATUSES.map((status) => [status, 0])
	),
	countByStatus: Object.fromEntries(
		SALES_GLANCE_STATUSES.map((status) => [status, 0])
	),
	label,
});

const addToBucket = (
	bucket: SalesGlanceBucket,
	status: string,
	amount: number
): void => {
	if (!SALES_GLANCE_STATUSES.includes(status as never)) {
		return;
	}
	bucket.amountByStatus[status] = (bucket.amountByStatus[status] ?? 0) + amount;
	bucket.countByStatus[status] = (bucket.countByStatus[status] ?? 0) + 1;
};

const buildSalesGlance = (
	orders: SalesOrder[],
	salesByOrderId: Map<string, number>
) => {
	const today = new Date(`${getIstDateKey(new Date())}T00:00:00.000Z`);
	const weekStart = new Date(today);
	weekStart.setUTCDate(weekStart.getUTCDate() - ((today.getUTCDay() + 6) % 7));
	const monthStart = new Date(
		Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1)
	);
	const todayBucket = buildBucket("Today");
	const weekBucket = buildBucket("This week");
	const monthBucket = buildBucket("This month");

	for (const order of orders) {
		const date = new Date(`${getIstDateKey(order.createdAt)}T00:00:00.000Z`);
		const amount = salesByOrderId.get(order.id) ?? 0;
		if (date.getTime() === today.getTime()) {
			addToBucket(todayBucket, order.status, amount);
		}
		if (date >= weekStart && date <= today) {
			addToBucket(weekBucket, order.status, amount);
		}
		if (date >= monthStart && date <= today) {
			addToBucket(monthBucket, order.status, amount);
		}
	}
	return {
		buckets: [todayBucket, weekBucket, monthBucket],
		statuses: SALES_GLANCE_STATUSES,
	};
};

const getMonthlyOutcomeStats = (
	orders: SalesOrder[],
	startOfMonthUtc: Date
) => {
	let monthlyOrderCount = 0;
	let monthlyDeliveredCount = 0;
	let monthlyReturnCount = 0;

	for (const order of orders) {
		if (order.createdAt < startOfMonthUtc) {
			continue;
		}
		monthlyOrderCount += 1;
		if (order.status === "delivered") {
			monthlyDeliveredCount += 1;
		}
		if (
			order.status === "return_in_transit" ||
			order.status === "return_in_warehouse"
		) {
			monthlyReturnCount += 1;
		}
	}

	return {
		monthlyDeliveredCount,
		monthlyDeliveredRate:
			monthlyOrderCount > 0 ? monthlyDeliveredCount / monthlyOrderCount : 0,
		monthlyReturnCount,
		monthlyReturnRate:
			monthlyOrderCount > 0 ? monthlyReturnCount / monthlyOrderCount : 0,
	};
};

export const buildAdvisorDashboard = ({
	items,
	orders,
	target,
}: {
	items: SalesItem[];
	orders: SalesOrder[];
	target: {
		dailySalesTarget: string | null;
		monthlySalesTarget: string | null;
	} | null;
}) => {
	const salesByOrderId = new Map<string, number>();
	for (const item of items) {
		salesByOrderId.set(
			item.orderId,
			(salesByOrderId.get(item.orderId) ?? 0) + Number(item.lineTotalAmount)
		);
	}
	const { startOfDayUtc, startOfMonthUtc } = getIstWindowStarts(new Date());
	let dailySales = 0;
	let monthlySales = 0;
	const monthlyOutcomeStats = getMonthlyOutcomeStats(orders, startOfMonthUtc);
	for (const order of orders) {
		if (!isSaleStatus(order.status)) {
			continue;
		}
		const amount = salesByOrderId.get(order.id) ?? 0;
		if (order.createdAt >= startOfMonthUtc) {
			monthlySales += amount;
		}
		if (order.createdAt >= startOfDayUtc) {
			dailySales += amount;
		}
	}
	return {
		sales: {
			dailySales: toMoney(dailySales),
			dailySalesTarget: target?.dailySalesTarget ?? null,
			monthlySales: toMoney(monthlySales),
			monthlySalesTarget: target?.monthlySalesTarget ?? null,
			...monthlyOutcomeStats,
		},
		salesGlance: buildSalesGlance(orders, salesByOrderId),
	};
};
