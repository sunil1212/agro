import type { db } from "@agro-erp-fullstack/db";
import {
	teamLeaderAdvisor,
	userSalesTarget,
} from "@agro-erp-fullstack/db/schema/auth";
import { order, orderItem } from "@agro-erp-fullstack/db/schema/order";
import { eq, inArray, or, sql } from "drizzle-orm";

export const findAdvisorSalesTarget = async (
	database: typeof db,
	userId: string
) => {
	const [target] = await database
		.select({
			dailySalesTarget: userSalesTarget.dailySalesTarget,
			monthlySalesTarget: userSalesTarget.monthlySalesTarget,
		})
		.from(userSalesTarget)
		.where(eq(userSalesTarget.userId, userId))
		.limit(1);

	return target ?? null;
};

export const findAdvisorSalesOrders = async (
	database: typeof db,
	userId: string,
	role: string,
	managerCode: null | string
) => {
	let accessCondition = eq(order.createdByUserId, userId);
	if (role === "team_leader") {
		accessCondition =
			or(
				eq(order.createdByUserId, userId),
				sql`exists (
				select 1
				from ${teamLeaderAdvisor} assigned_advisor
				where assigned_advisor.team_leader_id = ${userId}
					and assigned_advisor.advisor_id = ${order.createdByUserId}
			)`
			) ?? accessCondition;
	}
	if (managerCode) {
		accessCondition = sql`exists (
			select 1
			from "user" order_creator
			left join user_manager_code direct_code
				on direct_code.user_id = order_creator.id
			left join user_manager_code creator_code
				on creator_code.user_id = order_creator.created_by_user_id
			where order_creator.id = ${order.createdByUserId}
				and coalesce(direct_code.manager_code, creator_code.manager_code) = ${managerCode}
		)`;
	}
	const orders = await database
		.select({ createdAt: order.createdAt, id: order.id, status: order.status })
		.from(order)
		.where(accessCondition);
	const orderIds = orders.map((entry) => entry.id);
	const items =
		orderIds.length === 0
			? []
			: await database
					.select({
						lineTotalAmount: orderItem.lineTotalAmount,
						orderId: orderItem.orderId,
					})
					.from(orderItem)
					.where(inArray(orderItem.orderId, orderIds));

	return { items, orders };
};
