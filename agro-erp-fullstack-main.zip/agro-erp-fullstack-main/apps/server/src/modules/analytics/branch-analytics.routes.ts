import { db } from "@agro-erp-fullstack/db";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";
import { requireActionSession, requireRoleSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import {
	getBranchStatsDetail,
	getBranchStatsList,
	getBranchTrendStats,
	getManagerStats,
	getManagerTrendStats,
} from "../../services/sales-analytics";
import { isOrderStatus } from "../orders/order-lifecycle";
import advisorAnalyticsRouter from "./advisor-analytics.routes";

export const branchAnalyticsRouter: Router = createRouter();
branchAnalyticsRouter.use(advisorAnalyticsRouter);

const getAnalyticsQuery = (request: Request) =>
	request.query as {
		actorId?: string;
		from?: string;
		status?: string;
		to?: string;
	};

const validateStatus = (request: Request, response: Response) => {
	const query = getAnalyticsQuery(request);
	if (query.status && !isOrderStatus(query.status)) {
		response
			.status(400)
			.json({ message: "Invalid order status", success: false });
		return null;
	}
	return query;
};

const branchStatsHandler = async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "manager_stats:read",
			forbiddenMessage: "You do not have access to branch stats",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}
		const query = validateStatus(request, response);
		if (!query) {
			return;
		}
		response
			.status(200)
			.json(await getManagerStats(db, session.user.id, query));
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

const branchTrendsHandler = async (request: Request, response: Response) => {
	try {
		const session = await requireActionSession(request, response, {
			action: "manager_stats:read",
			forbiddenMessage: "You do not have access to branch stats",
			forbiddenSuccess: false,
		});
		if (!session) {
			return;
		}
		const query = validateStatus(request, response);
		if (!query) {
			return;
		}
		response
			.status(200)
			.json(await getManagerTrendStats(db, session.user.id, query));
	} catch (error) {
		sendErrorResponse(response, error, { success: false });
	}
};

branchAnalyticsRouter.get("/", branchStatsHandler);
branchAnalyticsRouter.get("/trends", branchTrendsHandler);
branchAnalyticsRouter.get("/branch", branchStatsHandler);
branchAnalyticsRouter.get("/branch/trends", branchTrendsHandler);

const requireSuperAdminSession = (request: Request, response: Response) =>
	requireRoleSession(request, response, {
		allowedRoles: ["superadmin"],
		forbiddenMessage: "Only super admins can perform this action",
	});

branchAnalyticsRouter.get(
	"/branch-stats",
	async (request: Request, response: Response) => {
		try {
			const session = await requireSuperAdminSession(request, response);
			if (!session) {
				return;
			}
			const { from, to } = request.query as { from?: string; to?: string };
			const branches = await getBranchStatsList(db, { from, to });
			response.status(200).json({ branches, success: true });
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

branchAnalyticsRouter.get(
	"/branch-stats/:managerCode",
	async (request: Request, response: Response) => {
		try {
			const session = await requireSuperAdminSession(request, response);
			if (!session) {
				return;
			}
			const query = validateStatus(request, response);
			if (!query) {
				return;
			}
			const { managerCode } = request.params as { managerCode: string };
			const result = await getBranchStatsDetail(db, managerCode, query);
			if (!result) {
				response
					.status(404)
					.json({ message: "Branch not found", success: false });
				return;
			}
			response.status(200).json(result);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

branchAnalyticsRouter.get(
	"/branch-stats/:managerCode/trends",
	async (request: Request, response: Response) => {
		try {
			const session = await requireSuperAdminSession(request, response);
			if (!session) {
				return;
			}
			const query = validateStatus(request, response);
			if (!query) {
				return;
			}
			const { managerCode } = request.params as { managerCode: string };
			const result = await getBranchTrendStats(db, managerCode, query);
			if (!result) {
				response
					.status(404)
					.json({ message: "Branch not found", success: false });
				return;
			}
			response.status(200).json(result);
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);
