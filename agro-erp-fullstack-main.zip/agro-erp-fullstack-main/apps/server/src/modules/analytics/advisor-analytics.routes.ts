import { db } from "@agro-erp-fullstack/db";
import type { Request, Response, Router } from "express";
import { Router as createRouter } from "express";

import { requireActionSession } from "../../auth/session";
import { sendErrorResponse } from "../../lib/http";
import { requireUserManagerCode } from "../branches/branches.service";
import {
	findAdvisorSalesOrders,
	findAdvisorSalesTarget,
} from "./advisor-analytics.repository";
import { buildAdvisorDashboard } from "./advisor-analytics.service";

const advisorAnalyticsRouter: Router = createRouter();

advisorAnalyticsRouter.get(
	"/advisor-dashboard",
	async (request: Request, response: Response) => {
		try {
			const session = await requireActionSession(request, response, {
				action: "farmer:manage",
				forbiddenMessage: "Only advisors can manage farmers",
				forbiddenSuccess: false,
			});
			if (!session) {
				return;
			}
			const managerCode =
				session.user.role === "admin"
					? await requireUserManagerCode(db, session.user.id)
					: null;
			const [target, salesRows] = await Promise.all([
				findAdvisorSalesTarget(db, session.user.id),
				findAdvisorSalesOrders(
					db,
					session.user.id,
					session.user.role,
					managerCode
				),
			]);
			response.status(200).json({
				...buildAdvisorDashboard({
					items: salesRows.items,
					orders: salesRows.orders,
					target,
				}),
				success: true,
			});
		} catch (error) {
			sendErrorResponse(response, error, { success: false });
		}
	}
);

export default advisorAnalyticsRouter;
