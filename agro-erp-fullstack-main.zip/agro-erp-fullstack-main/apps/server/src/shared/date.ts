export const addDaysToIsoDate = (isoDate: string, days: number): string => {
	const [year = 0, month = 1, day = 1] = isoDate
		.split("-")
		.map((part) => Number(part));
	const date = new Date(Date.UTC(year, month - 1, day + days));

	return date.toISOString().slice(0, 10);
};
