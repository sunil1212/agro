import { db } from "@agro-erp-fullstack/db";
import { isValidFarmerLocation } from "@agro-erp-fullstack/db/data/farmer-locations";
import { farmer, farmerCrop } from "@agro-erp-fullstack/db/schema/farmer";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { and, eq, inArray } from "drizzle-orm";
import z from "zod";

import { generateNotifications } from "../services/farmer-crops";

export const phoneNumberPattern = /^\+[1-9]\d{7,14}$/;
const pincodePattern = /^\d{6}$/;

export const cancellableStatuses = ["created", "confirmed"] as const;

export const createFarmerSchema = z
	.object({
		name: z.string().trim().min(1, "Name is required"),
		primaryMobileNumber: z.string().trim().min(1, "Primary mobile is required"),
		secondaryMobileNumber: z.string().trim().optional(),
		addressAt: z.string().trim().min(1, "At / Village is required"),
		nearbyLandmark: z.string().trim().optional(),
		post: z.string().trim().min(1, "Post is required"),
		state: z.string().trim().min(1, "State is required"),
		taluka: z.string().trim().min(1, "Taluka is required"),
		district: z.string().trim().min(1, "District is required"),
		pincode: z
			.string()
			.trim()
			.regex(pincodePattern, "Pincode must be 6 digits"),
		serviceByUserId: z.string().trim().min(1, "Service By is required"),
		referralFarmerId: z.string().trim().optional(),
		farmSize: z.string().trim().min(1, "Farm size is required"),
		irrigation: z.string().trim().min(1, "Irrigation is required"),
		crops: z
			.array(
				z.object({
					cropId: z.string().trim().min(1, "Crop is required"),
					dateOfSowing: z.iso.date("Date of sowing is required"),
					currentStage: z.string().trim().optional(),
				})
			)
			.min(1, "At least one crop is required"),
	})
	.superRefine((values, context) => {
		if (!isValidFarmerLocation(values)) {
			context.addIssue({
				code: "custom",
				message: "Select a valid state, district, and taluka",
				path: ["taluka"],
			});
		}
	});

export const normalizePhoneNumber = (value: string) =>
	value.replace(/\s+/g, "");

export const toMoney = (value: number) => value.toFixed(2);

export const moneySum = (values: number[]) =>
	toMoney(values.reduce((sum, value) => sum + value, 0));

export const getIstWindowStarts = (currentDate: Date) => {
	const istOffsetMinutes = 330;
	const currentDateInIst = new Date(
		currentDate.getTime() + istOffsetMinutes * 60 * 1000
	);

	const startOfDayInIst = new Date(currentDateInIst);
	startOfDayInIst.setHours(0, 0, 0, 0);

	const startOfMonthInIst = new Date(startOfDayInIst);
	startOfMonthInIst.setDate(1);
	startOfMonthInIst.setHours(0, 0, 0, 0);

	const toUtcFromIstDate = (dateInIst: Date) =>
		new Date(dateInIst.getTime() - istOffsetMinutes * 60 * 1000);

	return {
		startOfDayUtc: toUtcFromIstDate(startOfDayInIst),
		startOfMonthUtc: toUtcFromIstDate(startOfMonthInIst),
	};
};

export const insertFarmerWithCrops = async ({
	createdByUserId,
	createdFarmerId,
	parsedValues,
	primaryMobileNumber,
	secondaryMobileNumber,
}: {
	createdByUserId: string;
	createdFarmerId: string;
	parsedValues: z.infer<typeof createFarmerSchema>;
	primaryMobileNumber: string;
	secondaryMobileNumber?: string;
}) => {
	await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;
		await database.insert(farmer).values({
			id: createdFarmerId,
			name: parsedValues.name.trim(),
			primaryMobileNumber,
			secondaryMobileNumber: secondaryMobileNumber ?? null,
			addressAt: parsedValues.addressAt.trim(),
			nearbyLandmark: parsedValues.nearbyLandmark?.trim() || null,
			post: parsedValues.post.trim(),
			state: parsedValues.state.trim(),
			taluka: parsedValues.taluka.trim(),
			district: parsedValues.district.trim(),
			pincode: parsedValues.pincode.trim(),
			serviceByUserId: parsedValues.serviceByUserId,
			createdByUserId,
			referralFarmerId: parsedValues.referralFarmerId || null,
			farmSize: parsedValues.farmSize.trim(),
			irrigation: parsedValues.irrigation.trim(),
			lastOrderDate: null,
		});

		const farmerCropRows = parsedValues.crops.map((item) => ({
			id: crypto.randomUUID(),
			farmerId: createdFarmerId,
			cropId: item.cropId,
			dateOfSowing: item.dateOfSowing,
			currentStage: item.currentStage?.trim() || null,
		}));

		await database.insert(farmerCrop).values(farmerCropRows);

		await generateNotifications(
			database,
			createdFarmerId,
			parsedValues.serviceByUserId,
			farmerCropRows.map((row) => ({
				cropId: row.cropId,
				dateOfSowing: row.dateOfSowing,
				farmerCropId: row.id,
			}))
		);
	});
};

const trailingDecimalZeroPattern = /\.?0+$/;

export const formatPackageQuantity = (value: null | string) => {
	if (!value) {
		return "";
	}

	const numericValue = Number(value);
	return Number.isInteger(numericValue)
		? String(numericValue)
		: numericValue.toFixed(3).replace(trailingDecimalZeroPattern, "");
};

export const buildVariantLabel = ({
	name,
	packageQuantity,
	packageUnit,
	packagingType,
	skuCode,
}: {
	name: string;
	packageQuantity: null | string;
	packageUnit: null | string;
	packagingType: null | string;
	skuCode: null | string;
}) => {
	const packSize = [formatPackageQuantity(packageQuantity), packageUnit]
		.filter(Boolean)
		.join(" ");
	const parts = [
		name,
		packSize,
		packagingType,
		skuCode ? `SKU: ${skuCode}` : "",
	].filter(Boolean);

	return parts.join(" | ");
};

export const getProductSnapshot = async (productIds: string[]) => {
	const rows = await db
		.select({
			id: product.id,
			name: product.name,
			packageQuantity: product.packageQuantity,
			packageUnit: product.packageUnit,
			packagingType: product.packagingType,
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
			costPerUnit: product.costPerUnit,
			categoryCode: product.categoryCode,
			offerPrice: product.offerPrice,
			skuCode: product.skuCode,
		})
		.from(product)
		.innerJoin(productInventory, eq(productInventory.productId, product.id))
		.where(and(inArray(product.id, productIds), eq(product.isActive, true)));

	return new Map(
		rows.map((row) => [
			row.id,
			{
				...row,
				name: buildVariantLabel(row),
			},
		])
	);
};
