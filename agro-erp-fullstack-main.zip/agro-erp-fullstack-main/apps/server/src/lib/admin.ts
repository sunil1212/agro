import z from "zod";

export const adminCreatableRoles = ["admin", "warehouse"] as const;

export const createAccountSchema = z.object({
	name: z.string().trim().min(2, "Name must be at least 2 characters"),
	email: z.email("Enter a valid email address"),
	managerCode: z.preprocess(
		(value) =>
			typeof value === "string" && value.trim() === "" ? undefined : value,
		z
			.string()
			.trim()
			.min(2, "Manager code must be at least 2 characters")
			.max(24, "Manager code must be 24 characters or fewer")
			.regex(
				/^[a-zA-Z0-9_-]+$/,
				"Use only letters, numbers, hyphen, or underscore"
			)
			.optional()
	),
	password: z.string().min(8, "Password must be at least 8 characters"),
	role: z.enum(adminCreatableRoles),
	title: z.string().trim().min(2).max(120).optional(),
	dailySalesTarget: z.number().nonnegative().optional(),
	monthlySalesTarget: z.number().nonnegative().optional(),
});

export const consignmentNumberSchema = z
	.string()
	.trim()
	.min(1, "Consignment number is required")
	.max(64, "Consignment number must be 64 characters or fewer")
	.regex(/^[a-zA-Z0-9/-]+$/, "Use only letters, numbers, slash, or hyphen")
	.transform((value) => value.toUpperCase());

export const importConsignmentRowSchema = z.object({
	consignmentNumber: consignmentNumberSchema,
	serialNumber: z
		.number()
		.int("Serial number must be a whole number")
		.positive("Serial number must be greater than zero")
		.optional(),
});

export const importConsignmentsSchema = z.object({
	consignments: z
		.array(importConsignmentRowSchema)
		.min(1, "Add at least one consignment number")
		.max(5000, "Import 5000 consignments or fewer at a time"),
});

export const importProductRowSchema = z.object({
	categoryCode: z.string().trim().min(1).max(12),
	discount: z.number().min(0).max(100),
	mrp: z.number().nonnegative(),
	packageQuantity: z.number().positive(),
	packageUnit: z.string().trim().min(1).max(12),
	packagingType: z.string().trim().min(1).max(32),
	packingCode: z.string().trim().min(1).max(12),
	productCode: z.string().trim().min(1).max(12),
	productName: z.string().trim().min(2).max(255),
	sellingPrice: z.number().nonnegative(),
	sku: z.string().trim().min(1).max(32),
	stock: z.number().int().nonnegative(),
});

export const importProductsSchema = z
	.object({
		products: z
			.array(importProductRowSchema)
			.min(1, "Add at least one product")
			.max(5000, "Import 5000 products or fewer at a time"),
	})
	.superRefine(({ products }, context) => {
		const seenSkus = new Set<string>();

		for (const [index, productRow] of products.entries()) {
			const normalizedSku = productRow.sku.trim().toUpperCase();
			if (seenSkus.has(normalizedSku)) {
				context.addIssue({
					code: "custom",
					message: `SKU ${normalizedSku} appears more than once`,
					path: ["products", index, "sku"],
				});
			}
			seenSkus.add(normalizedSku);
		}
	});
