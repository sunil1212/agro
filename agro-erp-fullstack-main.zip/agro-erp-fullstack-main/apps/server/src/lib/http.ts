import type { Response } from "express";

interface ErrorResponseOptions {
	success?: boolean;
}

export class HttpError extends Error {
	readonly status: number;

	constructor(status: number, message: string) {
		super(message);
		this.name = "HttpError";
		this.status = status;
	}
}

export const getErrorMessage = (error: unknown) =>
	error instanceof Error ? error.message : "Request failed";

export const sendErrorResponse = (
	response: Response,
	error: unknown,
	options: ErrorResponseOptions = {}
) => {
	const payload =
		typeof options.success === "boolean"
			? { message: getErrorMessage(error), success: options.success }
			: { message: getErrorMessage(error) };

	response
		.status(error instanceof HttpError ? error.status : 400)
		.json(payload);
};
