import { db } from "@agro-erp-fullstack/db";
import { user } from "@agro-erp-fullstack/db/schema/auth";
import { inArray } from "drizzle-orm";
import z from "zod";
import { dispatchStatuses, rawAndPackingCategories } from "./inventory";

export const createInventoryItemSchema = z.object({
	category: z.enum(rawAndPackingCategories),
	currentStock: z.number().nonnegative(),
	itemCode: z.string().trim().min(1, "Item code is required"),
	lowStockThreshold: z.number().nonnegative(),
	name: z.string().trim().min(2, "Item name is required"),
	supplierName: z.string().trim().optional(),
	unit: z.string().trim().min(1, "Unit is required"),
});

export const updateInventoryItemSchema = createInventoryItemSchema
	.partial()
	.extend({
		category: z.enum(rawAndPackingCategories).optional(),
	});

export const updateFinishedGoodInventorySchema = z.object({
	batchNumber: z.string().trim().optional(),
	expiryDate: z.iso.date().optional().nullable(),
	minimumStockLevel: z.number().int().nonnegative().optional(),
	skuCode: z.string().trim().optional(),
	warehouseLocation: z.string().trim().optional(),
});

export const stockInwardSchema = z.object({
	batchNumber: z.string().trim().optional(),
	category: z.enum(["raw_material", "packing_material", "finished_good"]),
	inventoryItemId: z.string().trim().optional(),
	manualOrderNumber: z.string().trim().optional(),
	productId: z.string().trim().optional(),
	quantityAdded: z.number().positive("Quantity must be greater than 0"),
	remarks: z.string().trim().optional(),
	supplierName: z.string().trim().optional(),
});

export const stockOutwardSchema = z.object({
	approvedByUserId: z.string().trim().min(1, "Approved by is required"),
	category: z.enum(["raw_material", "packing_material", "finished_good"]),
	inventoryItemId: z.string().trim().optional(),
	productId: z.string().trim().optional(),
	quantityReduced: z.number().positive("Quantity must be greater than 0"),
	reason: z.string().trim().min(2, "Reason is required"),
	remarks: z.string().trim().optional(),
});

export const dispatchStatusSchema = z.object({
	status: z.enum(dispatchStatuses),
});

export const followUpUpdateSchema = z.object({
	slot: z.number().int().min(1).max(4),
	text: z.string().trim().max(1000),
});

export const followUpSlots = [1, 2, 3, 4] as const;
export type FollowUpSlot = (typeof followUpSlots)[number];
export const inventoryManagerRoles = ["admin", "warehouse"] as const;
export const finishedGoodsReadRoles = ["admin", "warehouse"] as const;

export const getStartOfToday = () => {
	const startOfToday = new Date();
	startOfToday.setHours(0, 0, 0, 0);
	return startOfToday;
};

export const formatInventoryQuantity = (value: number) => value.toFixed(3);

export const normalizeFollowUpInput = (value: undefined | string) => {
	const trimmed = value?.trim();
	return trimmed ? trimmed : null;
};

interface FollowUpOrderColumns {
	followUp1Text: null | string | string[];
	followUp1UpdatedAt: Date | null;
	followUp1UpdatedByUserId: null | string;
	followUp2Text: null | string | string[];
	followUp2UpdatedAt: Date | null;
	followUp2UpdatedByUserId: null | string;
	followUp3Text: null | string | string[];
	followUp3UpdatedAt: Date | null;
	followUp3UpdatedByUserId: null | string;
	followUp4Text: null | string | string[];
	followUp4UpdatedAt: Date | null;
	followUp4UpdatedByUserId: null | string;
}

const formatFollowUpText = (value: null | string | string[]) => {
	if (Array.isArray(value)) {
		const text = value.filter(Boolean).join(", ");
		return text || null;
	}

	return value;
};

export const getFollowUps = (
	currentOrder: FollowUpOrderColumns,
	currentUserId: string,
	userNameById: Map<string, string>
) =>
	followUpSlots.map((slot) => {
		const text = formatFollowUpText(currentOrder[`followUp${slot}Text`]);
		const updatedAt = currentOrder[`followUp${slot}UpdatedAt`];
		const updatedByUserId = currentOrder[`followUp${slot}UpdatedByUserId`];
		const hasValue = Boolean(text);

		return {
			canEdit: !hasValue || updatedByUserId === currentUserId,
			slot,
			text,
			updatedAt,
			updatedByName: updatedByUserId
				? (userNameById.get(updatedByUserId) ?? null)
				: null,
			updatedByUserId,
		};
	});

export const getFollowUpUserIds = (currentOrder: FollowUpOrderColumns) =>
	followUpSlots
		.map((slot) => currentOrder[`followUp${slot}UpdatedByUserId`])
		.filter((value): value is string => Boolean(value));

export const getUserNameById = async (
	userIds: string[]
): Promise<Map<string, string>> => {
	if (userIds.length === 0) {
		return new Map();
	}

	const rows = await db
		.select({ id: user.id, name: user.name })
		.from(user)
		.where(inArray(user.id, Array.from(new Set(userIds))));

	return new Map(rows.map((row) => [row.id, row.name]));
};

export const createFollowUpUserNameMap = getUserNameById;

export type StockInwardValues = z.infer<typeof stockInwardSchema>;
export type StockOutwardValues = z.infer<typeof stockOutwardSchema>;
export type DispatchStatus = (typeof dispatchStatuses)[number];
