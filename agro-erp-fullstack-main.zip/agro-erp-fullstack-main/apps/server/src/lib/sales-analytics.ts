import { CANONICAL_ORDER_STATUSES } from "../modules/orders/order-lifecycle";

export const IST_OFFSET_MINUTES = 330;
const DATE_ONLY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** Sale statuses that count toward sales totals. */
export const SALE_STATUSES = [
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
] as const;

/** Whether a given order status counts as a sale. */
export function isSaleStatus(status: string): boolean {
	return (SALE_STATUSES as readonly string[]).includes(status);
}

export function getSaleStatuses(): readonly string[] {
	return SALE_STATUSES;
}

export function getNonSaleStatuses(): string[] {
	return CANONICAL_ORDER_STATUSES.filter((s) => !isSaleStatus(s));
}

export interface TargetProgress {
	progress: number | null;
	sales: number;
	target: number;
}

export type SalesActorRole = "admin" | "advisor" | "team_leader";

export interface SalesActorStat {
	dailyProgress: TargetProgress | null;
	dailySalesTarget: string | null;
	email: string;
	id: string;
	monthlyDeliveredCount: number;
	monthlyDeliveredRate: number;
	monthlyProgress: TargetProgress | null;
	monthlyReturnCount: number;
	monthlyReturnRate: number;
	monthlySalesTarget: string | null;
	name: string;
	orderCount: number;
	role: SalesActorRole;
	totalSales: number;
}

export interface StatusPeriodStat {
	label: string;
	orders: number;
	sales: number;
	status: string;
}

export interface BranchSalesSummary {
	adminName: string;
	adminUserId: string;
	advisorCount: number;
	managerCode: string;
	orderCount: number;
	totalSales: number;
}

export interface PeriodStat {
	label: string;
	orders: number;
	sales: number;
}

export interface ManagerStatsResponse {
	actors: SalesActorStat[];
	periods: { daily: PeriodStat[]; monthly: PeriodStat[] };
	statuses: { daily: StatusPeriodStat[]; monthly: StatusPeriodStat[] };
	success: true;
	summary: {
		actorCount: number;
		dailySalesTarget?: string | null;
		monthlySalesTarget?: string | null;
		orderCount: number;
		totalSales: number;
	};
}

export interface ManagerStatsTrendsResponse {
	periods: { daily: PeriodStat[]; monthly: PeriodStat[] };
	statuses: { daily: StatusPeriodStat[]; monthly: StatusPeriodStat[] };
	success: true;
}

export interface BranchStatsDetailResponse {
	actors: SalesActorStat[];
	branch: BranchSalesSummary;
	periods: { daily: PeriodStat[]; monthly: PeriodStat[] };
	statuses: { daily: StatusPeriodStat[]; monthly: StatusPeriodStat[] };
	success: true;
	summary: {
		actorCount: number;
		orderCount: number;
		totalSales: number;
	};
}

/**
 * Parse IST date boundaries from optional from/to query strings.
 * Both are YYYY-MM-DD in Asia/Kolkata.
 * Returns UTC Date bounds for DB queries plus IST-aligned window starts
 * for daily/monthly target progress.
 */
export function parseIstDateRange(from?: string, to?: string) {
	const now = new Date();

	// Default to current IST month if not specified.
	const istNow = new Date(now.getTime() + IST_OFFSET_MINUTES * 60 * 1000);

	if (from && !DATE_ONLY_PATTERN.test(from)) {
		throw new Error("from must use YYYY-MM-DD format");
	}
	if (to && !DATE_ONLY_PATTERN.test(to)) {
		throw new Error("to must use YYYY-MM-DD format");
	}

	const defaultFrom = `${istNow.getUTCFullYear()}-${String(
		istNow.getUTCMonth() + 1
	).padStart(2, "0")}-01`;
	const defaultTo = `${istNow.getUTCFullYear()}-${String(
		istNow.getUTCMonth() + 1
	).padStart(2, "0")}-${String(istNow.getUTCDate()).padStart(2, "0")}`;
	const fromUtc = new Date(`${from ?? defaultFrom}T00:00:00.000+05:30`);
	const toUtc = new Date(`${to ?? defaultTo}T23:59:59.999+05:30`);

	if (
		Number.isNaN(fromUtc.getTime()) ||
		Number.isNaN(toUtc.getTime()) ||
		fromUtc > toUtc
	) {
		throw new Error("Invalid stats date range");
	}

	// Compute start of today and start of month in IST for target progress calculations.
	const startOfDayUtc = new Date(`${defaultTo}T00:00:00.000+05:30`);
	const startOfMonthUtc = new Date(`${defaultFrom}T00:00:00.000+05:30`);

	return { fromUtc, toUtc, startOfDayUtc, startOfMonthUtc };
}

export function toAmount(value: null | string | undefined): number {
	return Number(value ?? 0);
}

export function computeProgress(
	sales: number,
	target: string | null
): TargetProgress | null {
	if (!target) {
		return null;
	}
	const targetValue = toAmount(target);
	if (targetValue <= 0) {
		return null;
	}
	return {
		progress: sales / targetValue,
		sales,
		target: targetValue,
	};
}

/**
 * Build a period key from a Date for grouping.
 * "daily" -> ISO date string, "monthly" -> YYYY-MM.
 */
export function getPeriodKey(date: Date, period: "daily" | "monthly"): string {
	if (period === "daily") {
		return date.toISOString().slice(0, 10);
	}
	const year = date.getFullYear();
	const month = date.getMonth() + 1;
	return `${year}-${String(month).padStart(2, "0")}`;
}
