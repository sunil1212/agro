import type { db } from "@agro-erp-fullstack/db";
import {
	inventoryAlert,
	inventoryEvent,
	inventoryItem,
} from "@agro-erp-fullstack/db/schema/inventory";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { and, eq, sql } from "drizzle-orm";

export const inventoryCategories = [
	"raw_material",
	"packing_material",
	"finished_good",
] as const;

export const rawAndPackingCategories = [
	"raw_material",
	"packing_material",
] as const;

export const inventoryEventTypes = [
	"inward",
	"outward",
	"order_reservation",
	"order_cancellation",
	"order_dispatch",
	"manual_adjustment",
	"alert_opened",
	"alert_resolved",
] as const;

export const inventoryAlertTypes = ["low_stock", "expiring_product"] as const;
export const inventoryAlertStatuses = ["active", "resolved"] as const;

export const dispatchStatuses = [
	"confirmed",
	"dispatched",
	"return_in_transit",
	"return_in_warehouse",
] as const;

type InventoryCategory = (typeof inventoryCategories)[number];
type InventoryEventType = (typeof inventoryEventTypes)[number];
type InventoryAlertType = (typeof inventoryAlertTypes)[number];
type InventoryDb = typeof db;

const EXPIRY_ALERT_WINDOW_DAYS = 30;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;

const toInventoryQuantity = (value: number) => value.toFixed(3);

const getExpiryThresholdDate = () =>
	new Date(Date.now() + EXPIRY_ALERT_WINDOW_DAYS * MILLISECONDS_PER_DAY)
		.toISOString()
		.slice(0, 10);

export const getDispatchableQuantity = (quantity: number) => quantity;

export const getNextDispatchStatus = (
	currentStatus: (typeof dispatchStatuses)[number]
): (typeof dispatchStatuses)[number] | null => {
	switch (currentStatus) {
		case "confirmed":
			return "dispatched";
		case "return_in_transit":
			return "return_in_warehouse";
		default:
			return null;
	}
};

export async function insertInventoryEvent(
	database: InventoryDb,
	values: {
		actorUserId: string;
		approvedByUserId?: null | string;
		batchNumber?: null | string;
		category: InventoryCategory;
		eventType: InventoryEventType;
		inventoryItemId?: null | string;
		manualOrderNumber?: null | string;
		productId?: null | string;
		quantityAfter: number;
		quantityBefore: number;
		quantityDelta: number;
		reason?: null | string;
		referenceOrderId?: null | string;
		remarks?: null | string;
		reservedAfter?: null | number;
		reservedBefore?: null | number;
		supplierName?: null | string;
	}
) {
	const [createdEvent] = await database
		.insert(inventoryEvent)
		.values({
			id: crypto.randomUUID(),
			actorUserId: values.actorUserId,
			approvedByUserId: values.approvedByUserId ?? null,
			batchNumber: values.batchNumber ?? null,
			category: values.category,
			eventType: values.eventType,
			inventoryItemId: values.inventoryItemId ?? null,
			manualOrderNumber: values.manualOrderNumber ?? null,
			productId: values.productId ?? null,
			quantityAfter: toInventoryQuantity(values.quantityAfter),
			quantityBefore: toInventoryQuantity(values.quantityBefore),
			quantityDelta: toInventoryQuantity(values.quantityDelta),
			reason: values.reason ?? null,
			referenceOrderId: values.referenceOrderId ?? null,
			remarks: values.remarks ?? null,
			reservedAfter:
				typeof values.reservedAfter === "number"
					? toInventoryQuantity(values.reservedAfter)
					: null,
			reservedBefore:
				typeof values.reservedBefore === "number"
					? toInventoryQuantity(values.reservedBefore)
					: null,
			supplierName: values.supplierName ?? null,
		})
		.returning({ id: inventoryEvent.id });

	if (!createdEvent) {
		throw new Error("Failed to record inventory movement");
	}

	return createdEvent;
}

async function getActiveAlert(
	database: InventoryDb,
	values: {
		alertType: InventoryAlertType;
		inventoryItemId?: string;
		productId?: string;
	}
) {
	const rows = await database
		.select({ id: inventoryAlert.id })
		.from(inventoryAlert)
		.where(
			and(
				eq(inventoryAlert.alertType, values.alertType),
				eq(inventoryAlert.status, "active"),
				values.productId
					? eq(inventoryAlert.productId, values.productId)
					: eq(inventoryAlert.inventoryItemId, values.inventoryItemId ?? "")
			)
		)
		.limit(1);

	return rows[0] ?? null;
}

async function openAlert(
	database: InventoryDb,
	values: {
		actorUserId: string;
		alertType: InventoryAlertType;
		category: InventoryCategory;
		inventoryItemId?: null | string;
		message: string;
		productId?: null | string;
		thresholdValue: number;
		triggeredValue: number;
	}
) {
	const activeAlert = await getActiveAlert(database, {
		alertType: values.alertType,
		inventoryItemId: values.inventoryItemId ?? undefined,
		productId: values.productId ?? undefined,
	});

	if (activeAlert) {
		return;
	}

	const openedEvent = await insertInventoryEvent(database, {
		actorUserId: values.actorUserId,
		category: values.category,
		eventType: "alert_opened",
		inventoryItemId: values.inventoryItemId ?? null,
		productId: values.productId ?? null,
		quantityAfter: values.triggeredValue,
		quantityBefore: values.triggeredValue,
		quantityDelta: 0,
		remarks: values.message,
	});

	await database.insert(inventoryAlert).values({
		id: crypto.randomUUID(),
		alertType: values.alertType,
		category: values.category,
		inventoryItemId: values.inventoryItemId ?? null,
		message: values.message,
		openedEventId: openedEvent.id,
		productId: values.productId ?? null,
		thresholdValue: toInventoryQuantity(values.thresholdValue),
		triggeredValue: toInventoryQuantity(values.triggeredValue),
	});
}

async function resolveAlert(
	database: InventoryDb,
	values: {
		actorUserId: string;
		alertType: InventoryAlertType;
		category: InventoryCategory;
		inventoryItemId?: null | string;
		message: string;
		productId?: null | string;
		quantity: number;
		thresholdValue: number;
	}
) {
	const activeAlert = await getActiveAlert(database, {
		alertType: values.alertType,
		inventoryItemId: values.inventoryItemId ?? undefined,
		productId: values.productId ?? undefined,
	});

	if (!activeAlert) {
		return;
	}

	const resolvedEvent = await insertInventoryEvent(database, {
		actorUserId: values.actorUserId,
		category: values.category,
		eventType: "alert_resolved",
		inventoryItemId: values.inventoryItemId ?? null,
		productId: values.productId ?? null,
		quantityAfter: values.quantity,
		quantityBefore: values.quantity,
		quantityDelta: 0,
		remarks: values.message,
	});

	await database
		.update(inventoryAlert)
		.set({
			resolvedAt: new Date(),
			resolvedEventId: resolvedEvent.id,
			status: "resolved",
		})
		.where(eq(inventoryAlert.id, activeAlert.id));
}

export async function reconcileInventoryItemLowStockAlert(
	database: InventoryDb,
	values: { actorUserId: string; inventoryItemId: string }
) {
	const rows = await database
		.select({
			category: inventoryItem.category,
			currentStock: inventoryItem.currentStock,
			id: inventoryItem.id,
			lowStockThreshold: inventoryItem.lowStockThreshold,
			name: inventoryItem.name,
		})
		.from(inventoryItem)
		.where(eq(inventoryItem.id, values.inventoryItemId))
		.limit(1);
	const currentItem = rows[0];

	if (!currentItem) {
		return;
	}

	const currentStock = Number(currentItem.currentStock);
	const threshold = Number(currentItem.lowStockThreshold);
	const shouldAlert = threshold > 0 && currentStock < threshold;
	const message = `${currentItem.name} is below ${currentItem.category === "raw_material" ? "minimum stock" : "reorder"} level`;

	if (shouldAlert) {
		await openAlert(database, {
			actorUserId: values.actorUserId,
			alertType: "low_stock",
			category: currentItem.category,
			inventoryItemId: currentItem.id,
			message,
			thresholdValue: threshold,
			triggeredValue: currentStock,
		});
		return;
	}

	await resolveAlert(database, {
		actorUserId: values.actorUserId,
		alertType: "low_stock",
		category: currentItem.category,
		inventoryItemId: currentItem.id,
		message: `${currentItem.name} stock is back above threshold`,
		quantity: currentStock,
		thresholdValue: threshold,
	});
}

export async function reconcileProductInventoryAlerts(
	database: InventoryDb,
	values: { actorUserId: string; productId: string }
) {
	const rows = await database
		.select({
			expiryDate: productInventory.expiryDate,
			id: product.id,
			minimumStockLevel: productInventory.minimumStockLevel,
			name: product.name,
			packageQuantity: product.packageQuantity,
			packageUnit: product.packageUnit,
			packagingType: product.packagingType,
			quantity: productInventory.quantity,
			skuCode: product.skuCode,
		})
		.from(product)
		.innerJoin(productInventory, eq(productInventory.productId, product.id))
		.where(eq(product.id, values.productId))
		.limit(1);
	const currentProduct = rows[0];

	if (!currentProduct) {
		return;
	}

	const lowStockThreshold = currentProduct.minimumStockLevel;
	const shouldLowStockAlert =
		lowStockThreshold > 0 && currentProduct.quantity < lowStockThreshold;

	if (shouldLowStockAlert) {
		await openAlert(database, {
			actorUserId: values.actorUserId,
			alertType: "low_stock",
			category: "finished_good",
			message: `${currentProduct.name} is below minimum stock level`,
			productId: currentProduct.id,
			thresholdValue: lowStockThreshold,
			triggeredValue: currentProduct.quantity,
		});
	} else {
		await resolveAlert(database, {
			actorUserId: values.actorUserId,
			alertType: "low_stock",
			category: "finished_good",
			message: `${currentProduct.name} stock is back above threshold`,
			productId: currentProduct.id,
			quantity: currentProduct.quantity,
			thresholdValue: lowStockThreshold,
		});
	}

	const expiryDate = currentProduct.expiryDate;
	const shouldExpiryAlert =
		typeof expiryDate === "string" && expiryDate <= getExpiryThresholdDate();

	if (shouldExpiryAlert) {
		await openAlert(database, {
			actorUserId: values.actorUserId,
			alertType: "expiring_product",
			category: "finished_good",
			message: `${currentProduct.name} expires on ${expiryDate}`,
			productId: currentProduct.id,
			thresholdValue: EXPIRY_ALERT_WINDOW_DAYS,
			triggeredValue: 0,
		});
		return;
	}

	await resolveAlert(database, {
		actorUserId: values.actorUserId,
		alertType: "expiring_product",
		category: "finished_good",
		message: `${currentProduct.name} is no longer inside the expiry alert window`,
		productId: currentProduct.id,
		quantity: currentProduct.quantity,
		thresholdValue: EXPIRY_ALERT_WINDOW_DAYS,
	});
}

export async function reserveProductStock(
	database: InventoryDb,
	values: {
		actorUserId: string;
		productId: string;
		quantity: number;
		referenceOrderId: string;
	}
) {
	const currentRows = await database
		.select({
			name: product.name,
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		})
		.from(product)
		.innerJoin(productInventory, eq(productInventory.productId, product.id))
		.where(eq(product.id, values.productId))
		.limit(1);
	const currentProduct = currentRows[0];

	if (!currentProduct) {
		throw new Error("Selected product is invalid");
	}

	if (currentProduct.quantity < values.quantity) {
		throw new Error(
			`Insufficient available quantity for ${currentProduct.name}`
		);
	}

	const [updatedProduct] = await database
		.update(productInventory)
		.set({
			lastInventoryUpdatedAt: new Date(),
			quantity: sql`${productInventory.quantity} - ${values.quantity}`,
			reservedQuantity: sql`${productInventory.reservedQuantity} + ${values.quantity}`,
		})
		.where(
			and(
				eq(productInventory.productId, values.productId),
				sql`${productInventory.quantity} >= ${values.quantity}`
			)
		)
		.returning({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		});

	if (!updatedProduct) {
		throw new Error(
			`Insufficient available quantity for ${currentProduct.name}`
		);
	}

	await insertInventoryEvent(database, {
		actorUserId: values.actorUserId,
		category: "finished_good",
		eventType: "order_reservation",
		productId: values.productId,
		quantityAfter: updatedProduct.quantity,
		quantityBefore: currentProduct.quantity,
		quantityDelta: -values.quantity,
		referenceOrderId: values.referenceOrderId,
		reservedAfter: updatedProduct.reservedQuantity,
		reservedBefore: currentProduct.reservedQuantity,
	});
	await reconcileProductInventoryAlerts(database, {
		actorUserId: values.actorUserId,
		productId: values.productId,
	});
}

export async function releaseProductReservation(
	database: InventoryDb,
	values: {
		actorUserId: string;
		productId: string;
		quantity: number;
		referenceOrderId: string;
	}
) {
	const currentRows = await database
		.select({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		})
		.from(productInventory)
		.where(eq(productInventory.productId, values.productId))
		.limit(1);
	const currentProduct = currentRows[0];

	if (!currentProduct) {
		throw new Error("Selected product is invalid");
	}

	const [updatedProduct] = await database
		.update(productInventory)
		.set({
			lastInventoryUpdatedAt: new Date(),
			quantity: sql`${productInventory.quantity} + ${values.quantity}`,
			reservedQuantity: sql`GREATEST(${productInventory.reservedQuantity} - ${values.quantity}, 0)`,
		})
		.where(eq(productInventory.productId, values.productId))
		.returning({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		});

	if (!updatedProduct) {
		throw new Error("Failed to release reserved stock");
	}

	await insertInventoryEvent(database, {
		actorUserId: values.actorUserId,
		category: "finished_good",
		eventType: "order_cancellation",
		productId: values.productId,
		quantityAfter: updatedProduct.quantity,
		quantityBefore: currentProduct.quantity,
		quantityDelta: values.quantity,
		referenceOrderId: values.referenceOrderId,
		reservedAfter: updatedProduct.reservedQuantity,
		reservedBefore: currentProduct.reservedQuantity,
	});
	await reconcileProductInventoryAlerts(database, {
		actorUserId: values.actorUserId,
		productId: values.productId,
	});
}

export async function dispatchProductReservation(
	database: InventoryDb,
	values: {
		actorUserId: string;
		productId: string;
		quantity: number;
		referenceOrderId: string;
	}
) {
	const currentRows = await database
		.select({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		})
		.from(productInventory)
		.where(eq(productInventory.productId, values.productId))
		.limit(1);
	const currentProduct = currentRows[0];

	if (!currentProduct) {
		throw new Error("Selected product is invalid");
	}

	const [updatedProduct] = await database
		.update(productInventory)
		.set({
			lastInventoryUpdatedAt: new Date(),
			reservedQuantity: sql`GREATEST(${productInventory.reservedQuantity} - ${values.quantity}, 0)`,
		})
		.where(eq(productInventory.productId, values.productId))
		.returning({
			quantity: productInventory.quantity,
			reservedQuantity: productInventory.reservedQuantity,
		});

	if (!updatedProduct) {
		throw new Error("Failed to dispatch reserved stock");
	}

	await insertInventoryEvent(database, {
		actorUserId: values.actorUserId,
		category: "finished_good",
		eventType: "order_dispatch",
		productId: values.productId,
		quantityAfter: updatedProduct.quantity,
		quantityBefore: currentProduct.quantity,
		quantityDelta: 0,
		referenceOrderId: values.referenceOrderId,
		reservedAfter: updatedProduct.reservedQuantity,
		reservedBefore: currentProduct.reservedQuantity,
	});
}
