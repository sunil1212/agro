const CSV_ESCAPE_PATTERN = /[",\r\n]/;

export const escapeCsvCell = (value: unknown): string => {
	const text = value == null ? "" : String(value);
	return CSV_ESCAPE_PATTERN.test(text)
		? `"${text.replaceAll('"', '""')}"`
		: text;
};

export const toCsvRow = (
	row: Record<string, unknown>,
	headers: readonly string[]
): string => headers.map((header) => escapeCsvCell(row[header])).join(",");

export const toCsv = (
	rows: Record<string, unknown>[],
	headers: readonly string[]
): string => {
	const headerRow = headers.map((h) => escapeCsvCell(h)).join(",");
	const dataRows = rows.map((row) => toCsvRow(row, headers));
	return [headerRow, ...dataRows].join("\r\n");
};

export const toCsvWithBom = (
	rows: Record<string, unknown>[],
	headers: readonly string[]
): string => `\uFEFF${toCsv(rows, headers)}`;

export const formatPackSize = (
	packageQuantity: string | null,
	packageUnit: string | null
): string => {
	if (!(packageQuantity && packageUnit)) {
		return "";
	}
	return `${packageQuantity} ${packageUnit}`;
};
