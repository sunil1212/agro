import z from "zod";

export const adminAssignableRoles = [
	"team_leader",
	"advisor",
	"logistics",
] as const;

/** Roles that super admin is restricted to creating. */
export const superAdminAssignableRoles = ["admin", "warehouse"] as const;

/** All roles accepted at the validation layer by the account-creation schema. */
const accountCreatableRoles = [
	"admin",
	...adminAssignableRoles,
	"warehouse",
] as const;

export const createAccountSchema = z
	.object({
		name: z.string().trim().min(2, "Name must be at least 2 characters"),
		email: z.email("Enter a valid email address"),
		managerCode: z.preprocess(
			(value) =>
				value === null || (typeof value === "string" && value.trim() === "")
					? undefined
					: value,
			z
				.string()
				.trim()
				.min(2, "Manager code must be at least 2 characters")
				.max(24, "Manager code must be 24 characters or fewer")
				.regex(
					/^[a-zA-Z0-9_-]+$/,
					"Use only letters, numbers, hyphen, or underscore"
				)
				.optional()
		),
		password: z.string().min(8, "Password must be at least 8 characters"),
		role: z.enum(accountCreatableRoles),
		title: z.string().trim().min(2).max(120).optional(),
		dailySalesTarget: z.number().nonnegative().optional(),
		monthlySalesTarget: z.number().nonnegative().optional(),
		teamLeaderId: z.string().trim().min(1).nullable().optional(),
	})
	.superRefine((values, context) => {
		if (values.role !== "advisor") {
			return;
		}

		if (values.dailySalesTarget === undefined) {
			context.addIssue({
				code: "custom",
				message: "Daily sales target is required",
				path: ["dailySalesTarget"],
			});
		}

		if (values.monthlySalesTarget === undefined) {
			context.addIssue({
				code: "custom",
				message: "Monthly sales target is required",
				path: ["monthlySalesTarget"],
			});
		}
	});

export const importAdvisorAccountsSchema = z.object({
	names: z
		.array(
			z
				.string()
				.trim()
				.min(2, "Advisor names must be at least 2 characters")
				.max(120, "Advisor names must be 120 characters or fewer")
		)
		.min(1, "Add at least one advisor name")
		.max(500, "Import 500 advisors or fewer at a time"),
});

export const importFarmerRowsSchema = z.object({
	rows: z
		.array(
			z.object({
				advisorName: z.string().trim().min(1),
				alternateNumber: z.string().trim().optional(),
				addressAt: z.string().trim().optional(),
				cropText: z.string().trim().optional(),
				crops: z.string().trim().optional(),
				date: z.iso.date(),
				district: z.string().trim().optional(),
				farmerName: z.string().trim().min(1),
				farmSize: z.string().trim().optional(),
				irrigation: z.string().trim().optional(),
				landmark: z.string().trim().optional(),
				mobileNumber: z.string().trim().min(1),
				pincode: z.preprocess(
					(value) =>
						typeof value === "string" && value.trim() === ""
							? undefined
							: value,
					z
						.string()
						.trim()
						.regex(/^\d{6}$/)
						.optional()
				),
				post: z.string().trim().optional(),
				referenceFarmerMobile: z.string().trim().optional(),
				rowNumber: z.number().int().positive(),
				state: z.string().trim().optional(),
				taluka: z.string().trim().optional(),
			})
		)
		.min(1, "Add at least one farmer")
		.max(1000, "Import 1,000 farmers or fewer at a time"),
});

export const importOrderRowsSchema = z.object({
	rows: z
		.array(
			z.object({
				advancePayment: z.number().nonnegative(),
				advisorName: z.string().trim().min(1),
				date: z.iso.date(),
				farmerName: z.string().trim().min(1),
				farmerPhone: z.string().trim().min(10),
				modeOfPayment: z.string().trim().min(1),
				orderId: z.string().trim().min(1),
				productAmount: z.number().nonnegative(),
				quantity: z.number().int().positive(),
				remainingCodPayment: z.number().nonnegative(),
				remarkDelivered: z.string().trim().optional(),
				returnReason: z.string().trim().optional(),
				returnStatus: z.string().trim().optional(),
				rowNumber: z.number().int().positive(),
				skuCode: z.string().trim().min(1),
			})
		)
		.min(1, "Add at least one order row")
		.max(5000, "Import 5,000 order rows or fewer at a time"),
});

const productBaseSchema = z.object({
	additionalNotes: z.string().trim().optional(),
	categoryCode: z
		.string()
		.trim()
		.min(1, "Category code is required")
		.max(12, "Category code must be 12 characters or fewer"),
	name: z.string().trim().min(2, "Product name must be at least 2 characters"),
	productCode: z
		.string()
		.trim()
		.min(1, "Product code is required")
		.max(12, "Product code must be 12 characters or fewer"),
});

const productVariantSchema = z.object({
	additionalNotes: z.string().trim().optional(),
	costPerUnit: z.number().nonnegative("MRP cannot be negative"),
	discount: z
		.number()
		.min(0, "Discount cannot be negative")
		.max(100, "Discount cannot exceed 100%"),
	offerPrice: z.number().nonnegative("Selling price cannot be negative"),
	packageQuantity: z.number().positive("Pack quantity must be greater than 0"),
	packageUnit: z
		.string()
		.trim()
		.min(1, "Pack unit is required")
		.max(12, "Pack unit must be 12 characters or fewer"),
	packagingType: z
		.string()
		.trim()
		.min(2, "Packaging type is required")
		.max(32, "Packaging type must be 32 characters or fewer"),
	packingCode: z
		.string()
		.trim()
		.min(1, "Packing code is required")
		.max(12, "Packing code must be 12 characters or fewer"),
	skuCode: z.string().trim().max(32, "SKU must be 32 characters or fewer"),
});

const legacyCreateProductSchema = productBaseSchema
	.merge(productVariantSchema)
	.extend({
		quantity: z.number().int().nonnegative("Opening stock cannot be negative"),
	});

const variantWithStockSchema = productVariantSchema.extend({
	id: z.string().trim().optional(),
	isActive: z.boolean().optional(),
	quantity: z.number().int().nonnegative("Opening stock cannot be negative"),
});

const productWithVariantsSchema = productBaseSchema.extend({
	variants: z.array(variantWithStockSchema).min(1, "Add at least one variant"),
});

export const createProductSchema = z.union([
	productWithVariantsSchema,
	legacyCreateProductSchema,
]);

export const updateProductSchema = z.union([
	productWithVariantsSchema,
	productBaseSchema.merge(
		productVariantSchema.extend({
			id: z.string().trim().optional(),
			isActive: z.boolean().optional(),
			quantity: z.number().int().nonnegative().optional().default(0),
		})
	),
]);

export const productIdSchema = z.string().min(1);

const digitsOnlyPattern = /^\d+$/;
const buildSkuCode = (
	categoryCode: string,
	productCode: string,
	packingCode: string
) => {
	const normalizedPackingCode = digitsOnlyPattern.test(packingCode)
		? packingCode.padStart(2, "0")
		: packingCode.toUpperCase();

	return `${categoryCode}${productCode}${normalizedPackingCode}`;
};

const calculateDiscount = (mrp: number, sellingPrice: number) => {
	if (mrp <= 0 || sellingPrice <= 0 || sellingPrice >= mrp) {
		return 0;
	}

	return Number((((mrp - sellingPrice) / mrp) * 100).toFixed(2));
};

const assertProductPricingIsValid = ({
	mrp,
	sellingPrice,
}: {
	mrp: number;
	sellingPrice: number;
}) => {
	if (sellingPrice > mrp && mrp > 0) {
		throw new Error("Selling price cannot be greater than MRP");
	}
};

export const normalizeProductCatalogValues = (
	values: z.infer<typeof productBaseSchema>
) => ({
	categoryCode: values.categoryCode.trim().toUpperCase(),
	name: values.name.trim(),
	productCode: values.productCode.trim().toUpperCase(),
	productNotes: values.additionalNotes || null,
});

export const normalizeProductVariantValues = (
	values: z.infer<typeof productVariantSchema>,
	codes: {
		categoryCode: string;
		productCode: string;
	}
) => {
	assertProductPricingIsValid({
		mrp: values.costPerUnit,
		sellingPrice: values.offerPrice,
	});

	const packingCode = values.packingCode.trim().toUpperCase();
	const packageUnit = values.packageUnit.trim().toUpperCase();
	const discount = calculateDiscount(values.costPerUnit, values.offerPrice);
	const skuCode =
		values.skuCode.trim().toUpperCase() ||
		buildSkuCode(codes.categoryCode, codes.productCode, packingCode);

	return {
		costPerUnit: values.costPerUnit.toFixed(2),
		discount: discount.toFixed(2),
		offerPrice: values.offerPrice.toFixed(2),
		packageQuantity: values.packageQuantity.toFixed(3),
		packageUnit,
		packagingType: values.packagingType.trim().toUpperCase(),
		packingCode,
		productNotes: values.additionalNotes || null,
		skuCode,
	};
};

export const getProductVariantInputs = (
	values:
		| z.infer<typeof createProductSchema>
		| z.infer<typeof updateProductSchema>
) =>
	"variants" in values
		? values.variants
		: [
				{
					additionalNotes: values.additionalNotes,
					costPerUnit: values.costPerUnit,
					discount: values.discount,
					id: "id" in values ? values.id : undefined,
					isActive: "isActive" in values ? values.isActive : undefined,
					offerPrice: values.offerPrice,
					packageQuantity: values.packageQuantity,
					packageUnit: values.packageUnit,
					packagingType: values.packagingType,
					packingCode: values.packingCode,
					quantity: values.quantity,
					skuCode: values.skuCode,
				},
			];

export const getManagerSafeErrorMessage = (error: unknown) => {
	if (error instanceof z.ZodError) {
		return (
			error.issues[0]?.message ??
			"Please check the product details and try again"
		);
	}

	const message = error instanceof Error ? error.message : "";
	if (
		message.includes("product_sku_code_uidx") ||
		message.includes("product_product_code_uidx") ||
		message.includes("duplicate key")
	) {
		return "A product or variant with this code already exists";
	}

	return "Unable to save the product right now. Please try again";
};

export const logManagerProductError = (
	action: "create" | "update",
	error: unknown,
	context: Record<string, unknown>
) => {
	const message = error instanceof Error ? error.message : String(error);
	const name = error instanceof Error ? error.name : "UnknownError";
	const zodIssues =
		error instanceof z.ZodError
			? error.issues.map((issue) => ({
					message: issue.message,
					path: issue.path.join("."),
				}))
			: undefined;

	console.error("[manager/products]", {
		action,
		context,
		error: {
			message,
			name,
			zodIssues,
		},
	});
};

export const createCropSchema = z.object({
	name: z.string().trim().min(2, "Crop name must be at least 2 characters"),
	schedules: z
		.array(
			z
				.object({
					endDay: z.number().int().positive("End day must be greater than 0"),
					instruction: z
						.string()
						.trim()
						.min(2, "Instruction must be at least 2 characters"),
					startDay: z
						.number()
						.int()
						.positive("Start day must be greater than 0"),
				})
				.refine((value) => value.endDay >= value.startDay, {
					message: "End day must be after start day",
					path: ["endDay"],
				})
		)
		.min(1, "Add at least one crop schedule entry"),
});

export const updateAdvisorTargetsSchema = z.object({
	dailySalesTarget: z
		.number("Daily sales target must be a number")
		.nonnegative("Daily sales target cannot be negative")
		.finite("Daily sales target must be a finite number")
		.nullable(),
	monthlySalesTarget: z
		.number("Monthly sales target must be a number")
		.nonnegative("Monthly sales target cannot be negative")
		.finite("Monthly sales target must be a finite number")
		.nullable(),
});

export const assignAdvisorTeamLeaderSchema = z.object({
	teamLeaderId: z.string().trim().min(1).nullable(),
});

export const resetAccountPasswordSchema = z.object({
	password: z.string().min(8, "Password must be at least 8 characters"),
});
