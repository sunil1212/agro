import { auth } from "@agro-erp-fullstack/auth";
import { env } from "@agro-erp-fullstack/env/server";
import { toNodeHandler } from "better-auth/node";
import cors from "cors";
import type { Express } from "express";
import express from "express";
import morgan from "morgan";

import { accountsRouter } from "./modules/accounts/accounts.routes";
import advisorTasksRouter from "./modules/advisor-tasks/advisor-tasks.routes";
import { branchAnalyticsRouter } from "./modules/analytics/branch-analytics.routes";
import { consignmentsRouter } from "./modules/consignments/consignments.routes";
import { cropsRouter } from "./modules/crops/crops.routes";
import farmersRouter from "./modules/farmers/farmers.routes";
import { importsRouter } from "./modules/imports/imports.routes";
import inventoryRouter from "./modules/inventory/inventory.routes";
import advisorOrdersRouter from "./modules/orders/advisor-orders.routes";
import { orderExportsRouter } from "./modules/orders/order-exports.routes";
import ordersRouter from "./modules/orders/orders.routes";
import { productsRouter } from "./modules/products/products.routes";

const app: Express = express();
const corsOptions = {
	origin: env.CORS_ORIGIN,
	methods: ["DELETE", "GET", "POST", "PATCH", "OPTIONS"],
	allowedHeaders: ["Content-Type", "Authorization"],
	credentials: true,
};

app.use(cors(corsOptions));

app.use(morgan("tiny"));

app.all("/api/auth{/*path}", toNodeHandler(auth));

app.use(express.json({ limit: "6mb" }));
app.use("/api/accounts", accountsRouter);
app.use("/api/advisor-tasks", advisorTasksRouter);
app.use("/api/analytics", branchAnalyticsRouter);
app.use("/api", importsRouter);
app.use("/api/consignments", consignmentsRouter);
app.use("/api/crops", cropsRouter);
app.use("/api/farmers", farmersRouter);
app.use("/api/inventory", inventoryRouter);
app.use("/api/orders", ordersRouter);
app.use("/api/orders", advisorOrdersRouter);
app.use("/api/orders/exports", orderExportsRouter);
app.use("/api/products", productsRouter);

app.get("/", (_req, res) => {
	res.status(200).send("OK");
});

export default app;

if (!process.env.VERCEL) {
	app.listen(3000, () => {
		console.log("Server is running on http://localhost:3000");
	});
}
