import { auth } from "@agro-erp-fullstack/auth";
import { db } from "@agro-erp-fullstack/db";
import {
	account,
	getDefaultTitleForRole,
	session,
	teamLeaderAdvisor,
	type UserRole,
	user,
	userManagerCode,
	userSalesTarget,
} from "@agro-erp-fullstack/db/schema/auth";
import { and, eq, inArray, sql } from "drizzle-orm";

const advisorEmailDomain = "growmize.org";
const advisorInitialPassword = "qwerty123";
const whitespacePattern = /\s+/;
const advisorRoleValues = ["advisor"] as const;

const isAdvisorRole = (role: string) =>
	advisorRoleValues.some((advisorRole) => advisorRole === role);

export interface CreateAccountServiceInput {
	createdByUserId: string;
	dailySalesTarget?: null | number;
	email: string;
	managerCode?: null | string;
	monthlySalesTarget?: null | number;
	name: string;
	password: string;
	role: UserRole;
	teamLeaderId?: null | string;
	title?: null | string;
}

export interface ListAccountsServiceInput {
	createdByUserId?: string;
}

export const normalizeManagerCode = (value: string) =>
	value.trim().toUpperCase();

export const normalizeAdvisorName = (value: string) =>
	value.trim().split(whitespacePattern).filter(Boolean).join(" ");

export const getAdvisorEmail = (name: string) =>
	`${normalizeAdvisorName(name).toLowerCase().split(" ").join(".")}@${advisorEmailDomain}`;

export const listAccounts = async (input: ListAccountsServiceInput = {}) => {
	const accounts = await db
		.select({
			createdAt: user.createdAt,
			createdByUserId: user.createdByUserId,
			dailySalesTarget: sql<null | string>`case
					when ${user.role} = 'team_leader' then (
						select sum(assigned_target.daily_sales_target)::text
						from ${teamLeaderAdvisor} assigned_advisor
						left join ${userSalesTarget} assigned_target
							on assigned_target.user_id = assigned_advisor.advisor_id
						where assigned_advisor.team_leader_id = ${user.id}
					)
					else ${userSalesTarget.dailySalesTarget}::text
				end`,
			email: user.email,
			id: user.id,
			managerCode: userManagerCode.managerCode,
			monthlySalesTarget: sql<null | string>`case
					when ${user.role} = 'team_leader' then (
						select sum(assigned_target.monthly_sales_target)::text
						from ${teamLeaderAdvisor} assigned_advisor
						left join ${userSalesTarget} assigned_target
							on assigned_target.user_id = assigned_advisor.advisor_id
						where assigned_advisor.team_leader_id = ${user.id}
					)
					else ${userSalesTarget.monthlySalesTarget}::text
				end`,
			name: user.name,
			role: user.role,
			teamLeaderId: teamLeaderAdvisor.teamLeaderId,
			teamLeaderName: sql<null | string>`(
					select team_leader.name
					from "user" team_leader
					where team_leader.id = ${teamLeaderAdvisor.teamLeaderId}
				)`,
			title: user.title,
		})
		.from(user)
		.leftJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.leftJoin(userSalesTarget, eq(userSalesTarget.userId, user.id))
		.leftJoin(teamLeaderAdvisor, eq(teamLeaderAdvisor.advisorId, user.id))
		.where(
			input.createdByUserId
				? eq(user.createdByUserId, input.createdByUserId)
				: undefined
		);

	accounts.sort(
		(left, right) => right.createdAt.getTime() - left.createdAt.getTime()
	);

	return accounts;
};

export const getUserManagerCode = async (userId: string) => {
	const [currentUser] = await db
		.select({ managerCode: userManagerCode.managerCode })
		.from(userManagerCode)
		.where(eq(userManagerCode.userId, userId))
		.limit(1);

	return currentUser?.managerCode ?? null;
};

export const managerCodeExists = async (managerCode: string) => {
	const existingManagerCode = await db
		.select({ id: userManagerCode.userId })
		.from(userManagerCode)
		.innerJoin(user, eq(user.id, userManagerCode.userId))
		.where(
			and(eq(userManagerCode.managerCode, managerCode), eq(user.role, "admin"))
		)
		.limit(1);

	return existingManagerCode.length > 0;
};

export const createAccount = async (input: CreateAccountServiceInput) => {
	await auth.api.signUpEmail({
		body: {
			email: input.email,
			name: input.name,
			password: input.password,
			role: input.role,
		},
		headers: new Headers(),
	});

	const [createdAccount] = await db
		.update(user)
		.set({
			createdByUserId: input.createdByUserId,
			title: input.title?.trim() || getDefaultTitleForRole(input.role),
		})
		.where(eq(user.email, input.email))
		.returning({
			createdAt: user.createdAt,
			email: user.email,
			id: user.id,
			name: user.name,
			role: user.role,
			title: user.title,
		});

	if (!createdAccount) {
		throw new Error("Account was created but could not be loaded");
	}

	if (input.managerCode) {
		await db
			.insert(userManagerCode)
			.values({
				managerCode: input.managerCode,
				userId: createdAccount.id,
			})
			.onConflictDoUpdate({
				set: { managerCode: input.managerCode },
				target: userManagerCode.userId,
			});
	}

	if (
		typeof input.monthlySalesTarget === "number" ||
		typeof input.dailySalesTarget === "number"
	) {
		await db
			.insert(userSalesTarget)
			.values({
				dailySalesTarget:
					typeof input.dailySalesTarget === "number"
						? input.dailySalesTarget.toFixed(2)
						: null,
				monthlySalesTarget:
					typeof input.monthlySalesTarget === "number"
						? input.monthlySalesTarget.toFixed(2)
						: null,
				userId: createdAccount.id,
			})
			.onConflictDoUpdate({
				set: {
					dailySalesTarget:
						typeof input.dailySalesTarget === "number"
							? input.dailySalesTarget.toFixed(2)
							: null,
					monthlySalesTarget:
						typeof input.monthlySalesTarget === "number"
							? input.monthlySalesTarget.toFixed(2)
							: null,
				},
				target: userSalesTarget.userId,
			});
	}

	if (input.teamLeaderId && isAdvisorRole(createdAccount.role)) {
		await db.insert(teamLeaderAdvisor).values({
			advisorId: createdAccount.id,
			teamLeaderId: input.teamLeaderId,
		});
	}

	return {
		...createdAccount,
		dailySalesTarget:
			typeof input.dailySalesTarget === "number"
				? input.dailySalesTarget.toFixed(2)
				: null,
		managerCode: input.managerCode ?? null,
		monthlySalesTarget:
			typeof input.monthlySalesTarget === "number"
				? input.monthlySalesTarget.toFixed(2)
				: null,
		teamLeaderId: input.teamLeaderId ?? null,
		teamLeaderName: null,
		title: createdAccount.title,
	};
};

interface ImportAdvisorAccountsInput {
	createdByUserId: string;
	managerCode: string;
	names: string[];
}

interface AdvisorImportEntry {
	email: string;
	name: string;
}

interface FailedAdvisorImportEntry extends AdvisorImportEntry {
	message: string;
}

export const importAdvisorAccounts = async (
	input: ImportAdvisorAccountsInput
) => {
	const uniqueNames = new Map<string, AdvisorImportEntry>();

	for (const rawName of input.names) {
		const name = normalizeAdvisorName(rawName);
		if (!name) {
			continue;
		}

		const normalizedName = name.toLowerCase();
		if (uniqueNames.has(normalizedName)) {
			continue;
		}

		uniqueNames.set(normalizedName, {
			email: getAdvisorEmail(name),
			name,
		});
	}

	const advisors = [...uniqueNames.values()];
	const emails = advisors.map(({ email }) => email);
	const existingAccounts =
		emails.length > 0
			? await db
					.select({ email: user.email })
					.from(user)
					.where(inArray(user.email, emails))
			: [];
	const existingEmails = new Set(
		existingAccounts.map(({ email }) => email.toLowerCase())
	);
	const created: AdvisorImportEntry[] = [];
	const failed: FailedAdvisorImportEntry[] = [];
	const skipped: AdvisorImportEntry[] = [];

	for (const advisor of advisors) {
		if (existingEmails.has(advisor.email)) {
			skipped.push(advisor);
			continue;
		}

		try {
			await createAccount({
				createdByUserId: input.createdByUserId,
				email: advisor.email,
				managerCode: input.managerCode,
				name: advisor.name,
				password: advisorInitialPassword,
				role: "advisor",
			});
			created.push(advisor);
		} catch (error) {
			failed.push({
				...advisor,
				message:
					error instanceof Error ? error.message : "Account creation failed",
			});
		}
	}

	return {
		created,
		failed,
		received: input.names.length,
		skipped,
		unique: advisors.length,
	};
};

export const updateAdvisorTargets = async (input: {
	accountId: string;
	dailySalesTarget: number | null;
	monthlySalesTarget: number | null;
}) => {
	const [result] = await db
		.insert(userSalesTarget)
		.values({
			dailySalesTarget:
				input.dailySalesTarget === null
					? null
					: input.dailySalesTarget.toFixed(2),
			monthlySalesTarget:
				input.monthlySalesTarget === null
					? null
					: input.monthlySalesTarget.toFixed(2),
			userId: input.accountId,
		})
		.onConflictDoUpdate({
			set: {
				dailySalesTarget:
					input.dailySalesTarget === null
						? null
						: input.dailySalesTarget.toFixed(2),
				monthlySalesTarget:
					input.monthlySalesTarget === null
						? null
						: input.monthlySalesTarget.toFixed(2),
			},
			target: userSalesTarget.userId,
		})
		.returning({
			userId: userSalesTarget.userId,
			dailySalesTarget: userSalesTarget.dailySalesTarget,
			monthlySalesTarget: userSalesTarget.monthlySalesTarget,
		});

	if (!result) {
		throw new Error("Failed to update advisor targets");
	}

	return {
		id: result.userId,
		dailySalesTarget: result.dailySalesTarget,
		monthlySalesTarget: result.monthlySalesTarget,
	};
};

export const assignAdvisorTeamLeader = async (input: {
	advisorId: string;
	teamLeaderId: null | string;
}) => {
	if (!input.teamLeaderId) {
		await db
			.delete(teamLeaderAdvisor)
			.where(eq(teamLeaderAdvisor.advisorId, input.advisorId));

		return {
			advisorId: input.advisorId,
			teamLeaderId: null,
			teamLeaderName: null,
		};
	}

	const [teamLeader] = await db
		.select({ id: user.id, name: user.name, role: user.role })
		.from(user)
		.where(eq(user.id, input.teamLeaderId))
		.limit(1);

	if (!teamLeader || teamLeader.role !== "team_leader") {
		throw new Error("Team leader account not found");
	}

	await db
		.insert(teamLeaderAdvisor)
		.values({
			advisorId: input.advisorId,
			teamLeaderId: input.teamLeaderId,
		})
		.onConflictDoUpdate({
			set: { teamLeaderId: input.teamLeaderId },
			target: teamLeaderAdvisor.advisorId,
		});

	return {
		advisorId: input.advisorId,
		teamLeaderId: teamLeader.id,
		teamLeaderName: teamLeader.name,
	};
};

export const promoteAdvisorToSeniorAdvisor = async (accountId: string) => {
	const [updatedAccount] = await db
		.update(user)
		.set({
			title: "Senior Advisor",
		})
		.where(and(eq(user.id, accountId), eq(user.role, "advisor")))
		.returning({
			id: user.id,
			role: user.role,
			title: user.title,
		});

	if (!updatedAccount) {
		throw new Error("Advisor account not found");
	}

	return updatedAccount;
};

export const resetAccountPassword = async (input: {
	accountId: string;
	password: string;
}) => {
	const context = await auth.$context;
	const hashedPassword = await context.password.hash(input.password);

	const [updatedAccount] = await db
		.update(account)
		.set({
			password: hashedPassword,
		})
		.where(
			and(
				eq(account.userId, input.accountId),
				eq(account.providerId, "credential")
			)
		)
		.returning({
			userId: account.userId,
		});

	if (!updatedAccount) {
		throw new Error("Account password could not be reset");
	}

	await db.delete(session).where(eq(session.userId, input.accountId));

	return {
		id: updatedAccount.userId,
	};
};
