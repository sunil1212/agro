import { db } from "@agro-erp-fullstack/db";
import {
	product,
	productInventory,
} from "@agro-erp-fullstack/db/schema/product";
import { inArray, sql } from "drizzle-orm";
import type { z } from "zod";
import type { importProductsSchema } from "../lib/admin";

type ImportProduct = z.infer<typeof importProductsSchema>["products"][number];

const importChunkSize = 250;

const chunkRows = <TRow>(rows: TRow[], size: number): TRow[][] => {
	const chunks: TRow[][] = [];
	for (let index = 0; index < rows.length; index += size) {
		chunks.push(rows.slice(index, index + size));
	}
	return chunks;
};

const normalizeProduct = (productRow: ImportProduct) => ({
	categoryCode: productRow.categoryCode.trim().toUpperCase(),
	costPerUnit: productRow.mrp.toFixed(2),
	discount: productRow.discount.toFixed(2),
	name: productRow.productName.trim(),
	offerPrice: productRow.sellingPrice.toFixed(2),
	packageQuantity: productRow.packageQuantity.toFixed(3),
	packageUnit: productRow.packageUnit.trim().toUpperCase(),
	packagingType: productRow.packagingType.trim().toUpperCase(),
	packingCode: productRow.packingCode.trim().toUpperCase(),
	productCode: productRow.productCode.trim().toUpperCase(),
	skuCode: productRow.sku.trim().toUpperCase(),
	stock: productRow.stock,
});

const getImportedProductId = (
	importedProductIds: Map<string, string>,
	skuCode: string
) => {
	const productId = importedProductIds.get(skuCode);
	if (!productId) {
		throw new Error(`Unable to import SKU ${skuCode}`);
	}
	return productId;
};

export const importProducts = async (productRows: ImportProduct[]) => {
	const normalizedProducts = productRows.map(normalizeProduct);
	const skuCodes = normalizedProducts.map(({ skuCode }) => skuCode);
	const existingProducts = await db
		.select({ skuCode: product.skuCode })
		.from(product)
		.where(inArray(product.skuCode, skuCodes));
	const existingSkus = new Set(existingProducts.map(({ skuCode }) => skuCode));
	const now = new Date();

	await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;

		for (const productChunk of chunkRows(normalizedProducts, importChunkSize)) {
			const importedProducts = await database
				.insert(product)
				.values(
					productChunk.map(({ stock: _stock, ...productRow }) => ({
						...productRow,
						id: crypto.randomUUID(),
						isActive: true,
					}))
				)
				.onConflictDoUpdate({
					target: product.skuCode,
					set: {
						categoryCode: sql`excluded.category_code`,
						costPerUnit: sql`excluded.cost_per_unit`,
						discount: sql`excluded.discount`,
						isActive: true,
						name: sql`excluded.name`,
						offerPrice: sql`excluded.offer_price`,
						packageQuantity: sql`excluded.package_quantity`,
						packageUnit: sql`excluded.package_unit`,
						packagingType: sql`excluded.packaging_type`,
						packingCode: sql`excluded.packing_code`,
						productCode: sql`excluded.product_code`,
						updatedAt: now,
					},
				})
				.returning({
					id: product.id,
					skuCode: product.skuCode,
				});

			const importedProductIds = new Map(
				importedProducts.map(({ id, skuCode }) => [skuCode, id])
			);

			await database
				.insert(productInventory)
				.values(
					productChunk.map(({ skuCode, stock }) => ({
						lastInventoryUpdatedAt: now,
						pointsAdded: 0,
						pointsReason: "Product CSV migration",
						productId: getImportedProductId(importedProductIds, skuCode),
						quantity: stock,
					}))
				)
				.onConflictDoUpdate({
					target: productInventory.productId,
					set: {
						lastInventoryUpdatedAt: now,
						quantity: sql`excluded.quantity`,
					},
				});
		}
	});

	const updated = normalizedProducts.filter(({ skuCode }) =>
		existingSkus.has(skuCode)
	).length;

	return {
		inserted: normalizedProducts.length - updated,
		received: normalizedProducts.length,
		updated,
	};
};
