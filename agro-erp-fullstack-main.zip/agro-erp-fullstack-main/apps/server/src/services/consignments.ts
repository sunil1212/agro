import { db } from "@agro-erp-fullstack/db";
import {
	consignment,
	order,
	orderConsignment,
} from "@agro-erp-fullstack/db/schema/order";
import { desc, eq, max } from "drizzle-orm";

const completedOrderStatuses = ["delivered", "return_in_warehouse"] as const;

interface ImportConsignmentRow {
	consignmentNumber: string;
	serialNumber?: number;
}

interface NormalizedImportConsignmentRow {
	consignmentNumber: string;
	serialNumber: number;
}

export const listConsignments = () =>
	db
		.select({
			addedAt: consignment.addedAt,
			consignmentNumber: consignment.consignmentNumber,
			id: consignment.id,
			isActive: consignment.isActive,
			serialNumber: consignment.serialNumber,
		})
		.from(consignment)
		.orderBy(desc(consignment.serialNumber));

export const importConsignments = async (
	consignments: ImportConsignmentRow[]
) => {
	const seenNumbers = new Set<string>();
	const seenSerialNumbers = new Set<number>();
	const uniqueConsignments: NormalizedImportConsignmentRow[] = [];

	for (const [index, currentConsignment] of consignments.entries()) {
		const normalizedSerialNumber = currentConsignment.serialNumber ?? index + 1;

		if (seenNumbers.has(currentConsignment.consignmentNumber)) {
			continue;
		}

		if (seenSerialNumbers.has(normalizedSerialNumber)) {
			throw new Error(
				`Serial number ${normalizedSerialNumber} appears more than once`
			);
		}

		seenNumbers.add(currentConsignment.consignmentNumber);
		seenSerialNumbers.add(normalizedSerialNumber);
		uniqueConsignments.push({
			...currentConsignment,
			serialNumber: normalizedSerialNumber,
		});
	}

	const now = new Date();

	const result = await db.transaction(async (tx) => {
		const database = tx as unknown as typeof db;
		const [currentMaxSerialNumber] = await database
			.select({ value: max(consignment.serialNumber) })
			.from(consignment);
		const serialNumberOffset = currentMaxSerialNumber?.value ?? 0;
		let inserted = 0;
		let reactivated = 0;
		let skipped = 0;

		for (const currentImport of uniqueConsignments) {
			const nextSerialNumber = serialNumberOffset + currentImport.serialNumber;
			const [currentConsignment] = await database
				.select({
					id: consignment.id,
					isActive: consignment.isActive,
				})
				.from(consignment)
				.where(
					eq(consignment.consignmentNumber, currentImport.consignmentNumber)
				)
				.limit(1);

			if (!currentConsignment) {
				await database.insert(consignment).values({
					addedAt: now,
					consignmentNumber: currentImport.consignmentNumber,
					id: crypto.randomUUID(),
					isActive: true,
					serialNumber: nextSerialNumber,
				});
				inserted += 1;
				continue;
			}

			if (currentConsignment.isActive) {
				skipped += 1;
				continue;
			}

			const [latestAssignment] = await database
				.select({ status: order.status })
				.from(orderConsignment)
				.innerJoin(order, eq(order.id, orderConsignment.orderId))
				.where(eq(orderConsignment.consignmentId, currentConsignment.id))
				.orderBy(desc(orderConsignment.assignedAt))
				.limit(1);

			const canReactivate =
				!latestAssignment ||
				completedOrderStatuses.some(
					(status) => status === latestAssignment.status
				);

			if (!canReactivate) {
				skipped += 1;
				continue;
			}

			await database
				.update(consignment)
				.set({ addedAt: now, isActive: true, serialNumber: nextSerialNumber })
				.where(eq(consignment.id, currentConsignment.id));
			reactivated += 1;
		}

		return { inserted, reactivated, skipped };
	});

	return {
		...result,
		received: uniqueConsignments.length,
	};
};

export const deleteUnusedConsignment = async (consignmentId: string) => {
	const [existingAssignment] = await db
		.select({ id: orderConsignment.id })
		.from(orderConsignment)
		.where(eq(orderConsignment.consignmentId, consignmentId))
		.limit(1);

	if (existingAssignment) {
		return "has_order_history" as const;
	}

	const [deletedConsignment] = await db
		.delete(consignment)
		.where(eq(consignment.id, consignmentId))
		.returning({ id: consignment.id });

	return deletedConsignment ? ("deleted" as const) : ("not_found" as const);
};
