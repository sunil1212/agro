import type { db } from "@agro-erp-fullstack/db";
import {
	crop,
	cropSchedule,
	farmerCrop,
	farmerCropNotification,
} from "@agro-erp-fullstack/db/schema/farmer";
import { and, eq, inArray, sql } from "drizzle-orm";
import z from "zod";

import { HttpError } from "../lib/http";
import { addDaysToIsoDate } from "../shared/date";

export const addFarmerCropSchema = z.object({
	cropId: z.string().trim().min(1, "Crop is required"),
	dateOfSowing: z.iso.date("Date of sowing is required"),
});

export interface AddFarmerCropParams {
	cropId: string;
	database: typeof db;
	dateOfSowing: string;
	farmerId: string;
	serviceByUserId: string;
}

export interface CropInput {
	cropId: string;
	dateOfSowing: string;
	farmerCropId: string;
}

export async function generateNotifications(
	database: typeof db,
	farmerId: string,
	serviceByUserId: string,
	crops: CropInput[]
): Promise<void> {
	if (crops.length === 0) {
		return;
	}

	const scheduleRows = await database
		.select({
			id: cropSchedule.id,
			cropId: cropSchedule.cropId,
			startDay: cropSchedule.startDay,
			instruction: cropSchedule.instruction,
		})
		.from(cropSchedule)
		.where(
			and(
				inArray(
					cropSchedule.cropId,
					crops.map((item) => item.cropId)
				),
				eq(cropSchedule.isActive, true)
			)
		);

	if (scheduleRows.length === 0) {
		return;
	}

	const cropInputById = new Map(crops.map((item) => [item.cropId, item]));
	const farmerCropIdByCropId = new Map(
		crops.map((item) => [item.cropId, item.farmerCropId])
	);

	await database.insert(farmerCropNotification).values(
		scheduleRows.flatMap((schedule) => {
			const cropInput = cropInputById.get(schedule.cropId);
			const farmerCropId = farmerCropIdByCropId.get(schedule.cropId);

			if (!(cropInput && farmerCropId)) {
				return [];
			}

			return {
				id: crypto.randomUUID(),
				advisorUserId: serviceByUserId,
				cropId: schedule.cropId,
				cropScheduleId: schedule.id,
				farmerId,
				farmerCropId,
				instruction: schedule.instruction,
				isCompleted: false,
				scheduledFor: addDaysToIsoDate(
					cropInput.dateOfSowing,
					schedule.startDay
				),
			};
		})
	);
}

export async function addFarmerCrop(
	params: AddFarmerCropParams
): Promise<void> {
	const { database, farmerId, serviceByUserId, cropId, dateOfSowing } = params;

	const farmerCropId = crypto.randomUUID();

	await database.transaction(async (tx) => {
		const dbTx = tx as unknown as typeof db;
		const [activeCrop] = await dbTx
			.select({ id: crop.id })
			.from(crop)
			.where(and(eq(crop.id, cropId), eq(crop.isActive, true)))
			.limit(1);

		if (!activeCrop) {
			throw new HttpError(400, "Selected crop is not active");
		}

		await dbTx.insert(farmerCrop).values({
			id: farmerCropId,
			farmerId,
			cropId,
			dateOfSowing,
			currentStage: null,
		});

		await generateNotifications(dbTx, farmerId, serviceByUserId, [
			{ cropId, dateOfSowing, farmerCropId },
		]);
	});
}

export async function validateActiveCrop(
	database: typeof db,
	cropId: string
): Promise<boolean> {
	const rows = await database
		.select({ id: crop.id })
		.from(crop)
		.where(and(eq(crop.id, cropId), eq(crop.isActive, true)))
		.limit(1);

	return rows.length > 0;
}

export interface FarmerCropHistoryItem {
	createdAt: Date;
	cropId: string;
	cropName: string;
	currentStage: string | null;
	dateOfSowing: string;
	id: string;
	taskCount: number;
}

export async function getFarmerCropHistory(
	database: typeof db,
	farmerId: string
): Promise<FarmerCropHistoryItem[]> {
	const rows = await database
		.select({
			id: farmerCrop.id,
			cropId: farmerCrop.cropId,
			cropName: crop.name,
			dateOfSowing: farmerCrop.dateOfSowing,
			currentStage: farmerCrop.currentStage,
			createdAt: farmerCrop.createdAt,
			taskCount: sql<number>`(
				select count(*)::int
				from ${farmerCropNotification}
				where ${farmerCropNotification.farmerCropId} = ${farmerCrop.id}
			)`,
		})
		.from(farmerCrop)
		.innerJoin(crop, eq(crop.id, farmerCrop.cropId))
		.where(eq(farmerCrop.farmerId, farmerId))
		.orderBy(farmerCrop.dateOfSowing);

	return rows;
}
