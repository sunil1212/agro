import { db } from "@agro-erp-fullstack/db";
import { user } from "@agro-erp-fullstack/db/schema/auth";
import { farmer } from "@agro-erp-fullstack/db/schema/farmer";
import {
	order,
	orderConsignment,
	orderItem,
} from "@agro-erp-fullstack/db/schema/order";
import { product } from "@agro-erp-fullstack/db/schema/product";
import { and, asc, eq, gte, isNotNull, lte, sql } from "drizzle-orm";
import { escapeCsvCell, formatPackSize, toCsvWithBom } from "../lib/csv";

// Static booking sender details from reference
const BOOKING_CUSTOMER_NAME = "FARMTABLE SUPPLIERS LLP-1000060572";
const BOOKING_CUSTOMER_ID = "1000060572";
const BOOKING_SENDER_MOBILE = "7028706451";

const BOOKING_SENDER = {
	addressLine1: "SASWAD INDUSTRIAL AREA, SASWAD, PUNE MH - 412301",
	addressLine2: "SASWAD INDUSTRIAL AREA, SASWAD, PUNE MH - 412301",
	city: "Pune",
	companyName: "",
	email: "growmizeagri@gmail.com",
	mobileNumber: "7028706451",
	name: "Growmize pvt ltd",
	pincode: "412301",
	state: "Maharashtra",
} as const;

const BOOKING_HEADERS = [
	"SERIAL NUMBER",
	"BARCODE NO",
	"PHYSICAL WEIGHT",
	"RECEIVER CITY",
	"RECEIVER PINCODE",
	"RECEIVER NAME",
	"RECEIVER ADD LINE 1",
	"RECEIVER ADD LINE 2",
	"ACK",
	"SENDER MOBILE NO",
	"RECEIVER MOBILE NO",
	"PREPAYMENT CODE",
	"VALUE OF PREPAYMENT",
	"CODR/COD",
	"VALUE FOR CODR/COD",
	"INSURANCE TYPE",
	"VALUE OF INSURANCE",
	"SHAPE OF ARTICLE",
	"LENGTH ",
	"BREADTH/DIAMETER",
	"HEIGHT",
	"PRIORITY FLAG",
	"DELIVERY INSTRUCTION",
	"DELIVERY SLOT",
	"INSTRUCTION RTS",
	"SENDER NAME",
	"SENDER COMPANY NAME",
	"SENDER CITY",
	"SENDER STATE/UT",
	"SENDER PINCODE",
	"SENDER EMAILID",
	"SENDER ALT CONTACT",
	"SENDER KYC",
	"SENDER TAX",
	"RECEIVER COMPANY NAME",
	"RECEIVER STATE/UT",
	"RECEIVER EMAILID",
	"RECEIVER ALT CONTACT",
	"RECEIVER KYC",
	"RECEIVER TAX REF",
	"ALT ADDRESS FLAG",
	"BULK REFERENCE",
	"SENDER ADD LINE 1",
	"SENDER ADD LINE 2",
	"SENDER ADD LINE 3",
	"FT-N0.",
] as const;

const PACKING_HEADERS = [
	"ORDER_ID",
	"STATUS",
	"PRODUCT_NAME",
	"PACK_SIZE",
	"QUANTITY",
	"LINE_TOTAL",
	"ORDER_TOTAL",
	"PAYMENT_MODE",
	"COD_AMOUNT",
] as const;

const PAYMENT_MODE_LABELS: Record<string, string> = {
	cod: "COD",
	partial_payment: "Partial Payment",
	prepaid: "Prepaid",
};

export interface ExportBranchParams {
	fromDate?: string;
	managerCode: string;
	status?: string;
	toDate?: string;
}

const DATE_ONLY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

const getExportDateRangeConditions = (params: ExportBranchParams) => {
	if (params.fromDate && !DATE_ONLY_PATTERN.test(params.fromDate)) {
		throw new Error("from must use YYYY-MM-DD format");
	}
	if (params.toDate && !DATE_ONLY_PATTERN.test(params.toDate)) {
		throw new Error("to must use YYYY-MM-DD format");
	}

	const fromDate = params.fromDate
		? new Date(`${params.fromDate}T00:00:00.000+05:30`)
		: undefined;
	const toDate = params.toDate
		? new Date(`${params.toDate}T23:59:59.999+05:30`)
		: undefined;
	if (fromDate && toDate && fromDate > toDate) {
		throw new Error("from must not be after to");
	}

	return [
		fromDate ? gte(order.createdAt, fromDate) : undefined,
		toDate ? lte(order.createdAt, toDate) : undefined,
	];
};

export const getPackingExport = async (params: ExportBranchParams) => {
	const dateRangeConditions = getExportDateRangeConditions(params);
	const rows = await db
		.select({
			codAmount: order.totalCodAmount,
			createdAt: order.createdAt,
			lineTotalAmount: orderItem.lineTotalAmount,
			orderId: order.orderId,
			orderStatus: order.status,
			orderTotalAmount: order.grandTotalAmount,
			packageQuantity: product.packageQuantity,
			packageUnit: product.packageUnit,
			paymentMode: order.paymentMode,
			productName: product.name,
			quantity: orderItem.quantity,
		})
		.from(order)
		.innerJoin(user, eq(user.id, order.createdByUserId))
		.innerJoin(
			sql`user_manager_code`,
			sql`user_manager_code.user_id = ${user.id}`
		)
		.innerJoin(orderItem, eq(orderItem.orderId, order.id))
		.innerJoin(product, eq(product.skuCode, orderItem.productSku))
		.where(
			and(
				sql`user_manager_code.manager_code = ${params.managerCode}`,
				params.status
					? eq(order.status, params.status as typeof order.$inferSelect.status)
					: eq(order.status, "confirmed"),
				isNotNull(order.orderId),
				...dateRangeConditions
			)
		)
		.orderBy(asc(order.createdAt), asc(order.id), asc(orderItem.createdAt));

	const dataRows = rows.map((row) => ({
		COD_AMOUNT: row.codAmount,
		LINE_TOTAL: row.lineTotalAmount,
		ORDER_ID: row.orderId ?? "",
		ORDER_TOTAL: row.orderTotalAmount,
		PACK_SIZE: formatPackSize(row.packageQuantity, row.packageUnit),
		PAYMENT_MODE: PAYMENT_MODE_LABELS[row.paymentMode] ?? row.paymentMode,
		PRODUCT_NAME: row.productName,
		QUANTITY: String(row.quantity),
		STATUS: String(row.orderStatus),
	}));

	return toCsvWithBom(dataRows, PACKING_HEADERS);
};

export const getBookingExport = async (params: ExportBranchParams) => {
	const dateRangeConditions = getExportDateRangeConditions(params);
	const rows = await db
		.select({
			codAmount: order.totalCodAmount,
			consignmentNumber: orderConsignment.consignmentNumber,
			farmerAddressAt: farmer.addressAt,
			farmerDistrict: farmer.district,
			farmerName: farmer.name,
			farmerNearbyLandmark: farmer.nearbyLandmark,
			farmerPincode: farmer.pincode,
			farmerPost: farmer.post,
			farmerPrimaryMobileNumber: farmer.primaryMobileNumber,
			farmerState: farmer.state,
			farmerTaluka: farmer.taluka,
			orderId: order.orderId,
			paymentMode: order.paymentMode,
		})
		.from(order)
		.innerJoin(user, eq(user.id, order.createdByUserId))
		.innerJoin(
			sql`user_manager_code`,
			sql`user_manager_code.user_id = ${user.id}`
		)
		.innerJoin(farmer, eq(farmer.id, order.farmerId))
		.innerJoin(orderConsignment, eq(orderConsignment.orderId, order.id))
		.where(
			and(
				sql`user_manager_code.manager_code = ${params.managerCode}`,
				params.status
					? eq(order.status, params.status as typeof order.$inferSelect.status)
					: eq(order.status, "confirmed"),
				isNotNull(order.orderId),
				isNotNull(orderConsignment.consignmentNumber),
				...dateRangeConditions
			)
		)
		.orderBy(asc(order.createdAt), asc(order.id));

	if (rows.length === 0) {
		return null;
	}

	const formatAddress = (row: (typeof rows)[number]) =>
		[
			row.farmerAddressAt ? `At - ${row.farmerAddressAt}` : null,
			row.farmerPost ? `Post - ${row.farmerPost}` : null,
			row.farmerNearbyLandmark
				? `Landmark - ${row.farmerNearbyLandmark}`
				: null,
			row.farmerTaluka ? `Taluka - ${row.farmerTaluka}` : null,
			row.farmerDistrict ? `District - ${row.farmerDistrict}` : null,
			row.farmerState ? `State - ${row.farmerState.toUpperCase()}` : null,
			row.farmerPincode ? `Pincode - ${row.farmerPincode}` : null,
		]
			.filter(Boolean)
			.join(", ");

	const emptyMetaRow = Array.from({ length: BOOKING_HEADERS.length }, () => "");
	const metaRows = [
		emptyMetaRow,
		["", "CUSTOMER NAME ", BOOKING_CUSTOMER_NAME],
		["", "CUSTOMER ID ", BOOKING_CUSTOMER_ID],
		["", "DATE", new Date().toLocaleDateString("en-IN")],
	];

	const headerRow = BOOKING_HEADERS.map((h) => escapeCsvCell(h)).join(",");

	const dataRows = rows.map((row, index) => {
		const address = formatAddress(row);
		const hasCodAmount = Number(row.codAmount) > 0;
		return [
			String(index + 1),
			row.consignmentNumber ?? "",
			"", // PHYSICAL WEIGHT - intentionally blank
			row.farmerDistrict ?? "",
			row.farmerPincode ?? "",
			row.farmerName,
			address,
			address,
			hasCodAmount ? "COD" : "",
			BOOKING_SENDER_MOBILE,
			row.farmerPrimaryMobileNumber,
			"", // PREPAYMENT CODE
			"", // VALUE OF PREPAYMENT
			hasCodAmount ? "COD" : "",
			hasCodAmount ? row.codAmount : "",
			"", // INSURANCE TYPE
			"", // VALUE OF INSURANCE
			"", // SHAPE OF ARTICLE
			"15", // LENGTH
			"10", // BREADTH / DIAMETER
			"10", // HEIGHT
			"", // PRIORITY FLAG
			"", // DELIVERY INSTRUCTION
			"", // DELIVERY SLOT
			"", // INSTRUCTION RTS
			BOOKING_SENDER.name,
			BOOKING_SENDER.companyName,
			BOOKING_SENDER.city,
			BOOKING_SENDER.state,
			BOOKING_SENDER.pincode,
			BOOKING_SENDER.email,
			"", // SENDER ALT CONTACT
			"", // SENDER KYC
			"", // SENDER TAX
			"", // RECEIVER COMPANY NAME
			row.farmerState?.toUpperCase() ?? "",
			"", // RECEIVER EMAILID
			"", // RECEIVER ALT CONTACT
			"", // RECEIVER KYC
			"", // RECEIVER TAX REF
			"FALSE",
			"", // BULK REFERENCE
			BOOKING_SENDER.addressLine1,
			BOOKING_SENDER.addressLine2,
			"", // SENDER ADD LINE 3
			row.orderId ?? "",
		]
			.map(escapeCsvCell)
			.join(",");
	});

	const metaCsv = metaRows
		.map((metaRow) =>
			Array.from({ length: BOOKING_HEADERS.length }, (_, index) =>
				escapeCsvCell(metaRow[index] ?? "")
			).join(",")
		)
		.join("\r\n");

	return `\uFEFF${metaCsv}\r\n${headerRow}\r\n${dataRows.join("\r\n")}`;
};
