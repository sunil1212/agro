import { db } from "@agro-erp-fullstack/db";
import { user, userManagerCode } from "@agro-erp-fullstack/db/schema/auth";
import { farmer } from "@agro-erp-fullstack/db/schema/farmer";
import {
	branchOrderSequence,
	order,
	orderDiscount,
	orderItem,
	orderPaymentTransaction,
} from "@agro-erp-fullstack/db/schema/order";
import { product } from "@agro-erp-fullstack/db/schema/product";
import { and, eq, inArray, sql } from "drizzle-orm";
import {
	formatBranchOrderId,
	parseBranchOrderSequence,
} from "../modules/orders/order-lifecycle";

interface OrderImportRow {
	advancePayment: number;
	advisorName: string;
	date: string;
	farmerName: string;
	farmerPhone: string;
	modeOfPayment: string;
	orderId: string;
	productAmount: number;
	quantity: number;
	remainingCodPayment: number;
	remarkDelivered?: string;
	returnReason?: string;
	returnStatus?: string;
	rowNumber: number;
	skuCode: string;
}

interface OrderImportEntry {
	orderId: string;
	rowNumbers: number[];
}

interface OrderImportIssue extends OrderImportEntry {
	message: string;
}

const whitespacePattern = /\s+/g;
const nonDigitPattern = /\D/g;
const orderIdPattern = /^([^-]+)-(\d+)$/;
const returnPattern = /return/i;

const normalizeText = (value: string | undefined) =>
	value?.trim().replace(whitespacePattern, " ") ?? "";

const normalizeName = (value: string) =>
	normalizeText(value).toLocaleLowerCase("en-IN");

const normalizePhone = (value: string) => {
	const digits = value.replace(nonDigitPattern, "");
	return digits.length === 12 && digits.startsWith("91")
		? `+${digits}`
		: `+91${digits}`;
};

const toMoney = (value: number) => value.toFixed(2);

const normalizeExternalOrderId = (value: string) => {
	const orderId = normalizeText(value).toUpperCase();
	const match = orderId.match(orderIdPattern);
	if (!match) {
		return orderId;
	}

	const [, adminCode, sequenceText] = match;
	const sequence = Number(sequenceText);
	if (!(adminCode && Number.isSafeInteger(sequence))) {
		return orderId;
	}

	return formatBranchOrderId(adminCode, sequence);
};

const getOrderStatus = (row: OrderImportRow) => {
	const hasReturn = [row.remarkDelivered, row.returnStatus].some((value) =>
		returnPattern.test(value ?? "")
	);
	if (hasReturn) {
		return "return_in_warehouse" as const;
	}
	const hasDelivered = normalizeText(row.remarkDelivered)
		.toUpperCase()
		.includes("DELIVERED");
	return hasDelivered ? ("delivered" as const) : ("confirmed" as const);
};

const getPaymentMode = (value: string) => {
	const normalizedMode = normalizeText(value).toUpperCase();
	if (normalizedMode === "PREPAID") {
		return "prepaid" as const;
	}
	if (normalizedMode === "PARTIAL" || normalizedMode === "PARTIAL_PAYMENT") {
		return "partial_payment" as const;
	}
	return "cod" as const;
};

const groupRowsByOrderId = (rows: OrderImportRow[]) => {
	const groupedRows = new Map<string, OrderImportRow[]>();
	for (const row of rows) {
		const orderId = normalizeExternalOrderId(row.orderId);
		const orderRows = groupedRows.get(orderId) ?? [];
		orderRows.push({ ...row, orderId });
		groupedRows.set(orderId, orderRows);
	}
	return groupedRows;
};

const findDuplicateSkuCodeAndUnitPrice = (rows: OrderImportRow[]) => {
	const seenSkuCodesAndUnitPrices = new Set<string>();
	for (const row of rows) {
		const normalizedSkuCode = row.skuCode.toUpperCase();
		const pricePerUnit = toMoney(row.productAmount / row.quantity);
		const duplicateKey = `${normalizedSkuCode}:${pricePerUnit}`;
		if (seenSkuCodesAndUnitPrices.has(duplicateKey)) {
			return {
				pricePerUnit,
				skuCode: normalizedSkuCode,
			};
		}
		seenSkuCodesAndUnitPrices.add(duplicateKey);
	}
	return null;
};

const getOrderImportErrorMessage = (error: unknown) => {
	const message = error instanceof Error ? error.message : "";
	if (
		message.includes("order_item_order_id_product_sku_unit_price_uidx") ||
		message.includes("order_item_order_id_product_sku_uidx") ||
		message.includes("duplicate key")
	) {
		return "Duplicate order item: the same SKU with the same unit price cannot appear more than once in a single order";
	}
	return error instanceof Error
		? error.message
		: "Order import failed for this row set";
};

const buildOrderItems = ({
	importedAt,
	internalOrderId,
	orderRows,
	productSkuByNormalizedSku,
}: {
	importedAt: Date;
	internalOrderId: string;
	orderRows: OrderImportRow[];
	productSkuByNormalizedSku: Map<string, string>;
}) =>
	orderRows.map((row) => {
		const productSku = productSkuByNormalizedSku.get(row.skuCode.toUpperCase());
		if (!productSku) {
			throw new Error(`Product SKU "${row.skuCode}" was not found`);
		}
		const pricePerUnit = row.productAmount / row.quantity;
		return {
			createdAt: importedAt,
			id: crypto.randomUUID(),
			lineTotalAmount: toMoney(row.productAmount),
			orderId: internalOrderId,
			productSku,
			quantity: row.quantity,
			sellingPricePerUnit: toMoney(pricePerUnit),
			unitPricePerUnit: toMoney(pricePerUnit),
			updatedAt: importedAt,
		};
	});

// Each external order is transactional: an unseen ID creates its order header,
// while an existing ID receives only the imported line items.
export const importOrders = async ({
	adminUserId,
	managerCode,
	rows,
}: {
	adminUserId: string;
	managerCode: string;
	rows: OrderImportRow[];
	// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: keeping create-or-append orchestration together prevents partial orders
}) => {
	const groupedRows = groupRowsByOrderId(rows);
	const orderIds = [...groupedRows.keys()];
	const phoneNumbers = [
		...new Set(rows.map((row) => normalizePhone(row.farmerPhone))),
	];
	const skuCodes = [...new Set(rows.map((row) => row.skuCode.toUpperCase()))];

	const [advisors, farmers, products, existingOrders] = await Promise.all([
		db
			.select({ id: user.id, name: user.name })
			.from(user)
			.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
			.where(
				and(
					eq(user.role, "advisor"),
					eq(userManagerCode.managerCode, managerCode)
				)
			),
		db
			.select({
				id: farmer.id,
				name: farmer.name,
				primaryMobileNumber: farmer.primaryMobileNumber,
			})
			.from(farmer)
			.where(inArray(farmer.primaryMobileNumber, phoneNumbers)),
		db
			.select({
				skuCode: product.skuCode,
			})
			.from(product)
			.where(inArray(product.skuCode, skuCodes)),
		db
			.select({
				createdAt: order.createdAt,
				id: order.id,
				orderId: order.orderId,
			})
			.from(order)
			.where(inArray(order.orderId, orderIds)),
	]);

	const advisorIdByName = new Map<string, string>();
	const ambiguousAdvisorNames = new Set<string>();
	for (const advisor of advisors) {
		const name = normalizeName(advisor.name);
		if (advisorIdByName.has(name)) {
			ambiguousAdvisorNames.add(name);
		}
		advisorIdByName.set(name, advisor.id);
	}

	const farmerByPhone = new Map(
		farmers.map((entry) => [entry.primaryMobileNumber, entry])
	);
	const productSkuByNormalizedSku = new Map(
		products.map((entry) => [entry.skuCode.toUpperCase(), entry.skuCode])
	);
	const existingOrderByExternalId = new Map(
		existingOrders
			.filter((entry): entry is typeof entry & { orderId: string } =>
				Boolean(entry.orderId)
			)
			.map((entry) => [entry.orderId.toUpperCase(), entry])
	);
	const created: OrderImportEntry[] = [];
	const failed: OrderImportIssue[] = [];
	const skipped: OrderImportIssue[] = [];
	const updated: OrderImportEntry[] = [];

	for (const [externalOrderId, orderRows] of groupedRows) {
		const entry = {
			orderId: externalOrderId,
			rowNumbers: orderRows.map((row) => row.rowNumber),
		};
		const firstRow = orderRows[0];
		if (!firstRow) {
			continue;
		}
		const branchOrderSequenceValue = parseBranchOrderSequence(
			externalOrderId,
			managerCode
		);
		if (branchOrderSequenceValue === null) {
			failed.push({
				...entry,
				message: `Order ID must use the ${managerCode}-<numeric sequence> format`,
			});
			continue;
		}
		const missingSku = orderRows.find(
			(row) => !productSkuByNormalizedSku.has(row.skuCode.toUpperCase())
		)?.skuCode;
		if (missingSku) {
			failed.push({
				...entry,
				message: `Product SKU "${missingSku}" was not found`,
			});
			continue;
		}
		const duplicateSkuCodeAndUnitPrice =
			findDuplicateSkuCodeAndUnitPrice(orderRows);
		if (duplicateSkuCodeAndUnitPrice) {
			failed.push({
				...entry,
				message: `Product SKU "${duplicateSkuCodeAndUnitPrice.skuCode}" with unit price "${duplicateSkuCodeAndUnitPrice.pricePerUnit}" is duplicated within order "${externalOrderId}"`,
			});
			continue;
		}

		const existingOrder = existingOrderByExternalId.get(externalOrderId);
		if (existingOrder) {
			try {
				await db.insert(orderItem).values(
					buildOrderItems({
						importedAt: existingOrder.createdAt,
						internalOrderId: existingOrder.id,
						orderRows,
						productSkuByNormalizedSku,
					})
				);
				updated.push(entry);
			} catch (error) {
				failed.push({
					...entry,
					message: getOrderImportErrorMessage(error),
				});
			}
			continue;
		}

		const advisorName = normalizeName(firstRow.advisorName);
		const advisorId = advisorIdByName.get(advisorName);
		if (!advisorId || ambiguousAdvisorNames.has(advisorName)) {
			failed.push({
				...entry,
				message: ambiguousAdvisorNames.has(advisorName)
					? `Advisor "${firstRow.advisorName}" is not unique`
					: `Advisor "${firstRow.advisorName}" was not found`,
			});
			continue;
		}

		const farmerPhone = normalizePhone(firstRow.farmerPhone);
		const matchedFarmer = farmerByPhone.get(farmerPhone);
		if (!matchedFarmer) {
			failed.push({
				...entry,
				message: `Farmer with phone ${farmerPhone} was not found`,
			});
			continue;
		}

		const importedAt = new Date(`${firstRow.date}T00:00:00+05:30`);
		const internalOrderId = crypto.randomUUID();
		const legacyOrderTotal = firstRow.remainingCodPayment;

		try {
			await db.transaction(async (tx) => {
				const database = tx as unknown as typeof db;
				await database.insert(order).values({
					createdAt: importedAt,
					createdByUserId: advisorId,
					farmerId: matchedFarmer.id,
					grandTotalAmount: toMoney(legacyOrderTotal),
					id: internalOrderId,
					orderId: externalOrderId,
					paidAmount: toMoney(firstRow.advancePayment),
					paymentMode: getPaymentMode(firstRow.modeOfPayment),
					shippingCharges: toMoney(0),
					status: getOrderStatus(firstRow),
					subtotalAmount: toMoney(legacyOrderTotal),
					totalCodAmount: toMoney(legacyOrderTotal),
					updatedAt: importedAt,
				});
				await database.insert(orderDiscount).values({
					cashbackAmount: toMoney(0),
					couponCode: null,
					couponDiscountAmount: toMoney(0),
					couponId: null,
					orderId: internalOrderId,
					pointsDiscountAmount: toMoney(0),
					pointsUsed: 0,
					promoDiscount: toMoney(0),
					totalDiscountAmount: toMoney(0),
				});
				await database.insert(orderPaymentTransaction).values({
					orderId: internalOrderId,
					transactionScreenshotBase64: null,
					transactionUtr: null,
				});
				await database.insert(orderItem).values(
					buildOrderItems({
						importedAt,
						internalOrderId,
						orderRows,
						productSkuByNormalizedSku,
					})
				);
				await database
					.update(farmer)
					.set({ lastOrderDate: importedAt, updatedAt: importedAt })
					.where(eq(farmer.id, matchedFarmer.id));
				await database
					.insert(branchOrderSequence)
					.values({
						adminUserId,
						lastValue: branchOrderSequenceValue,
					})
					.onConflictDoUpdate({
						set: {
							lastValue: sql`greatest(${branchOrderSequence.lastValue}, ${branchOrderSequenceValue})`,
							updatedAt: new Date(),
						},
						target: branchOrderSequence.adminUserId,
					});
			});
			created.push(entry);
		} catch (error) {
			failed.push({
				...entry,
				message: getOrderImportErrorMessage(error),
			});
		}
	}

	return {
		created,
		failed,
		receivedOrders: groupedRows.size,
		receivedRows: rows.length,
		skipped,
		updated,
	};
};
