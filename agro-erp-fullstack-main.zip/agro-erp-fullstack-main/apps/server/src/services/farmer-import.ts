import { db } from "@agro-erp-fullstack/db";
import { user, userManagerCode } from "@agro-erp-fullstack/db/schema/auth";
import { farmer } from "@agro-erp-fullstack/db/schema/farmer";
import { and, eq, inArray } from "drizzle-orm";

interface FarmerImportRow {
	addressAt?: string;
	advisorName: string;
	alternateNumber?: string;
	crops?: string;
	cropText?: string;
	date: string;
	district?: string;
	farmerName: string;
	farmSize?: string;
	irrigation?: string;
	landmark?: string;
	mobileNumber: string;
	pincode?: string;
	post?: string;
	referenceFarmerMobile?: string;
	rowNumber: number;
	state?: string;
	taluka?: string;
}

interface FarmerImportEntry {
	farmerName: string;
	mobileNumber: string;
	rowNumber: number;
}

interface FarmerImportFailure extends FarmerImportEntry {
	message: string;
}

interface FarmerImportSkipped extends FarmerImportEntry {
	message: string;
}

const whitespacePattern = /\s+/g;
const nonDigitPattern = /\D/g;
const indianMobilePattern = /^\+91\d{10}$/;

const normalizeText = (value: string | undefined) =>
	value?.trim().replace(whitespacePattern, " ") ?? "";

const normalizeMobileNumber = (value: string | undefined) => {
	const digits = value?.replace(nonDigitPattern, "") ?? "";

	if (digits.length === 10) {
		return `+91${digits}`;
	}

	if (digits.length === 12 && digits.startsWith("91")) {
		return `+${digits}`;
	}

	return value?.trim() ?? "";
};

const normalizeAdvisorName = (value: string) =>
	normalizeText(value).toLocaleLowerCase("en-IN");

interface ImportContext {
	advisorIdsByName: Map<string, string>;
	ambiguousAdvisorNames: Set<string>;
	created: FarmerImportEntry[];
	createdRows: Array<{
		id: string;
		importedAt: Date;
		referenceFarmerMobile: string;
	}>;
	failed: FarmerImportFailure[];
	farmerIdByMobile: Map<string, string>;
	seenMobiles: Set<string>;
	skipped: FarmerImportSkipped[];
}

function validateRow(
	row: NormalizedFarmerRow,
	context: ImportContext
): "skip" | "fail" | null {
	const entry = {
		farmerName: normalizeText(row.farmerName),
		mobileNumber: row.mobileNumber,
		rowNumber: row.rowNumber,
	};

	if (context.farmerIdByMobile.has(row.mobileNumber)) {
		context.skipped.push({
			...entry,
			message: "A farmer with this mobile number already exists",
		});
		return "skip";
	}
	if (context.seenMobiles.has(row.mobileNumber)) {
		context.skipped.push({
			...entry,
			message: "Duplicate mobile number in this import",
		});
		return "skip";
	}
	context.seenMobiles.add(row.mobileNumber);

	if (!indianMobilePattern.test(row.mobileNumber)) {
		context.failed.push({
			...entry,
			message: "Mobile number must be 10 digits",
		});
		return "fail";
	}
	if (
		row.alternateNumber &&
		(!indianMobilePattern.test(row.alternateNumber) ||
			row.alternateNumber === row.mobileNumber)
	) {
		context.failed.push({
			...entry,
			message: "Alternate number is invalid or matches the primary number",
		});
		return "fail";
	}

	const normalizedAdvisorName = normalizeAdvisorName(row.advisorName);
	const advisorId = context.advisorIdsByName.get(normalizedAdvisorName);
	if (!advisorId || context.ambiguousAdvisorNames.has(normalizedAdvisorName)) {
		context.failed.push({
			...entry,
			message: context.ambiguousAdvisorNames.has(normalizedAdvisorName)
				? `Advisor name "${row.advisorName}" is not unique`
				: `Advisor "${row.advisorName}" was not found`,
		});
		return "fail";
	}

	return null;
}

async function insertFarmer(
	row: NormalizedFarmerRow,
	advisorId: string,
	context: ImportContext
) {
	const entry = {
		farmerName: normalizeText(row.farmerName),
		mobileNumber: row.mobileNumber,
		rowNumber: row.rowNumber,
	};
	const importedAt = new Date(`${row.date}T00:00:00+05:30`);
	const id = crypto.randomUUID();

	try {
		await db.insert(farmer).values({
			addressAt: normalizeText(row.addressAt) || null,
			createdAt: importedAt,
			createdByUserId: advisorId,
			cropText: normalizeText(row.cropText ?? row.crops) || null,
			district: normalizeText(row.district) || null,
			farmSize: normalizeText(row.farmSize),
			id,
			irrigation: normalizeText(row.irrigation),
			name: entry.farmerName,
			nearbyLandmark: normalizeText(row.landmark) || null,
			pincode: normalizeText(row.pincode) || null,
			post: normalizeText(row.post) || null,
			primaryMobileNumber: row.mobileNumber,
			referralFarmerId: null,
			secondaryMobileNumber: row.alternateNumber || null,
			serviceByUserId: advisorId,
			state: normalizeText(row.state) || "Maharashtra",
			taluka: normalizeText(row.taluka) || null,
			updatedAt: importedAt,
		});
		context.farmerIdByMobile.set(row.mobileNumber, id);
		context.createdRows.push({
			id,
			importedAt,
			referenceFarmerMobile: row.referenceFarmerMobile,
		});
		context.created.push(entry);
	} catch (error) {
		context.failed.push({
			...entry,
			message:
				error instanceof Error ? error.message : "Farmer creation failed",
		});
	}
}

interface NormalizedFarmerRow extends FarmerImportRow {
	alternateNumber: string;
	mobileNumber: string;
	referenceFarmerMobile: string;
}

function normalizeImportRows(rows: FarmerImportRow[]): NormalizedFarmerRow[] {
	return rows.map((row) => ({
		...row,
		alternateNumber: normalizeMobileNumber(row.alternateNumber),
		mobileNumber: normalizeMobileNumber(row.mobileNumber),
		referenceFarmerMobile: normalizeMobileNumber(row.referenceFarmerMobile),
	}));
}

async function loadAdvisors(managerCode: string) {
	const advisors = await db
		.select({ id: user.id, name: user.name })
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(
			and(
				eq(user.role, "advisor"),
				eq(userManagerCode.managerCode, managerCode)
			)
		);

	const advisorIdsByName = new Map<string, string>();
	const ambiguousAdvisorNames = new Set<string>();

	for (const advisor of advisors) {
		const normalizedName = normalizeAdvisorName(advisor.name);
		if (advisorIdsByName.has(normalizedName)) {
			ambiguousAdvisorNames.add(normalizedName);
			continue;
		}
		advisorIdsByName.set(normalizedName, advisor.id);
	}

	return { advisorIdsByName, ambiguousAdvisorNames };
}

async function loadExistingFarmers(mobileNumbers: string[]) {
	if (mobileNumbers.length === 0) {
		return new Map<string, string>();
	}

	const existingFarmers = await db
		.select({
			id: farmer.id,
			primaryMobileNumber: farmer.primaryMobileNumber,
		})
		.from(farmer)
		.where(inArray(farmer.primaryMobileNumber, mobileNumbers));

	return new Map(
		existingFarmers.map((entry) => [entry.primaryMobileNumber, entry.id])
	);
}

async function linkReferralFarmers(
	createdRows: Array<{
		id: string;
		importedAt: Date;
		referenceFarmerMobile: string;
	}>,
	farmerIdByMobile: Map<string, string>
) {
	for (const createdRow of createdRows) {
		if (!createdRow.referenceFarmerMobile) {
			continue;
		}

		const referralFarmerId = farmerIdByMobile.get(
			createdRow.referenceFarmerMobile
		);
		if (!referralFarmerId || referralFarmerId === createdRow.id) {
			continue;
		}

		await db
			.update(farmer)
			.set({ referralFarmerId, updatedAt: createdRow.importedAt })
			.where(eq(farmer.id, createdRow.id));
	}
}

// Import orchestration necessarily coordinates validation, advisor lookup,
// duplicate handling, insertion, and second-pass referral linking.
export const importFarmers = async (
	rows: FarmerImportRow[],
	managerCode: string
) => {
	const { advisorIdsByName, ambiguousAdvisorNames } =
		await loadAdvisors(managerCode);
	const normalizedRows = normalizeImportRows(rows);
	const mobileNumbers = normalizedRows.map(({ mobileNumber }) => mobileNumber);
	const farmerIdByMobile = await loadExistingFarmers(mobileNumbers);

	const context: ImportContext = {
		advisorIdsByName,
		ambiguousAdvisorNames,
		farmerIdByMobile,
		seenMobiles: new Set(),
		created: [],
		failed: [],
		skipped: [],
		createdRows: [],
	};

	for (const row of normalizedRows) {
		const validation = validateRow(row, context);
		if (validation !== null) {
			continue;
		}

		const normalizedAdvisorName = normalizeAdvisorName(row.advisorName);
		// biome-ignore lint/style/noNonNullAssertion: validateRow already confirmed the advisor exists, making this lookup safe
		const advisorId = context.advisorIdsByName.get(normalizedAdvisorName)!;
		await insertFarmer(row, advisorId, context);
	}

	await linkReferralFarmers(context.createdRows, context.farmerIdByMobile);

	return {
		created: context.created,
		failed: context.failed,
		received: rows.length,
		skipped: context.skipped,
	};
};
