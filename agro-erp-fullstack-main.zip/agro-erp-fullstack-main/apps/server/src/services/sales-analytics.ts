import type { db } from "@agro-erp-fullstack/db";
import {
	teamLeaderAdvisor,
	user,
	userManagerCode,
	userSalesTarget,
} from "@agro-erp-fullstack/db/schema/auth";
import { order } from "@agro-erp-fullstack/db/schema/order";
import { and, asc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import {
	type BranchSalesSummary,
	type BranchStatsDetailResponse,
	computeProgress,
	type ManagerStatsResponse,
	type ManagerStatsTrendsResponse,
	type PeriodStat,
	parseIstDateRange,
	SALE_STATUSES,
	type SalesActorRole,
	type SalesActorStat,
	type StatusPeriodStat,
	toAmount,
} from "../lib/sales-analytics";

interface GetManagerStatsOptions {
	actorId?: string;
	from?: string;
	status?: string;
	to?: string;
}

async function getScopedActorIds(
	database: typeof db,
	currentUserId: string
): Promise<null | { actorIds: string[]; currentUserRole: string }> {
	const [currentUser] = await database
		.select({ id: user.id, role: user.role })
		.from(user)
		.where(eq(user.id, currentUserId))
		.limit(1);

	if (!currentUser) {
		return null;
	}

	const [currentBranch] = await database
		.select({ managerCode: userManagerCode.managerCode })
		.from(userManagerCode)
		.where(eq(userManagerCode.userId, currentUserId))
		.limit(1);

	if (!currentBranch) {
		return null;
	}

	const actorRows =
		currentUser.role === "team_leader"
			? await database
					.select({ id: user.id })
					.from(teamLeaderAdvisor)
					.innerJoin(user, eq(user.id, teamLeaderAdvisor.advisorId))
					.where(eq(teamLeaderAdvisor.teamLeaderId, currentUserId))
			: await database
					.select({ id: user.id })
					.from(user)
					.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
					.where(
						and(
							eq(userManagerCode.managerCode, currentBranch.managerCode),
							sql`(${user.id} = ${currentUserId} OR ${user.role} = 'advisor')`
						)
					);

	return {
		actorIds: actorRows.map((row) => row.id),
		currentUserRole: currentUser.role,
	};
}

async function getTrendPeriods(
	database: typeof db,
	actorIds: string[],
	options: GetManagerStatsOptions = {}
): Promise<ManagerStatsTrendsResponse["periods"]> {
	if (actorIds.length === 0) {
		return { daily: [], monthly: [] };
	}

	const { fromUtc, toUtc } = parseIstDateRange(options.from, options.to);
	const baseConditions = sql`${order.createdByUserId} = ANY(ARRAY[${sql.join(
		actorIds.map((id) => sql`${id}::text`),
		sql`, `
	)}]::text[]) 
		AND ${order.createdAt} >= ${fromUtc} 
		AND ${order.createdAt} <= ${toUtc}`;
	const conditions = options.status
		? sql`${baseConditions} AND ${order.status} = ${options.status}`
		: baseConditions;
	const saleCondition = sql`${order.status} IN (${sql.join(
		SALE_STATUSES.map((status) => sql`${status}`),
		sql`, `
	)})`;
	const actorIdCondition = options.actorId
		? sql` AND ${order.createdByUserId} = ${options.actorId}`
		: sql``;
	const actorWhere = sql`${conditions}${actorIdCondition}`;

	const dailyRows = await database.execute<{
		label: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT 
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD') as label,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label
		ORDER BY label
	`);
	const monthlyRows = await database.execute<{
		label: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT 
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM') as label,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label
		ORDER BY label
	`);

	return {
		daily: dailyRows.rows.map((row) => ({
			label: row.label,
			orders: row.orders,
			sales: toAmount(row.sales),
		})),
		monthly: monthlyRows.rows.map((row) => ({
			label: row.label,
			orders: row.orders,
			sales: toAmount(row.sales),
		})),
	};
}

export async function getManagerTrendStats(
	database: typeof db,
	currentUserId: string,
	options: GetManagerStatsOptions = {}
): Promise<ManagerStatsTrendsResponse> {
	const { fromUtc, toUtc } = parseIstDateRange(options.from, options.to);
	const scope = await getScopedActorIds(database, currentUserId);

	if (!scope || scope.actorIds.length === 0) {
		return {
			periods: { daily: [], monthly: [] },
			statuses: { daily: [], monthly: [] },
			success: true,
		};
	}

	const actorWhere = and(
		inArray(order.createdByUserId, scope.actorIds),
		gte(order.createdAt, fromUtc),
		lte(order.createdAt, toUtc),
		options.actorId ? eq(order.createdByUserId, options.actorId) : undefined,
		options.status ? sql`${order.status} = ${options.status}` : undefined
	);
	const saleCondition = sql`${order.status} IN ('confirmed','dispatched','delivered','return_in_transit','return_in_warehouse')`;
	const dailyStatusRows = await database.execute<{
		label: string;
		status: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD') as label,
			${order.status} as status,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label, ${order.status}
		ORDER BY label, ${order.status}
	`);
	const monthlyStatusRows = await database.execute<{
		label: string;
		status: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM') as label,
			${order.status} as status,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label, ${order.status}
		ORDER BY label, ${order.status}
	`);
	const mapStatusRows = (
		rows: Array<{
			label: string;
			orders: number;
			sales: string;
			status: string;
		}>
	): StatusPeriodStat[] =>
		rows.map((row) => ({
			label: row.label,
			orders: row.orders,
			sales: toAmount(row.sales),
			status: row.status,
		}));

	return {
		periods: await getTrendPeriods(database, scope.actorIds, options),
		statuses: {
			daily: mapStatusRows(dailyStatusRows.rows),
			monthly: mapStatusRows(monthlyStatusRows.rows),
		},
		success: true,
	};
}

/**
 * Get aggregated stats for an admin's branch.
 * Returns per-actor stats (advisors + admin row), period trends, status breakdown.
 * Uses SQL aggregation instead of loading all orders.
 */
export async function getManagerStats(
	database: typeof db,
	currentUserId: string,
	options: GetManagerStatsOptions = {}
): Promise<ManagerStatsResponse> {
	const { fromUtc, toUtc, startOfDayUtc, startOfMonthUtc } = parseIstDateRange(
		options.from,
		options.to
	);

	const [currentUser] = await database
		.select({ id: user.id, role: user.role })
		.from(user)
		.where(eq(user.id, currentUserId))
		.limit(1);

	if (!currentUser) {
		return {
			actors: [],
			periods: { daily: [], monthly: [] },
			statuses: { daily: [], monthly: [] },
			summary: { actorCount: 0, orderCount: 0, totalSales: 0 },
			success: true,
		};
	}

	const [currentBranch] = await database
		.select({ managerCode: userManagerCode.managerCode })
		.from(userManagerCode)
		.where(eq(userManagerCode.userId, currentUserId))
		.limit(1);

	if (!currentBranch) {
		return {
			actors: [],
			periods: { daily: [], monthly: [] },
			statuses: { daily: [], monthly: [] },
			summary: { actorCount: 0, orderCount: 0, totalSales: 0 },
			success: true,
		};
	}

	const actorRows =
		currentUser.role === "team_leader"
			? await database
					.select({
						id: user.id,
						name: user.name,
						email: user.email,
						role: user.role,
						dailySalesTarget: userSalesTarget.dailySalesTarget,
						monthlySalesTarget: userSalesTarget.monthlySalesTarget,
					})
					.from(teamLeaderAdvisor)
					.innerJoin(user, eq(user.id, teamLeaderAdvisor.advisorId))
					.leftJoin(userSalesTarget, eq(userSalesTarget.userId, user.id))
					.where(eq(teamLeaderAdvisor.teamLeaderId, currentUserId))
					.orderBy(asc(user.name))
			: await database
					.select({
						id: user.id,
						name: user.name,
						email: user.email,
						role: user.role,
						dailySalesTarget: userSalesTarget.dailySalesTarget,
						monthlySalesTarget: userSalesTarget.monthlySalesTarget,
					})
					.from(user)
					.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
					.leftJoin(userSalesTarget, eq(userSalesTarget.userId, user.id))
					.where(
						and(
							eq(userManagerCode.managerCode, currentBranch.managerCode),
							sql`(${user.id} = ${currentUserId} OR ${user.role} = 'advisor')`
						)
					)
					.orderBy(
						asc(sql`CASE WHEN ${user.id} = ${currentUserId} THEN 0 ELSE 1 END`),
						asc(user.name)
					);

	const dailyTeamTarget =
		currentUser.role === "team_leader"
			? actorRows.reduce(
					(sum, row) => sum + Number(row.dailySalesTarget ?? 0),
					0
				)
			: null;
	const monthlyTeamTarget =
		currentUser.role === "team_leader"
			? actorRows.reduce(
					(sum, row) => sum + Number(row.monthlySalesTarget ?? 0),
					0
				)
			: null;

	const actorIds = actorRows.map((r) => r.id);
	if (actorIds.length === 0) {
		return {
			actors: [],
			periods: { daily: [], monthly: [] },
			statuses: { daily: [], monthly: [] },
			summary: {
				actorCount: 0,
				...(dailyTeamTarget === null
					? {}
					: { dailySalesTarget: dailyTeamTarget.toFixed(2) }),
				...(monthlyTeamTarget === null
					? {}
					: { monthlySalesTarget: monthlyTeamTarget.toFixed(2) }),
				orderCount: 0,
				totalSales: 0,
			},
			success: true,
		};
	}

	// Build base conditions for order queries.
	const baseConditions = sql`${order.createdByUserId} = ANY(ARRAY[${sql.join(
		actorIds.map((id) => sql`${id}::text`),
		sql`, `
	)}]::text[]) 
		AND ${order.createdAt} >= ${fromUtc} 
		AND ${order.createdAt} <= ${toUtc}`;

	const conditions = options.status
		? sql`${baseConditions} AND ${order.status} = ${options.status}`
		: baseConditions;
	const saleCondition = sql`${order.status} IN (${sql.join(
		SALE_STATUSES.map((status) => sql`${status}`),
		sql`, `
	)})`;

	const actorIdCondition = options.actorId
		? sql` AND ${order.createdByUserId} = ${options.actorId}`
		: sql``;

	const actorWhere = sql`${conditions}${actorIdCondition}`;

	// Actor-level aggregation: total + daily/monthly windows.
	const actorAggRows = await database.execute<{
		user_id: string;
		order_count: number;
		total_sales: string;
		daily_sales: string;
		monthly_sales: string;
	}>(sql`
		SELECT 
			${order.createdByUserId} as user_id,
			COUNT(*)::int as order_count,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as total_sales,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition} AND ${order.createdAt} >= ${startOfDayUtc}), 0) as daily_sales,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition} AND ${order.createdAt} >= ${startOfMonthUtc}), 0) as monthly_sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY ${order.createdByUserId}
	`);

	const aggMap = new Map(actorAggRows.rows.map((r) => [r.user_id, r]));
	// Monthly delivery and return rates intentionally ignore the status filter so
	// their denominator includes every order lifecycle state.
	const monthlyMetricRows = await database.execute<{
		monthly_delivered_count: number;
		monthly_order_count: number;
		monthly_return_count: number;
		user_id: string;
	}>(sql`
		SELECT
			${order.createdByUserId} as user_id,
			COUNT(*) FILTER (WHERE ${order.createdAt} >= ${startOfMonthUtc})::int as monthly_order_count,
			COUNT(*) FILTER (WHERE ${order.status} = 'delivered' AND ${order.createdAt} >= ${startOfMonthUtc})::int as monthly_delivered_count,
			COUNT(*) FILTER (WHERE ${order.status} IN ('return_in_transit', 'return_in_warehouse') AND ${order.createdAt} >= ${startOfMonthUtc})::int as monthly_return_count
		FROM ${order}
		WHERE ${baseConditions}${actorIdCondition}
		GROUP BY ${order.createdByUserId}
	`);
	const monthlyMetricMap = new Map(
		monthlyMetricRows.rows.map((row) => [row.user_id, row])
	);

	// Build actors with progress.
	const actors: SalesActorStat[] = actorRows.map((row) => {
		const agg = aggMap.get(row.id);
		const totalSales = toAmount(agg?.total_sales);
		const dailySales = toAmount(agg?.daily_sales);
		const monthlySales = toAmount(agg?.monthly_sales);
		const orderCount = agg?.order_count ?? 0;
		const monthlyMetrics = monthlyMetricMap.get(row.id);
		const monthlyOrderCount = monthlyMetrics?.monthly_order_count ?? 0;
		const monthlyDeliveredCount = monthlyMetrics?.monthly_delivered_count ?? 0;
		const monthlyReturnCount = monthlyMetrics?.monthly_return_count ?? 0;
		const monthlyOrderRate = monthlyOrderCount > 0 ? 1 / monthlyOrderCount : 0;

		return {
			id: row.id,
			name: row.name,
			email: row.email,
			role: row.role as SalesActorRole,
			orderCount,
			totalSales,
			dailySalesTarget: row.dailySalesTarget,
			monthlySalesTarget: row.monthlySalesTarget,
			monthlyDeliveredCount,
			monthlyDeliveredRate: monthlyDeliveredCount * monthlyOrderRate,
			monthlyReturnCount,
			monthlyReturnRate: monthlyReturnCount * monthlyOrderRate,
			dailyProgress:
				row.role === "admin"
					? null
					: computeProgress(dailySales, row.dailySalesTarget),
			monthlyProgress:
				row.role === "admin"
					? null
					: computeProgress(monthlySales, row.monthlySalesTarget),
		};
	});

	// Daily period stats.
	const dailyRows = await database.execute<{
		label: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT 
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD') as label,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label
		ORDER BY label
	`);
	const daily: PeriodStat[] = dailyRows.rows.map((r) => ({
		label: r.label,
		orders: r.orders,
		sales: toAmount(r.sales),
	}));

	// Monthly period stats.
	const monthlyRows = await database.execute<{
		label: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT 
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM') as label,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label
		ORDER BY label
	`);
	const monthly: PeriodStat[] = monthlyRows.rows.map((r) => ({
		label: r.label,
		orders: r.orders,
		sales: toAmount(r.sales),
	}));

	// Status stats.
	const dailyStatusRows = await database.execute<{
		label: string;
		status: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT 
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD') as label,
			${order.status} as status,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label, ${order.status}
		ORDER BY label, ${order.status}
	`);
	const monthlyStatusRows = await database.execute<{
		label: string;
		status: string;
		orders: number;
		sales: string;
	}>(sql`
		SELECT 
			TO_CHAR(${order.createdAt} AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM') as label,
			${order.status} as status,
			COUNT(*)::int as orders,
			COALESCE(SUM(${order.grandTotalAmount}::numeric) FILTER (WHERE ${saleCondition}), 0) as sales
		FROM ${order}
		WHERE ${actorWhere}
		GROUP BY label, ${order.status}
		ORDER BY label, ${order.status}
	`);
	const mapStatusRows = (
		rows: Array<{
			label: string;
			orders: number;
			sales: string;
			status: string;
		}>
	): StatusPeriodStat[] =>
		rows.map((row) => ({
			label: row.label,
			orders: row.orders,
			sales: toAmount(row.sales),
			status: row.status,
		}));
	const statuses = {
		daily: mapStatusRows(dailyStatusRows.rows),
		monthly: mapStatusRows(monthlyStatusRows.rows),
	};

	// Summary.
	const totalOrderCount = actors.reduce((sum, a) => sum + a.orderCount, 0);
	const totalSales = actors.reduce((sum, a) => sum + a.totalSales, 0);

	return {
		actors,
		periods: { daily, monthly },
		statuses,
		summary: {
			actorCount: actors.length,
			...(dailyTeamTarget === null
				? {}
				: { dailySalesTarget: dailyTeamTarget.toFixed(2) }),
			...(monthlyTeamTarget === null
				? {}
				: { monthlySalesTarget: monthlyTeamTarget.toFixed(2) }),
			orderCount: totalOrderCount,
			totalSales,
		},
		success: true,
	};
}

/**
 * List all branches with aggregate sales summary for super admin.
 */
export async function getBranchStatsList(
	database: typeof db,
	options: { from?: string; to?: string } = {}
): Promise<BranchSalesSummary[]> {
	const { fromUtc, toUtc } = parseIstDateRange(options.from, options.to);
	const saleCondition = sql`o.status IN (${sql.join(
		SALE_STATUSES.map((status) => sql`${status}`),
		sql`, `
	)})`;

	const rows = await database.execute<{
		admin_user_id: string;
		admin_name: string;
		manager_code: string;
		advisor_count: number;
		order_count: number;
		total_sales: string;
	}>(sql`
		WITH branch_users AS (
			SELECT
				umc.manager_code,
				u.id AS user_id,
				u.role
			FROM user_manager_code umc
			INNER JOIN "user" u ON u.id = umc.user_id
			WHERE u.role IN ('admin', 'advisor', 'team_leader')
		),
		branch_orders AS (
			SELECT
				bu.manager_code,
				COUNT(o.id)::int AS order_count,
				COALESCE(
					SUM(o.grand_total_amount::numeric) FILTER (WHERE ${saleCondition}),
					0
				) AS total_sales
			FROM branch_users bu
			LEFT JOIN "order" o
				ON o.created_by_user_id = bu.user_id
				AND o.created_at >= ${fromUtc}
				AND o.created_at <= ${toUtc}
			GROUP BY bu.manager_code
		)
		SELECT
			admin_user.id AS admin_user_id,
			admin_user.name AS admin_name,
			admin_code.manager_code,
			COUNT(advisor_user.user_id)::int AS advisor_count,
			COALESCE(branch_orders.order_count, 0)::int AS order_count,
			COALESCE(branch_orders.total_sales, 0) AS total_sales
		FROM user_manager_code admin_code
		INNER JOIN "user" admin_user
			ON admin_user.id = admin_code.user_id
			AND admin_user.role = 'admin'
		LEFT JOIN branch_users advisor_user
			ON advisor_user.manager_code = admin_code.manager_code
			AND advisor_user.role = 'advisor'
		LEFT JOIN branch_orders
			ON branch_orders.manager_code = admin_code.manager_code
		GROUP BY
			admin_user.id,
			admin_user.name,
			admin_code.manager_code,
			branch_orders.order_count,
			branch_orders.total_sales
		ORDER BY admin_code.manager_code
	`);

	return rows.rows.map((r) => ({
		adminUserId: r.admin_user_id,
		adminName: r.admin_name,
		managerCode: r.manager_code,
		advisorCount: r.advisor_count,
		orderCount: r.order_count,
		totalSales: toAmount(r.total_sales),
	}));
}

/**
 * Get detailed stats for a specific branch (super admin drilldown).
 */
export async function getBranchStatsDetail(
	database: typeof db,
	managerCode: string,
	options: GetManagerStatsOptions = {}
): Promise<BranchStatsDetailResponse | null> {
	// Find the admin for this branch.
	const [adminRow] = await database
		.select({ id: user.id, name: user.name })
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(
			and(eq(userManagerCode.managerCode, managerCode), eq(user.role, "admin"))
		)
		.limit(1);

	if (!adminRow) {
		return null;
	}

	// Count advisors.
	const [countRow] = await database
		.select({ count: sql<number>`COUNT(*)::int` })
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(
			and(
				eq(userManagerCode.managerCode, managerCode),
				eq(user.role, "advisor")
			)
		);

	// Get manager stats for this admin.
	const stats = await getManagerStats(database, adminRow.id, options);

	const branch: BranchSalesSummary = {
		adminUserId: adminRow.id,
		adminName: adminRow.name,
		managerCode,
		advisorCount: countRow?.count ?? 0,
		orderCount: stats.summary.orderCount,
		totalSales: stats.summary.totalSales,
	};

	return {
		branch,
		actors: stats.actors,
		periods: stats.periods,
		statuses: stats.statuses,
		summary: stats.summary,
		success: true,
	};
}

export async function getBranchTrendStats(
	database: typeof db,
	managerCode: string,
	options: GetManagerStatsOptions = {}
): Promise<ManagerStatsTrendsResponse | null> {
	const [adminRow] = await database
		.select({ id: user.id })
		.from(user)
		.innerJoin(userManagerCode, eq(userManagerCode.userId, user.id))
		.where(
			and(eq(userManagerCode.managerCode, managerCode), eq(user.role, "admin"))
		)
		.limit(1);

	if (!adminRow) {
		return null;
	}

	return getManagerTrendStats(database, adminRow.id, options);
}
