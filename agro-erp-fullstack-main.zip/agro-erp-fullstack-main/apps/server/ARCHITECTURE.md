# Server architecture

The server is organized by business feature under `src/modules`. Each module may
contain a route, service, repository, schema, and pure domain files as needed.
Do not create empty layers for a feature that does not need them.

## Dependency direction

```text
route -> service -> repository -> database
               -> domain
route -> auth
all layers -> shared (only for domain-neutral utilities)
```

Dependencies must only point to the right in this diagram. In particular,
repositories must not import Express code, services must not create HTTP
responses, and domain files must not access the database.

## Layer responsibilities

- `*.routes.ts`: Express routing, authentication, authorization, request parsing,
  validation, and HTTP response mapping.
- `*.service.ts`: business workflows, transaction boundaries, and coordination
  between repositories or external services.
- `*.repository.ts`: Drizzle queries and persistence mapping. Repositories do not
  make authorization or HTTP decisions.
- `*.schemas.ts`: request and input schemas shared by routes and services.
- Domain files: pure business invariants and state transitions.
- `src/auth`: application roles, capabilities, session loading, and access-scope
  policies.
- `src/shared`: small domain-neutral utilities used by unrelated modules.

The old `src/lib` directory is transitional. Do not add new feature logic to it.
Move feature-specific code into its owning module and move genuinely generic
code into `shared` or the relevant platform/auth folder.

## Migration status

The feature-first migration is in progress. Accounts, advisor tasks, advisor
analytics, advisor orders, branches, crops, farmers, and products have explicit
module boundaries. Imports, consignments, and exports have resource-owned route
modules backed by the existing application services.

Two large workflows still need repository extraction:

- `modules/inventory/inventory.routes.ts` still contains Drizzle queries and
  transaction workflows.
- `modules/orders/logistics-orders.controller.ts` has separated routing,
  schemas, and pure helpers, but still contains the verification/tracking
  queries and transactions.

When continuing the migration, split these by complete use case (query,
follow-up, status transition, approval, cancellation) and move each transaction
as a unit. Do not create controller or service facades that merely rename a
SQL-heavy route without moving persistence into a repository.

## API conventions

Public endpoints are resource-oriented and do not encode the caller's role:

- `/api/accounts`
- `/api/advisor-tasks`
- `/api/analytics`
- `/api/branches`
- `/api/consignments`
- `/api/crops`
- `/api/farmers`
- `/api/inventory`
- `/api/orders`
- `/api/products`

The same endpoint may be used by multiple roles. Capability checks decide
whether an action is allowed, while access-scope policies decide which records
are visible (own, team, branch, or global).

`senior_advisor` is not an application role. A senior advisor is stored as
`role: "advisor"` with an appropriate display title.

## Naming

Use current business language in new application code. Prefer `branchCode` over
`managerCode` in TypeScript APIs; the existing database column can be migrated
separately. Legacy database migrations remain immutable.

Avoid generic base repositories and top-level barrel files. Import the specific
module file that owns the behavior.
