"use client";

import { Toaster } from "@agro-erp-fullstack/ui/components/sonner";
import { TooltipProvider } from "@agro-erp-fullstack/ui/components/tooltip";

export default function Providers({ children }: { children: React.ReactNode }) {
	return (
		<TooltipProvider>
			{children}
			<Toaster richColors />
		</TooltipProvider>
	);
}
