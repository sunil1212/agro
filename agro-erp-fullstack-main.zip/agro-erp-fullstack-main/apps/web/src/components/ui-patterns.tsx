import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import { Skeleton } from "@agro-erp-fullstack/ui/components/skeleton";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import {
	AlertCircleIcon,
	ArrowLeftIcon,
	ArrowRightIcon,
	InboxIcon,
} from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import type { ReactNode } from "react";

type PageShellWidth = "default" | "wide" | "prose";

const pageShellWidths: Record<PageShellWidth, string> = {
	default: "max-w-6xl",
	wide: "max-w-[1680px]",
	prose: "max-w-xl",
};

export function PageShell({
	children,
	className,
	width = "default",
}: {
	children: ReactNode;
	className?: string;
	width?: PageShellWidth;
}) {
	return (
		<main
			className={cn(
				"mx-auto flex w-full flex-col gap-7 px-4 py-6 sm:px-6 sm:py-8 lg:px-8",
				pageShellWidths[width],
				className
			)}
		>
			{children}
		</main>
	);
}

export function PageHeader({
	actions,
	backHref,
	eyebrow,
	children,
	title,
}: {
	actions?: ReactNode;
	backHref?: Route;
	eyebrow?: ReactNode;
	children?: ReactNode;
	title: string;
}) {
	return (
		<header className="flex flex-col gap-4 border-border/60 pb-1 sm:flex-row sm:items-start sm:justify-between">
			<div className="min-w-0 space-y-2.5">
				{backHref ? (
					<Link
						className="inline-flex w-fit items-center gap-1.5 text-muted-foreground text-xs transition hover:text-foreground"
						href={backHref}
					>
						<ArrowLeftIcon className="size-3.5" />
						Back
					</Link>
				) : null}
				<div className="min-w-0 space-y-1">
					{eyebrow ? (
						<p className="font-medium text-muted-foreground text-sm leading-5">
							{eyebrow}
						</p>
					) : null}
					<h1 className="font-semibold text-2xl leading-tight tracking-tight sm:text-3xl">
						{title}
					</h1>
					{children ? (
						<div className="max-w-2xl text-muted-foreground text-sm leading-6">
							{children}
						</div>
					) : null}
				</div>
			</div>
			{actions ? (
				<div className="flex shrink-0 flex-wrap gap-2 sm:justify-end sm:self-center">
					{actions}
				</div>
			) : null}
		</header>
	);
}

export function SectionHeader({
	action,
	children,
	title,
}: {
	action?: ReactNode;
	children?: ReactNode;
	title: string;
}) {
	return (
		<div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
			<div className="space-y-1">
				<h2 className="font-semibold text-lg leading-tight">{title}</h2>
				{children ? (
					<p className="max-w-2xl text-muted-foreground text-sm leading-6">
						{children}
					</p>
				) : null}
			</div>
			{action}
		</div>
	);
}

export function Surface({
	children,
	className,
}: {
	children: ReactNode;
	className?: string;
}) {
	return (
		<section
			className={cn(
				"rounded-[2rem] border border-border/70 bg-card p-5 text-card-foreground shadow-sm ring-1 ring-foreground/5 sm:p-6",
				className
			)}
		>
			{children}
		</section>
	);
}

export function FieldGroup({
	children,
	description,
	label,
}: {
	children: ReactNode;
	description?: string;
	label: ReactNode;
}) {
	return (
		<div className="space-y-2">
			<div className="space-y-1">
				<p className="font-medium text-foreground text-sm">{label}</p>
				{description ? (
					<p className="text-muted-foreground text-xs leading-5">
						{description}
					</p>
				) : null}
			</div>
			{children}
		</div>
	);
}

export function MetricCard({
	label,
	trend,
	value,
}: {
	label: string;
	trend?: string;
	value: string;
}) {
	return (
		<div className="rounded-3xl border border-border/70 bg-card p-4 shadow-sm">
			<p className="font-medium text-muted-foreground text-xs uppercase tracking-[0.18em]">
				{label}
			</p>
			<p className="mt-2 font-semibold text-2xl leading-none">{value}</p>
			{trend ? (
				<p className="mt-2 text-muted-foreground text-xs">{trend}</p>
			) : null}
		</div>
	);
}

export function StatusPill({
	children,
	tone = "neutral",
}: {
	children: ReactNode;
	tone?: "neutral" | "success" | "warning" | "danger";
}) {
	return (
		<span
			className={cn(
				"inline-flex items-center rounded-full px-3 py-1 font-medium text-xs capitalize ring-1",
				tone === "neutral" && "bg-muted text-foreground ring-border/60",
				tone === "success" && "bg-primary/10 text-primary ring-primary/15",
				tone === "warning" &&
					"bg-amber-500/10 text-amber-700 ring-amber-500/20",
				tone === "danger" &&
					"bg-destructive/10 text-destructive ring-destructive/20"
			)}
		>
			{children}
		</span>
	);
}

export function EmptyState({
	actionHref,
	actionLabel,
	children,
	title,
}: {
	actionHref?: Route;
	actionLabel?: string;
	children: ReactNode;
	title: string;
}) {
	return (
		<div className="flex min-h-56 flex-col items-center justify-center rounded-3xl border border-border/70 border-dashed bg-muted/15 p-6 text-center">
			<div className="flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
				<InboxIcon className="size-6" />
			</div>
			<h2 className="mt-4 font-semibold text-xl">{title}</h2>
			<p className="mt-2 max-w-md text-muted-foreground text-sm leading-6">
				{children}
			</p>
			{actionHref && actionLabel ? (
				<Link
					className={cn(buttonVariants({ variant: "default" }), "mt-5 gap-2")}
					href={actionHref}
				>
					{actionLabel}
					<ArrowRightIcon className="size-4" />
				</Link>
			) : null}
		</div>
	);
}

export function LoadingState({ message }: { message: string }) {
	return (
		<div
			aria-busy="true"
			aria-label={message}
			className="space-y-5 rounded-3xl border border-border/60 bg-muted/20 p-5"
			role="status"
		>
			<div className="flex items-center gap-3">
				<Skeleton className="size-10 rounded-2xl" />
				<div className="space-y-2">
					<Skeleton className="h-4 w-44" />
					<Skeleton className="h-3 w-64 max-w-[62vw]" />
				</div>
			</div>
			<div className="grid gap-3">
				<Skeleton className="h-12 w-full rounded-2xl" />
				<Skeleton className="h-12 w-full rounded-2xl" />
				<Skeleton className="h-12 w-4/5 rounded-2xl" />
			</div>
		</div>
	);
}

export function PageSkeleton({
	rows = 4,
	showMetrics = true,
}: {
	rows?: number;
	showMetrics?: boolean;
}) {
	return (
		<PageShell width="wide">
			<div
				aria-busy="true"
				aria-label="Loading page"
				className="space-y-3"
				role="status"
			>
				<Skeleton className="h-8 w-72 max-w-[70vw]" />
				<Skeleton className="h-4 w-[32rem] max-w-full" />
			</div>
			{showMetrics ? (
				<section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
					{Array.from({ length: 4 }).map((_, index) => (
						<Skeleton
							className="h-28 rounded-3xl"
							key={`page-metric-skeleton-${index}`}
						/>
					))}
				</section>
			) : null}
			<Surface className="space-y-4">
				<div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
					<div className="space-y-2">
						<Skeleton className="h-5 w-48" />
						<Skeleton className="h-4 w-80 max-w-full" />
					</div>
					<Skeleton className="h-9 w-28 rounded-full" />
				</div>
				<div className="grid gap-3">
					{Array.from({ length: rows }).map((_, index) => (
						<Skeleton
							className="h-14 rounded-2xl"
							key={`page-row-skeleton-${index}`}
						/>
					))}
				</div>
			</Surface>
		</PageShell>
	);
}

export function ErrorState({
	message,
	title = "Something went wrong",
}: {
	message: string;
	title?: string;
}) {
	return (
		<Surface className="border-destructive/20 bg-destructive/5">
			<div className="flex gap-3">
				<div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
					<AlertCircleIcon className="size-5" />
				</div>
				<div className="min-w-0">
					<p className="font-medium text-destructive">{title}</p>
					<p className="mt-1 text-foreground/75 text-sm leading-6">{message}</p>
				</div>
			</div>
		</Surface>
	);
}
