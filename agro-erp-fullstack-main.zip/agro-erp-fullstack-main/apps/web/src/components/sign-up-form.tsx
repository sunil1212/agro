import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import { useForm } from "@tanstack/react-form";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { toast } from "sonner";
import z from "zod";
import { PageShell, Surface } from "@/components/ui-patterns";

import { authClient } from "@/lib/auth-client";

import Loader from "./loader";

const getRoleHomePath = (role: string) => {
	switch (role) {
		case "superadmin":
		case "admin":
		case "team_leader":
		case "advisor":
		case "warehouse":
			return "/dashboard";
		case "logistics":
			return "/orders/verification";
		default:
			return "/dashboard";
	}
};

export default function SignUpForm({
	onSwitchToSignIn,
}: {
	onSwitchToSignIn: () => void;
}) {
	const router = useRouter();
	const { data: session, isPending } = authClient.useSession();

	useEffect(() => {
		if (!(session?.user && "role" in session.user)) {
			return;
		}

		const role =
			typeof session.user.role === "string" ? session.user.role : null;
		if (!role) {
			return;
		}

		router.replace(getRoleHomePath(role));
	}, [router, session]);

	const form = useForm({
		defaultValues: {
			email: "",
			password: "",
			name: "",
		},
		onSubmit: async ({ value }) => {
			await authClient.signUp.email(
				{
					email: value.email,
					password: value.password,
					name: value.name,
				},
				{
					onSuccess: () => {
						toast.success("Sign up successful");
						router.replace("/dashboard");
						router.refresh();
					},
					onError: (error) => {
						toast.error(error.error.message || error.error.statusText);
					},
				}
			);
		},
		validators: {
			onSubmit: z.object({
				name: z.string().min(2, "Name must be at least 2 characters"),
				email: z.email("Invalid email address"),
				password: z.string().min(8, "Password must be at least 8 characters"),
			}),
		},
	});

	if (isPending) {
		return <Loader />;
	}

	return (
		<PageShell width="prose">
			<Surface className="space-y-6">
				<div className="space-y-2 text-center">
					<h1 className="font-semibold text-2xl leading-tight tracking-tight">
						Create account
					</h1>
					<p className="text-muted-foreground text-sm leading-6">
						Set up your Agro ERP access to continue.
					</p>
				</div>

				<form
					className="space-y-4"
					onSubmit={(e) => {
						e.preventDefault();
						e.stopPropagation();
						form.handleSubmit();
					}}
				>
					<div>
						<form.Field name="name">
							{(field) => (
								<div className="space-y-2">
									<Label htmlFor={field.name}>Name</Label>
									<Input
										id={field.name}
										name={field.name}
										onBlur={field.handleBlur}
										onChange={(e) => field.handleChange(e.target.value)}
										value={field.state.value}
									/>
									{field.state.meta.errors.map((error) => (
										<p
											className="text-destructive text-sm"
											key={error?.message}
										>
											{error?.message}
										</p>
									))}
								</div>
							)}
						</form.Field>
					</div>

					<div>
						<form.Field name="email">
							{(field) => (
								<div className="space-y-2">
									<Label htmlFor={field.name}>Email</Label>
									<Input
										id={field.name}
										name={field.name}
										onBlur={field.handleBlur}
										onChange={(e) => field.handleChange(e.target.value)}
										type="email"
										value={field.state.value}
									/>
									{field.state.meta.errors.map((error) => (
										<p
											className="text-destructive text-sm"
											key={error?.message}
										>
											{error?.message}
										</p>
									))}
								</div>
							)}
						</form.Field>
					</div>

					<div>
						<form.Field name="password">
							{(field) => (
								<div className="space-y-2">
									<Label htmlFor={field.name}>Password</Label>
									<Input
										id={field.name}
										name={field.name}
										onBlur={field.handleBlur}
										onChange={(e) => field.handleChange(e.target.value)}
										type="password"
										value={field.state.value}
									/>
									{field.state.meta.errors.map((error) => (
										<p
											className="text-destructive text-sm"
											key={error?.message}
										>
											{error?.message}
										</p>
									))}
								</div>
							)}
						</form.Field>
					</div>

					<form.Subscribe
						selector={(state) => ({
							canSubmit: state.canSubmit,
							isSubmitting: state.isSubmitting,
						})}
					>
						{({ canSubmit, isSubmitting }) => (
							<Button
								className="w-full"
								disabled={!canSubmit || isSubmitting}
								type="submit"
							>
								{isSubmitting ? "Submitting..." : "Sign up"}
							</Button>
						)}
					</form.Subscribe>
				</form>

				<div className="text-center">
					<Button
						className="text-primary hover:text-primary/80"
						onClick={onSwitchToSignIn}
						variant="link"
					>
						Already have an account? Sign in
					</Button>
				</div>
			</Surface>
		</PageShell>
	);
}
