import {
	Button,
	buttonVariants,
} from "@agro-erp-fullstack/ui/components/button";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuGroup,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from "@agro-erp-fullstack/ui/components/dropdown-menu";
import { Skeleton } from "@agro-erp-fullstack/ui/components/skeleton";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

import { authClient } from "@/lib/auth-client";

export default function UserMenu() {
	const router = useRouter();
	const { data: session, isPending } = authClient.useSession();
	const [isMounted, setIsMounted] = useState(false);

	useEffect(() => {
		setIsMounted(true);
	}, []);

	if (!(isMounted && !isPending)) {
		return <Skeleton className="h-9 w-24" />;
	}

	if (!session) {
		return (
			<Link
				className={cn(buttonVariants({ variant: "outline" }))}
				href="/login"
			>
				Sign In
			</Link>
		);
	}

	const user = session.user as typeof session.user & {
		title?: string;
	};

	return (
		<DropdownMenu>
			<DropdownMenuTrigger render={<Button variant="outline" />}>
				{user.name}
			</DropdownMenuTrigger>
			<DropdownMenuContent align="center" className="min-w-72 bg-card">
				<DropdownMenuGroup>
					<DropdownMenuLabel>My Account</DropdownMenuLabel>
					<DropdownMenuSeparator />
					<DropdownMenuItem
						className="truncate"
						title={user.email ?? undefined}
					>
						{user.email}
					</DropdownMenuItem>
					<DropdownMenuItem>{user.title ?? "No title set"}</DropdownMenuItem>
					<DropdownMenuItem
						onClick={() => {
							authClient.signOut({
								fetchOptions: {
									onSuccess: () => {
										router.push("/");
									},
								},
							});
						}}
						variant="destructive"
					>
						Sign Out
					</DropdownMenuItem>
				</DropdownMenuGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}
