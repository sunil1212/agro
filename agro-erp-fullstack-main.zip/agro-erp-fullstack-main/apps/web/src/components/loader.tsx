import { PageSkeleton } from "@/components/ui-patterns";

export default function Loader() {
	return <PageSkeleton rows={3} showMetrics={false} />;
}
