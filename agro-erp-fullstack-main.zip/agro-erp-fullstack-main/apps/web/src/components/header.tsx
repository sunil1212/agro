"use client";

import {
	NavigationMenu,
	NavigationMenuContent,
	NavigationMenuItem,
	NavigationMenuLink,
	NavigationMenuList,
	NavigationMenuTrigger,
} from "@agro-erp-fullstack/ui/components/navigation-menu";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { SproutIcon } from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import { usePathname } from "next/navigation";

import { authClient } from "@/lib/auth-client";

import UserMenu from "./user-menu";

const getUserRole = (
	session: ReturnType<typeof authClient.useSession>["data"]
) => {
	if (!(session?.user && "role" in session.user)) {
		return null;
	}

	return typeof session.user.role === "string" ? session.user.role : null;
};

interface HeaderNavItem {
	children?: ReadonlyArray<{ label: string; to: Route }>;
	label: string;
	to?: Route;
}

const exactMatchRoutes = new Set<Route>(["/orders" as Route]);

const isRouteActive = (pathname: string, to: Route) =>
	pathname === to ||
	(!(exactMatchRoutes.has(to) || to === "/") && pathname.startsWith(`${to}/`));

export default function Header() {
	const pathname = usePathname();
	const { data: session } = authClient.useSession();
	const userRole = getUserRole(session);

	const baseLinks: readonly HeaderNavItem[] = [
		// { to: "/", label: "Home" },
		{ to: "/dashboard", label: "Dashboard" },
		// { to: "/scratchpad", label: "Scratchpad" },
	];
	const adminBranchLinks: readonly HeaderNavItem[] = [
		{ to: "/accounts", label: "Accounts" },
		{ to: "/stats", label: "Stats" },
		{ to: "/farmers", label: "Farmers" },
		{
			children: [
				{ to: "/orders", label: "Order list" },
				{ to: "/orders/verification", label: "Logistics" },
				{ to: "/orders/tracking" as Route, label: "Tracking" },
			],
			label: "Orders",
		},
		{ to: "/tasks", label: "Tasks" },
		{
			children: [
				{ to: "/migration/advisor" as Route, label: "Advisor import" },
				{ to: "/migration/farmer" as Route, label: "Farmer import" },
				{ to: "/migration/orders" as Route, label: "Order import" },
			],
			label: "Migration",
		},
	];
	const adminLinks: readonly HeaderNavItem[] = [
		{ to: "/accounts", label: "Accounts" },
		{ to: "/products", label: "Products" },
		{ to: "/crops", label: "Crops" },
		{ to: "/inventory", label: "Inventory" },
		{ to: "/consignments" as Route, label: "Consignment" },
		{ to: "/migration/products" as Route, label: "Migration" },
	];
	const warehouseLinks: readonly HeaderNavItem[] = [
		{ to: "/inventory/dispatch", label: "Orders" },
		{ to: "/inventory", label: "Inventory" },
	];
	const logisticsLinks: readonly HeaderNavItem[] = [
		{ to: "/orders/verification", label: "Logistics" },
		{ to: "/orders/tracking" as Route, label: "Tracking" },
	];
	const advisorLinks: readonly HeaderNavItem[] = [
		{
			children: [
				{ to: "/farmers", label: "Farmers" },
				{ to: "/farmers/directory" as Route, label: "Global farmer directory" },
			],
			label: "Farmers",
		},
		{ to: "/orders", label: "Orders" },
		{ to: "/tasks", label: "Tasks" },
		{ to: "/crops", label: "Crops" },
	];
	const teamLeaderLinks: readonly HeaderNavItem[] = [
		{ to: "/accounts", label: "Advisors" },
		{ to: "/stats", label: "Stats" },
		{
			children: [
				{ to: "/farmers", label: "Farmers" },
				{ to: "/farmers/directory" as Route, label: "Global farmer directory" },
			],
			label: "Farmers",
		},
		{
			children: [
				{ to: "/orders", label: "My orders" },
				{ to: "/orders/advisors" as Route, label: "Advisor orders" },
			],
			label: "Orders",
		},
		{ to: "/tasks", label: "Tasks" },
		{ to: "/crops", label: "Crops" },
	];

	let roleLinks: readonly HeaderNavItem[] = [];

	if (userRole === "superadmin") {
		roleLinks = adminLinks;
	} else if (userRole === "admin") {
		roleLinks = adminBranchLinks;
	} else if (userRole === "warehouse") {
		roleLinks = warehouseLinks;
	} else if (userRole === "logistics") {
		roleLinks = logisticsLinks;
	} else if (userRole === "team_leader") {
		roleLinks = teamLeaderLinks;
	} else if (userRole === "advisor") {
		roleLinks = advisorLinks;
	}

	const links = [...baseLinks, ...roleLinks];

	return (
		<header
			className="sticky top-0 z-40 border-border/70 border-b bg-background/85 backdrop-blur-xl"
			data-view-transition="persistent-nav"
		>
			<div className="mx-auto flex min-h-16 w-full max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
				<Link
					className="flex shrink-0 items-center gap-2 font-semibold text-sm tracking-tight"
					href="/"
				>
					<span className="flex size-9 items-center justify-center rounded-2xl bg-primary/10 text-primary ring-1 ring-primary/15">
						<SproutIcon className="size-5" />
					</span>
					<span className="hidden sm:inline">Growmize Pvt Ltd</span>
				</Link>
				<nav aria-label="Primary navigation" className="min-w-0 flex-1">
					<NavigationMenu className="max-w-full justify-start">
						<NavigationMenuList className="justify-start overflow-x-auto py-3">
							{links.map((item) => {
								const childActive = item.children?.some((child) =>
									isRouteActive(pathname, child.to)
								);
								const itemActive = item.to
									? isRouteActive(pathname, item.to)
									: Boolean(childActive);

								if (item.children) {
									return (
										<NavigationMenuItem key={item.label}>
											<NavigationMenuTrigger
												className={cn(
													"shrink-0 text-muted-foreground",
													itemActive &&
														"bg-card font-medium text-foreground shadow-sm ring-1 ring-border/70"
												)}
											>
												{item.label}
											</NavigationMenuTrigger>
											<NavigationMenuContent>
												<div className="grid w-64 gap-1">
													{item.children.map((child) => {
														const isActive = isRouteActive(pathname, child.to);

														return (
															<NavigationMenuLink
																active={isActive}
																className={cn(
																	"flex-col items-start gap-1 text-muted-foreground",
																	isActive && "font-medium text-foreground"
																)}
																closeOnClick
																key={child.to}
																render={<Link href={child.to} />}
															>
																<span>{child.label}</span>
															</NavigationMenuLink>
														);
													})}
												</div>
											</NavigationMenuContent>
										</NavigationMenuItem>
									);
								}

								if (!item.to) {
									return null;
								}

								return (
									<NavigationMenuItem key={item.to}>
										<NavigationMenuLink
											active={itemActive}
											className={cn(
												"shrink-0 text-muted-foreground",
												itemActive &&
													"bg-card font-medium text-foreground shadow-sm ring-1 ring-border/70"
											)}
											closeOnClick
											render={<Link href={item.to} />}
										>
											{item.label}
										</NavigationMenuLink>
									</NavigationMenuItem>
								);
							})}
						</NavigationMenuList>
					</NavigationMenu>
				</nav>
				<div className="flex shrink-0 items-center gap-2">
					<UserMenu />
				</div>
			</div>
		</header>
	);
}
