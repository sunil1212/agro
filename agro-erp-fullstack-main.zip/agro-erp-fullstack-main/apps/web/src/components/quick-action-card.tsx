import { Card, CardContent } from "@agro-erp-fullstack/ui/components/card";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ArrowRight } from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import type { ReactNode } from "react";

const quickActionCardSizes = {
	lg: {
		card: "min-h-[8.5rem]",
		content: "p-4 sm:p-5",
		icon: "size-11 rounded-2xl",
		title: "text-xl",
	},
	md: {
		card: "min-h-[8rem]",
		content: "p-4",
		icon: "size-10 rounded-xl",
		title: "text-lg",
	},
	sm: {
		card: "min-h-[7rem]",
		content: "p-4",
		icon: "size-9 rounded-xl",
		title: "text-lg",
	},
} as const;

const quickActionCardTones = {
	solid: {
		card: "bg-card",
		icon: "bg-primary/10 text-primary ring-primary/10",
		label: "text-muted-foreground",
	},
	soft: {
		card: "bg-muted/45",
		icon: "bg-card text-foreground ring-border/70",
		label: "text-foreground/70",
	},
} as const;

type QuickActionCardSize = keyof typeof quickActionCardSizes;
type QuickActionCardTone = keyof typeof quickActionCardTones;
type QuickActionCardVariant = "tile" | "banner";
type QuickActionCardHeadingLevel = "h2" | "h3";

export function QuickActionCard({
	actionLabel = "Open",
	className,
	description,
	headingLevel = "h2",
	href,
	icon,
	label,
	meta,
	size = "lg",
	title,
	tone = "solid",
	variant = "tile",
}: {
	actionLabel?: string;
	className?: string;
	description: string;
	headingLevel?: QuickActionCardHeadingLevel;
	href: Route;
	icon?: ReactNode;
	label?: string;
	meta?: ReactNode;
	size?: QuickActionCardSize;
	title: string;
	tone?: QuickActionCardTone;
	variant?: QuickActionCardVariant;
}) {
	const HeadingTag = headingLevel;

	if (variant === "banner") {
		return (
			<Link
				aria-label={`${actionLabel}: ${title}`}
				className={cn("group block rounded-[1.75rem] outline-none", className)}
				href={href}
			>
				<Card
					className={cn(
						"h-fit overflow-hidden rounded-[1.75rem] border border-border/70 py-0 shadow-sm transition duration-200 group-hover:-translate-y-0.5 group-hover:border-border group-focus-visible:border-ring group-focus-visible:ring-3 group-focus-visible:ring-ring/30 motion-reduce:transition-none motion-reduce:group-hover:translate-y-0",
						quickActionCardTones[tone].card
					)}
				>
					<CardContent className="relative flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
						<div className="relative min-w-0 space-y-1.5">
							<HeadingTag className="font-semibold text-base tracking-normal">
								{title}
							</HeadingTag>
							<p className="max-w-2xl text-muted-foreground text-sm leading-6">
								{description}
							</p>
							{meta ? (
								<p className="text-foreground/70 text-xs leading-5">{meta}</p>
							) : null}
						</div>
						<ActionCue actionLabel={actionLabel} />
					</CardContent>
				</Card>
			</Link>
		);
	}

	const sizeClasses = quickActionCardSizes[size] ?? quickActionCardSizes.lg;
	const toneClasses = quickActionCardTones[tone] ?? quickActionCardTones.solid;

	return (
		<Link
			aria-label={`${actionLabel}: ${title}`}
			className={cn("group block rounded-[1.5rem] outline-none", className)}
			href={href}
		>
			<Card
				className={cn(
					"overflow-hidden rounded-[1.5rem] border border-border/70 py-0 shadow-sm transition duration-200 group-hover:-translate-y-0.5 group-hover:border-border group-hover:shadow-sm group-focus-visible:border-ring group-focus-visible:ring-3 group-focus-visible:ring-ring/30 motion-reduce:transition-none motion-reduce:group-hover:translate-y-0",
					toneClasses.card,
					sizeClasses.card
				)}
			>
				<CardContent
					className={cn("relative flex items-start gap-4", sizeClasses.content)}
				>
					{icon ? (
						<div
							className={cn(
								"mt-0.5 flex shrink-0 items-center justify-center ring-1",
								toneClasses.icon,
								sizeClasses.icon
							)}
						>
							{icon}
						</div>
					) : null}
					<div className="relative flex min-w-0 flex-1 flex-col gap-3">
						<div className="min-w-0 space-y-1.5">
							{label ? (
								<p
									className={cn(
										"min-w-0 truncate font-medium text-xs",
										toneClasses.label
									)}
								>
									{label}
								</p>
							) : null}
							<HeadingTag
								className={cn(
									"font-semibold leading-tight tracking-normal",
									sizeClasses.title
								)}
							>
								{title}
							</HeadingTag>
							<p className="max-w-sm text-muted-foreground text-sm leading-5">
								{description}
							</p>
							{meta ? (
								<p className="text-foreground/70 text-xs leading-5">{meta}</p>
							) : null}
						</div>
					</div>
					<ActionCue actionLabel={actionLabel} />
				</CardContent>
			</Card>
		</Link>
	);
}

function ActionCue({ actionLabel }: { actionLabel: string }) {
	return (
		<span className="inline-flex w-fit shrink-0 items-center gap-1.5 font-medium text-primary text-sm transition-colors group-hover:text-primary/80">
			{actionLabel}
			<ArrowRight className="size-4 transition-transform duration-200 group-hover:translate-x-0.5 motion-reduce:transition-none motion-reduce:group-hover:translate-x-0" />
		</span>
	);
}
