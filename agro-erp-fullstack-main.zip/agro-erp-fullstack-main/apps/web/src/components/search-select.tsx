"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Popover,
	PopoverContent,
	PopoverTrigger,
} from "@agro-erp-fullstack/ui/components/popover";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { LiteDebouncer } from "@tanstack/pacer-lite/lite-debouncer";
import { CheckIcon, ChevronDownIcon, SearchIcon } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface SearchSelectProps<TItem> {
	emptyMessage: string;
	getItemDescription?: (item: TItem) => string | null;
	getItemId: (item: TItem) => string;
	getItemKeywords?: (item: TItem) => string;
	getItemLabel: (item: TItem) => string;
	items: TItem[];
	label: string;
	onValueChange: (item: TItem) => void;
	placeholder: string;
	renderItem?: (item: TItem, isSelected: boolean) => React.ReactNode;
	renderValue?: (item: TItem) => React.ReactNode;
	searchPlaceholder: string;
	value: TItem | null;
}

export function SearchSelect<TItem>({
	emptyMessage,
	getItemDescription,
	getItemId,
	getItemKeywords,
	getItemLabel,
	items,
	label,
	onValueChange,
	placeholder,
	renderItem,
	renderValue,
	searchPlaceholder,
	value,
}: SearchSelectProps<TItem>) {
	const [isOpen, setIsOpen] = useState(false);
	const [query, setQuery] = useState("");
	const [debouncedQuery, setDebouncedQuery] = useState("");
	const debouncerRef = useRef<LiteDebouncer<
		(nextValue: string) => void
	> | null>(null);

	if (!debouncerRef.current) {
		debouncerRef.current = new LiteDebouncer(
			(nextValue: string) => setDebouncedQuery(nextValue),
			{ wait: 180 }
		);
	}

	useEffect(
		() => () => {
			debouncerRef.current?.cancel();
		},
		[]
	);

	const normalizedQuery = debouncedQuery.trim().toLowerCase();
	const filteredItems = items.filter((item) => {
		if (!normalizedQuery) {
			return true;
		}

		const keywords = getItemKeywords?.(item) ?? "";
		const haystack = `${getItemLabel(item)} ${getItemDescription?.(item) ?? ""} ${keywords}`;
		return haystack.toLowerCase().includes(normalizedQuery);
	});
	const selectedValue = value ? (renderValue?.(value) ?? null) : null;

	return (
		<div className="grid gap-2">
			<span className="font-medium text-sm">{label}</span>
			<Popover onOpenChange={setIsOpen} open={isOpen}>
				<PopoverTrigger
					render={
						<Button
							className="w-full justify-between rounded-3xl px-4 py-3"
							variant="outline"
						/>
					}
				>
					<div className="flex w-full items-center justify-between gap-3">
						<div className="min-w-0 text-left">
							{selectedValue ??
								(value ? (
									<>
										<div className="truncate text-sm">
											{getItemLabel(value)}
										</div>
										{getItemDescription ? (
											<div className="truncate text-muted-foreground text-xs">
												{getItemDescription(value)}
											</div>
										) : null}
									</>
								) : (
									<div className="truncate text-muted-foreground text-sm">
										{placeholder}
									</div>
								))}
						</div>
						<ChevronDownIcon className="size-4 text-muted-foreground" />
					</div>
				</PopoverTrigger>
				<PopoverContent
					align="start"
					className="w-[var(--anchor-width)] gap-3 p-4"
				>
					<div className="relative">
						<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
						<Input
							className="pl-9"
							onChange={(event) => {
								const nextValue = event.target.value;
								setQuery(nextValue);
								debouncerRef.current?.maybeExecute(nextValue);
							}}
							placeholder={searchPlaceholder}
							value={query}
						/>
					</div>
					<div className="max-h-72 overflow-y-auto">
						{filteredItems.length === 0 ? (
							<div className="rounded-3xl border border-dashed px-4 py-6 text-center text-muted-foreground text-sm">
								{emptyMessage}
							</div>
						) : (
							<div className="space-y-1.5">
								{filteredItems.map((item) => {
									const itemId = getItemId(item);
									const isSelected = value
										? getItemId(value) === itemId
										: false;

									return (
										<button
											className={cn(
												"flex w-full items-start gap-3 rounded-3xl border border-transparent px-4 py-4 text-left transition hover:border-border hover:bg-muted/60",
												isSelected && "border-border bg-muted/70"
											)}
											key={itemId}
											onClick={() => {
												onValueChange(item);
												setIsOpen(false);
												setQuery("");
												setDebouncedQuery("");
											}}
											type="button"
										>
											<div className="min-w-0 flex-1">
												{renderItem ? (
													renderItem(item, isSelected)
												) : (
													<>
														<div className="font-medium text-sm">
															{getItemLabel(item)}
														</div>
														{getItemDescription ? (
															<div className="mt-1 text-muted-foreground text-xs">
																{getItemDescription(item)}
															</div>
														) : null}
													</>
												)}
											</div>
											{isSelected ? (
												<CheckIcon className="mt-0.5 size-4 shrink-0 text-primary" />
											) : null}
										</button>
									);
								})}
							</div>
						)}
					</div>
				</PopoverContent>
			</Popover>
		</div>
	);
}
