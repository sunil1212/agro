import {
	ManagerStatsClient,
	type ManagerStatsResponse,
} from "@/features/manager/stats/stats-client";
import { fetchServerApi } from "@/lib/api-server";

export const dynamic = "force-dynamic";

type DatePreset = "today" | "this-month" | "last-30" | "last-90";

const IST_TIME_ZONE = "Asia/Kolkata";

function formatDateInIst(date: Date): string {
	const parts = new Intl.DateTimeFormat("en-CA", {
		day: "2-digit",
		month: "2-digit",
		timeZone: IST_TIME_ZONE,
		year: "numeric",
	}).formatToParts(date);
	const values = Object.fromEntries(
		parts.map((part) => [part.type, part.value])
	);

	return `${values.year}-${values.month}-${values.day}`;
}

function getPresetRange(preset: DatePreset): { from: string; to: string } {
	const now = new Date();
	const today = formatDateInIst(now);

	switch (preset) {
		case "today":
			return { from: today, to: today };
		case "this-month": {
			const monthStart = `${today.slice(0, 7)}-01`;
			return { from: monthStart, to: today };
		}
		case "last-30": {
			const twentyNineDaysAgo = new Date(
				now.getTime() - 29 * 24 * 60 * 60 * 1000
			);
			return { from: formatDateInIst(twentyNineDaysAgo), to: today };
		}
		case "last-90": {
			const eightyNineDaysAgo = new Date(
				now.getTime() - 89 * 24 * 60 * 60 * 1000
			);
			return { from: formatDateInIst(eightyNineDaysAgo), to: today };
		}
		default:
			return { from: today, to: today };
	}
}

export default async function BranchStatsDetailPage({
	params,
	searchParams,
}: {
	params: Promise<{ managerCode: string }>;
	searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
	const { managerCode } = await params;
	const sp = await searchParams;

	const preset = (sp.preset as DatePreset | undefined) ?? "this-month";
	const from = (sp.from as string | undefined) ?? getPresetRange(preset).from;
	const to = (sp.to as string | undefined) ?? getPresetRange(preset).to;
	const actorId = sp.actorId as string | undefined;
	const status = sp.status as string | undefined;

	const query = new URLSearchParams();
	query.set("from", from);
	query.set("to", to);
	if (actorId) {
		query.set("actorId", actorId);
	}
	if (status) {
		query.set("status", status);
	}

	const qs = query.toString();
	const data = await fetchServerApi<ManagerStatsResponse>(
		"analytics",
		`/branch-stats/${managerCode}${qs ? `?${qs}` : ""}`
	);

	return (
		<ManagerStatsClient
			contextLabel={`Super Admin · ${managerCode}`}
			data={data}
			filterPath={`/admin/branch-stats/${encodeURIComponent(managerCode)}`}
			trendApiPath={`/branch-stats/${encodeURIComponent(managerCode)}/trends`}
		/>
	);
}
