import { EditProductForm } from "@/features/manager/products/edit/product-edit-form";
import { fetchServerApi } from "@/lib/api-server";

export const dynamic = "force-dynamic";

interface EditProductPageProps {
	params: Promise<{
		productId: string;
	}>;
}

interface EditableProductResponse {
	additionalNotes: null | string;
	categoryCode: null | string;
	id: string;
	isActive: boolean;
	name: string;
	productCode: null | string;
	variants: Array<{
		additionalNotes: null | string;
		costPerUnit: string;
		discount: string;
		id: string;
		isActive: boolean;
		offerPrice: string;
		packageQuantity: null | string;
		packageUnit: null | string;
		packagingType: null | string;
		packingCode: null | string;
		quantity: number;
		skuCode: null | string;
	}>;
}

export default async function EditProductPage({
	params,
}: EditProductPageProps) {
	const { productId } = await params;
	const { product } = await fetchServerApi<{
		product: EditableProductResponse;
		success: true;
	}>("products", `/${productId}`);

	if (product.variants.length === 0) {
		throw new Error("Product has no variants");
	}
	const editableVariants = product.isActive
		? product.variants.filter((variant) => variant.isActive)
		: product.variants;

	if (editableVariants.length === 0) {
		throw new Error("Product has no active variants");
	}

	return (
		<EditProductForm
			product={{
				additionalNotes: product.additionalNotes ?? "",
				categoryCode: product.categoryCode ?? "",
				id: product.id,
				isActive: product.isActive,
				name: product.name,
				productCode: product.productCode ?? "",
				variants: editableVariants.map((variant) => ({
					additionalNotes: variant.additionalNotes ?? "",
					costPerUnit: Number(variant.costPerUnit),
					discount: Number(variant.discount),
					id: variant.id,
					isActive: variant.isActive,
					offerPrice: Number(variant.offerPrice),
					packageQuantity: Number(variant.packageQuantity ?? 1),
					packageUnit: variant.packageUnit ?? "ML",
					packagingType: variant.packagingType ?? "BOTTLE",
					packingCode: variant.packingCode ?? "",
					quantity: variant.quantity,
					skuCode: variant.skuCode ?? "",
				})),
			}}
		/>
	);
}
