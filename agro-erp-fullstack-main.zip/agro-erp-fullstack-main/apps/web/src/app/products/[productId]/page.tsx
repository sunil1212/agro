interface ProductDetailsPageProps {
	params: Promise<{
		productId: string;
	}>;
}

export default async function ProductDetailsPage({
	params,
}: ProductDetailsPageProps) {
	const { productId } = await params;

	return <div>Product details: {productId}</div>;
}
