export { default } from "@/features/manager/products/create/create-product-page";
