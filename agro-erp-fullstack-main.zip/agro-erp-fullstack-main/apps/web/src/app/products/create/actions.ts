"use client";

import { getClientApiUrl } from "@/lib/api-client";

export interface CreateProductInput {
	additionalNotes: string;
	categoryCode: string;
	costPerUnit: number;
	discount: number;
	name: string;
	offerPrice: number;
	packageQuantity: number;
	packageUnit: string;
	packagingType: string;
	packingCode: string;
	productCode: string;
	quantity: number;
	skuCode: string;
	variants?: ProductVariantInput[];
}

export interface ProductVariantInput {
	additionalNotes?: string;
	costPerUnit: number;
	discount: number;
	id?: string;
	isActive?: boolean;
	offerPrice: number;
	packageQuantity: number;
	packageUnit: string;
	packagingType: string;
	packingCode: string;
	quantity: number;
	skuCode: string;
}

export type UpdateProductInput = Omit<CreateProductInput, "quantity"> & {
	id?: string;
	isActive?: boolean;
	quantity?: number;
};

export interface ManagedProductResponse {
	additionalNotes: null | string;
	categoryCode: null | string;
	id: string;
	isActive: boolean;
	name: string;
	productCode: null | string;
	variants: Array<{
		additionalNotes: null | string;
		costPerUnit: string;
		discount: string;
		id: string;
		isActive: boolean;
		offerPrice: string;
		packageQuantity: null | string;
		packageUnit: null | string;
		packagingType: null | string;
		packingCode: null | string;
		quantity: number;
		skuCode: null | string;
	}>;
}

export type CreateProductResult =
	| {
			success: true;
			product: ManagedProductResponse;
	  }
	| {
			success: false;
			message: string;
	  };

export type UpdateProductResult = CreateProductResult;

export async function createManagedProduct(
	input: CreateProductInput
): Promise<CreateProductResult> {
	const response = await fetch(getClientApiUrl("products"), {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		credentials: "include",
		body: JSON.stringify(input),
	});

	return (await response.json()) as CreateProductResult;
}

export async function updateManagedProduct(
	productId: string,
	input: UpdateProductInput
): Promise<UpdateProductResult> {
	const response = await fetch(getClientApiUrl("products", `/${productId}`), {
		method: "PATCH",
		headers: {
			"Content-Type": "application/json",
		},
		credentials: "include",
		body: JSON.stringify(input),
	});

	return (await response.json()) as UpdateProductResult;
}
