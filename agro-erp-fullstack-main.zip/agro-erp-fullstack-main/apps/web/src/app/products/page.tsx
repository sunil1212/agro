import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ArrowRightIcon } from "lucide-react";
import type { Route } from "next";
import { headers } from "next/headers";
import Link from "next/link";

import {
	EmptyState,
	MetricCard,
	PageHeader,
	PageShell,
	Surface,
} from "@/components/ui-patterns";
import {
	type ManagedProduct,
	ProductsTable,
} from "@/features/manager/products/products-table";
import { fetchServerApi } from "@/lib/api-server";
import { authClient } from "@/lib/auth-client";

export const dynamic = "force-dynamic";

const currencyFormatter = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2,
});

export default async function ProductsPage() {
	const requestHeaders = await headers();
	const session = await authClient.getSession({
		fetchOptions: {
			headers: { cookie: requestHeaders.get("cookie") ?? "" },
			throw: true,
		},
	});
	const userRole =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: null;
	const isWarehouse = userRole === "warehouse";
	const canCreateProducts = userRole === "superadmin";

	const { products } = await fetchServerApi<{
		products: ManagedProduct[];
		success: true;
	}>("products");

	const totalStockUnits = products.reduce(
		(sum, product) =>
			sum +
			product.variants.reduce(
				(variantSum, variant) => variantSum + variant.quantity,
				0
			),
		0
	);
	const totalStockValue = products.reduce(
		(sum, product) =>
			sum +
			product.variants.reduce(
				(variantSum, variant) =>
					variantSum + variant.quantity * Number(variant.offerPrice),
				0
			),
		0
	);
	const totalCategories = new Set(
		products
			.map((product) => product.categoryCode?.trim())
			.filter((value): value is string => Boolean(value))
	).size;

	return (
		<PageShell width="wide">
			<PageHeader
				actions={
					<div className="flex flex-wrap items-center gap-2">
						{isWarehouse ? (
							<Link
								className={cn(buttonVariants({ variant: "outline" }), "gap-2")}
								href={"/inventory/grn" as Route}
							>
								Update inventory
								<ArrowRightIcon className="size-4" />
							</Link>
						) : null}
						{canCreateProducts ? (
							<Link
								className={cn(buttonVariants({ variant: "default" }), "gap-2")}
								href="/products/create"
							>
								Create product
								<ArrowRightIcon className="size-4" />
							</Link>
						) : null}
					</div>
				}
				eyebrow={isWarehouse ? "Warehouse" : "Manager"}
				title="Products"
			>
				<p>Manage products, pricing, and finished-goods stock.</p>
			</PageHeader>

			<section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
				<MetricCard
					label="Products"
					trend="Catalog rows"
					value={String(products.length)}
				/>
				<MetricCard
					label="Categories"
					trend="Active code groups"
					value={String(totalCategories)}
				/>
				<MetricCard
					label="Stock"
					trend="Current finished units"
					value={String(totalStockUnits)}
				/>
				<MetricCard
					label="Stock value"
					trend="Selling price basis"
					value={currencyFormatter.format(totalStockValue)}
				/>
			</section>

			<Surface className="space-y-5 overflow-hidden">
				{products.length > 0 ? (
					<ProductsTable products={products} />
				) : (
					<EmptyState
						actionHref={canCreateProducts ? "/products/create" : undefined}
						actionLabel={canCreateProducts ? "Create product" : undefined}
						title="No products yet"
					>
						Create the first catalog row so advisors and warehouse flows can use
						a shared finished-goods master.
					</EmptyState>
				)}
			</Surface>
		</PageShell>
	);
}
