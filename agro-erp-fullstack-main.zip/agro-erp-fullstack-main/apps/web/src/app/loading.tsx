import { PageSkeleton } from "@/components/ui-patterns";

export default function Loading() {
	return <PageSkeleton />;
}
