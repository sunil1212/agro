import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import Link from "next/link";
import { PageHeader, PageShell } from "@/components/ui-patterns";
import { FarmerDetailsClient } from "@/features/advisor/farmers/details/farmer-details-client";
import type { FarmerDetailsResponse } from "@/features/advisor/farmers/details/farmer-details-types";
import { fetchServerApi } from "@/lib/api-server";

interface FarmerDetailsPageProps {
	params: Promise<{
		farmerId: string;
	}>;
}

export default async function FarmerDetailsPage({
	params,
}: FarmerDetailsPageProps) {
	const { farmerId } = await params;
	const data = await fetchServerApi<FarmerDetailsResponse>(
		"farmers",
		`/${farmerId}`
	);

	return (
		<PageShell>
			<PageHeader
				actions={
					<Link
						className={cn(
							buttonVariants({ variant: "default" }),
							"rounded-3xl"
						)}
						href={`/orders/create?farmerId=${farmerId}`}
					>
						Create order
					</Link>
				}
				title={data.farmer.name}
			>
				{data.farmer.canViewPhoneNumber
					? data.farmer.primaryMobileNumber
					: "Phone number is only visible to the onboarding advisor"}
			</PageHeader>

			<FarmerDetailsClient data={data} farmerId={farmerId} />
		</PageShell>
	);
}
