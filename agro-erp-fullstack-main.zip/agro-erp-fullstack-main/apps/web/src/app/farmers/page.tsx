import type { Route } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { QuickActionCard } from "@/components/quick-action-card";
import { EmptyState, PageShell, SectionHeader } from "@/components/ui-patterns";
import {
	type AdvisorFarmerListItem,
	FarmersDataTable,
} from "@/features/advisor/farmers/farmers-data-table";
import { fetchServerApi } from "@/lib/api-server";
import { authClient } from "@/lib/auth-client";

export const dynamic = "force-dynamic";

export default async function FarmersPage() {
	const requestHeaders = await headers();
	const session = await authClient.getSession({
		fetchOptions: {
			headers: { cookie: requestHeaders.get("cookie") ?? "" },
			throw: true,
		},
	});

	if (!session?.user) {
		redirect("/login" as Route);
	}

	const { farmers } = await fetchServerApi<{
		farmers: AdvisorFarmerListItem[];
		success: true;
	}>("farmers");

	return (
		<PageShell width="wide">
			<QuickActionCard
				actionLabel="Onboard new farmer"
				description="Create a new farmer profile with contact, crop, and farm details."
				href="/farmers/create"
				title="Create farmer"
				tone="solid"
				variant="banner"
			/>

			<section className="space-y-4">
				<SectionHeader title="Farmer directory" />

				{farmers.length > 0 ? (
					<FarmersDataTable farmers={farmers} />
				) : (
					<EmptyState
						actionHref="/farmers/create"
						actionLabel="Create farmer"
						title="No farmers yet"
					>
						Onboard the first farmer to start tracking contact, crop, and farm
						details.
					</EmptyState>
				)}
			</section>
		</PageShell>
	);
}
