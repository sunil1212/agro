"use client";

import type {
	CreateFarmerFormResult,
	CreateFarmerFormValues,
	FarmerStateOption,
	MultiFormOption,
	ReferralFarmerOption,
} from "@agro-erp-fullstack/ui/components/multi-form";

import { getClientApiUrl } from "@/lib/api-client";

export interface CreateFarmerOptionsResult {
	advisors: MultiFormOption[];
	crops: MultiFormOption[];
	currentAdvisor: {
		id: string;
		name: string;
	};
	locationOptions: readonly FarmerStateOption[];
	referralFarmers: ReferralFarmerOption[];
	success: true;
}

export type CreateFarmerOptionsResponse =
	| CreateFarmerOptionsResult
	| {
			success: false;
			message: string;
	  };

export async function fetchCreateFarmerOptions(): Promise<CreateFarmerOptionsResponse> {
	const response = await fetch(getClientApiUrl("farmers", "/create-options"), {
		credentials: "include",
	});

	return (await response.json()) as CreateFarmerOptionsResponse;
}

export async function createFarmer(
	input: CreateFarmerFormValues
): Promise<CreateFarmerFormResult> {
	const response = await fetch(getClientApiUrl("farmers"), {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		credentials: "include",
		body: JSON.stringify({
			...input,
			crops: input.standingCropIds.map((cropId) => ({
				cropId,
				dateOfSowing: input.cropSowingDates[cropId].toISOString().slice(0, 10),
			})),
		}),
	});

	return (await response.json()) as CreateFarmerFormResult;
}
