"use client";

import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import {
	type CreateFarmerFormResult,
	type CreateFarmerFormValues,
	MultiForm,
} from "@agro-erp-fullstack/ui/components/multi-form";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ArrowRightIcon, CheckCircle2Icon } from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
	ErrorState,
	LoadingState,
	PageHeader,
	PageShell,
	Surface,
} from "@/components/ui-patterns";
import { authClient } from "@/lib/auth-client";

import {
	type CreateFarmerOptionsResult,
	createFarmer,
	fetchCreateFarmerOptions,
} from "./actions";

const getErrorMessage = (result: CreateFarmerFormResult) =>
	result.success ? "Unable to create farmer" : result.message;

export default function CreateFarmerPage() {
	const router = useRouter();
	const { data: session, isPending } = authClient.useSession();
	const [options, setOptions] = useState<CreateFarmerOptionsResult | null>(
		null
	);
	const [loadError, setLoadError] = useState<string | null>(null);
	const [createdFarmer, setCreatedFarmer] = useState<{
		id: string;
		name: string;
		primaryMobileNumber: string;
	} | null>(null);

	useEffect(() => {
		if (isPending) {
			return;
		}

		if (!session?.user) {
			router.replace("/login" as Route);
			return;
		}

		let isMounted = true;

		const loadOptions = async () => {
			const result = await fetchCreateFarmerOptions();

			if (!isMounted) {
				return;
			}

			if (!result.success) {
				setLoadError(result.message);
				return;
			}

			setLoadError(null);
			setOptions(result);
		};

		loadOptions().catch((error: unknown) => {
			if (!isMounted) {
				return;
			}

			setLoadError(
				error instanceof Error ? error.message : "Failed to load farmer options"
			);
		});

		return () => {
			isMounted = false;
		};
	}, [isPending, router, session]);

	const handleSubmit = async (
		values: CreateFarmerFormValues
	): Promise<CreateFarmerFormResult> => {
		const result = await createFarmer(values);

		if (!result.success) {
			toast.error(getErrorMessage(result));
			return result;
		}

		toast.success("Farmer created");
		setCreatedFarmer(result.farmer);
		router.refresh();
		return result;
	};

	return (
		<PageShell>
			<PageHeader backHref="/farmers" eyebrow="Advisor" title="Create farmer">
				<p>
					Add a farmer profile with crop and farm details for advisor follow-up
					in one structured form.
				</p>
			</PageHeader>

			{isPending || !(options || loadError) ? (
				<LoadingState message="Loading farmer options..." />
			) : null}

			{loadError ? (
				<ErrorState message={loadError} title="Unable to load form options" />
			) : null}

			{createdFarmer ? (
				<Surface className="space-y-5">
					<div className="flex flex-col gap-4 sm:flex-row sm:items-start">
						<div className="flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
							<CheckCircle2Icon className="size-6" />
						</div>
						<div className="space-y-2">
							<h2 className="font-semibold text-xl">Farmer created</h2>
							<p className="max-w-2xl text-muted-foreground text-sm leading-6">
								{createdFarmer.name} has been saved with{" "}
								{createdFarmer.primaryMobileNumber}. Choose the next operational
								step.
							</p>
						</div>
					</div>
					<div className="flex flex-wrap gap-3">
						<Link
							className={cn(buttonVariants({ variant: "outline" }))}
							href="/farmers"
						>
							Back to farmers
						</Link>
						<Link
							className={cn(buttonVariants({ variant: "default" }))}
							href={`/orders/create?farmerId=${createdFarmer.id}`}
						>
							Create new order
							<ArrowRightIcon className="size-4" />
						</Link>
					</div>
				</Surface>
			) : null}

			{options && !createdFarmer ? (
				<MultiForm
					advisors={options.advisors}
					crops={options.crops}
					defaultServiceByUserId={options.currentAdvisor.id}
					locationOptions={options.locationOptions}
					onSubmit={handleSubmit}
					referralFarmers={options.referralFarmers}
				/>
			) : null}
		</PageShell>
	);
}
