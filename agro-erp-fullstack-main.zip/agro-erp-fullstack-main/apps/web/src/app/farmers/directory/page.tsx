import type { Route } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { EmptyState, PageShell, SectionHeader } from "@/components/ui-patterns";
import {
	type FarmerDirectoryListItem,
	FarmersDirectoryDataTable,
} from "@/features/advisor/farmers/farmers-directory-data-table";
import { fetchServerApi } from "@/lib/api-server";
import { authClient } from "@/lib/auth-client";

export const dynamic = "force-dynamic";

export default async function FarmerDirectoryPage() {
	const requestHeaders = await headers();
	const session = await authClient.getSession({
		fetchOptions: {
			headers: { cookie: requestHeaders.get("cookie") ?? "" },
			throw: true,
		},
	});

	if (!session?.user) {
		redirect("/login" as Route);
	}

	const { farmers } = await fetchServerApi<{
		farmers: FarmerDirectoryListItem[];
		success: true;
	}>("farmers", "/directory");

	return (
		<PageShell width="wide">
			<section className="space-y-4">
				<SectionHeader title="Global farmer directory">
					Search all farmers by pincode and review their mapped product.
				</SectionHeader>

				{farmers.length > 0 ? (
					<FarmersDirectoryDataTable farmers={farmers} />
				) : (
					<EmptyState title="No farmers found">
						Farmers will appear here once they are available in the database.
					</EmptyState>
				)}
			</section>
		</PageShell>
	);
}
