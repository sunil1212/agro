import type { Route } from "next";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { AdvisorDashboard } from "@/features/dashboard/advisor-dashboard";
import { getDashboardDescription } from "@/features/dashboard/dashboard-copy";
import { DashboardShell } from "@/features/dashboard/dashboard-shell";
import { ManagerDashboard } from "@/features/dashboard/manager-dashboard";
import { SuperAdminDashboard } from "@/features/dashboard/super-admin-dashboard";
import { WarehouseDashboard } from "@/features/dashboard/warehouse-dashboard";
import { authClient } from "@/lib/auth-client";
import { isAdvisorLikeRole } from "@/lib/roles";

const getUserRole = (
	session: Awaited<ReturnType<typeof authClient.getSession>> | null
) => {
	if (!(session?.user && "role" in session.user)) {
		return null;
	}

	return typeof session.user.role === "string" ? session.user.role : null;
};

export default async function DashboardPage() {
	const requestHeaders = await headers();
	const session = await authClient.getSession({
		fetchOptions: {
			headers: { cookie: requestHeaders.get("cookie") ?? "" },
			throw: true,
		},
	});

	if (!session?.user) {
		redirect("/login" as Route);
	}

	const userRole = getUserRole(session);

	return (
		<DashboardShell
			description={getDashboardDescription(userRole)}
			userName={session.user.name}
		>
			{userRole === "team_leader" ||
			(userRole ? isAdvisorLikeRole(userRole) : false) ? (
				<AdvisorDashboard />
			) : null}
			{userRole === "superadmin" ? <SuperAdminDashboard /> : null}
			{userRole === "admin" ? (
				<ManagerDashboard isAdmin={userRole === "admin"} />
			) : null}
			{userRole === "warehouse" ? <WarehouseDashboard /> : null}
		</DashboardShell>
	);
}
