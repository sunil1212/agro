import {
	EmptyState,
	PageHeader,
	PageShell,
	SectionHeader,
} from "@/components/ui-patterns";
import {
	type AdvisorOrderListItem,
	OrdersDataTable,
} from "@/features/advisor/orders/orders-data-table";
import { fetchServerApi } from "@/lib/api-server";

interface AdvisorOrdersResponse {
	orders: AdvisorOrderListItem[];
	success: true;
}

const AdvisorOrdersPage = async () => {
	const ordersData = await fetchServerApi<AdvisorOrdersResponse>(
		"orders",
		"/advisor/advisors"
	);
	const { orders } = ordersData;

	return (
		<PageShell width="wide">
			<PageHeader eyebrow="Team Leader" title="Advisor orders">
				<p>Review orders created by advisors assigned to your team.</p>
			</PageHeader>
			<section className="space-y-4">
				<SectionHeader title="Advisor order queue">
					Advisor names stay visible beside each order for quick ownership
					checks.
				</SectionHeader>
				{orders.length > 0 ? (
					<OrdersDataTable orders={orders} showAdvisorColumn />
				) : (
					<EmptyState title="No advisor orders yet">
						Assigned advisor orders will appear here once they are created.
					</EmptyState>
				)}
			</section>
		</PageShell>
	);
};

export default AdvisorOrdersPage;
