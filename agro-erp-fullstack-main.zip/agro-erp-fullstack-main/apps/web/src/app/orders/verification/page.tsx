"use client";

import {
	Button,
	buttonVariants,
} from "@agro-erp-fullstack/ui/components/button";
import {
	Card,
	CardContent,
	CardHeader,
	CardTitle,
} from "@agro-erp-fullstack/ui/components/card";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@agro-erp-fullstack/ui/components/dialog";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Sheet,
	SheetContent,
	SheetDescription,
	SheetHeader,
	SheetTitle,
	SheetTrigger,
} from "@agro-erp-fullstack/ui/components/sheet";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ArrowDownIcon, ArrowUpIcon } from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
	type ReactNode,
	useCallback,
	useEffect,
	useMemo,
	useState,
} from "react";
import { toast } from "sonner";
import {
	EmptyState,
	ErrorState,
	LoadingState,
	PageHeader,
	PageShell,
	PageSkeleton,
	SectionHeader,
	StatusPill,
} from "@/components/ui-patterns";
import {
	fetchOrdersClientApi,
	patchOrdersClientApi,
	postOrdersClientApi,
} from "@/lib/api-client";
import { authClient } from "@/lib/auth-client";

const getRoleHomePath = (role: string) => {
	switch (role) {
		case "advisor":
		case "warehouse":
			return "/dashboard";
		case "logistics":
		case "admin":
			return "/orders/verification";
		default:
			return "/dashboard";
	}
};

const moneyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 2,
	minimumFractionDigits: 2,
	style: "currency",
});

type VerificationStatus =
	| "cancelled"
	| "created"
	| "confirmed"
	| "delivered"
	| "dispatched"
	| "return_in_transit"
	| "return_in_warehouse";
type LogisticsTab = "all" | VerificationStatus;

interface FarmerDetails {
	addressAt: string;
	district: string;
	nearbyLandmark: null | string;
	pincode: string;
	post: string;
	primaryMobileNumber: string;
	secondaryMobileNumber: null | string;
	taluka: string;
}

interface PendingFarmerDetails extends FarmerDetails {
	updatedAt: Date | null | string;
	updatedByUserId: null | string;
}

interface VerificationOrder {
	approvedAt: null | string;
	cancelledAt: null | string;
	cancelledReason: null | string;
	consignmentNumber: null | string;
	createdAt: string;
	createdByName: string;
	effectiveFarmerDetails: FarmerDetails;
	farmerDetails: FarmerDetails;
	farmerId: string;
	farmerName: string;
	followUps: Array<{
		canEdit: boolean;
		slot: number;
		text: null | string;
		updatedAt: null | string;
		updatedByName: null | string;
		updatedByUserId: null | string;
	}>;
	grandTotalAmount: string;
	id: string;
	items: Array<{
		id: string;
		lineTotalAmount: string;
		productName: string;
		productSku: string;
		quantity: number;
		unitPricePerUnit: string;
		sellingPricePerUnit: string;
	}>;
	orderId: string | null;
	paidAmount: string;
	paymentMode: "cod" | "partial_payment" | "prepaid";
	pendingFarmerDetails: PendingFarmerDetails;
	shippingCharges: string;
	status: VerificationStatus;
	subtotalAmount: string;
	totalCodAmount: string;
	totalDiscountAmount: string;
}

interface VerificationResponse {
	orders: VerificationOrder[];
	success: true;
}

interface FarmerFormValues {
	addressAt: string;
	district: string;
	nearbyLandmark: string;
	pincode: string;
	post: string;
	primaryMobileNumber: string;
	secondaryMobileNumber: string;
	taluka: string;
}

const toFormValues = (details: FarmerDetails): FarmerFormValues => ({
	addressAt: details.addressAt,
	district: details.district,
	nearbyLandmark: details.nearbyLandmark ?? "",
	pincode: details.pincode,
	post: details.post,
	primaryMobileNumber: details.primaryMobileNumber,
	secondaryMobileNumber: details.secondaryMobileNumber ?? "",
	taluka: details.taluka,
});

const statusLabels: Record<VerificationStatus, string> = {
	cancelled: "Cancelled",
	confirmed: "Confirmed",
	created: "Created",
	delivered: "Delivered",
	dispatched: "Dispatched",
	return_in_transit: "Return: in transit",
	return_in_warehouse: "Return: in warehouse",
};

const statusOrder: VerificationStatus[] = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
];
const LOGISTICS_QUEUE_MIN_ROWS = 10;

const hasPreOrderFollowUps = (status: VerificationStatus) =>
	status === "created" || status === "cancelled";

const paymentModeLabels: Record<VerificationOrder["paymentMode"], string> = {
	cod: "COD",
	partial_payment: "Partial Payment",
	prepaid: "Prepaid Payment",
};

type QueueSortKey = "approvedAt" | "createdAt" | "orderId";
type QueueSortDirection = "asc" | "desc";
type VerificationPageRole = "admin" | "logistics";

const getQueueSortTimestamp = (
	order: VerificationOrder,
	sortBy: "approvedAt" | "createdAt"
) => {
	if (sortBy === "approvedAt") {
		return order.approvedAt ? new Date(order.approvedAt).getTime() : 0;
	}

	return new Date(order.createdAt).getTime();
};

const startOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(0, 0, 0, 0);
	return nextDate;
};

const endOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(23, 59, 59, 999);
	return nextDate;
};

export default function VerificationPage() {
	const router = useRouter();
	const { data: session, isPending } = authClient.useSession();
	const [orders, setOrders] = useState<VerificationOrder[]>([]);
	const [forms, setForms] = useState<Record<string, FarmerFormValues>>({});
	const [reasons, setReasons] = useState<Record<string, string>>({});
	const [busyOrderId, setBusyOrderId] = useState<string | null>(null);
	const [activeTab, setActiveTab] = useState<LogisticsTab>("created");
	const [errorMessage, setErrorMessage] = useState("");
	const [isLoading, setIsLoading] = useState(true);
	const [dateFrom, setDateFrom] = useState<Date>();
	const [dateTo, setDateTo] = useState<Date>();
	const userRole =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: null;

	useEffect(() => {
		if (!(session?.user && "role" in session.user)) {
			return;
		}

		const role =
			typeof session.user.role === "string" ? session.user.role : null;
		if (!role) {
			return;
		}

		const allowedRoles = ["logistics", "admin"];
		if (!allowedRoles.includes(role)) {
			router.replace(getRoleHomePath(role));
		}
	}, [router, session]);

	const loadOrders = useCallback(async () => {
		setErrorMessage("");
		setIsLoading(true);
		try {
			const data =
				await fetchOrdersClientApi<VerificationResponse>("/verification");
			setOrders(data.orders);
			setForms((current) => {
				const next = { ...current };
				for (const currentOrder of data.orders) {
					next[currentOrder.id] =
						current[currentOrder.id] ??
						toFormValues(currentOrder.effectiveFarmerDetails);
				}
				return next;
			});
		} catch (error) {
			const message =
				error instanceof Error ? error.message : "Failed to load orders";
			setErrorMessage(message);
			toast.error(message);
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		loadOrders().catch(() => undefined);
	}, [loadOrders]);

	if (isPending) {
		return <PageSkeleton rows={5} showMetrics={false} />;
	}

	const statusTabs: Array<{
		label: string;
		status: LogisticsTab;
	}> = [
		...statusOrder.map((status) => ({ label: statusLabels[status], status })),
		{ label: "All", status: "all" as const },
	];
	const ordersByStatus = Object.fromEntries(
		statusOrder.map((status) => [
			status,
			orders.filter((order) => order.status === status),
		])
	) as Record<VerificationStatus, VerificationOrder[]>;
	const visibleOrders =
		activeTab === "all" ? orders : (ordersByStatus[activeTab] ?? []);
	const activeTabTitle =
		activeTab === "all"
			? "All logistics orders"
			: `${statusTabs
					.find((tab) => tab.status === activeTab)
					?.label.toLowerCase()} orders`;
	const resetDateFilters = () => {
		setDateFrom(undefined);
		setDateTo(undefined);
	};

	return (
		<PageShell width="wide">
			<PageHeader title="Order review queue">
				<p className="max-w-3xl text-muted-foreground text-sm">
					Review every order phase, keep farmer communication updated, and
					manage order lifecycle transitions.
				</p>
			</PageHeader>

			<div className="space-y-6">
				<section>
					<div className="flex flex-col gap-3 rounded-3xl border border-border/70 bg-card p-2 shadow-sm ring-1 ring-foreground/5 xl:flex-row xl:items-center xl:justify-between">
						<div className="flex flex-wrap gap-2">
							{statusTabs.map((tab) => {
								const count =
									tab.status === "all"
										? orders.length
										: ordersByStatus[tab.status].length;

								return (
									<Button
										aria-pressed={activeTab === tab.status}
										key={tab.status}
										onClick={() => setActiveTab(tab.status)}
										size="sm"
										type="button"
										variant={activeTab === tab.status ? "default" : "ghost"}
									>
										{tab.label}
										<span className="ml-1 rounded-full bg-background/40 px-1.5 text-xs tabular-nums">
											{count}
										</span>
									</Button>
								);
							})}
						</div>
						<div className="flex flex-wrap gap-2">
							<DatePicker
								className="w-44 bg-background"
								onChange={setDateFrom}
								placeholder="From date"
								value={dateFrom}
							/>
							<DatePicker
								className="w-44 bg-background"
								onChange={setDateTo}
								placeholder="To date"
								value={dateTo}
							/>
							<Button
								onClick={resetDateFilters}
								type="button"
								variant="outline"
							>
								Reset
							</Button>
						</div>
					</div>
				</section>

				<section className="space-y-4">
					<SectionHeader
						action={<StatusPill>{visibleOrders.length} orders</StatusPill>}
						title={activeTabTitle}
					>
						Review details in the side panel without losing queue context.
					</SectionHeader>
					{isLoading ? (
						<LoadingState message="Loading logistics orders..." />
					) : null}
					{!isLoading && errorMessage ? (
						<ErrorState message={errorMessage} title="Failed to load orders" />
					) : null}
					{!(isLoading || errorMessage) && visibleOrders.length > 0 ? (
						<OrderCategoryTable
							busyOrderId={busyOrderId}
							dateFrom={dateFrom}
							dateTo={dateTo}
							onApprove={async (order) => {
								setBusyOrderId(order.id);
								try {
									await postOrdersClientApi(
										`/verification/${order.id}/approve`,
										{}
									);
									toast.success("Order approved");
									await loadOrders();
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to approve order"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							onChange={(order, field, value) => {
								setForms((current) => ({
									...current,
									[order.id]: {
										...(current[order.id] ??
											toFormValues(order.effectiveFarmerDetails)),
										[field]: value,
									},
								}));
							}}
							onManagerCancel={async (order, reason) => {
								setBusyOrderId(order.id);
								try {
									await postOrdersClientApi(
										`/verification/${order.id}/cancel`,
										{ reason: reason.trim() || undefined }
									);
									toast.success("Order cancelled");
									await loadOrders();
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to cancel order"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							onReasonChange={(order, value) => {
								setReasons((current) => ({
									...current,
									[order.id]: value,
								}));
							}}
							onReject={async (order) => {
								const reason = reasons[order.id]?.trim() ?? "";
								if (!reason) {
									toast.error("Cancellation reason is required");
									return;
								}

								setBusyOrderId(order.id);
								try {
									await postOrdersClientApi(
										`/verification/${order.id}/cancel`,
										{ reason }
									);
									toast.success("Order cancelled");
									await loadOrders();
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to reject order"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							onSaveFarmer={async (order) => {
								setBusyOrderId(order.id);
								try {
									const form =
										forms[order.id] ??
										toFormValues(order.effectiveFarmerDetails);
									const result = await patchOrdersClientApi<{
										effectiveFarmerDetails: FarmerDetails;
										pendingFarmerDetails: PendingFarmerDetails;
										success: true;
									}>(`/verification/${order.id}/farmer`, form);
									setOrders((current) =>
										current.map((item) =>
											item.id === order.id
												? {
														...item,
														effectiveFarmerDetails:
															result.effectiveFarmerDetails,
														pendingFarmerDetails: result.pendingFarmerDetails,
													}
												: item
										)
									);
									setForms((current) => ({
										...current,
										[order.id]: toFormValues(result.effectiveFarmerDetails),
									}));
									toast.success("Farmer details saved");
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to save farmer details"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							onSaveFollowUp={async (order, slot, values) => {
								setBusyOrderId(order.id);
								try {
									const result = await patchOrdersClientApi<{
										followUps: VerificationOrder["followUps"];
										success: true;
									}>(`/verification/${order.id}/follow-up`, {
										slot,
										text: values.text,
									});
									setOrders((current) =>
										current.map((item) =>
											item.id === order.id
												? {
														...item,
														followUps: result.followUps,
													}
												: item
										)
									);
									toast.success(`Follow-up ${slot} saved`);
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to save follow-up"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							onUndo={async (order) => {
								setBusyOrderId(order.id);
								try {
									await postOrdersClientApi(
										`/verification/${order.id}/undo-cancel`,
										{}
									);
									toast.success("Order moved back to verification");
									await loadOrders();
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to undo cancellation"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							onUpdateStatus={async (order, status) => {
								setBusyOrderId(order.id);
								try {
									await patchOrdersClientApi(
										`/verification/${order.id}/status`,
										{ status }
									);
									toast.success(`Order moved to ${statusLabels[status]}`);
									await loadOrders();
									router.refresh();
								} catch (error) {
									toast.error(
										error instanceof Error
											? error.message
											: "Failed to update order status"
									);
								} finally {
									setBusyOrderId(null);
								}
							}}
							orders={visibleOrders}
							resolveForm={(order) =>
								forms[order.id] ?? toFormValues(order.effectiveFarmerDetails)
							}
							resolveReason={(order) => reasons[order.id] ?? ""}
							role={
								userRole === "admin" || userRole === "logistics"
									? userRole
									: "logistics"
							}
							showConfirmedAtColumn={activeTab === "confirmed"}
						/>
					) : null}
					{!(isLoading || errorMessage) && visibleOrders.length === 0 ? (
						<EmptyState title="No orders in this status">
							Orders will appear here when their logistics status matches the
							selected filter.
						</EmptyState>
					) : null}
				</section>
			</div>
		</PageShell>
	);
}

function OrderCategoryTable({
	busyOrderId,
	dateFrom,
	dateTo,
	onApprove,
	onChange,
	onManagerCancel,
	onReasonChange,
	onReject,
	onSaveFarmer,
	onSaveFollowUp,
	onUpdateStatus,
	onUndo,
	orders,
	role,
	showConfirmedAtColumn,
	resolveForm,
	resolveReason,
}: {
	busyOrderId: null | string;
	dateFrom: Date | undefined;
	dateTo: Date | undefined;
	onApprove: (order: VerificationOrder) => Promise<void>;
	onChange: (
		order: VerificationOrder,
		field: keyof FarmerFormValues,
		value: string
	) => void;
	onManagerCancel: (order: VerificationOrder, reason: string) => Promise<void>;
	onReasonChange: (order: VerificationOrder, value: string) => void;
	onReject: (order: VerificationOrder) => Promise<void>;
	onSaveFarmer: (order: VerificationOrder) => Promise<void>;
	onSaveFollowUp: (
		order: VerificationOrder,
		slot: number,
		values: { text: string }
	) => Promise<void>;
	onUpdateStatus: (
		order: VerificationOrder,
		status: "delivered" | "return_in_transit"
	) => Promise<void>;
	onUndo: (order: VerificationOrder) => Promise<void>;
	orders: VerificationOrder[];
	role: VerificationPageRole;
	showConfirmedAtColumn: boolean;
	resolveForm: (order: VerificationOrder) => FarmerFormValues;
	resolveReason: (order: VerificationOrder) => string;
}) {
	const pageSizeOptions = [10, 25, 50] as const;
	const [sortBy, setSortBy] = useState<QueueSortKey>("createdAt");
	const [sortDirection, setSortDirection] =
		useState<QueueSortDirection>("desc");
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] =
		useState<(typeof pageSizeOptions)[number]>(10);

	const sortedOrders = useMemo(() => {
		const lowerDate = dateFrom ? startOfDay(dateFrom).getTime() : null;
		const upperDate = dateTo ? endOfDay(dateTo).getTime() : null;
		const nextOrders = orders.filter((order) => {
			const orderTime = new Date(order.createdAt).getTime();
			if (lowerDate !== null && orderTime < lowerDate) {
				return false;
			}

			if (upperDate !== null && orderTime > upperDate) {
				return false;
			}

			return true;
		});

		nextOrders.sort((left, right) => {
			if (sortBy === "approvedAt" || sortBy === "createdAt") {
				const leftValue = getQueueSortTimestamp(left, sortBy);
				const rightValue = getQueueSortTimestamp(right, sortBy);

				return sortDirection === "asc"
					? leftValue - rightValue
					: rightValue - leftValue;
			}

			const leftValue = left.orderId ?? "";
			const rightValue = right.orderId ?? "";
			const comparison = leftValue.localeCompare(rightValue);

			return sortDirection === "asc" ? comparison : -comparison;
		});

		return nextOrders;
	}, [dateFrom, dateTo, orders, sortBy, sortDirection]);

	const totalPages = Math.max(1, Math.ceil(sortedOrders.length / pageSize));
	const safeCurrentPage = Math.min(currentPage, totalPages);
	const pageStartIndex = (safeCurrentPage - 1) * pageSize;
	const paginatedOrders = sortedOrders.slice(
		pageStartIndex,
		pageStartIndex + pageSize
	);
	const fillerRows = Math.max(
		0,
		LOGISTICS_QUEUE_MIN_ROWS - paginatedOrders.length
	);
	const pageInputValue = String(safeCurrentPage);

	useEffect(() => {
		if (currentPage > totalPages) {
			setCurrentPage(totalPages);
		}
	}, [currentPage, totalPages]);

	const toggleSort = (nextSortBy: QueueSortKey) => {
		setCurrentPage(1);
		if (nextSortBy === sortBy) {
			setSortDirection((currentDirection) =>
				currentDirection === "asc" ? "desc" : "asc"
			);
			return;
		}

		setSortBy(nextSortBy);
		setSortDirection("desc");
	};

	const sortIcon = (column: QueueSortKey) => {
		if (sortBy !== column) {
			return <ArrowDownIcon className="size-3 opacity-30" />;
		}

		return sortDirection === "asc" ? (
			<ArrowUpIcon className="size-3" />
		) : (
			<ArrowDownIcon className="size-3" />
		);
	};

	return (
		<div className="overflow-hidden rounded-xl border bg-card">
			<Table>
				<TableHeader>
					<TableRow>
						<TableHead>
							<button
								className="inline-flex items-center gap-1 text-left font-medium"
								onClick={() => toggleSort("orderId")}
								type="button"
							>
								Order ID
								{sortIcon("orderId")}
							</button>
						</TableHead>
						<TableHead>Consignment</TableHead>
						<TableHead>
							<button
								className="inline-flex items-center gap-1 text-left font-medium"
								onClick={() => toggleSort("createdAt")}
								type="button"
							>
								Order date
								{sortIcon("createdAt")}
							</button>
						</TableHead>
						{showConfirmedAtColumn ? (
							<TableHead>
								<button
									className="inline-flex items-center gap-1 text-left font-medium"
									onClick={() => toggleSort("approvedAt")}
									type="button"
								>
									Confirmed at
									{sortIcon("approvedAt")}
								</button>
							</TableHead>
						) : null}
						<TableHead>Farmer name</TableHead>
						<TableHead>Advisor name</TableHead>
						<TableHead>Items</TableHead>
						<TableHead>Pre follow-ups</TableHead>
						<TableHead className="text-right">Total</TableHead>
						<TableHead>Status</TableHead>
						<TableHead className="w-28 text-right">Action</TableHead>
					</TableRow>
				</TableHeader>
				<TableBody>
					{paginatedOrders.map((order) => {
						const canEditCurrentOrder = order.status === "created";

						return (
							<TableRow key={order.id}>
								<TableCell className="font-medium">
									{order.orderId ?? "Pending confirmation"}
								</TableCell>
								<TableCell>
									{order.consignmentNumber ? (
										<StatusPill>{order.consignmentNumber}</StatusPill>
									) : (
										<span className="text-muted-foreground">Not assigned</span>
									)}
								</TableCell>
								<TableCell>{formatDate(order.createdAt)}</TableCell>
								{showConfirmedAtColumn ? (
									<TableCell>
										{order.approvedAt ? formatDateTime(order.approvedAt) : "—"}
									</TableCell>
								) : null}
								<TableCell>{order.farmerName}</TableCell>
								<TableCell>{order.createdByName}</TableCell>
								<TableCell>{order.items.length}</TableCell>
								<TableCell>
									{hasPreOrderFollowUps(order.status)
										? order.followUps.filter((entry) =>
												Boolean(entry.text?.trim())
											).length
										: "—"}
								</TableCell>
								<TableCell className="text-right font-medium">
									{order.grandTotalAmount}
								</TableCell>
								<TableCell>
									<span className="rounded-full bg-muted px-3 py-1 text-xs">
										{statusLabels[order.status]}
									</span>
								</TableCell>
								<TableCell className="text-right">
									<div className="flex justify-end gap-2">
										<Sheet>
											<SheetTrigger
												render={<Button size="sm" variant="outline" />}
											>
												Review
											</SheetTrigger>
											<SheetContent className="max-w-3xl overflow-hidden p-0 sm:max-w-3xl">
												<SheetHeader className="shrink-0 bg-card pr-14">
													<SheetTitle>
														{order.orderId ?? "Pending confirmation"}
													</SheetTitle>
													<SheetDescription>
														{order.farmerName} • Advisor {order.createdByName}
													</SheetDescription>
												</SheetHeader>
												<div className="flex-1 overflow-y-auto p-6">
													{order.status === "cancelled" ? (
														<CancelledOrderCard
															busyOrderId={busyOrderId}
															onUndo={() => onUndo(order)}
															order={order}
															showHeader={false}
														/>
													) : (
														<QueuedOrderCard
															busyOrderId={busyOrderId}
															currentRole={role}
															form={resolveForm(order)}
															onApprove={() => onApprove(order)}
															onChange={(field, value) =>
																onChange(order, field, value)
															}
															onManagerCancel={(reason) =>
																onManagerCancel(order, reason)
															}
															onReasonChange={(value) =>
																onReasonChange(order, value)
															}
															onReject={() => onReject(order)}
															onSaveFarmer={() => onSaveFarmer(order)}
															onSaveFollowUp={(slot, values) =>
																onSaveFollowUp(order, slot, values)
															}
															onUpdateStatus={(status) =>
																onUpdateStatus(order, status)
															}
															order={order}
															reason={resolveReason(order)}
															showHeader={false}
														/>
													)}
												</div>
											</SheetContent>
										</Sheet>
										{canEditCurrentOrder ? (
											<Link
												className={cn(
													buttonVariants({
														size: "sm",
														variant: "secondary",
													})
												)}
												href={`/orders/${order.id}/edit` as Route}
											>
												Edit
											</Link>
										) : null}
									</div>
								</TableCell>
							</TableRow>
						);
					})}
					{Array.from({ length: fillerRows }).map((_, index) => (
						<TableRow
							aria-hidden
							className="hover:bg-transparent"
							key={`logistics-filler-${index}`}
						>
							<TableCell
								className="h-16"
								colSpan={showConfirmedAtColumn ? 11 : 10}
							>
								&nbsp;
							</TableCell>
						</TableRow>
					))}
				</TableBody>
			</Table>
			<div className="grid gap-3 border-border/70 border-t bg-muted/20 px-4 py-3 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
				<div className="text-muted-foreground text-sm">
					Showing {sortedOrders.length === 0 ? 0 : pageStartIndex + 1} to{" "}
					{Math.min(
						pageStartIndex + paginatedOrders.length,
						sortedOrders.length
					)}{" "}
					of {sortedOrders.length} orders
				</div>
				<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
					<PaginationContent>
						<PaginationItem>
							<PaginationPrevious
								disabled={safeCurrentPage === 1}
								onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
								type="button"
							/>
						</PaginationItem>
						<PaginationItem>
							<div className="flex h-9 items-center gap-2 px-2 text-sm">
								<span className="text-muted-foreground">Page</span>
								<Input
									className="h-8 w-16 text-center"
									inputMode="numeric"
									max={totalPages}
									min={1}
									onBlur={() => {
										setCurrentPage((value) => Math.min(totalPages, value));
									}}
									onChange={(event) => {
										const nextPage = Number(event.target.value);
										if (!Number.isInteger(nextPage)) {
											return;
										}

										setCurrentPage(Math.min(totalPages, Math.max(1, nextPage)));
									}}
									value={pageInputValue}
								/>
								<span className="text-muted-foreground">of {totalPages}</span>
							</div>
						</PaginationItem>
						<PaginationItem>
							<PaginationNext
								disabled={safeCurrentPage === totalPages}
								onClick={() =>
									setCurrentPage((page) => Math.min(totalPages, page + 1))
								}
								type="button"
							/>
						</PaginationItem>
					</PaginationContent>
				</Pagination>
				<div className="flex flex-wrap items-center gap-3 lg:justify-end">
					<div className="flex items-center gap-2">
						<span className="text-muted-foreground text-sm">Rows</span>
						<Select
							onValueChange={(value) => {
								setCurrentPage(1);
								setPageSize(Number(value) as (typeof pageSizeOptions)[number]);
							}}
							value={String(pageSize)}
						>
							<SelectTrigger className="h-9 w-20 bg-background">
								<SelectValue />
							</SelectTrigger>
							<SelectContent align="end">
								{pageSizeOptions.map((option) => (
									<SelectItem key={option} value={String(option)}>
										{option}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
					</div>
				</div>
			</div>
		</div>
	);
}

function QueuedOrderCard({
	busyOrderId,
	currentRole,
	form,
	onApprove,
	onChange,
	onManagerCancel,
	onReasonChange,
	onReject,
	onSaveFarmer,
	onSaveFollowUp,
	onUpdateStatus,
	order,
	reason,
	showHeader = true,
}: {
	busyOrderId: null | string;
	currentRole: VerificationPageRole;
	form: FarmerFormValues;
	onApprove: () => Promise<void>;
	onChange: (field: keyof FarmerFormValues, value: string) => void;
	onManagerCancel: (reason: string) => Promise<void>;
	onReasonChange: (value: string) => void;
	onReject: () => Promise<void>;
	onSaveFarmer: () => Promise<void>;
	onSaveFollowUp: (slot: number, values: { text: string }) => Promise<void>;
	onUpdateStatus: (status: "delivered" | "return_in_transit") => Promise<void>;
	order: VerificationOrder;
	reason: string;
	showHeader?: boolean;
}) {
	const isBusy = busyOrderId === order.id;
	const canCancelConfirmedOrder =
		currentRole === "admin" && order.status === "confirmed";
	const canEditOrder = order.status === "created";
	const canMarkDelivered = order.status === "dispatched";
	const canStartReturn = order.status === "dispatched";
	const itemDiscountTotal = order.items.reduce(
		(total, item) => total + getItemDiscount(item),
		0
	);
	const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false);
	const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
	let primaryAction: ReactNode = (
		<p className="text-muted-foreground text-sm">
			This order is in {statusLabels[order.status].toLowerCase()}.
		</p>
	);

	if (canEditOrder) {
		primaryAction = (
			<div className="grid gap-2 sm:grid-cols-2">
				<Button
					className="w-full"
					disabled={isBusy}
					onClick={() => {
						setIsApproveDialogOpen(true);
					}}
					type="button"
				>
					Accept Order
				</Button>
				<Button
					className="w-full border-destructive/40 text-destructive hover:bg-destructive hover:text-white"
					disabled={isBusy}
					onClick={() => {
						setIsRejectDialogOpen(true);
					}}
					type="button"
					variant="outline"
				>
					Reject Order
				</Button>
			</div>
		);
	} else if (canCancelConfirmedOrder) {
		primaryAction = (
			<Button
				className="w-full border-destructive/40 text-destructive hover:bg-destructive hover:text-white"
				disabled={isBusy}
				onClick={() => {
					setIsRejectDialogOpen(true);
				}}
				type="button"
				variant="outline"
			>
				Cancel Order
			</Button>
		);
	}

	return (
		<Card
			className={
				showHeader
					? undefined
					: "gap-0 rounded-none bg-transparent p-0 shadow-none ring-0"
			}
		>
			{showHeader ? (
				<CardHeader className="flex flex-row items-start justify-between gap-4">
					<div className="space-y-1">
						<CardTitle className="text-lg">
							{order.orderId ?? "Pending confirmation"}
						</CardTitle>
						<p className="text-muted-foreground text-sm">
							{order.farmerName} • Advisor {order.createdByName}
						</p>
						{order.consignmentNumber ? (
							<p className="font-mono text-muted-foreground text-sm">
								Consignment {order.consignmentNumber}
							</p>
						) : null}
					</div>
					<span className="rounded-full bg-muted px-3 py-1 text-xs">
						{statusLabels[order.status]}
					</span>
				</CardHeader>
			) : null}
			<CardContent className={showHeader ? "space-y-6" : "space-y-6 px-0"}>
				<section className="space-y-3">
					<h3 className="font-medium text-muted-foreground text-sm uppercase tracking-wide">
						Order items
					</h3>
					<div className="rounded-2xl border border-border/70 bg-background">
						<table className="w-full table-fixed text-sm">
							<thead className="border-border/70 border-b bg-muted/40 text-muted-foreground">
								<tr>
									<th className="w-[46%] px-4 py-3 text-left font-medium">
										Product
									</th>
									<th className="w-[16%] px-4 py-3 text-left font-medium">
										Quantity
									</th>
									<th className="w-[19%] px-4 py-3 text-left font-medium">
										Unit price
									</th>
									<th className="w-[19%] px-4 py-3 text-left font-medium">
										Discount
									</th>
									<th className="w-[19%] px-4 py-3 text-right font-medium">
										Line total
									</th>
								</tr>
							</thead>
							<tbody>
								{order.items.map((item) => (
									<tr
										className="border-border/70 border-b last:border-b-0"
										key={item.id}
									>
										<td className="whitespace-normal break-words px-4 py-3 font-medium">
											{item.productName}
										</td>
										<td className="px-4 py-3 align-top">{item.quantity}</td>
										<td className="px-4 py-3 align-top">
											{item.sellingPricePerUnit}
										</td>
										<td className="px-4 py-3 align-top">
											{formatItemDiscount(item)}
										</td>
										<td className="px-4 py-3 text-right font-medium">
											{item.lineTotalAmount}
										</td>
									</tr>
								))}
							</tbody>
						</table>
					</div>
				</section>

				<details className="group rounded-2xl border border-border/70 bg-background">
					<summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3">
						<div className="flex items-center gap-3">
							<h3 className="font-medium text-muted-foreground text-sm uppercase tracking-wide">
								Farmer contact and billing
							</h3>
							{order.pendingFarmerDetails.updatedAt ? (
								<span className="rounded-full bg-amber-100 px-3 py-1 text-[11px] text-amber-800">
									Pending changes saved
								</span>
							) : null}
						</div>
						<span className="text-muted-foreground text-xs group-open:hidden">
							Expand
						</span>
						<span className="hidden text-muted-foreground text-xs group-open:inline">
							Collapse
						</span>
					</summary>
					<div className="space-y-3 border-border/70 border-t p-4">
						<div className="grid gap-4 md:grid-cols-2">
							<Field
								id={`primary-mobile-${order.id}`}
								label="Primary mobile"
								onChange={(value) => onChange("primaryMobileNumber", value)}
								value={form.primaryMobileNumber}
							/>
							<Field
								id={`secondary-mobile-${order.id}`}
								label="Secondary mobile"
								onChange={(value) => onChange("secondaryMobileNumber", value)}
								value={form.secondaryMobileNumber}
							/>
							<Field
								id={`address-${order.id}`}
								label="Address / village"
								onChange={(value) => onChange("addressAt", value)}
								value={form.addressAt}
							/>
							<Field
								id={`landmark-${order.id}`}
								label="Nearby landmark"
								onChange={(value) => onChange("nearbyLandmark", value)}
								value={form.nearbyLandmark}
							/>
							<Field
								id={`post-${order.id}`}
								label="Post"
								onChange={(value) => onChange("post", value)}
								value={form.post}
							/>
							<Field
								id={`taluka-${order.id}`}
								label="Taluka"
								onChange={(value) => onChange("taluka", value)}
								value={form.taluka}
							/>
							<Field
								id={`district-${order.id}`}
								label="District"
								onChange={(value) => onChange("district", value)}
								value={form.district}
							/>
							<Field
								id={`pincode-${order.id}`}
								label="Pincode"
								onChange={(value) => onChange("pincode", value)}
								value={form.pincode}
							/>
						</div>
						<Button
							disabled={isBusy || !canEditOrder}
							onClick={() => {
								onSaveFarmer().catch(() => undefined);
							}}
							type="button"
							variant="outline"
						>
							Save Farmer Details
						</Button>
					</div>
				</details>

				{hasPreOrderFollowUps(order.status) ? (
					<details className="group rounded-2xl border border-border/70 bg-background">
						<summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3">
							<h3 className="font-medium text-muted-foreground text-sm uppercase tracking-wide">
								Pre Order Confirmation Follow Ups
							</h3>
							<span className="text-muted-foreground text-xs group-open:hidden">
								Expand
							</span>
							<span className="hidden text-muted-foreground text-xs group-open:inline">
								Collapse
							</span>
						</summary>
						<div className="border-border/70 border-t p-4">
							<FollowUpSection
								disabled={isBusy}
								followUps={order.followUps}
								onSave={onSaveFollowUp}
							/>
						</div>
					</details>
				) : null}

				<div className="space-y-4 rounded-2xl border bg-card p-4 shadow-sm">
					<div className="space-y-1 text-sm">
						<div className="flex items-center justify-between gap-3">
							<span>Payment mode</span>
							<span className="font-medium">
								{paymentModeLabels[order.paymentMode]}
							</span>
						</div>
						<div className="flex items-center justify-between gap-3">
							<span>Subtotal</span>
							<span>{order.subtotalAmount}</span>
						</div>
						<div className="flex items-center justify-between gap-3">
							<span>Product discount</span>
							<span>{formatMoney(itemDiscountTotal)}</span>
						</div>
						<div className="flex items-center justify-between gap-3">
							<span>Total discount</span>
							<span>
								{formatMoney(
									itemDiscountTotal + Number(order.totalDiscountAmount)
								)}
							</span>
						</div>
						<div className="flex items-center justify-between gap-3">
							<span>Shipping</span>
							<span>{order.shippingCharges}</span>
						</div>
						<div className="flex items-center justify-between gap-3">
							<span>Payment received</span>
							<span>{order.paidAmount}</span>
						</div>
						<div className="flex items-center justify-between gap-3">
							<span>COD remaining</span>
							<span>{order.totalCodAmount}</span>
						</div>
						<div className="flex items-center justify-between gap-3 font-semibold text-base">
							<span>Total</span>
							<span>{order.grandTotalAmount}</span>
						</div>
					</div>

					<div className="space-y-3 border-border/70 border-t pt-4">
						<h3 className="font-medium text-muted-foreground text-sm uppercase tracking-wide">
							Order lifecycle
						</h3>
						{order.status === "dispatched" ? (
							<div className="grid gap-2 sm:grid-cols-2">
								<Button
									disabled={isBusy || !canMarkDelivered}
									onClick={() => {
										onUpdateStatus("delivered").catch(() => undefined);
									}}
									type="button"
								>
									Mark Delivered
								</Button>
								<Button
									className="hover:border-destructive hover:bg-destructive hover:text-white"
									disabled={isBusy || !canStartReturn}
									onClick={() => {
										onUpdateStatus("return_in_transit").catch(() => undefined);
									}}
									type="button"
									variant="outline"
								>
									Start Return
								</Button>
							</div>
						) : (
							primaryAction
						)}
					</div>
				</div>

				<Dialog
					onOpenChange={setIsApproveDialogOpen}
					open={isApproveDialogOpen}
				>
					<DialogContent showCloseButton={!isBusy}>
						<DialogHeader>
							<DialogTitle>Confirm order approval</DialogTitle>
							<DialogDescription>
								This will approve the order and move it into the next logistics
								stage.
							</DialogDescription>
						</DialogHeader>
						<DialogFooter>
							<Button
								disabled={isBusy}
								onClick={() => setIsApproveDialogOpen(false)}
								type="button"
								variant="outline"
							>
								Cancel
							</Button>
							<Button
								disabled={isBusy}
								onClick={() => {
									onApprove()
										.then(() => {
											setIsApproveDialogOpen(false);
										})
										.catch(() => undefined);
								}}
								type="button"
							>
								Accept Order
							</Button>
						</DialogFooter>
					</DialogContent>
				</Dialog>

				<OrderCancellationDialog
					allowSkipReason={canCancelConfirmedOrder}
					isBusy={isBusy}
					onConfirm={() =>
						canCancelConfirmedOrder ? onManagerCancel(reason) : onReject()
					}
					onOpenChange={setIsRejectDialogOpen}
					onReasonChange={onReasonChange}
					onSkipReason={() => onManagerCancel("")}
					open={isRejectDialogOpen}
					orderId={order.id}
					reason={reason}
				/>
			</CardContent>
		</Card>
	);
}

function OrderCancellationDialog({
	allowSkipReason,
	isBusy,
	onConfirm,
	onOpenChange,
	onReasonChange,
	onSkipReason,
	open,
	orderId,
	reason,
}: {
	allowSkipReason: boolean;
	isBusy: boolean;
	onConfirm: () => Promise<void>;
	onOpenChange: (open: boolean) => void;
	onReasonChange: (value: string) => void;
	onSkipReason: () => Promise<void>;
	open: boolean;
	orderId: string;
	reason: string;
}) {
	const dialogTitle = allowSkipReason
		? "Cancel confirmed order"
		: "Reject order";
	const dialogDescription = allowSkipReason
		? "Add an optional reason before cancelling this confirmed order."
		: "Add a rejection reason before cancelling this order.";
	const reasonLabel = allowSkipReason ? "Cancellation reason" : "Reject reason";
	const reasonPlaceholder = allowSkipReason
		? "Optional reason for cancellation"
		: "Reason for rejection";

	return (
		<Dialog onOpenChange={onOpenChange} open={open}>
			<DialogContent showCloseButton={!isBusy}>
				<DialogHeader>
					<DialogTitle>{dialogTitle}</DialogTitle>
					<DialogDescription>{dialogDescription}</DialogDescription>
				</DialogHeader>
				<div className="space-y-2">
					<Label htmlFor={`cancel-${orderId}`}>{reasonLabel}</Label>
					<Textarea
						id={`cancel-${orderId}`}
						onChange={(event) => onReasonChange(event.target.value)}
						placeholder={reasonPlaceholder}
						value={reason}
					/>
				</div>
				<DialogFooter>
					{allowSkipReason ? (
						<>
							<Button
								className="bg-destructive text-white hover:bg-destructive/90"
								disabled={isBusy}
								onClick={() => {
									onConfirm()
										.then(() => {
											onOpenChange(false);
										})
										.catch(() => undefined);
								}}
								type="button"
							>
								Confirm cancellation
							</Button>
							<Button
								disabled={isBusy}
								onClick={() => {
									onSkipReason()
										.then(() => {
											onOpenChange(false);
										})
										.catch(() => undefined);
								}}
								type="button"
								variant="outline"
							>
								Skip reason and cancel
							</Button>
						</>
					) : (
						<>
							<Button
								disabled={isBusy}
								onClick={() => onOpenChange(false)}
								type="button"
								variant="outline"
							>
								Cancel
							</Button>
							<Button
								className="bg-destructive text-white hover:bg-destructive/90"
								disabled={isBusy || reason.trim().length === 0}
								onClick={() => {
									onConfirm()
										.then(() => {
											onOpenChange(false);
										})
										.catch(() => undefined);
								}}
								type="button"
							>
								Reject Order
							</Button>
						</>
					)}
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}

function FollowUpSection({
	disabled,
	followUps,
	onSave,
}: {
	disabled: boolean;
	followUps: VerificationOrder["followUps"];
	onSave: (slot: number, values: { text: string }) => Promise<void>;
}) {
	return (
		<div className="overflow-hidden rounded-2xl border border-border/70 bg-background">
			{followUps.map((entry) => (
				<FollowUpRow
					disabled={disabled}
					entry={entry}
					key={entry.slot}
					onSave={onSave}
				/>
			))}
		</div>
	);
}

function FollowUpRow({
	disabled,
	entry,
	onSave,
}: {
	disabled: boolean;
	entry: VerificationOrder["followUps"][number];
	onSave: (slot: number, values: { text: string }) => Promise<void>;
}) {
	const [text, setText] = useState(entry.text ?? "");
	const updatedByLabel = entry.updatedByName ?? entry.updatedByUserId;

	useEffect(() => {
		setText(entry.text ?? "");
	}, [entry.text]);

	return (
		<div className="grid gap-2 border-border/70 border-b p-3 last:border-b-0 md:grid-cols-[7rem_minmax(0,1fr)_16rem_8rem] md:items-center">
			<p className="font-medium text-sm">Follow-up {entry.slot}</p>
			<Input
				id={`follow-up-text-${entry.slot}`}
				onChange={(event) => setText(event.target.value)}
				placeholder="Add follow-up note"
				value={text}
			/>
			<div className="space-y-0.5 text-muted-foreground text-xs">
				<p>
					{entry.updatedAt
						? `${formatRelativeDate(entry.updatedAt)} (${formatDateTime(entry.updatedAt)})`
						: "No update yet"}
				</p>
				<p>{updatedByLabel ? `By ${updatedByLabel}` : ""}</p>
			</div>
			<Button
				className="justify-center"
				disabled={disabled || !entry.canEdit}
				onClick={() => {
					onSave(entry.slot, { text }).catch(() => undefined);
				}}
				size="sm"
				type="button"
				variant="outline"
			>
				Save
			</Button>
		</div>
	);
}

function CancelledOrderCard({
	busyOrderId,
	onUndo,
	order,
	showHeader = true,
}: {
	busyOrderId: null | string;
	onUndo: () => Promise<void>;
	order: VerificationOrder;
	showHeader?: boolean;
}) {
	return (
		<Card
			className={
				showHeader
					? undefined
					: "gap-0 rounded-none bg-transparent p-0 shadow-none ring-0"
			}
		>
			{showHeader ? (
				<CardHeader className="flex flex-row items-start justify-between gap-4">
					<div className="space-y-1">
						<CardTitle className="text-lg">
							{order.orderId ?? "Pending confirmation"}
						</CardTitle>
						<p className="text-muted-foreground text-sm">
							{order.farmerName} • Cancelled{" "}
							{order.cancelledAt ? formatDate(order.cancelledAt) : ""}
						</p>
						{order.consignmentNumber ? (
							<p className="font-mono text-muted-foreground text-sm">
								Consignment {order.consignmentNumber}
							</p>
						) : null}
					</div>
					<span className="rounded-full bg-muted px-3 py-1 text-xs">
						{statusLabels[order.status]}
					</span>
				</CardHeader>
			) : null}
			<CardContent
				className={
					showHeader
						? "flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"
						: "flex flex-col gap-4 px-0 lg:flex-row lg:items-center lg:justify-between"
				}
			>
				<div className="space-y-2 text-sm">
					<p>
						<span className="font-medium">Reason:</span>{" "}
						{order.cancelledReason ?? "No reason recorded"}
					</p>
					<p className="text-muted-foreground">
						{order.farmerName} •{" "}
						{order.effectiveFarmerDetails.primaryMobileNumber}
					</p>
				</div>
				{order.orderId ? null : (
					<Button
						disabled={busyOrderId === order.id}
						onClick={() => {
							onUndo().catch(() => undefined);
						}}
						type="button"
						variant="outline"
					>
						Undo Cancellation
					</Button>
				)}
			</CardContent>
		</Card>
	);
}

function Field({
	id,
	label,
	onChange,
	value,
}: {
	id: string;
	label: string;
	onChange: (value: string) => void;
	value: string;
}) {
	return (
		<label className="space-y-2" htmlFor={id}>
			<span className="font-medium text-sm">{label}</span>
			<Input
				id={id}
				onChange={(event) => onChange(event.target.value)}
				value={value}
			/>
		</label>
	);
}

function formatDate(value: string) {
	return new Intl.DateTimeFormat("en-IN", {
		day: "2-digit",
		month: "short",
		timeZone: "Asia/Kolkata",
		year: "numeric",
	}).format(new Date(value));
}

function formatDateTime(value: string) {
	return new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short",
		timeZone: "Asia/Kolkata",
	}).format(new Date(value));
}

function formatRelativeDate(value: string) {
	const now = Date.now();
	const then = new Date(value).getTime();
	const diffMs = then - now;
	const minuteMs = 60_000;
	const hourMs = 60 * minuteMs;
	const dayMs = 24 * hourMs;
	const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });

	if (Math.abs(diffMs) < hourMs) {
		return rtf.format(Math.round(diffMs / minuteMs), "minute");
	}
	if (Math.abs(diffMs) < dayMs) {
		return rtf.format(Math.round(diffMs / hourMs), "hour");
	}
	return rtf.format(Math.round(diffMs / dayMs), "day");
}

function getItemDiscount(item: {
	quantity: number;
	sellingPricePerUnit: string;
	unitPricePerUnit: string;
}): number {
	return (
		Math.max(
			Number(item.unitPricePerUnit) - Number(item.sellingPricePerUnit),
			0
		) * item.quantity
	);
}

function formatItemDiscount(item: {
	quantity: number;
	sellingPricePerUnit: string;
	unitPricePerUnit: string;
}): string {
	const unitPrice = Number(item.unitPricePerUnit);
	const rate =
		unitPrice > 0
			? Math.max(
					Number(item.unitPricePerUnit) - Number(item.sellingPricePerUnit),
					0
				) / unitPrice
			: 0;
	const discount = getItemDiscount(item);
	return discount > 0
		? `${moneyFormatter.format(discount)} (${Math.round(rate * 100)}%)`
		: "—";
}

function formatMoney(value: number): string {
	return moneyFormatter.format(value);
}
