"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Combobox,
	ComboboxChip,
	ComboboxChips,
	ComboboxChipsInput,
	ComboboxContent,
	ComboboxEmpty,
	ComboboxItem,
	ComboboxList,
	useComboboxAnchor,
} from "@agro-erp-fullstack/ui/components/combobox";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { LiteDebouncer } from "@tanstack/pacer-lite/lite-debouncer";
import { ArrowDownIcon, ChevronDownIcon, DownloadIcon } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
	EmptyState,
	ErrorState,
	LoadingState,
	PageHeader,
	PageShell,
	PageSkeleton,
	StatusPill,
} from "@/components/ui-patterns";
import { fetchOrdersClientApi, patchOrdersClientApi } from "@/lib/api-client";
import { authClient } from "@/lib/auth-client";

type SortDirection = "asc" | "desc";
type TrackingSortKey = "createdAt" | "farmerName" | "orderId" | "status";
type FilterValue = "all" | string;
type FollowUpSlot = 1 | 2 | 3 | 4;

interface TrackingOrder {
	consignmentNumber: null | string;
	createdAt: string;
	farmerAddress: string;
	farmerName: string;
	farmerPrimaryMobileNumber: string;
	followUp1Text: null | string[];
	followUp1UpdatedAt: null | string;
	followUp2Text: null | string[];
	followUp2UpdatedAt: null | string;
	followUp3Text: null | string[];
	followUp3UpdatedAt: null | string;
	followUp4Text: null | string[];
	followUp4UpdatedAt: null | string;
	id: string;
	orderId: null | string;
	status: string;
}

interface TrackingOrdersResponse {
	orders: TrackingOrder[];
	success: true;
}

const pageSizeOptions = [5, 10, 20] as const;
const TRACKING_TABLE_MIN_ROWS = 10;
const FOLLOW_UP_SAVE_WAIT_MS = 4000;
const defaultFollowUpOptions = [
	"DISPATCHED",
	"TRACKING NA",
	"DELIVERED",
	"RETURN",
	"CONNECTED",
	"NOT CONNECTED",
	"@DISTRICT B.O",
	"@VILLAGE B.O",
	"@TALUKA B.O",
	"CANCELLED",
	"CNR FARMER",
	"REDIRECTED MAIL DONE",
	"CONNECTED FARMER WILL COLLECT",
	"DOOR LOCKED",
	"BAGGED",
	"No booking info found",
	"Return to Sender",
	"LATE DELIVERY",
	"COMPLAINT DONE",
	"REDIRECT",
	"Money Issue",
	"Damage product",
	"PRICE ISSUE",
	"Trust Issues",
	"call busy",
	"Article not booked",
	"Booked",
] as const;
const followUp4Options = ["DELIVERED", "RETURNED"] as const;

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});
const dateTimeFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	hour: "2-digit",
	minute: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

const statusTone = (status: string) => {
	if (status === "delivered") {
		return "success";
	}

	if (
		status === "cancelled" ||
		status === "return_in_transit" ||
		status === "return_in_warehouse"
	) {
		return "danger";
	}

	if (status === "created" || status === "confirmed") {
		return "warning";
	}

	return "neutral";
};

const formatOrderStatus = (status: string) => status.replaceAll("_", " ");

const startOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(0, 0, 0, 0);
	return nextDate;
};

const endOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(23, 59, 59, 999);
	return nextDate;
};

const getRoleHomePath = (role: string) => {
	switch (role) {
		case "admin":
		case "logistics":
			return "/orders/tracking";
		default:
			return "/dashboard";
	}
};

const sortValue = (order: TrackingOrder, key: TrackingSortKey) => {
	if (key === "createdAt") {
		return new Date(order.createdAt).getTime();
	}

	return order[key] ?? "";
};

const getFollowUpValues = (order: TrackingOrder, slot: FollowUpSlot) =>
	order[`followUp${slot}Text`] ?? [];

const getFollowUpOptionsForSlot = (slot: FollowUpSlot, options: string[]) => {
	if (slot === 4) {
		return [...followUp4Options];
	}

	return options;
};

const getLastFollowUpUpdatedAt = (order: TrackingOrder) => {
	let latestTimestamp = 0;

	for (const slot of [1, 2, 3, 4] as const) {
		const value = order[`followUp${slot}UpdatedAt`];
		if (!value) {
			continue;
		}

		const timestamp = new Date(value).getTime();
		if (Number.isFinite(timestamp) && timestamp > latestTimestamp) {
			latestTimestamp = timestamp;
		}
	}

	return latestTimestamp ? new Date(latestTimestamp) : null;
};

const normalizeFollowUpValues = (
	value: null | string | string[] | undefined
) => {
	if (Array.isArray(value)) {
		return value.filter(
			(item): item is string =>
				typeof item === "string" && item.trim().length > 0
		);
	}

	if (typeof value === "string" && value.trim()) {
		return [value.trim()];
	}

	return [];
};

const normalizeTrackingOrder = (order: TrackingOrder): TrackingOrder => ({
	...order,
	followUp1Text: normalizeFollowUpValues(order.followUp1Text),
	followUp2Text: normalizeFollowUpValues(order.followUp2Text),
	followUp3Text: normalizeFollowUpValues(order.followUp3Text),
	followUp4Text: normalizeFollowUpValues(order.followUp4Text),
});

const csvValueEscapePattern = /[",\n\r]/;

const escapeCsvValue = (value: null | number | string): string => {
	const text = value === null ? "" : String(value);
	return csvValueEscapePattern.test(text)
		? `"${text.replaceAll('"', '""')}"`
		: text;
};

const downloadTrackingCsv = (orders: TrackingOrder[]): void => {
	const headers = [
		"Order ID",
		"Order date",
		"Consignment",
		"Farmer name",
		"Farmer mobile",
		"Farmer address",
		"Order status",
		"COD",
		"Last updated",
		"Follow up 1",
		"Follow up 2",
		"Follow up 3",
		"Follow up 4",
	];
	const rows = orders.map((order) => [
		order.orderId ?? "Pending confirmation",
		new Date(order.createdAt).toISOString(),
		order.consignmentNumber ?? "",
		order.farmerName,
		order.farmerPrimaryMobileNumber,
		order.farmerAddress,
		formatOrderStatus(order.status),
		"",
		getLastFollowUpUpdatedAt(order)?.toISOString() ?? "",
		getFollowUpValues(order, 1).join("; "),
		getFollowUpValues(order, 2).join("; "),
		getFollowUpValues(order, 3).join("; "),
		getFollowUpValues(order, 4).join("; "),
	]);
	const csv = `\uFEFF${[headers, ...rows]
		.map((row) => row.map(escapeCsvValue).join(","))
		.join("\n")}`;
	const url = URL.createObjectURL(
		new Blob([csv], { type: "text/csv;charset=utf-8" })
	);
	const link = document.createElement("a");
	link.href = url;
	link.download = "order-tracking-export.csv";
	link.click();
	URL.revokeObjectURL(url);
};

const FollowUpCombobox = ({
	disabled,
	onChange,
	options,
	value,
}: {
	disabled: boolean;
	onChange: (value: string[]) => void;
	options: string[];
	value: string[];
}) => {
	const anchorRef = useComboboxAnchor();

	return (
		<Combobox
			items={options}
			multiple
			onValueChange={(nextValue) => {
				onChange(Array.isArray(nextValue) ? nextValue : []);
			}}
			value={value}
		>
			<ComboboxChips
				className="relative min-h-9 rounded-xl pr-8"
				ref={anchorRef}
			>
				{value.map((item) => (
					<ComboboxChip key={item}>{item}</ComboboxChip>
				))}
				<ComboboxChipsInput
					aria-label="Select follow-up options"
					disabled={disabled}
					placeholder={value.length > 0 ? "" : "Select"}
				/>
				<ChevronDownIcon className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-muted-foreground" />
			</ComboboxChips>
			<ComboboxContent anchor={anchorRef} className="rounded-2xl">
				<ComboboxEmpty>No options found.</ComboboxEmpty>
				<ComboboxList>
					{options.map((option) => (
						<ComboboxItem key={option} value={option}>
							{option}
						</ComboboxItem>
					))}
				</ComboboxList>
			</ComboboxContent>
		</Combobox>
	);
};

export default function OrderTrackingPage() {
	const router = useRouter();
	const { data: session, isPending } = authClient.useSession();
	const isAdmin =
		session?.user && "role" in session.user
			? session.user.role === "admin"
			: false;
	const [orders, setOrders] = useState<TrackingOrder[]>([]);
	const [errorMessage, setErrorMessage] = useState("");
	const [isLoading, setIsLoading] = useState(true);
	const [sortBy, setSortBy] = useState<TrackingSortKey>("createdAt");
	const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] =
		useState<(typeof pageSizeOptions)[number]>(10);
	const [statusFilter, setStatusFilter] = useState<FilterValue>("all");
	const [followUpFilter, setFollowUpFilter] = useState<FilterValue>("all");
	const [dateFrom, setDateFrom] = useState<Date>();
	const [dateTo, setDateTo] = useState<Date>();
	const [savingFollowUpKey, setSavingFollowUpKey] = useState<string | null>(
		null
	);
	const followUpDebouncersRef = useRef<
		Map<string, LiteDebouncer<(values: string[]) => void>>
	>(new Map());

	useEffect(() => {
		if (!(session?.user && "role" in session.user)) {
			return;
		}

		const role =
			typeof session.user.role === "string" ? session.user.role : null;
		if (!role) {
			return;
		}

		if (!(role === "admin" || role === "logistics")) {
			router.replace(getRoleHomePath(role));
		}
	}, [router, session]);

	const loadOrders = useCallback(async () => {
		setErrorMessage("");
		setIsLoading(true);
		try {
			const data =
				await fetchOrdersClientApi<TrackingOrdersResponse>("/tracking");
			setOrders(data.orders.map(normalizeTrackingOrder));
		} catch (error) {
			const message =
				error instanceof Error
					? error.message
					: "Failed to load order tracking";
			setErrorMessage(message);
			toast.error(message);
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		loadOrders().catch(() => undefined);
	}, [loadOrders]);

	useEffect(
		() => () => {
			for (const debouncer of followUpDebouncersRef.current.values()) {
				debouncer.cancel();
			}
			followUpDebouncersRef.current.clear();
		},
		[]
	);

	const sortedOrders = useMemo(() => {
		const lowerDate = dateFrom ? startOfDay(dateFrom).getTime() : null;
		const upperDate = dateTo ? endOfDay(dateTo).getTime() : null;
		const filteredOrders = orders.filter((order) => {
			if (statusFilter !== "all" && order.status !== statusFilter) {
				return false;
			}

			const orderTime = new Date(order.createdAt).getTime();
			if (lowerDate !== null && orderTime < lowerDate) {
				return false;
			}

			if (upperDate !== null && orderTime > upperDate) {
				return false;
			}

			if (followUpFilter === "all") {
				return true;
			}

			return ([1, 2, 3, 4] as const).some((slot) =>
				getFollowUpValues(order, slot).includes(followUpFilter)
			);
		});
		const nextOrders = [...filteredOrders];

		nextOrders.sort((firstOrder, secondOrder) => {
			const firstValue = sortValue(firstOrder, sortBy);
			const secondValue = sortValue(secondOrder, sortBy);

			if (typeof firstValue === "number" && typeof secondValue === "number") {
				return sortDirection === "asc"
					? firstValue - secondValue
					: secondValue - firstValue;
			}

			const result = String(firstValue).localeCompare(String(secondValue));
			return sortDirection === "asc" ? result : -result;
		});

		return nextOrders;
	}, [
		dateFrom,
		dateTo,
		followUpFilter,
		orders,
		sortBy,
		sortDirection,
		statusFilter,
	]);
	const followUpOptions = useMemo(() => {
		const options = new Set<string>();
		for (const option of defaultFollowUpOptions) {
			const trimmed = option.trim();
			if (trimmed) {
				options.add(trimmed);
			}
		}
		for (const order of orders) {
			for (const slot of [1, 2, 3, 4] as const) {
				for (const value of getFollowUpValues(order, slot)) {
					const trimmed = value.trim();
					if (trimmed) {
						options.add(trimmed);
					}
				}
			}
		}

		return Array.from(options);
	}, [orders]);
	const statusOptions = useMemo(() => {
		const options = new Set<string>();
		for (const order of orders) {
			options.add(order.status);
		}

		return Array.from(options);
	}, [orders]);

	const totalPages = Math.max(1, Math.ceil(sortedOrders.length / pageSize));
	const safeCurrentPage = Math.min(currentPage, totalPages);
	const pageStartIndex = (safeCurrentPage - 1) * pageSize;
	const paginatedOrders = sortedOrders.slice(
		pageStartIndex,
		pageStartIndex + pageSize
	);
	const visibleTableRows = Math.max(1, paginatedOrders.length);
	const fillerRows = Math.max(0, TRACKING_TABLE_MIN_ROWS - visibleTableRows);

	useEffect(() => {
		if (currentPage > totalPages) {
			setCurrentPage(totalPages);
		}
	}, [currentPage, totalPages]);

	if (isPending) {
		return <PageSkeleton rows={5} showMetrics={false} />;
	}

	const toggleSort = (nextSortBy: TrackingSortKey) => {
		setCurrentPage(1);
		if (nextSortBy === sortBy) {
			setSortDirection((currentDirection) =>
				currentDirection === "asc" ? "desc" : "asc"
			);
			return;
		}

		setSortBy(nextSortBy);
		setSortDirection("desc");
	};
	const saveFollowUp = async (
		orderId: string,
		slot: 1 | 2 | 3 | 4,
		values: string[]
	) => {
		const savingKey = `${orderId}:${slot}`;
		setSavingFollowUpKey(savingKey);
		try {
			await patchOrdersClientApi<{
				followUp: string[];
				slot: number;
				success: true;
			}>(`/tracking/${orderId}/follow-up`, { slot, values });
			toast.success(`Follow up ${slot} saved`);
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to save follow-up"
			);
		} finally {
			setSavingFollowUpKey((currentKey) =>
				currentKey === savingKey ? null : currentKey
			);
		}
	};
	const updateFollowUp = (
		orderId: string,
		slot: FollowUpSlot,
		values: string[]
	) => {
		const savingKey = `${orderId}:${slot}`;
		const updatedAt = new Date().toISOString();
		setOrders((currentOrders) =>
			currentOrders.map((order) =>
				order.id === orderId
					? {
							...order,
							[`followUp${slot}Text`]: values,
							[`followUp${slot}UpdatedAt`]: updatedAt,
						}
					: order
			)
		);

		const existingDebouncer = followUpDebouncersRef.current.get(savingKey);
		if (existingDebouncer) {
			existingDebouncer.maybeExecute(values);
			return;
		}

		const nextDebouncer = new LiteDebouncer(
			(nextValues: string[]) => {
				saveFollowUp(orderId, slot, nextValues).catch(() => undefined);
			},
			{ wait: FOLLOW_UP_SAVE_WAIT_MS }
		);
		followUpDebouncersRef.current.set(savingKey, nextDebouncer);
		nextDebouncer.maybeExecute(values);
	};

	const sortIcon = (column: TrackingSortKey) => {
		if (sortBy !== column) {
			return <ArrowDownIcon className="size-3 opacity-30" />;
		}

		return (
			<ArrowDownIcon
				className={cn(
					"size-3 transition-transform",
					sortDirection === "asc" && "rotate-180"
				)}
			/>
		);
	};

	return (
		<PageShell width="wide">
			<PageHeader title="Order tracking">
				<p>
					Track every branch order and review post-order follow-up notes in one
					table.
				</p>
			</PageHeader>

			<section className="space-y-4">
				{isLoading ? (
					<LoadingState message="Loading order tracking..." />
				) : null}
				{!isLoading && errorMessage ? (
					<ErrorState message={errorMessage} title="Failed to load tracking" />
				) : null}
				{!(isLoading || errorMessage) && orders.length === 0 ? (
					<EmptyState title="No orders yet">
						Orders will appear here once advisors start creating them.
					</EmptyState>
				) : null}
				{!(isLoading || errorMessage) && orders.length > 0 ? (
					<div className="space-y-4">
						<div className="rounded-3xl border border-border/70 bg-card px-4 py-3 shadow-sm ring-1 ring-foreground/5">
							<div className="grid max-w-fit gap-3 sm:grid-cols-[180px_160px_160px_260px_88px_140px] sm:items-end">
								<div className="space-y-1.5">
									<label
										className="font-medium text-muted-foreground text-xs"
										htmlFor="tracking-status-filter"
									>
										Order status
									</label>
									<Select
										onValueChange={(value) => {
											setCurrentPage(1);
											setStatusFilter(value ?? "all");
										}}
										value={statusFilter}
									>
										<SelectTrigger
											className="!h-10 min-h-10 w-full rounded-2xl bg-background"
											id="tracking-status-filter"
										>
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value="all">All statuses</SelectItem>
											{statusOptions.map((status) => (
												<SelectItem key={status} value={status}>
													{formatOrderStatus(status)}
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								</div>
								<div className="space-y-1.5">
									<label
										className="font-medium text-muted-foreground text-xs"
										htmlFor="tracking-date-from"
									>
										Date from
									</label>
									<DatePicker
										className="!h-10 min-h-10 rounded-2xl bg-background"
										displayFormat="dd MMM yyyy"
										id="tracking-date-from"
										onChange={(date) => {
											setCurrentPage(1);
											setDateFrom(date);
										}}
										placeholder="Start date"
										value={dateFrom}
									/>
								</div>
								<div className="space-y-1.5">
									<label
										className="font-medium text-muted-foreground text-xs"
										htmlFor="tracking-date-to"
									>
										Date to
									</label>
									<DatePicker
										className="!h-10 min-h-10 rounded-2xl bg-background"
										displayFormat="dd MMM yyyy"
										id="tracking-date-to"
										onChange={(date) => {
											setCurrentPage(1);
											setDateTo(date);
										}}
										placeholder="End date"
										value={dateTo}
									/>
								</div>
								<div className="space-y-1.5">
									<label
										className="font-medium text-muted-foreground text-xs"
										htmlFor="tracking-follow-up-filter"
									>
										Follow-up status
									</label>
									<Select
										onValueChange={(value) => {
											setCurrentPage(1);
											setFollowUpFilter(value ?? "all");
										}}
										value={followUpFilter}
									>
										<SelectTrigger
											className="!h-10 min-h-10 w-full rounded-2xl bg-background"
											id="tracking-follow-up-filter"
										>
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											<SelectItem value="all">All follow-ups</SelectItem>
											{followUpOptions.map((option) => (
												<SelectItem key={option} value={option}>
													{option}
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								</div>
								<div className="space-y-1.5">
									<span
										aria-hidden
										className="block font-medium text-transparent text-xs"
									>
										Reset
									</span>
									<Button
										className="!h-10 min-h-10 w-full rounded-2xl px-4"
										onClick={() => {
											setCurrentPage(1);
											setStatusFilter("all");
											setDateFrom(undefined);
											setDateTo(undefined);
											setFollowUpFilter("all");
										}}
										type="button"
										variant="outline"
									>
										Reset
									</Button>
								</div>
								{isAdmin ? (
									<Button
										className="!h-10 min-h-10 rounded-2xl px-4"
										disabled={sortedOrders.length === 0}
										onClick={() => downloadTrackingCsv(sortedOrders)}
										type="button"
										variant="outline"
									>
										<DownloadIcon />
										Export CSV
									</Button>
								) : null}
							</div>
						</div>
						<div className="overflow-hidden rounded-4xl border bg-card shadow-md ring-1 ring-foreground/5">
							<Table
								className="min-w-[2280px] table-fixed"
								containerClassName="overflow-x-scroll"
							>
								<colgroup>
									<col className="w-[130px]" />
									<col className="w-[120px]" />
									<col className="w-[150px]" />
									<col className="w-[240px]" />
									<col className="w-[160px]" />
									<col className="w-[360px]" />
									<col className="w-[180px]" />
									<col className="w-[120px]" />
									<col className="w-[180px]" />
									<col className="w-[280px]" />
									<col className="w-[280px]" />
									<col className="w-[280px]" />
									<col className="w-[250px]" />
								</colgroup>
								<TableHeader>
									<TableRow className="hover:bg-transparent">
										<TableHead>
											<button
												className="inline-flex items-center gap-1 text-left font-medium"
												onClick={() => toggleSort("orderId")}
												type="button"
											>
												Order ID
												{sortIcon("orderId")}
											</button>
										</TableHead>
										<TableHead>
											<button
												className="inline-flex items-center gap-1 text-left font-medium"
												onClick={() => toggleSort("createdAt")}
												type="button"
											>
												Order date
												{sortIcon("createdAt")}
											</button>
										</TableHead>
										<TableHead>Consignment</TableHead>
										<TableHead>
											<button
												className="inline-flex items-center gap-1 text-left font-medium"
												onClick={() => toggleSort("farmerName")}
												type="button"
											>
												Farmer name
												{sortIcon("farmerName")}
											</button>
										</TableHead>
										<TableHead>Farmer mobile</TableHead>
										<TableHead>Farmer address</TableHead>
										<TableHead>
											<button
												className="inline-flex items-center gap-1 text-left font-medium"
												onClick={() => toggleSort("status")}
												type="button"
											>
												Order status
												{sortIcon("status")}
											</button>
										</TableHead>
										<TableHead>COD</TableHead>
										<TableHead>Last updated</TableHead>
										<TableHead>Follow up 1</TableHead>
										<TableHead>Follow up 2</TableHead>
										<TableHead>Follow up 3</TableHead>
										<TableHead>Follow up 4</TableHead>
									</TableRow>
								</TableHeader>
								<TableBody>
									{paginatedOrders.length > 0 ? (
										paginatedOrders.map((order) => {
											const lastUpdatedAt = getLastFollowUpUpdatedAt(order);

											return (
												<TableRow key={order.id}>
													<TableCell>
														<Link
															className="block max-w-full break-words font-medium underline-offset-4 hover:underline"
															href={`/orders/${order.id}`}
														>
															{order.orderId ?? "Pending"}
														</Link>
													</TableCell>
													<TableCell className="text-muted-foreground tabular-nums">
														{dateFormatter.format(new Date(order.createdAt))}
													</TableCell>
													<TableCell>
														{order.consignmentNumber ?? "—"}
													</TableCell>
													<TableCell className="whitespace-normal break-words text-muted-foreground leading-5">
														{order.farmerName}
													</TableCell>
													<TableCell className="whitespace-nowrap font-mono text-muted-foreground text-sm">
														{order.farmerPrimaryMobileNumber}
													</TableCell>
													<TableCell className="whitespace-normal break-words text-muted-foreground leading-5">
														{order.farmerAddress}
													</TableCell>
													<TableCell>
														<StatusPill tone={statusTone(order.status)}>
															{formatOrderStatus(order.status)}
														</StatusPill>
													</TableCell>
													<TableCell className="pl-4 text-muted-foreground">
														-
													</TableCell>
													<TableCell className="text-muted-foreground tabular-nums">
														{lastUpdatedAt
															? dateTimeFormatter.format(lastUpdatedAt)
															: "—"}
													</TableCell>
													<TableCell>
														<FollowUpCombobox
															disabled={savingFollowUpKey === `${order.id}:1`}
															onChange={(values) =>
																updateFollowUp(order.id, 1, values)
															}
															options={getFollowUpOptionsForSlot(
																1,
																followUpOptions
															)}
															value={getFollowUpValues(order, 1)}
														/>
													</TableCell>
													<TableCell>
														<FollowUpCombobox
															disabled={savingFollowUpKey === `${order.id}:2`}
															onChange={(values) =>
																updateFollowUp(order.id, 2, values)
															}
															options={getFollowUpOptionsForSlot(
																2,
																followUpOptions
															)}
															value={getFollowUpValues(order, 2)}
														/>
													</TableCell>
													<TableCell>
														<FollowUpCombobox
															disabled={savingFollowUpKey === `${order.id}:3`}
															onChange={(values) =>
																updateFollowUp(order.id, 3, values)
															}
															options={getFollowUpOptionsForSlot(
																3,
																followUpOptions
															)}
															value={getFollowUpValues(order, 3)}
														/>
													</TableCell>
													<TableCell>
														<FollowUpCombobox
															disabled={savingFollowUpKey === `${order.id}:4`}
															onChange={(values) =>
																updateFollowUp(order.id, 4, values)
															}
															options={getFollowUpOptionsForSlot(
																4,
																followUpOptions
															)}
															value={getFollowUpValues(order, 4)}
														/>
													</TableCell>
												</TableRow>
											);
										})
									) : (
										<TableRow>
											<TableCell
												className="h-16 text-muted-foreground"
												colSpan={13}
											>
												No orders match these filters.
											</TableCell>
										</TableRow>
									)}
									{Array.from({ length: fillerRows }).map((_, index) => (
										<TableRow
											aria-hidden
											className="hover:bg-transparent"
											key={index}
										>
											<TableCell className="h-16" colSpan={13}>
												&nbsp;
											</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
							<div className="grid gap-3 border-border/70 border-t bg-muted/20 px-4 py-3 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
								<div className="text-muted-foreground text-sm">
									{sortedOrders.length}{" "}
									{sortedOrders.length === 1 ? "record" : "records"}
								</div>
								<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
									<PaginationContent>
										<PaginationItem>
											<PaginationPrevious
												disabled={safeCurrentPage === 1}
												onClick={() =>
													setCurrentPage((page) => Math.max(1, page - 1))
												}
												type="button"
											/>
										</PaginationItem>
										<PaginationItem>
											<div className="flex h-9 items-center gap-2 px-2 text-sm">
												<span className="text-muted-foreground">Page</span>
												<Input
													className="h-8 w-16 text-center"
													inputMode="numeric"
													max={totalPages}
													min={1}
													onBlur={() => {
														setCurrentPage((page) =>
															Math.min(totalPages, Math.max(1, page))
														);
													}}
													onChange={(event) => {
														const nextPage = Number(event.target.value);
														if (!Number.isInteger(nextPage)) {
															return;
														}

														setCurrentPage(
															Math.min(totalPages, Math.max(1, nextPage))
														);
													}}
													value={String(safeCurrentPage)}
												/>
												<span className="text-muted-foreground">
													of {totalPages}
												</span>
											</div>
										</PaginationItem>
										<PaginationItem>
											<PaginationNext
												disabled={safeCurrentPage === totalPages}
												onClick={() =>
													setCurrentPage((page) =>
														Math.min(totalPages, page + 1)
													)
												}
												type="button"
											/>
										</PaginationItem>
									</PaginationContent>
								</Pagination>
								<div className="flex flex-wrap items-center gap-3 lg:justify-end">
									<span className="text-muted-foreground text-sm">
										Rows per page
									</span>
									<Select
										onValueChange={(value) => {
											setCurrentPage(1);
											setPageSize(
												Number(value) as (typeof pageSizeOptions)[number]
											);
										}}
										value={String(pageSize)}
									>
										<SelectTrigger className="w-20 bg-background" size="sm">
											<SelectValue />
										</SelectTrigger>
										<SelectContent>
											{pageSizeOptions.map((option) => (
												<SelectItem key={option} value={String(option)}>
													{option}
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								</div>
							</div>
						</div>
					</div>
				) : null}
			</section>
		</PageShell>
	);
}
