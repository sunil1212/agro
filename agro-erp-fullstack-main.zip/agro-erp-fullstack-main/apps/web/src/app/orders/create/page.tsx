"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useRef, useState } from "react";

import {
	ErrorState,
	LoadingState,
	PageHeader,
	PageShell,
} from "@/components/ui-patterns";
import type { OrderOptionsResponse } from "@/features/advisor/orders/create/order-types";
import type { OrderWorkspaceMode } from "@/features/advisor/orders/create/order-workspace";
import { OrderWorkspace } from "@/features/advisor/orders/create/order-workspace";
import { useOrderDraftStore } from "@/features/advisor/orders/create/use-order-draft-store";
import { fetchClientApi } from "@/lib/api-client";
import { createOrder } from "./actions";

export default function CreateOrderPage() {
	return (
		<Suspense fallback={<CreateOrderFallback />}>
			<CreateOrderClient />
		</Suspense>
	);
}

function CreateOrderClient() {
	const searchParams = useSearchParams();
	const presetFarmerId = searchParams.get("farmerId") ?? "";
	const [data, setData] = useState<OrderOptionsResponse | null>(null);
	const [errorMessage, setErrorMessage] = useState("");
	const [isLoading, setIsLoading] = useState(true);
	const hasLoadedOptionsRef = useRef(false);
	const hasHydrated = useOrderDraftStore((state) => state.hasHydrated);
	const setFarmerId = useOrderDraftStore((state) => state.setFarmerId);

	useEffect(() => {
		useOrderDraftStore.persist.rehydrate();
	}, []);

	useEffect(() => {
		const loadOptions = async () => {
			setErrorMessage("");
			setIsLoading(true);

			try {
				const result = await fetchClientApi<OrderOptionsResponse>(
					"orders",
					`/advisor/create-options${presetFarmerId ? `?farmerId=${encodeURIComponent(presetFarmerId)}` : ""}`
				);
				setData(result);

				const nextFarmerId =
					presetFarmerId ||
					result.selectedFarmer?.id ||
					result.primaryFarmers[0]?.id ||
					"";

				if (nextFarmerId) {
					setFarmerId(nextFarmerId);
				}
			} catch (error) {
				setErrorMessage(
					error instanceof Error
						? error.message
						: "Failed to load order options"
				);
			} finally {
				setIsLoading(false);
			}
		};

		if (hasHydrated && !hasLoadedOptionsRef.current) {
			loadOptions().catch(() => undefined);
			hasLoadedOptionsRef.current = true;
		}
	}, [hasHydrated, presetFarmerId, setFarmerId]);

	return (
		<PageShell width="wide">
			<PageHeader backHref="/orders" eyebrow="Advisor" title="Create order">
				<p>
					Select a farmer, build a product cart, then review totals in one
					sticky accordion workspace.
				</p>
			</PageHeader>
			{renderBody({ data, errorMessage, hasHydrated, isLoading })}
		</PageShell>
	);
}

function CreateOrderFallback() {
	return (
		<PageShell width="wide">
			<PageHeader backHref="/orders" eyebrow="Advisor" title="Create order" />
			<LoadingState message="Loading order workspace..." />
		</PageShell>
	);
}

function renderBody({
	data,
	errorMessage,
	hasHydrated,
	isLoading,
}: {
	data: OrderOptionsResponse | null;
	errorMessage: string;
	hasHydrated: boolean;
	isLoading: boolean;
}) {
	if (isLoading || !hasHydrated) {
		return <LoadingState message="Loading order workspace..." />;
	}

	if (errorMessage) {
		return <ErrorState message={errorMessage} title="Failed to load order" />;
	}

	if (!data) {
		return null;
	}

	const createMode: OrderWorkspaceMode = {
		kind: "create",
		onSubmit: async (input) => {
			await createOrder({
				...input,
				items: input.items.map((item) => ({
					...item,
					lineTotalAmount: item.lineTotalAmount,
					productId: item.productId,
					quantity: item.quantity,
					sellingPricePerUnit: item.sellingPricePerUnit,
					unitPricePerUnit: item.unitPricePerUnit,
				})),
			});
		},
	};

	return <OrderWorkspace data={data} mode={createMode} />;
}
