import { getClientApiUrl } from "@/lib/api-client";

export interface CreateOrderRequest {
	couponCode?: string;
	farmerId: string;
	items: Array<{
		lineTotalAmount: number;
		productId: string;
		quantity: number;
		sellingPricePerUnit: number;
		unitPricePerUnit: number;
	}>;
	paidAmount?: number;
	paymentMode: "cod" | "partial_payment" | "prepaid";
	shippingCharges: number;
	transactionScreenshotBase64?: string;
	transactionUtr?: string;
}

export interface UpdateOrderStatusRequest {
	status:
		| "created"
		| "confirmed"
		| "dispatched"
		| "delivered"
		| "return_in_transit"
		| "return_in_warehouse"
		| "cancelled";
}

async function parseResponse<T>(response: Response): Promise<T> {
	if (!response.ok) {
		const errorBody = (await response.json().catch(() => null)) as {
			message?: string;
		} | null;
		throw new Error(errorBody?.message ?? "Request failed");
	}

	return (await response.json()) as T;
}

export async function createOrder(request: CreateOrderRequest) {
	return parseResponse<{
		success: true;
		order: { id: string; orderId: null | string };
	}>(
		await fetch(getClientApiUrl("orders", "/advisor"), {
			body: JSON.stringify(request),
			credentials: "include",
			headers: { "Content-Type": "application/json" },
			method: "POST",
		})
	);
}

export async function updateOrderStatus(
	orderId: string,
	status: UpdateOrderStatusRequest["status"]
) {
	return parseResponse<{ success: true }>(
		await fetch(getClientApiUrl("orders", `/advisor/${orderId}/status`), {
			body: JSON.stringify({ status }),
			credentials: "include",
			headers: { "Content-Type": "application/json" },
			method: "PATCH",
		})
	);
}

export async function cancelOrder(orderId: string) {
	return parseResponse<{ success: true }>(
		await fetch(getClientApiUrl("orders", `/advisor/${orderId}/cancel`), {
			credentials: "include",
			method: "POST",
		})
	);
}
