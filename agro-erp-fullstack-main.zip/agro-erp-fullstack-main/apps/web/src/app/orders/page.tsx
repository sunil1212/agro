import { headers } from "next/headers";
import { QuickActionCard } from "@/components/quick-action-card";
import {
	EmptyState,
	PageHeader,
	PageShell,
	SectionHeader,
} from "@/components/ui-patterns";
import {
	type AdvisorOrderListItem,
	OrdersDataTable,
} from "@/features/advisor/orders/orders-data-table";
import { fetchServerApi } from "@/lib/api-server";
import { authClient } from "@/lib/auth-client";

interface OrdersResponse {
	orders: AdvisorOrderListItem[];
	success: true;
}

const whitespacePattern = /\s+/;

const getUserRole = (
	session: Awaited<ReturnType<typeof authClient.getSession>> | null
) => {
	if (!(session?.user && "role" in session.user)) {
		return null;
	}

	return typeof session.user.role === "string" ? session.user.role : null;
};

const getFirstName = (name: string) =>
	name.trim().split(whitespacePattern)[0] ?? "admin";

const OrdersPage = async () => {
	const requestHeaders = await headers();
	const [ordersData, session] = await Promise.all([
		fetchServerApi<OrdersResponse>("orders", "/advisor"),
		authClient.getSession({
			fetchOptions: {
				headers: { cookie: requestHeaders.get("cookie") ?? "" },
				throw: true,
			},
		}),
	]);
	const { orders } = ordersData;
	const userRole = getUserRole(session);

	return (
		<PageShell width="wide">
			<PageHeader title="Orders">
				<p>
					Browse advisor orders, confirm their status, and open details without
					losing context.
				</p>
			</PageHeader>
			<QuickActionCard
				actionLabel="Create order"
				description="Select a farmer, build the cart, and review checkout details before placing the order."
				href="/orders/create"
				title="Advisor order desk"
				tone="solid"
				variant="banner"
			/>
			<section className="space-y-4">
				<SectionHeader title="Order queue">
					Status gets a pill; amount and farmer stay readable without competing.
				</SectionHeader>
				{orders.length > 0 ? (
					<OrdersDataTable
						adminFirstName={
							userRole === "admin" && session?.user.name
								? getFirstName(session.user.name)
								: undefined
						}
						orders={orders}
					/>
				) : (
					<EmptyState
						actionHref="/orders/create"
						actionLabel="Create order"
						title="No orders yet"
					>
						Create the first advisor order once a farmer and product selection
						are ready.
					</EmptyState>
				)}
			</section>
		</PageShell>
	);
};

export default OrdersPage;
