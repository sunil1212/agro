import { OrderDetailsClient } from "@/features/advisor/orders/details/order-details-client";
import { fetchServerApi } from "@/lib/api-server";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

interface OrderDetailsPageProps {
	params: Promise<{
		orderId: string;
	}>;
}

interface OrderDetailsResponse {
	canCancel: boolean;
	items: Array<{
		id: string;
		lineTotalAmount: string;
		productName: string;
		productSku: string;
		quantity: number;
		sellingPricePerUnit: string;
		unitPricePerUnit: string;
	}>;
	order: {
		approvedAt: string | null;
		approvedByName: string | null;
		approvedByUserId: string | null;
		cancelledAt: string | null;
		cancelledByName: string | null;
		cancelledByUserId: string | null;
		cashbackAmount: string;
		consignmentNumber: string | null;
		createdAt: string;
		createdByName: string;
		createdByUserId: string;
		couponCode: string | null;
		couponDiscountAmount: string;
		dispatchedAt: string | null;
		estimatedDeliveryTat: string | null;
		farmerId: string;
		farmerMobile: string;
		farmerName: string;
		grandTotalAmount: string;
		id: string;
		orderId: null | string;
		paidAmount: string;
		paymentMode: string;
		pointsDiscountAmount: string;
		pointsUsed: number;
		promoDiscount: string;
		shippingCharges: string;
		status: string;
		subtotalAmount: string;
		totalCodAmount: string;
		totalDiscountAmount: string;
		transactionScreenshotBase64: string | null;
		transactionUtr: string | null;
	};
	success: true;
}

export default async function OrderDetailsPage({
	params,
}: OrderDetailsPageProps) {
	const { orderId } = await params;
	const data = await fetchServerApi<OrderDetailsResponse>(
		"orders",
		`/advisor/${orderId}`
	);
	return <OrderDetailsClient data={data} />;
}
