"use client";

import type { Route } from "next";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
	ErrorState,
	PageHeader,
	PageShell,
	PageSkeleton,
	StatusPill,
} from "@/components/ui-patterns";
import type { OrderWorkspaceMode } from "@/features/advisor/orders/create/order-workspace";
import { OrderWorkspace } from "@/features/advisor/orders/create/order-workspace";
import { authClient } from "@/lib/auth-client";

import {
	fetchOrderEdit,
	type OrderEditData,
	type OrderEditOptions,
	type OrderEditResponse,
	updateOrder,
} from "./actions";

const mapEditDataToOrderOptions = (
	editData: OrderEditData,
	options: OrderEditOptions
) => ({
	coupons: [],
	farmers: options.farmers.map((f) => ({
		...f,
		id: f.id,
		name: f.name,
		primaryMobileNumber: f.primaryMobileNumber,
	})),
	products: options.products.map((p) => ({
		...p,
		id: p.id,
		name: p.name,
		costPerUnit: p.costPerUnit,
		offerPrice: p.offerPrice,
		availableQuantity: p.availableQuantity,
		dispatchableQuantity: p.dispatchableQuantity,
		quantity: p.quantity,
		reservedQuantity: p.reservedQuantity,
	})),
	primaryFarmers: options.primaryFarmers,
	selectedFarmer:
		options.farmers.find((f) => f.id === editData.farmerId) ?? null,
	success: true as const,
});

export default function EditOrderPage() {
	const params = useParams<{ orderId: string }>();
	const router = useRouter();
	const { data: session, isPending } = authClient.useSession();
	const [editData, setEditData] = useState<OrderEditResponse | null>(null);
	const [error, setError] = useState<string | null>(null);
	const userRole =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: null;
	const editBackHref: Route =
		userRole === "team_leader" ? "/orders/advisors" : "/orders/verification";

	useEffect(() => {
		if (isPending) {
			return;
		}

		const allowedRoles = ["logistics", "admin", "team_leader"];
		if (!(session?.user && userRole && allowedRoles.includes(userRole))) {
			router.replace("/login");
			return;
		}

		let isMounted = true;

		const load = async () => {
			try {
				const data = await fetchOrderEdit(params.orderId);
				if (isMounted) {
					setEditData(data);
				}
			} catch (err) {
				if (isMounted) {
					setError(err instanceof Error ? err.message : "Failed to load order");
				}
			}
		};

		load().catch(() => undefined);

		return () => {
			isMounted = false;
		};
	}, [isPending, params.orderId, router, session, userRole]);

	if (isPending || !(editData || error)) {
		return <PageSkeleton rows={3} showMetrics={false} />;
	}

	if (error) {
		return (
			<PageShell width="wide">
				<PageHeader backHref={editBackHref} title="Edit order" />
				<ErrorState message={error} title="Unable to load order" />
			</PageShell>
		);
	}

	if (!editData) {
		return null;
	}

	if (!editData.canEdit) {
		return (
			<PageShell width="wide">
				<PageHeader backHref={editBackHref} title="Edit order" />
				<ErrorState
					message="This order can no longer be edited because its status changed."
					title="Order cannot be edited"
				/>
			</PageShell>
		);
	}

	const orderOptions = mapEditDataToOrderOptions(
		editData.order,
		editData.options
	);

	const editMode: OrderWorkspaceMode = {
		kind: "edit",
		initialData: {
			farmerId: editData.order.farmerId,
			items: editData.order.items.map((item) => ({
				costPerUnit: Number(item.sellingPricePerUnit),
				lineTotalAmount: Number(item.lineTotalAmount),
				name:
					editData.options.products.find(
						(product) => product.id === item.productId
					)?.name ?? item.productId,
				productId: item.productId,
				quantity: item.quantity,
				unitPricePerUnit: Number(item.unitPricePerUnit),
			})),
			paidAmount: Number(editData.order.paidAmount),
			paymentMode: editData.order.paymentMode,
			shippingCharges: Number(editData.order.shippingCharges),
			transactionScreenshotBase64:
				editData.order.transactionScreenshotBase64 ?? "",
			transactionUtr: editData.order.transactionUtr ?? "",
		},
		orderId: editData.order.id,
		onSubmit: async (input) => {
			await updateOrder(editData.order.id, input);
		},
		redirectHref: editBackHref,
	};

	const statusLabel =
		editData.order.status.charAt(0).toUpperCase() +
		editData.order.status.slice(1).replace(/_/g, " ");

	return (
		<PageShell width="wide">
			<PageHeader
				backHref={editBackHref}
				eyebrow={
					<span className="flex items-center gap-2">
						<span>
							{userRole === "team_leader"
								? "Team Leader"
								: "Logistics Executive"}
						</span>
						<StatusPill>{statusLabel}</StatusPill>
					</span>
				}
				title={`Edit order ${editData.order.orderId ?? "(pending confirmation)"}`}
			>
				<p className="max-w-2xl text-muted-foreground text-sm">
					{editData.order.consignmentNumber
						? `Consignment: ${editData.order.consignmentNumber}`
						: "No consignment assigned yet"}
				</p>
			</PageHeader>
			<OrderWorkspace data={orderOptions} mode={editMode} />
		</PageShell>
	);
}
