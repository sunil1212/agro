"use client";

import { getClientApiUrl } from "@/lib/api-client";

export interface OrderEditItem {
	lineTotalAmount: string;
	productId: string;
	quantity: number;
	sellingPricePerUnit: string;
	unitPricePerUnit: string;
}

export interface OrderEditData {
	consignmentNumber: string | null;
	farmerId: string;
	id: string;
	items: OrderEditItem[];
	orderId: string | null;
	paidAmount: string;
	paymentMode: "cod" | "partial_payment" | "prepaid";
	shippingCharges: string;
	status: string;
	transactionScreenshotBase64: string | null;
	transactionUtr: string | null;
}

export interface OrderEditOptions {
	farmers: Array<{
		id: string;
		name: string;
		pincode: string | null;
		primaryMobileNumber: string;
	}>;
	primaryFarmers: Array<{
		id: string;
		name: string;
		pincode: string | null;
		primaryMobileNumber: string;
	}>;
	products: Array<{
		availableQuantity: number;
		costPerUnit: string;
		dispatchableQuantity: number;
		id: string;
		name: string;
		offerPrice: string;
		quantity: number;
		reservedQuantity: number;
	}>;
}

export interface OrderEditResponse {
	canEdit: boolean;
	options: OrderEditOptions;
	order: OrderEditData;
	success: true;
}

export interface UpdateOrderRequest {
	farmerId: string;
	items: Array<{
		lineTotalAmount: number;
		productId: string;
		quantity: number;
		sellingPricePerUnit: number;
		unitPricePerUnit: number;
	}>;
	paidAmount?: number;
	paymentMode: "cod" | "partial_payment" | "prepaid";
	shippingCharges: number;
	transactionScreenshotBase64?: string;
	transactionUtr?: string;
}

export async function fetchOrderEdit(
	orderId: string
): Promise<OrderEditResponse> {
	const response = await fetch(
		getClientApiUrl("orders", `/verification/${orderId}/edit`),
		{ credentials: "include" }
	);

	if (!response.ok) {
		const error = await response.json().catch(() => null);
		throw new Error(error?.message ?? "Failed to load order edit data");
	}

	return (await response.json()) as OrderEditResponse;
}

export async function updateOrder(
	orderId: string,
	input: UpdateOrderRequest
): Promise<{ success: true }> {
	const response = await fetch(
		getClientApiUrl("orders", `/verification/${orderId}`),
		{
			method: "PATCH",
			headers: { "Content-Type": "application/json" },
			credentials: "include",
			body: JSON.stringify(input),
		}
	);

	if (!response.ok) {
		const error = await response.json().catch(() => null);
		throw new Error(error?.message ?? "Failed to update order");
	}

	return (await response.json()) as { success: true };
}
