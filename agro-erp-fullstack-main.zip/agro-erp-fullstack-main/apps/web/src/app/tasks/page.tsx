import { PageHeader, PageShell } from "@/components/ui-patterns";
import {
	type FarmerCropTaskItem,
	type TasksByCategory,
	TasksClient,
} from "@/features/advisor/tasks/tasks-client";
import { fetchServerApi } from "@/lib/api-server";

export default async function AdvisorTasksPage({
	searchParams,
}: {
	searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
	const params = await searchParams;
	const farmerId =
		typeof params.farmerId === "string" ? params.farmerId : undefined;
	const farmerQuery = farmerId
		? `&farmerId=${encodeURIComponent(farmerId)}`
		: "";
	const [currentTasks, backlogTasks, allTasks] = await Promise.all([
		fetchServerApi<{ success: true; tasks: FarmerCropTaskItem[] }>(
			"advisor-tasks",
			`/tasks?category=current${farmerQuery}`
		),
		fetchServerApi<{ success: true; tasks: FarmerCropTaskItem[] }>(
			"advisor-tasks",
			`/tasks?category=backlog${farmerQuery}`
		),
		fetchServerApi<{ success: true; tasks: FarmerCropTaskItem[] }>(
			"advisor-tasks",
			`/tasks?category=all${farmerQuery}`
		),
	]);

	const tasksByCategory: TasksByCategory = {
		all: allTasks.tasks,
		backlog: backlogTasks.tasks,
		current: currentTasks.tasks,
	};

	return (
		<PageShell>
			<PageHeader title={farmerId ? "Farmer tasks" : "Tasks"}>
				<p>
					{farmerId
						? "Scheduled crop follow-ups for the selected farmer."
						: "Scheduled crop follow-ups organised by category."}
				</p>
			</PageHeader>
			<section className="space-y-4">
				<TasksClient tasksByCategory={tasksByCategory} />
			</section>
		</PageShell>
	);
}
