"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import z from "zod";

import { PageHeader, PageShell } from "@/components/ui-patterns";
import { CropEditor } from "@/features/crops/crop-editor";
import type { CropFormValues } from "@/features/crops/types";

import { createManagedCrop } from "../../../features/crops/actions";

const cropSchema = z.object({
	name: z.string().trim().min(2, "Crop name must be at least 2 characters"),
	schedules: z
		.array(
			z
				.object({
					startDay: z
						.number()
						.int()
						.positive("Start day must be greater than 0"),
					endDay: z.number().int().positive("End day must be greater than 0"),
					instruction: z
						.string()
						.trim()
						.min(2, "Instruction must be at least 2 characters"),
				})
				.refine((value) => value.endDay >= value.startDay, {
					message: "End day must be after start day",
					path: ["endDay"],
				})
		)
		.min(1, "Add at least one schedule entry"),
});

const numberFromInput = (value: string) => Number(value || 0);

export default function CreateCropPage() {
	const router = useRouter();
	const [isSubmitting, setIsSubmitting] = useState(false);

	const handleSubmit = async (values: CropFormValues) => {
		const parsed = cropSchema.safeParse({
			name: values.name,
			schedules: values.schedules.map((schedule) => ({
				endDay: numberFromInput(schedule.endDay),
				instruction: schedule.instruction,
				startDay: numberFromInput(schedule.startDay),
			})),
		});

		if (!parsed.success) {
			toast.error(parsed.error.issues[0]?.message ?? "Check crop details");
			return;
		}

		setIsSubmitting(true);

		try {
			const result = await createManagedCrop({
				...parsed.data,
				pdfFile: values.pdfFile,
			});

			if (!result.success) {
				toast.error(result.success ? "Unable to create crop" : result.message);
				return;
			}

			toast.success("Crop created");
			router.refresh();
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<PageShell>
			<PageHeader backHref="/dashboard" eyebrow="Manager" title="Create crop">
				<p>
					Create a crop and define day-based follow-up instructions used to
					generate advisor tasks from farmer sowing dates.
				</p>
			</PageHeader>

			<div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]">
				<CropEditor
					backHref="/crops"
					isSubmitting={isSubmitting}
					onSubmit={handleSubmit}
					submitLabel="Create crop"
				/>
			</div>
		</PageShell>
	);
}
