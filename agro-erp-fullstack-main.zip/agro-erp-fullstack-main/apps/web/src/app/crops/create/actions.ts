"use client";

import { getClientApiUrl } from "@/lib/api-client";

export interface CreateCropInput {
	name: string;
	pdfFile?: File | null;
	schedules: Array<{
		endDay: number;
		instruction: string;
		startDay: number;
	}>;
}

export type CreateCropResult =
	| {
			success: true;
			crop: {
				id: string;
				name: string;
			};
	  }
	| {
			success: false;
			message: string;
	  };

export async function createManagedCrop(
	input: CreateCropInput
): Promise<CreateCropResult> {
	const body = input.pdfFile
		? (() => {
				const formData = new FormData();
				formData.set("name", input.name);
				formData.set("schedules", JSON.stringify(input.schedules));
				formData.set("pdf", input.pdfFile);
				return formData;
			})()
		: JSON.stringify({
				name: input.name,
				schedules: input.schedules,
			});
	const response = await fetch(getClientApiUrl("crops"), {
		body,
		credentials: "include",
		headers: input.pdfFile ? undefined : { "Content-Type": "application/json" },
		method: "POST",
	});

	return (await response.json()) as CreateCropResult;
}
