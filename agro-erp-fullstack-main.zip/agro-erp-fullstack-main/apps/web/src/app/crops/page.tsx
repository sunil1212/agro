"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuGroup,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from "@agro-erp-fullstack/ui/components/dropdown-menu";
import {
	ExternalLinkIcon,
	FileIcon,
	FileX2Icon,
	MoreHorizontalIcon,
	PencilIcon,
	PlusIcon,
} from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

import {
	EmptyState,
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
	Surface,
} from "@/components/ui-patterns";
import { getClientApiUrl } from "@/lib/api-client";
import { authClient } from "@/lib/auth-client";
import { isAdvisorRole } from "@/lib/roles";

import type { CropSummary } from "../../features/crops/types";

function getUserRole(
	session: ReturnType<typeof authClient.useSession>["data"]
): string {
	if (session?.user && "role" in session.user) {
		return typeof session.user.role === "string" ? session.user.role : "";
	}
	return "";
}

function getEyebrow(
	isSuperAdmin: boolean,
	isAdvisor: boolean
): string | undefined {
	if (isSuperAdmin) {
		return "Super Admin";
	}
	if (isAdvisor) {
		return "Advisor";
	}
	return;
}

export default function CropsPage() {
	const { data: session } = authClient.useSession();
	const userRole = getUserRole(session);
	const isSuperAdmin = userRole === "superadmin";
	const isAdvisor = isAdvisorRole(userRole) || userRole === "team_leader";

	const [crops, setCrops] = useState<CropSummary[]>([]);
	const [isLoading, setIsLoading] = useState(true);

	const fetchCrops = useCallback(async () => {
		try {
			const response = await fetch(getClientApiUrl("crops"), {
				credentials: "include",
			});
			const data = (await response.json()) as {
				crops: CropSummary[];
				success: true;
			};
			if (data.success) {
				setCrops(data.crops);
			}
		} catch {
			toast.error("Failed to load crops");
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		fetchCrops();
	}, [fetchCrops]);

	if (isLoading) {
		return (
			<PageShell>
				<PageHeader title="Crop catalogue" />
				<p className="text-muted-foreground">Loading crops...</p>
			</PageShell>
		);
	}

	return (
		<PageShell>
			<PageHeader
				eyebrow={getEyebrow(isSuperAdmin, isAdvisor)}
				title="Crop catalogue"
			>
				<p>
					{isSuperAdmin
						? "Manage crop templates, upload PDF guides, and control availability."
						: "Browse crop templates and open reference PDFs."}
				</p>
			</PageHeader>

			{isSuperAdmin ? (
				<Link href="/crops/create">
					<Button>
						<PlusIcon className="size-4" />
						Create crop
					</Button>
				</Link>
			) : null}

			<Surface>
				<SectionHeader
					action={
						<StatusPill>
							{crops.length} {crops.length === 1 ? "crop" : "crops"}
						</StatusPill>
					}
					title="All crops"
				/>

				{crops.length === 0 ? (
					<EmptyState
						actionHref={isSuperAdmin ? "/crops/create" : undefined}
						actionLabel={isSuperAdmin ? "Create crop" : undefined}
						title="No crops found"
					>
						{isSuperAdmin
							? "Get started by creating your first crop template."
							: "No active crops are available right now."}
					</EmptyState>
				) : (
					<CropTable crops={crops} isSuperAdmin={isSuperAdmin} />
				)}
			</Surface>
		</PageShell>
	);
}

const pdfUrl = (cropId: string) => getClientApiUrl("crops", `/${cropId}/pdf`);

interface CropTableProps {
	crops: CropSummary[];
	isSuperAdmin: boolean;
}

function CropActionsMenu({ cropItem }: { cropItem: CropSummary }) {
	const router = useRouter();
	const editHref = `/crops/${cropItem.id}/edit` as Route;

	return (
		<DropdownMenu>
			<DropdownMenuTrigger
				render={
					<Button size="icon" title="Open crop actions" variant="ghost" />
				}
			>
				<MoreHorizontalIcon className="size-4" />
			</DropdownMenuTrigger>
			<DropdownMenuContent align="end" className="bg-card">
				<DropdownMenuGroup>
					<DropdownMenuLabel className="px-2 py-1.5">Actions</DropdownMenuLabel>
					<DropdownMenuSeparator />
					<DropdownMenuItem onClick={() => router.push(editHref)}>
						<PencilIcon className="size-4" />
						Edit crop
					</DropdownMenuItem>
				</DropdownMenuGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}

function CropTable({ crops, isSuperAdmin }: CropTableProps) {
	return (
		<div className="mt-4 overflow-x-auto">
			<table className="w-full text-left text-sm">
				<thead>
					<tr className="border-border/60 border-b text-muted-foreground">
						<th className="pr-4 pb-3 font-medium">Name</th>
						<th className="pr-4 pb-3 font-medium">Schedules</th>
						<th className="pr-4 pb-3 font-medium">PDF</th>
						{isSuperAdmin ? (
							<th className="pr-4 pb-3 font-medium">Actions</th>
						) : null}
					</tr>
				</thead>
				<tbody>
					{crops.map((cropItem) => (
						<tr
							className="border-border/40 border-b last:border-0"
							key={cropItem.id}
						>
							<td className="py-3 pr-4 font-medium">{cropItem.name}</td>
							<td className="py-3 pr-4 text-muted-foreground">
								{cropItem.scheduleCount}
							</td>
							<td className="py-3 pr-4">
								{cropItem.hasPdf ? (
									<a
										className="inline-flex items-center gap-1.5 text-primary transition hover:text-primary/80"
										href={pdfUrl(cropItem.id)}
										rel="noopener noreferrer"
										target="_blank"
									>
										<FileIcon className="size-4" />
										<span className="max-w-32 truncate">
											{cropItem.pdfOriginalName ?? "Open PDF"}
										</span>
										<ExternalLinkIcon className="size-3.5" />
									</a>
								) : (
									<span className="inline-flex items-center gap-1.5 text-muted-foreground/50">
										<FileX2Icon className="size-4" />
										<span className="text-xs">No PDF</span>
									</span>
								)}
							</td>
							{isSuperAdmin ? (
								<td className="py-3">
									<CropActionsMenu cropItem={cropItem} />
								</td>
							) : null}
						</tr>
					))}
				</tbody>
			</table>
		</div>
	);
}
