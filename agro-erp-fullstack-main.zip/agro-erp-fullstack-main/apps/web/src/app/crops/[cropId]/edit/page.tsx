"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import z from "zod";

import { PageHeader, PageShell } from "@/components/ui-patterns";
import { CropEditor } from "@/features/crops/crop-editor";
import type { CropDetail, CropFormValues } from "@/features/crops/types";
import { getClientApiUrl } from "@/lib/api-client";
import { authClient } from "@/lib/auth-client";

import { updateManagedCrop } from "../../../../features/crops/actions";

function getRole(
	session: ReturnType<typeof authClient.useSession>["data"]
): string {
	if (session?.user && "role" in session.user) {
		return typeof session.user.role === "string" ? session.user.role : "";
	}
	return "";
}

const cropSchema = z.object({
	name: z.string().trim().min(2, "Crop name must be at least 2 characters"),
	schedules: z
		.array(
			z
				.object({
					startDay: z
						.number()
						.int()
						.positive("Start day must be greater than 0"),
					endDay: z.number().int().positive("End day must be greater than 0"),
					instruction: z
						.string()
						.trim()
						.min(2, "Instruction must be at least 2 characters"),
				})
				.refine((value) => value.endDay >= value.startDay, {
					message: "End day must be after start day",
					path: ["endDay"],
				})
		)
		.min(1, "Add at least one schedule entry"),
});

const numberFromInput = (value: string) => Number(value || 0);

export default function EditCropPage() {
	const params = useParams();
	const router = useRouter();
	const cropId = params.cropId as string;

	const { data: session } = authClient.useSession();
	const userRole = getRole(session);

	const [cropData, setCropData] = useState<CropDetail | null>(null);
	const [isLoading, setIsLoading] = useState(true);
	const [isSubmitting, setIsSubmitting] = useState(false);

	useEffect(() => {
		if (userRole && userRole !== "superadmin") {
			router.replace("/crops");
			return;
		}
	}, [userRole, router]);

	useEffect(() => {
		const fetchCrop = async () => {
			try {
				const response = await fetch(getClientApiUrl("crops", `/${cropId}`), {
					credentials: "include",
				});
				const data = (await response.json()) as {
					crop: CropDetail;
					success: true;
				};
				if (data.success) {
					setCropData(data.crop);
				} else {
					toast.error("Crop not found");
					router.replace("/crops");
				}
			} catch {
				toast.error("Failed to load crop");
				router.replace("/crops");
			} finally {
				setIsLoading(false);
			}
		};

		if (cropId) {
			fetchCrop();
		}
	}, [cropId, router]);

	const handleSubmit = async (values: CropFormValues) => {
		const parsed = cropSchema.safeParse({
			name: values.name,
			schedules: values.schedules.map((schedule) => ({
				endDay: numberFromInput(schedule.endDay),
				instruction: schedule.instruction,
				startDay: numberFromInput(schedule.startDay),
			})),
		});

		if (!parsed.success) {
			toast.error(parsed.error.issues[0]?.message ?? "Check crop details");
			return;
		}

		setIsSubmitting(true);

		try {
			const result = await updateManagedCrop(cropId, {
				...parsed.data,
				pdfFile: values.pdfFile,
			});

			if (!result.success) {
				toast.error(
					(result as { message?: string }).message ?? "Failed to update crop"
				);
				return;
			}

			toast.success("Crop updated");
			router.refresh();
			router.push("/crops");
		} finally {
			setIsSubmitting(false);
		}
	};

	if (isLoading) {
		return (
			<PageShell>
				<PageHeader title="Edit crop" />
				<p className="text-muted-foreground">Loading crop details...</p>
			</PageShell>
		);
	}

	if (!cropData) {
		return (
			<PageShell>
				<PageHeader title="Edit crop" />
				<p className="text-muted-foreground">Crop not found.</p>
			</PageShell>
		);
	}

	return (
		<PageShell>
			<PageHeader backHref="/crops" eyebrow="Super Admin" title="Edit crop">
				<p>Update crop details and schedule entries.</p>
			</PageHeader>

			<div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]">
				<CropEditor
					backHref="/crops"
					initialData={{
						name: cropData.name,
						pdfOriginalName: cropData.pdfOriginalName,
						schedules: cropData.schedules
							.filter((s) => s.isActive)
							.map((s) => ({
								endDay: String(s.endDay),
								id: s.id,
								instruction: s.instruction,
								startDay: String(s.startDay),
							})),
					}}
					isSubmitting={isSubmitting}
					onSubmit={handleSubmit}
					submitLabel="Save changes"
				/>

				<div className="space-y-4">
					<div className="rounded-2xl border border-border/70 bg-card p-4 shadow-sm">
						<p className="font-medium text-muted-foreground text-xs uppercase tracking-wider">
							Status
						</p>
						<p className="mt-1 font-medium text-foreground text-sm">
							{cropData.isActive ? "Active" : "Inactive"}
						</p>
					</div>
					{cropData.pdfOriginalName ? (
						<div className="rounded-2xl border border-border/70 bg-card p-4 shadow-sm">
							<p className="font-medium text-muted-foreground text-xs uppercase tracking-wider">
								Current PDF
							</p>
							<p className="mt-1 max-w-40 truncate font-medium text-foreground text-sm">
								{cropData.pdfOriginalName}
							</p>
							<a
								className="mt-2 inline-flex items-center gap-1 text-primary text-xs transition hover:text-primary/80"
								href={getClientApiUrl("crops", `/${cropId}/pdf`)}
								rel="noopener noreferrer"
								target="_blank"
							>
								Open PDF
							</a>
						</div>
					) : null}
					<div className="rounded-2xl border border-border/70 bg-card p-4 shadow-sm">
						<p className="font-medium text-muted-foreground text-xs uppercase tracking-wider">
							Schedule entries
						</p>
						<p className="mt-1 font-medium text-foreground text-sm">
							{cropData.schedules.filter((s) => s.isActive).length} active
						</p>
					</div>
				</div>
			</div>
		</PageShell>
	);
}
