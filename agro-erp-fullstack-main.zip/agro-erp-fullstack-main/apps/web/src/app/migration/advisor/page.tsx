import { PageHeader, PageShell } from "@/components/ui-patterns";
import { AdvisorImportEditor } from "@/features/admin/advisors/advisor-import-editor";

export default function AdvisorMigrationPage() {
	return (
		<PageShell width="wide">
			<PageHeader
				backHref="/migration"
				eyebrow="Admin migration"
				title="Import advisor accounts"
			>
				<p>
					Paste or drop a CSV of agent names, review the generated logins, then
					create every unique advisor through Better Auth.
				</p>
			</PageHeader>
			<AdvisorImportEditor />
		</PageShell>
	);
}
