import { PageHeader, PageShell } from "@/components/ui-patterns";
import { OrderImportEditor } from "@/features/admin/orders/order-import-editor";

export default function OrderMigrationPage() {
	return (
		<PageShell width="wide">
			<PageHeader
				backHref="/migration"
				eyebrow="Admin migration"
				title="Import orders"
			>
				<p>
					Paste or upload historical order rows, validate linked records, then
					create complete orders in bulk.
				</p>
			</PageHeader>
			<OrderImportEditor />
		</PageShell>
	);
}
