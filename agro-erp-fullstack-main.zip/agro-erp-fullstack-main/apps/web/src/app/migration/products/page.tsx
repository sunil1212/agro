import type { Route } from "next";
import { PageHeader, PageShell } from "@/components/ui-patterns";
import { ProductImportEditor } from "@/features/admin/products/product-import-editor";

export default function ProductMigrationPage() {
	return (
		<PageShell width="wide">
			<PageHeader
				backHref={"/migration" as Route}
				eyebrow="Admin migration"
				title="Import products"
			>
				<p>
					Upload the product master CSV, review validated rows, then write the
					catalog and opening stock in one transaction.
				</p>
			</PageHeader>
			<ProductImportEditor />
		</PageShell>
	);
}
