"use client";

import {
	FileSpreadsheetIcon,
	ShoppingCartIcon,
	SproutIcon,
	UsersIcon,
} from "lucide-react";
import { QuickActionCard } from "@/components/quick-action-card";
import { PageShell, SectionHeader } from "@/components/ui-patterns";
import { authClient } from "@/lib/auth-client";

export default function MigrationHubPage() {
	const { data: session } = authClient.useSession();
	const role =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: null;

	return (
		<PageShell width="wide">
			<SectionHeader title="Migration">
				Import data from spreadsheets into the system.
			</SectionHeader>
			<div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
				{role === "admin" ? (
					<>
						<QuickActionCard
							actionLabel="Import"
							description="Upload a CSV of agent names, review generated logins, then create advisor accounts in bulk."
							href={"/migration/advisor" as never}
							icon={<UsersIcon className="size-5" />}
							title="Advisor import"
						/>
						<QuickActionCard
							actionLabel="Import"
							description="Paste or upload farmer data, validate advisor mappings, then create farmers in bulk."
							href={"/migration/farmer" as never}
							icon={<SproutIcon className="size-5" />}
							title="Farmer import"
						/>
						<QuickActionCard
							actionLabel="Import"
							description="Paste or upload historical order rows, validate linked records, then create complete orders in bulk."
							href={"/migration/orders" as never}
							icon={<ShoppingCartIcon className="size-5" />}
							title="Order import"
						/>
					</>
				) : null}
				{role === "superadmin" ? (
					<QuickActionCard
						actionLabel="Import"
						description="Upload the product master CSV, review validated rows, then write the catalog and opening stock in one transaction."
						href={"/migration/products" as never}
						icon={<FileSpreadsheetIcon className="size-5" />}
						title="Product import"
					/>
				) : null}
			</div>
		</PageShell>
	);
}
