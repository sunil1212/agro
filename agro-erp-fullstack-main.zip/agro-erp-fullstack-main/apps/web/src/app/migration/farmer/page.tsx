import { PageHeader, PageShell } from "@/components/ui-patterns";
import { FarmerImportEditor } from "@/features/admin/farmers/farmer-import-editor";

export default function FarmerMigrationPage() {
	return (
		<PageShell width="wide">
			<PageHeader
				backHref="/migration"
				eyebrow="Admin migration"
				title="Import farmers"
			>
				<p>
					Paste or upload farmer data, validate advisor mappings, then create
					farmers in bulk.
				</p>
			</PageHeader>
			<FarmerImportEditor />
		</PageShell>
	);
}
