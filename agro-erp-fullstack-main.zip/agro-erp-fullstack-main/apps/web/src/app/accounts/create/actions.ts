"use client";

import { getClientApiUrl } from "@/lib/api-client";

const assignableRoles = [
	"admin",
	"team_leader",
	"advisor",
	"warehouse",
	"logistics",
] as const;

export type AssignableRole = (typeof assignableRoles)[number];
export const uiAssignableRoles = [
	"admin",
	"team_leader",
	"advisor",
	"senior_advisor",
	"warehouse",
	"logistics",
] as const;
export type UiAssignableRole = (typeof uiAssignableRoles)[number];

export interface CreateManagedAccountInput {
	dailySalesTarget: number;
	email: string;
	managerCode: null | string;
	monthlySalesTarget: number;
	name: string;
	password: string;
	role: AssignableRole;
	teamLeaderId?: null | string;
	title: string;
}

export type CreateManagedAccountResult =
	| {
			success: true;
			account: CreateManagedAccountInput;
	  }
	| {
			success: false;
			message: string;
	  };

export interface ManagedAccountOption {
	id: string;
	name: string;
	role: AssignableRole;
}

export async function createManagedAccount(
	input: CreateManagedAccountInput
): Promise<CreateManagedAccountResult> {
	const response = await fetch(getClientApiUrl("accounts"), {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		credentials: "include",
		body: JSON.stringify(input),
	});

	return (await response.json()) as CreateManagedAccountResult;
}

export async function fetchManagedAccountOptions(): Promise<
	ManagedAccountOption[]
> {
	const response = await fetch(getClientApiUrl("accounts"), {
		credentials: "include",
	});

	if (!response.ok) {
		return [];
	}

	const result = (await response.json()) as {
		accounts?: ManagedAccountOption[];
		success: boolean;
	};

	return result.accounts ?? [];
}
