"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle,
} from "@agro-erp-fullstack/ui/components/card";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { useForm } from "@tanstack/react-form";
import { CopyIcon, KeyRoundIcon, RefreshCwIcon } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import z from "zod";
import { PageHeader, PageShell } from "@/components/ui-patterns";
import { authClient } from "@/lib/auth-client";
import { getRoleLabel, isAdvisorLikeRole, isAdvisorRole } from "@/lib/roles";

import {
	type AssignableRole,
	type CreateManagedAccountResult,
	createManagedAccount,
	fetchManagedAccountOptions,
	type ManagedAccountOption,
	type UiAssignableRole,
} from "./actions";

const adminAssignableRoles = [
	"team_leader",
	"advisor",
	"senior_advisor",
	"logistics",
] as const;
const superAdminAssignableRoles = ["admin", "warehouse"] as const;
const formRoleOptions = [
	...superAdminAssignableRoles,
	...adminAssignableRoles,
] as const satisfies readonly UiAssignableRole[];

const getAccountTitleForRole = (role: UiAssignableRole): string => {
	if (role === "senior_advisor") {
		return "Senior Advisor";
	}

	if (role === "advisor") {
		return "Advisor";
	}

	return getRoleLabel(role);
};

const getBackendRoleForFormRole = (role: UiAssignableRole): AssignableRole =>
	role === "senior_advisor" ? "advisor" : role;

const getDisplayRole = (
	role: AssignableRole,
	title: string
): AssignableRole | UiAssignableRole =>
	role === "advisor" && title === "Senior Advisor" ? "senior_advisor" : role;

const formSchema = z
	.object({
		name: z.string().trim().min(2, "Name must be at least 2 characters"),
		email: z.email("Enter a valid email address"),
		managerCode: z.string().trim(),
		password: z.string().min(8, "Password must be at least 8 characters"),
		role: z.enum(formRoleOptions),
		title: z.string().trim().min(2, "Title is required"),
		dailySalesTarget: z.number().nonnegative(),
		monthlySalesTarget: z.number().nonnegative(),
		teamLeaderId: z.string().nullable(),
	})
	.refine((value) => value.role !== "admin" || value.managerCode.length >= 2, {
		message: "Admin code is required",
		path: ["managerCode"],
	});

type CreatedProfile = z.infer<typeof formSchema>;
type CreateAccountFormValues = z.infer<typeof formSchema>;

const renderFieldErrors = (errors: readonly unknown[]) =>
	errors.map((error, index) => (
		<p className="text-destructive text-sm" key={`${String(error)}-${index}`}>
			{String(error)}
		</p>
	));

const getErrorMessage = (result: CreateManagedAccountResult) =>
	result.success ? "Unable to create account" : result.message;

const generatePassword = () => {
	const alphabet =
		"ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";
	const generatedLength = 14;

	return Array.from({ length: generatedLength }, () => {
		const randomIndex = Math.floor(Math.random() * alphabet.length);
		return alphabet[randomIndex];
	}).join("");
};

const toProfileText = (profile: CreatedProfile) =>
	[
		`Name: ${profile.name}`,
		`Email: ${profile.email}`,
		`Role: ${getRoleLabel(profile.role)}`,
		`Title: ${profile.title}`,
		profile.role === "admin" ? `Admin code: ${profile.managerCode}` : null,
		isAdvisorRole(profile.role)
			? `Daily sales target: ${profile.dailySalesTarget ?? 0}, Monthly sales target: ${profile.monthlySalesTarget ?? 0}`
			: null,
		`Password: ${profile.password}`,
	]
		.filter(Boolean)
		.join("\n");

export default function CreateAccountPage() {
	const router = useRouter();
	const refreshRoute = () => {
		router.refresh();
	};
	const [createdProfile, setCreatedProfile] = useState<CreatedProfile | null>(
		null
	);
	const [accountOptions, setAccountOptions] = useState<ManagedAccountOption[]>(
		[]
	);
	const { data: session } = authClient.useSession();
	const userRole =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: "";
	const roleOptions =
		userRole === "superadmin"
			? superAdminAssignableRoles
			: adminAssignableRoles;
	const defaultRole: UiAssignableRole =
		userRole === "superadmin" ? "admin" : "advisor";
	const roleLabel = userRole === "superadmin" ? "Super Admin" : "Admin";
	const teamLeaderOptions = useMemo(
		() =>
			accountOptions
				.filter((account) => account.role === "team_leader")
				.sort((left, right) => left.name.localeCompare(right.name)),
		[accountOptions]
	);

	useEffect(() => {
		if (userRole !== "admin") {
			return;
		}

		let isMounted = true;

		fetchManagedAccountOptions()
			.then((accounts) => {
				if (isMounted) {
					setAccountOptions(accounts);
				}
			})
			.catch(() => undefined);

		return () => {
			isMounted = false;
		};
	}, [userRole]);

	const defaultValues: CreateAccountFormValues = {
		name: "",
		email: "",
		managerCode: "",
		password: "",
		role: defaultRole,
		title: getAccountTitleForRole(defaultRole),
		dailySalesTarget: 0,
		monthlySalesTarget: 0,
		teamLeaderId: null as string | null,
	};

	const form = useForm({
		defaultValues,
		onSubmit: async ({ value }) => {
			if (userRole !== "admin" && userRole !== "superadmin") {
				toast.error("You do not have permission to create accounts");
				return;
			}

			const result = await createManagedAccount({
				...value,
				role: getBackendRoleForFormRole(value.role),
				title: getAccountTitleForRole(value.role),
			});

			if (!result.success) {
				toast.error(getErrorMessage(result));
				return;
			}

			setCreatedProfile({
				...result.account,
				managerCode: result.account.managerCode ?? "",
				password: value.password,
				role: getDisplayRole(result.account.role, result.account.title),
				teamLeaderId: result.account.teamLeaderId ?? null,
				title: result.account.title,
			});
			toast.success("Account created");
			form.reset();
			refreshRoute();
		},
		validators: {
			onSubmit: formSchema,
		},
	});

	const handleCopyProfile = async () => {
		if (!createdProfile) {
			return;
		}

		await navigator.clipboard.writeText(toProfileText(createdProfile));
		toast.success("Profile copied");
	};

	return (
		<PageShell>
			<PageHeader
				backHref="/accounts"
				eyebrow={roleLabel}
				title="Create account"
			>
				<p>
					Create role-specific access and copy the generated profile once the
					account is ready.
				</p>
			</PageHeader>

			<div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
				<Card>
					<CardHeader>
						<CardTitle>Account details</CardTitle>
						<CardDescription>
							Create a login for one of the roles available to your account.
						</CardDescription>
					</CardHeader>
					<CardContent>
						<form
							className="space-y-5"
							onSubmit={(event) => {
								event.preventDefault();
								event.stopPropagation();
								form.handleSubmit();
							}}
						>
							<form.Field name="name">
								{(field) => (
									<div className="space-y-2">
										<Label htmlFor={field.name}>Full name</Label>
										<Input
											id={field.name}
											name={field.name}
											onBlur={field.handleBlur}
											onChange={(event) =>
												field.handleChange(event.target.value)
											}
											placeholder="Aman Verma"
											value={field.state.value}
										/>
										{renderFieldErrors(field.state.meta.errors)}
									</div>
								)}
							</form.Field>

							<form.Field name="email">
								{(field) => (
									<div className="space-y-2">
										<Label htmlFor={field.name}>Email address</Label>
										<Input
											id={field.name}
											name={field.name}
											onBlur={field.handleBlur}
											onChange={(event) =>
												field.handleChange(event.target.value)
											}
											placeholder="aman@example.com"
											type="email"
											value={field.state.value}
										/>
										{renderFieldErrors(field.state.meta.errors)}
									</div>
								)}
							</form.Field>

							<form.Field name="role">
								{(field) => (
									<div className="space-y-2">
										<Label htmlFor={field.name}>Role</Label>
										<div className="relative">
											<select
												className={cn(
													"h-9 w-full appearance-none rounded-lg border border-border bg-input/35 px-3 py-1 pr-10 text-sm outline-none transition-[color,box-shadow,background-color] focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
												)}
												id={field.name}
												name={field.name}
												onBlur={field.handleBlur}
												onChange={(event) => {
													const nextRole = event.target
														.value as UiAssignableRole;
													field.handleChange(nextRole);
													form.setFieldValue(
														"title",
														getAccountTitleForRole(nextRole)
													);
												}}
												value={field.state.value}
											>
												{roleOptions.map((role) => (
													<option key={role} value={role}>
														{getRoleLabel(role)}
													</option>
												))}
											</select>
											<div className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-muted-foreground text-sm">
												▾
											</div>
										</div>
										{renderFieldErrors(field.state.meta.errors)}
									</div>
								)}
							</form.Field>

							<form.Subscribe selector={(state) => state.values.role}>
								{(selectedRole) =>
									userRole === "superadmin" && selectedRole === "admin" ? (
										<form.Field name="managerCode">
											{(field) => (
												<div className="space-y-2">
													<Label htmlFor={field.name}>Admin code</Label>
													<Input
														id={field.name}
														name={field.name}
														onBlur={field.handleBlur}
														onChange={(event) =>
															field.handleChange(
																event.target.value.toUpperCase()
															)
														}
														placeholder="MGR-WEST"
														value={field.state.value}
													/>
													{renderFieldErrors(field.state.meta.errors)}
												</div>
											)}
										</form.Field>
									) : null
								}
							</form.Subscribe>

							<form.Subscribe selector={(state) => state.values.role}>
								{(selectedRole) =>
									isAdvisorLikeRole(selectedRole) ? (
										<div className="space-y-4">
											<div className="grid gap-4 sm:grid-cols-2">
												<form.Field name="dailySalesTarget">
													{(field) => (
														<div className="space-y-2">
															<Label htmlFor={field.name}>
																Daily sales target
															</Label>
															<Input
																id={field.name}
																min="0"
																name={field.name}
																onBlur={field.handleBlur}
																onChange={(event) =>
																	field.handleChange(
																		event.target.value
																			? Number(event.target.value)
																			: 0
																	)
																}
																placeholder="5000"
																step="0.01"
																type="number"
																value={field.state.value ?? 0}
															/>
															{renderFieldErrors(field.state.meta.errors)}
														</div>
													)}
												</form.Field>
												<form.Field name="monthlySalesTarget">
													{(field) => (
														<div className="space-y-2">
															<Label htmlFor={field.name}>
																Monthly sales target
															</Label>
															<Input
																id={field.name}
																min="0"
																name={field.name}
																onBlur={field.handleBlur}
																onChange={(event) =>
																	field.handleChange(
																		event.target.value
																			? Number(event.target.value)
																			: 0
																	)
																}
																placeholder="150000"
																step="0.01"
																type="number"
																value={field.state.value ?? 0}
															/>
															{renderFieldErrors(field.state.meta.errors)}
														</div>
													)}
												</form.Field>
											</div>
											{userRole === "admin" ? (
												<form.Field name="teamLeaderId">
													{(field) => (
														<div className="space-y-2">
															<Label htmlFor={field.name}>Team leader</Label>
															<select
																className={cn(
																	"h-9 w-full appearance-none rounded-lg border border-border bg-input/35 px-3 py-1 text-sm outline-none transition-[color,box-shadow,background-color] focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
																)}
																id={field.name}
																name={field.name}
																onBlur={field.handleBlur}
																onChange={(event) =>
																	field.handleChange(event.target.value || null)
																}
																value={field.state.value ?? ""}
															>
																<option value="">
																	No team leader assigned
																</option>
																{teamLeaderOptions.map((account) => (
																	<option key={account.id} value={account.id}>
																		{account.name}
																	</option>
																))}
															</select>
															{renderFieldErrors(field.state.meta.errors)}
														</div>
													)}
												</form.Field>
											) : null}
										</div>
									) : null
								}
							</form.Subscribe>

							<form.Field name="password">
								{(field) => (
									<div className="space-y-2">
										<div className="flex items-center justify-between gap-3">
											<Label htmlFor={field.name}>Password</Label>
											<Button
												onClick={() => field.handleChange(generatePassword())}
												size="sm"
												type="button"
												variant="outline"
											>
												<KeyRoundIcon />
												Generate random password
											</Button>
										</div>
										<Input
											id={field.name}
											name={field.name}
											onBlur={field.handleBlur}
											onChange={(event) =>
												field.handleChange(event.target.value)
											}
											placeholder="Enter a secure password"
											type="text"
											value={field.state.value}
										/>
										{renderFieldErrors(field.state.meta.errors)}
									</div>
								)}
							</form.Field>

							<form.Subscribe
								selector={(state) => ({
									canSubmit: state.canSubmit,
									isSubmitting: state.isSubmitting,
								})}
							>
								{({ canSubmit, isSubmitting }) => (
									<div className="flex flex-wrap items-center gap-3 pt-2">
										<Button disabled={!canSubmit || isSubmitting} type="submit">
											{isSubmitting ? "Creating..." : "Create account"}
										</Button>
										<Button
											onClick={() => {
												form.reset();
												setCreatedProfile(null);
											}}
											type="button"
											variant="outline"
										>
											<RefreshCwIcon />
											Reset form
										</Button>
										<Link
											className="text-muted-foreground text-sm transition-colors hover:text-foreground"
											href="/accounts"
										>
											Back to all accounts
										</Link>
									</div>
								)}
							</form.Subscribe>
						</form>
					</CardContent>
				</Card>

				<Card size="sm">
					<CardHeader>
						<CardTitle>Created profile</CardTitle>
						<CardDescription>
							Copy the generated profile after a successful account creation.
						</CardDescription>
					</CardHeader>
					<CardContent className="space-y-4">
						{createdProfile ? (
							<>
								<div className="rounded-2xl border border-border bg-card p-4 text-sm shadow-sm">
									<p className="font-medium text-foreground">
										{createdProfile.name}
									</p>
									<p className="mt-1 text-muted-foreground">
										{createdProfile.email}
									</p>
									<p className="mt-3 text-muted-foreground">
										Role:{" "}
										<span className="font-medium text-foreground">
											{getRoleLabel(createdProfile.role)}
										</span>
									</p>
									<p className="mt-1 text-muted-foreground">
										Title:{" "}
										<span className="font-medium text-foreground">
											{createdProfile.title}
										</span>
									</p>
									{createdProfile.role === "admin" ? (
										<p className="mt-1 text-muted-foreground">
											Admin code:{" "}
											<span className="font-medium text-foreground">
												{createdProfile.managerCode}
											</span>
										</p>
									) : null}
									{isAdvisorRole(createdProfile.role) ? (
										<>
											<p className="mt-1 text-muted-foreground">
												Daily target:{" "}
												<span className="font-medium text-foreground">
													{new Intl.NumberFormat("en-IN", {
														currency: "INR",
														maximumFractionDigits: 0,
														style: "currency",
													}).format(createdProfile.dailySalesTarget ?? 0)}
												</span>
											</p>
											<p className="mt-1 text-muted-foreground">
												Monthly target:{" "}
												<span className="font-medium text-foreground">
													{new Intl.NumberFormat("en-IN", {
														currency: "INR",
														maximumFractionDigits: 0,
														style: "currency",
													}).format(createdProfile.monthlySalesTarget ?? 0)}
												</span>
											</p>
										</>
									) : null}
									<p className="mt-1 break-all text-muted-foreground">
										Password:{" "}
										<span className="font-medium text-foreground">
											{createdProfile.password}
										</span>
									</p>
								</div>
								<Button
									className="w-full"
									onClick={handleCopyProfile}
									type="button"
								>
									<CopyIcon />
									Copy profile
								</Button>
							</>
						) : (
							<div className="rounded-2xl border border-border border-dashed px-4 py-8 text-center text-muted-foreground text-sm">
								No profile yet. Create an account to copy its login details.
							</div>
						)}
					</CardContent>
				</Card>
			</div>
		</PageShell>
	);
}
