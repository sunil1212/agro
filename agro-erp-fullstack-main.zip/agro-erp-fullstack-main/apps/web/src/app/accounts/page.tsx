import { headers } from "next/headers";
import { QuickActionCard } from "@/components/quick-action-card";
import {
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
} from "@/components/ui-patterns";
import type { ManagedAccount } from "@/features/accounts/accounts-data-table";
import { AccountsDataTable } from "@/features/accounts/accounts-data-table";
import { fetchServerApi } from "@/lib/api-server";
import { authClient } from "@/lib/auth-client";

export const dynamic = "force-dynamic";

const getAccountsPageCopy = (
	userRole: string
): {
	eyebrow: string;
	mode: "manager" | "superadmin" | "team_leader";
	path: "/accounts" | "/advisors";
	sectionDescription: string;
	sectionTitle: string;
	showQuickAction: boolean;
	summary: string;
	title: string;
} => {
	if (userRole === "superadmin") {
		return {
			eyebrow: "Super Admin",
			mode: "superadmin",
			path: "/accounts",
			sectionDescription:
				"Use one role term per teammate so permissions stay easy to scan.",
			sectionTitle: "Platform access",
			showQuickAction: true,
			summary:
				"Review access, roles, and account creation dates from one consistent list.",
			title: "Accounts",
		};
	}

	if (userRole === "team_leader") {
		return {
			eyebrow: "Team Leader",
			mode: "team_leader",
			path: "/advisors",
			sectionDescription:
				"Use this view to scan titles, targets, and assignment dates.",
			sectionTitle: "Assigned advisors",
			showQuickAction: false,
			summary:
				"Review the advisors assigned to your team in the same account table layout.",
			title: "Advisors",
		};
	}

	return {
		eyebrow: "Manager",
		mode: "manager",
		path: "/accounts",
		sectionDescription:
			"Use one role term per teammate so permissions stay easy to scan.",
		sectionTitle: "Team access",
		showQuickAction: true,
		summary:
			"Review access, roles, and account creation dates from one consistent list.",
		title: "Accounts",
	};
};

export default async function AccountsPage() {
	const requestHeaders = await headers();
	const session = await authClient.getSession({
		fetchOptions: {
			headers: { cookie: requestHeaders.get("cookie") ?? "" },
			throw: true,
		},
	});
	const userRole =
		session?.user && "role" in session.user && session.user.role
			? String(session.user.role)
			: "";
	const pageCopy = getAccountsPageCopy(userRole);
	const { accounts } = await fetchServerApi<{
		accounts: ManagedAccount[];
		success: true;
	}>("accounts", pageCopy.path === "/accounts" ? "" : pageCopy.path);

	return (
		<PageShell className="max-w-[80vw]">
			<PageHeader eyebrow={pageCopy.eyebrow} title={pageCopy.title}>
				<p>{pageCopy.summary}</p>
			</PageHeader>
			{pageCopy.showQuickAction ? (
				<QuickActionCard
					actionLabel="Create new account"
					description={
						pageCopy.mode === "superadmin"
							? "Create new admin and warehouse accounts for the platform."
							: "Review every login and create new accounts for the operations team."
					}
					href="/accounts/create"
					title="Create account"
					tone="solid"
					variant="banner"
				/>
			) : null}

			<section className="space-y-4">
				<SectionHeader
					action={
						<StatusPill>
							{accounts.length} {accounts.length === 1 ? "record" : "records"}
						</StatusPill>
					}
					title={pageCopy.sectionTitle}
				>
					{pageCopy.sectionDescription}
				</SectionHeader>
				<AccountsDataTable accounts={accounts} mode={pageCopy.mode} />
			</section>
		</PageShell>
	);
}
