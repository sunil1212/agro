import type { Route } from "next";
import { PageHeader, PageShell } from "@/components/ui-patterns";
import { ConsignmentImportEditor } from "@/features/admin/consignments/consignment-import-editor";

export default function ImportConsignmentsPage() {
	return (
		<PageShell>
			<PageHeader
				backHref={"/consignments" as Route}
				eyebrow="Admin"
				title="Import consignments"
			>
				<p>
					Review and edit post office CSV rows before adding them to the
					available consignment pool.
				</p>
			</PageHeader>
			<ConsignmentImportEditor />
		</PageShell>
	);
}
