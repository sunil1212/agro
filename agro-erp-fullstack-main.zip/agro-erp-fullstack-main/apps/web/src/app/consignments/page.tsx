import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import type { Route } from "next";
import Link from "next/link";
import {
	EmptyState,
	PageHeader,
	PageShell,
	SectionHeader,
} from "@/components/ui-patterns";
import type { ConsignmentRecord } from "@/features/admin/consignments/consignment-types";
import { ConsignmentsTable } from "@/features/admin/consignments/consignments-table";
import { fetchServerApi } from "@/lib/api-server";

export const dynamic = "force-dynamic";

export default async function ConsignmentsPage() {
	const { consignments } = await fetchServerApi<{
		consignments: ConsignmentRecord[];
		success: true;
	}>("consignments");

	return (
		<PageShell>
			<PageHeader eyebrow="Admin" title="Consignment">
				<p>
					Track postal consignment numbers and their availability for logistics
					approval.
				</p>
			</PageHeader>

			<section className="space-y-4">
				<SectionHeader
					action={
						<Link
							className={cn(buttonVariants({ size: "sm" }))}
							href={"/consignments/import" as Route}
						>
							Add import
						</Link>
					}
					title="Current consignment numbers"
				/>
				{consignments.length > 0 ? (
					<ConsignmentsTable consignments={consignments} />
				) : (
					<EmptyState
						actionHref={"/consignments/import" as Route}
						actionLabel="Add import"
						title="No consignment numbers"
					>
						Import the first CSV from the post office to start assigning numbers
						during logistics approval.
					</EmptyState>
				)}
			</section>
		</PageShell>
	);
}
