import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";

import "../index.css";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import Header from "@/components/header";
import Providers from "@/components/providers";

const geist = Geist({
	subsets: ["latin"],
	variable: "--font-sans",
});

const geistSans = Geist({
	variable: "--font-geist-sans",
	subsets: ["latin"],
});

const geistMono = Geist_Mono({
	variable: "--font-geist-mono",
	subsets: ["latin"],
});

export const metadata: Metadata = {
	title: "Growmize Pvt Ltd",
	description: "Growmize Pvt Ltd Operations Dashboard",
};

export default function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	return (
		<html
			className={cn("font-sans", geist.variable)}
			data-scroll-behavior="smooth"
			lang="en"
			suppressHydrationWarning
		>
			<body
				className={`${geistSans.variable} ${geistMono.variable} antialiased`}
			>
				<Providers>
					<div className="grid h-svh grid-rows-[auto_minmax(0,1fr)]">
						<Header />
						<div className="min-h-0 overflow-y-auto">{children}</div>
					</div>
				</Providers>
				{/* impeccable-live-start */}
				<script src="http://localhost:8401/live.js" />
				{/* impeccable-live-end */}
			</body>
		</html>
	);
}
