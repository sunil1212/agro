"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Checkbox } from "@agro-erp-fullstack/ui/components/checkbox";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuRadioGroup,
	DropdownMenuRadioItem,
	DropdownMenuTrigger,
} from "@agro-erp-fullstack/ui/components/dropdown-menu";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import { Skeleton } from "@agro-erp-fullstack/ui/components/skeleton";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import {
	ArrowRightIcon,
	CheckCircle2Icon,
	ChevronDownIcon,
	ClipboardListIcon,
	PackageIcon,
	PlusIcon,
	SearchIcon,
	SparklesIcon,
	TractorIcon,
} from "lucide-react";
import { useState } from "react";

import { QuickActionCard } from "@/components/quick-action-card";
import {
	EmptyState,
	FieldGroup,
	MetricCard,
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
	Surface,
} from "@/components/ui-patterns";

const priorityOptions = ["Low", "Medium", "High"] as const;
const designRules = [
	"Page shell: max-w-6xl, px-4 sm:px-6 lg:px-8, py-8 sm:py-10, gap-8.",
	"Major groups: gap-8. Card sections: gap-5 or gap-6. Field internals: gap-2.",
	"Headings: text-3xl/4xl for page titles, text-xl for sections, text-base for cards.",
	"Labels and metadata: text-xs, muted, uppercase tracking when scanning matters.",
	"Body copy: text-sm leading-6 for UI help, max-w-2xl for page descriptions.",
	"Cards use solid bg-card surfaces with subtle borders and shadows. Do not use transparent, frosted, blurred, or glow backgrounds for cards.",
	"One primary action per section. Use outline or ghost for secondary actions.",
] as const;

const sampleRows = [
	{
		meta: "Updated 12 May 2026",
		name: "Aman Verma",
		status: "Active",
		subtitle: "Nashik · 8 orders",
	},
	{
		meta: "Created 10 May 2026",
		name: "Premium rice seed",
		status: "In stock",
		subtitle: "240 units · INR 1,250 offer price",
	},
	{
		meta: "Review pending",
		name: "ORD-1042",
		status: "Pending",
		subtitle: "Savita Patil · INR 14,850 total",
	},
] as const;

export default function ScratchpadPage() {
	const [priority, setPriority] =
		useState<(typeof priorityOptions)[number]>("Medium");

	return (
		<PageShell>
			<PageHeader
				actions={
					<>
						<Button variant="outline">
							<SearchIcon className="size-4" />
							Search
						</Button>
						<Button>
							<PlusIcon className="size-4" />
							Primary action
						</Button>
					</>
				}
				eyebrow="UI contract"
				title="Agro ERP interface scratchpad"
			>
				<p>
					Use this page as the glanceable source for new UI. Keep the warm
					shadcn base, rounded cards, green primary accents, generous grouping,
					and scan-first typography.
				</p>
			</PageHeader>

			<section className="grid gap-4 sm:grid-cols-3">
				<MetricCard
					label="Spacing"
					trend="4 / 8 / 16 / 24 / 32 / 48"
					value="System"
				/>
				<MetricCard
					label="Type"
					trend="Tight headings, relaxed body copy"
					value="Clear"
				/>
				<MetricCard label="UX" trend="One obvious next action" value="Simple" />
			</section>

			<section className="grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(20rem,0.65fr)]">
				<div className="space-y-6">
					<QuickActionCard
						actionLabel="Open workflow"
						description="Primary page-level CTA. Use a banner when the action launches a core workflow and should be noticed before the list."
						href="/orders/create"
						icon={<ClipboardListIcon className="size-5" />}
						label="Primary workflow"
						title="Create an advisor order"
						tone="solid"
						variant="banner"
					/>

					<Surface className="space-y-6">
						<SectionHeader
							action={<StatusPill tone="success">Ready</StatusPill>}
							title="Form pattern"
						>
							Labels are close to inputs. Help text is short. Error and loading
							copy should say what happened and what to do next.
						</SectionHeader>

						<div className="grid gap-5 md:grid-cols-2">
							<FieldGroup
								description="Use the real-world term users recognize."
								label="Farmer name"
							>
								<Input placeholder="Aman Verma" />
							</FieldGroup>
							<FieldGroup
								description="Keep placeholders realistic, not instructional."
								label="Mobile number"
							>
								<Input placeholder="+91 98765 43210" type="tel" />
							</FieldGroup>
							<FieldGroup
								description="Prefer constrained controls."
								label="Visit date"
							>
								<DatePicker />
							</FieldGroup>
							<FieldGroup
								description="Dropdown labels stay plain."
								label="Priority"
							>
								<DropdownMenu>
									<DropdownMenuTrigger
										render={
											<Button
												className="w-full justify-between"
												variant="outline"
											>
												{priority}
												<ChevronDownIcon className="size-4" />
											</Button>
										}
									/>
									<DropdownMenuContent>
										<DropdownMenuRadioGroup
											onValueChange={(value) =>
												setPriority(value as (typeof priorityOptions)[number])
											}
											value={priority}
										>
											{priorityOptions.map((option) => (
												<DropdownMenuRadioItem key={option} value={option}>
													{option}
												</DropdownMenuRadioItem>
											))}
										</DropdownMenuRadioGroup>
									</DropdownMenuContent>
								</DropdownMenu>
							</FieldGroup>
						</div>

						<div className="rounded-3xl border border-border/70 bg-card p-4 shadow-sm">
							<Label className="mb-3">Product selection</Label>
							<div className="grid gap-2 sm:grid-cols-3">
								{["Rice seed", "Cotton kit", "Maize pack"].map((item) => (
									<label
										className="flex min-h-11 cursor-pointer items-center gap-2 rounded-2xl border border-border/70 bg-card px-3 text-sm transition hover:bg-muted/40"
										htmlFor={`scratch-${item}`}
										key={item}
									>
										<Checkbox id={`scratch-${item}`} />
										<span>{item}</span>
									</label>
								))}
							</div>
						</div>

						<div className="flex flex-wrap items-center gap-3 border-border/70 border-t pt-5">
							<Button>
								<CheckCircle2Icon className="size-4" />
								Save record
							</Button>
							<Button variant="outline">Save draft</Button>
							<Button variant="ghost">Cancel</Button>
						</div>
					</Surface>

					<Surface className="space-y-5">
						<SectionHeader title="List pattern">
							Rows are full-click targets when opening details. Primary value
							left, status and metadata right, with a soft hover state.
						</SectionHeader>
						<div className="grid gap-3">
							{sampleRows.map((row) => (
								<a
									className="group flex flex-col gap-4 rounded-3xl border border-border/70 bg-card p-4 shadow-sm transition hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring/30 sm:flex-row sm:items-center sm:justify-between"
									href="/scratchpad"
									key={row.name}
								>
									<span className="space-y-1">
										<span className="block font-semibold text-foreground">
											{row.name}
										</span>
										<span className="block text-muted-foreground text-sm">
											{row.subtitle}
										</span>
									</span>
									<span className="flex flex-wrap items-center gap-3 text-sm">
										<StatusPill
											tone={row.status === "Pending" ? "warning" : "success"}
										>
											{row.status}
										</StatusPill>
										<span className="text-muted-foreground">{row.meta}</span>
										<ArrowRightIcon className="size-4 text-muted-foreground transition group-hover:translate-x-0.5 group-hover:text-foreground" />
									</span>
								</a>
							))}
						</div>
					</Surface>
				</div>

				<aside className="space-y-6">
					<Surface className="space-y-4">
						<div className="flex items-center gap-3">
							<div className="flex size-11 items-center justify-center rounded-2xl bg-primary/10 text-primary">
								<SparklesIcon className="size-5" />
							</div>
							<div>
								<h2 className="font-semibold text-xl">Agent rules</h2>
								<p className="text-muted-foreground text-sm">
									Apply these before writing page UI.
								</p>
							</div>
						</div>
						<ul className="space-y-3 text-sm leading-6">
							{designRules.map((rule) => (
								<li className="flex gap-3" key={rule}>
									<span className="mt-2 size-1.5 rounded-full bg-primary" />
									<span className="text-muted-foreground">{rule}</span>
								</li>
							))}
						</ul>
					</Surface>

					<Surface className="space-y-4">
						<SectionHeader title="Hierarchy scale" />
						<div className="space-y-4">
							<TypeSample
								className="text-4xl"
								label="Page title"
								value="Create order"
							/>
							<TypeSample
								className="text-xl"
								label="Section title"
								value="Order queue"
							/>
							<TypeSample
								className="text-sm leading-6"
								label="Body help"
								value="Short supporting copy explains context without becoming a paragraph."
							/>
							<TypeSample
								className="text-xs uppercase tracking-[0.18em]"
								label="Metadata"
								value="Updated today"
							/>
						</div>
					</Surface>

					<Surface className="space-y-4">
						<SectionHeader title="State pattern">
							Every async area needs a visible loading, empty, and error state.
						</SectionHeader>
						<div className="space-y-2 rounded-3xl border border-border/70 bg-card p-4 shadow-sm">
							<Skeleton className="h-4 w-1/2" />
							<Skeleton className="h-4 w-3/4" />
							<Skeleton className="h-4 w-full" />
						</div>
						<div className="rounded-3xl border border-destructive/20 bg-destructive/5 p-4">
							<p className="font-medium text-destructive text-sm">
								Failed to load products
							</p>
							<p className="mt-1 text-muted-foreground text-sm">
								Check the connection and retry.
							</p>
						</div>
					</Surface>
				</aside>
			</section>

			<section className="grid gap-4 md:grid-cols-3">
				<QuickActionCard
					description="Tile for high-priority dashboard shortcuts."
					href="/farmers/create"
					icon={<TractorIcon className="size-5" />}
					label="Tile"
					size="md"
					title="Create farmer"
					tone="solid"
				/>
				<QuickActionCard
					description="Secondary shortcuts still use the same solid card surface."
					href="/products/create"
					icon={<PackageIcon className="size-5" />}
					label="Soft"
					size="md"
					title="Create product"
					tone="soft"
				/>
				<EmptyState
					actionHref="/scratchpad"
					actionLabel="Start"
					title="Empty state"
				>
					Use a concise explanation and one recovery action. Never leave blank
					space without guidance.
				</EmptyState>
			</section>
		</PageShell>
	);
}

function TypeSample({
	className,
	label,
	value,
}: {
	className: string;
	label: string;
	value: string;
}) {
	return (
		<div>
			<p className="font-medium text-muted-foreground text-xs uppercase tracking-[0.18em]">
				{label}
			</p>
			<p className={cn("mt-1 font-semibold leading-tight", className)}>
				{value}
			</p>
		</div>
	);
}
