"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { PackagePlusIcon, RefreshCwIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import type { Dispatch, ReactNode, SetStateAction } from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import {
	ErrorState,
	LoadingState,
	MetricCard,
	PageHeader,
	PageShell,
	SectionHeader,
	Surface,
} from "@/components/ui-patterns";
import {
	fetchInventoryClientApi,
	postInventoryClientApi,
} from "@/lib/api-client";

type InventoryCategory = "finished_good" | "packing_material" | "raw_material";

interface InventoryItem {
	category: "packing_material" | "raw_material";
	currentStock: string;
	id: string;
	name: string;
	unit: string;
}

interface FinishedGood {
	dispatchableQuantity: number;
	id: string;
	name: string;
	quantity: number;
}

interface ItemsResponse {
	items: InventoryItem[];
	success: true;
}

interface FinishedGoodsResponse {
	products: FinishedGood[];
	success: true;
}

const categoryLabels: Record<InventoryCategory, string> = {
	finished_good: "Finished goods",
	packing_material: "Packing material",
	raw_material: "Raw material",
};

const emptyForm = {
	batchNumber: "",
	category: "finished_good" as InventoryCategory,
	inventoryItemId: "",
	manualOrderNumber: "",
	productId: "",
	quantityAdded: "1",
	remarks: "",
	supplierName: "",
};

export default function GrnPage() {
	const router = useRouter();
	const [errorMessage, setErrorMessage] = useState("");
	const [finishedGoods, setFinishedGoods] = useState<FinishedGood[]>([]);
	const [form, setForm] = useState(emptyForm);
	const [items, setItems] = useState<InventoryItem[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [isSubmitting, setIsSubmitting] = useState(false);

	const loadOptions = useCallback(async () => {
		setIsLoading(true);
		setErrorMessage("");
		try {
			const [rawItems, packingItems, products] = await Promise.all([
				fetchInventoryClientApi<ItemsResponse>("/items?category=raw_material"),
				fetchInventoryClientApi<ItemsResponse>(
					"/items?category=packing_material"
				),
				fetchInventoryClientApi<FinishedGoodsResponse>("/finished-goods"),
			]);
			setItems([...rawItems.items, ...packingItems.items]);
			setFinishedGoods(products.products);
		} catch (error) {
			setErrorMessage(
				error instanceof Error ? error.message : "Failed to load GRN options"
			);
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		loadOptions().catch(() => undefined);
	}, [loadOptions]);

	const selectedStock = useMemo(() => {
		if (form.category === "finished_good") {
			return (
				finishedGoods.find((item) => item.id === form.productId)?.quantity ?? 0
			);
		}

		return Number(
			items.find((item) => item.id === form.inventoryItemId)?.currentStock ?? 0
		);
	}, [
		finishedGoods,
		form.category,
		form.inventoryItemId,
		form.productId,
		items,
	]);
	const quantityAdded = Number(form.quantityAdded || 0);
	const resultingStock = selectedStock + quantityAdded;

	const submitGrn = async () => {
		setIsSubmitting(true);
		try {
			await postInventoryClientApi("/inward", {
				batchNumber: form.batchNumber || undefined,
				category: form.category,
				inventoryItemId:
					form.category === "finished_good" ? undefined : form.inventoryItemId,
				manualOrderNumber: form.manualOrderNumber || undefined,
				productId:
					form.category === "finished_good" ? form.productId : undefined,
				quantityAdded,
				remarks: form.remarks || undefined,
				supplierName: form.supplierName || undefined,
			});
			toast.success("Stock inward recorded");
			setForm(emptyForm);
			await loadOptions();
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to add stock"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	const selectableItems =
		form.category === "finished_good"
			? finishedGoods
			: items.filter((item) => item.category === form.category);
	const canSubmit =
		quantityAdded > 0 &&
		(form.category === "finished_good" ? form.productId : form.inventoryItemId);

	return (
		<PageShell>
			<PageHeader
				actions={
					<Button
						onClick={() => loadOptions().catch(() => undefined)}
						variant="outline"
					>
						<RefreshCwIcon className="size-4" />
						Refresh
					</Button>
				}
				backHref="/inventory"
				eyebrow="Inventory"
				title="Stock inward"
			>
				<p>
					Record GRN entries for raw material, packing material, and finished
					goods.
				</p>
			</PageHeader>

			{renderGrnContent({
				canSubmit,
				errorMessage,
				form,
				isLoading,
				isSubmitting,
				quantityAdded,
				resultingStock,
				selectableItems,
				selectedStock,
				setForm,
				submitGrn,
			})}
		</PageShell>
	);
}

function renderGrnContent({
	canSubmit,
	errorMessage,
	form,
	isLoading,
	isSubmitting,
	quantityAdded,
	resultingStock,
	selectableItems,
	selectedStock,
	setForm,
	submitGrn,
}: {
	canSubmit: false | string;
	errorMessage: string;
	form: typeof emptyForm;
	isLoading: boolean;
	isSubmitting: boolean;
	quantityAdded: number;
	resultingStock: number;
	selectableItems: Array<FinishedGood | InventoryItem>;
	selectedStock: number;
	setForm: Dispatch<SetStateAction<typeof emptyForm>>;
	submitGrn: () => Promise<void>;
}) {
	if (isLoading) {
		return <LoadingState message="Loading stock options..." />;
	}

	if (errorMessage) {
		return <ErrorState message={errorMessage} title="Failed to load GRN" />;
	}

	return (
		<section className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
			<Surface className="space-y-5">
				<SectionHeader title="Goods receipt">
					Batch number, supplier, remarks, and manual order number are optional.
				</SectionHeader>
				<div className="grid gap-4 md:grid-cols-2">
					<Field label="Category">
						<select
							className={selectClassName}
							onChange={(event) =>
								setForm((current) => ({
									...current,
									category: event.target.value as InventoryCategory,
									inventoryItemId: "",
									productId: "",
								}))
							}
							value={form.category}
						>
							<option value="finished_good">Finished goods</option>
							<option value="raw_material">Raw material</option>
							<option value="packing_material">Packing material</option>
						</select>
					</Field>
					<Field label="Item name">
						<select
							className={selectClassName}
							onChange={(event) =>
								setForm((current) => ({
									...current,
									inventoryItemId:
										current.category === "finished_good"
											? current.inventoryItemId
											: event.target.value,
									productId:
										current.category === "finished_good"
											? event.target.value
											: current.productId,
								}))
							}
							value={
								form.category === "finished_good"
									? form.productId
									: form.inventoryItemId
							}
						>
							<option value="">Select {categoryLabels[form.category]}</option>
							{selectableItems.map((item) => (
								<option key={item.id} value={item.id}>
									{item.name}
								</option>
							))}
						</select>
					</Field>
					<Field label="Quantity added">
						<Input
							min="0"
							onChange={(event) =>
								setForm((current) => ({
									...current,
									quantityAdded: event.target.value,
								}))
							}
							type="number"
							value={form.quantityAdded}
						/>
					</Field>
					<Field label="Batch number">
						<Input
							onChange={(event) =>
								setForm((current) => ({
									...current,
									batchNumber: event.target.value,
								}))
							}
							value={form.batchNumber}
						/>
					</Field>
					<Field label="Supplier">
						<Input
							onChange={(event) =>
								setForm((current) => ({
									...current,
									supplierName: event.target.value,
								}))
							}
							value={form.supplierName}
						/>
					</Field>
					<Field label="Manual order number">
						<Input
							onChange={(event) =>
								setForm((current) => ({
									...current,
									manualOrderNumber: event.target.value,
								}))
							}
							value={form.manualOrderNumber}
						/>
					</Field>
					<label className="space-y-2 md:col-span-2">
						<span className="font-medium text-sm">Remarks</span>
						<Textarea
							onChange={(event) =>
								setForm((current) => ({
									...current,
									remarks: event.target.value,
								}))
							}
							value={form.remarks}
						/>
					</label>
				</div>
				<Button
					disabled={!canSubmit || isSubmitting}
					onClick={() => submitGrn().catch(() => undefined)}
				>
					<PackagePlusIcon className="size-4" />
					Record stock inward
				</Button>
			</Surface>

			<Surface className="space-y-4">
				<SectionHeader title="Stock preview" />
				<MetricCard
					label="Current stock"
					value={formatQuantity(selectedStock)}
				/>
				<MetricCard
					label="Quantity added"
					value={formatQuantity(quantityAdded)}
				/>
				<MetricCard
					label="Resulting stock"
					value={formatQuantity(resultingStock)}
				/>
			</Surface>
		</section>
	);
}

function Field({ children, label }: { children: ReactNode; label: string }) {
	return (
		<label className="space-y-2">
			<span className="font-medium text-sm">{label}</span>
			{children}
		</label>
	);
}

const selectClassName = cn(
	"h-10 w-full rounded-3xl border border-border bg-input/50 px-3 text-sm outline-none transition focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
);

function formatQuantity(value: number) {
	if (!Number.isFinite(value)) {
		return "0";
	}

	return Number.isInteger(value) ? String(value) : value.toFixed(3);
}
