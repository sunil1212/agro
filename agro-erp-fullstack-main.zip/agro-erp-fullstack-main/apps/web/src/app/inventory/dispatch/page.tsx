"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import { Skeleton } from "@agro-erp-fullstack/ui/components/skeleton";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import {
	ArrowLeftIcon,
	DownloadIcon,
	RefreshCwIcon,
	TruckIcon,
	WarehouseIcon,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
	EmptyState,
	ErrorState,
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
	Surface,
} from "@/components/ui-patterns";
import {
	fetchInventoryClientApi,
	getClientApiUrl,
	patchInventoryClientApi,
} from "@/lib/api-client";

type WarehouseStatus =
	| "confirmed"
	| "dispatched"
	| "return_in_transit"
	| "return_in_warehouse";

interface BranchSummary {
	adminName: string;
	adminUserId: string;
	counts: {
		confirmed: number;
		dispatched: number;
		returnInTransit: number;
		returnInWarehouse: number;
	};
	managerCode: string;
}

interface BranchesResponse {
	branches: BranchSummary[];
	success: true;
}

interface WarehouseOrder {
	approvedAt: null | string;
	approvedByName: null | string;
	consignmentNumber: null | string;
	createdAt: string;
	dispatchedAt: null | string;
	id: string;
	items: Array<{
		productId: string;
		productName: string;
		productSku: string;
		quantity: number;
	}>;
	nextStatus: WarehouseStatus | null;
	orderId: string | null;
	status: WarehouseStatus;
}

interface WarehouseOrdersResponse {
	orders: WarehouseOrder[];
	success: true;
}

const statusLabels: Record<WarehouseStatus, string> = {
	confirmed: "Confirmed",
	dispatched: "Dispatched",
	return_in_transit: "Return: in transit",
	return_in_warehouse: "Return: in warehouse",
};

const statusTabs = Object.entries(statusLabels) as [WarehouseStatus, string][];

const contentDispositionFileNamePattern = /filename="(.+)"/;
const WAREHOUSE_TABLE_MIN_ROWS = 10;

const getDateOnly = (date: Date): string => {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
};

const getBranchOrderCount = (branch: BranchSummary): number =>
	branch.counts.confirmed +
	branch.counts.dispatched +
	branch.counts.returnInTransit +
	branch.counts.returnInWarehouse;

const downloadAuthenticatedFile = async (
	path: string,
	fallbackFileName: string
): Promise<void> => {
	const response = await fetch(getClientApiUrl("inventory", path), {
		credentials: "include",
	});
	if (!response.ok) {
		const error = (await response.json().catch(() => null)) as {
			message?: string;
		} | null;
		throw new Error(error?.message ?? "Export failed");
	}

	const blob = await response.blob();
	const objectUrl = URL.createObjectURL(blob);
	const link = document.createElement("a");
	const disposition = response.headers.get("Content-Disposition");
	const match = disposition?.match(contentDispositionFileNamePattern);
	link.href = objectUrl;
	link.download = match?.[1] ?? fallbackFileName;
	link.click();
	URL.revokeObjectURL(objectUrl);
};

const startOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(0, 0, 0, 0);
	return nextDate;
};

const endOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(23, 59, 59, 999);
	return nextDate;
};

export default function InventoryDispatchPage({
	managerCode,
}: {
	managerCode?: string;
}) {
	const router = useRouter();
	const [activeStatus, setActiveStatus] =
		useState<WarehouseStatus>("confirmed");
	const [branches, setBranches] = useState<BranchSummary[]>([]);
	const [busyOrderId, setBusyOrderId] = useState<string | null>(null);
	const [errorMessage, setErrorMessage] = useState("");
	const [isExporting, setIsExporting] = useState<"booking" | "packing" | null>(
		null
	);
	const [isLoadingBranches, setIsLoadingBranches] = useState(true);
	const [isLoadingOrders, setIsLoadingOrders] = useState(false);
	const [orders, setOrders] = useState<WarehouseOrder[]>([]);
	const selectedManagerCode = managerCode ?? null;

	const selectedBranch = useMemo(
		() =>
			branches.find((branch) => branch.managerCode === selectedManagerCode) ??
			null,
		[branches, selectedManagerCode]
	);

	const loadBranches = useCallback(async () => {
		setErrorMessage("");
		setIsLoadingBranches(true);
		try {
			const result =
				await fetchInventoryClientApi<BranchesResponse>("/branches");
			setBranches(result.branches);
		} catch (error) {
			setErrorMessage(
				error instanceof Error ? error.message : "Failed to load branches"
			);
		} finally {
			setIsLoadingBranches(false);
		}
	}, []);

	const loadOrders = useCallback(async (managerCode: string) => {
		setErrorMessage("");
		setIsLoadingOrders(true);
		try {
			const result = await fetchInventoryClientApi<WarehouseOrdersResponse>(
				`/branches/${encodeURIComponent(managerCode)}/orders`
			);
			setOrders(result.orders);
		} catch (error) {
			setErrorMessage(
				error instanceof Error ? error.message : "Failed to load branch orders"
			);
		} finally {
			setIsLoadingOrders(false);
		}
	}, []);

	useEffect(() => {
		loadBranches().catch(() => undefined);
	}, [loadBranches]);

	useEffect(() => {
		if (selectedManagerCode) {
			loadOrders(selectedManagerCode).catch(() => undefined);
		}
	}, [loadOrders, selectedManagerCode]);

	const advanceOrder = async (
		orderId: string,
		status: WarehouseStatus
	): Promise<void> => {
		if (!selectedManagerCode) {
			return;
		}

		setBusyOrderId(orderId);
		try {
			await patchInventoryClientApi(`/dispatch/orders/${orderId}/status`, {
				status,
			});
			toast.success(`Order moved to ${statusLabels[status]}`);
			await Promise.all([loadOrders(selectedManagerCode), loadBranches()]);
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to update order"
			);
		} finally {
			setBusyOrderId(null);
		}
	};

	const exportBranch = async (
		kind: "booking" | "packing",
		from?: Date,
		to?: Date
	) => {
		if (!selectedManagerCode) {
			return;
		}

		setIsExporting(kind);
		try {
			const query = new URLSearchParams();
			if (from) {
				query.set("from", getDateOnly(from));
			}
			if (to) {
				query.set("to", getDateOnly(to));
			}
			const queryString = query.toString();
			await downloadAuthenticatedFile(
				`/branches/${encodeURIComponent(selectedManagerCode)}/order-exports/${kind}.csv${queryString ? `?${queryString}` : ""}`,
				`${kind}-sheet-${selectedManagerCode}.csv`
			);
			toast.success(
				`${kind === "booking" ? "Booking" : "Packing"} CSV downloaded`
			);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Export failed");
		} finally {
			setIsExporting(null);
		}
	};

	const visibleOrders = orders.filter((order) => order.status === activeStatus);

	return (
		<PageShell width="wide">
			<PageHeader
				actions={
					<Button
						onClick={() => {
							const refresh = selectedManagerCode
								? Promise.all([loadBranches(), loadOrders(selectedManagerCode)])
								: loadBranches();
							refresh.catch(() => undefined);
						}}
						variant="outline"
					>
						<RefreshCwIcon />
						Refresh
					</Button>
				}
				backHref="/inventory"
				eyebrow="Warehouse"
				title={
					selectedBranch
						? `${selectedBranch.managerCode} order queue`
						: "Order queue"
				}
			>
				<p>
					Select a branch, dispatch confirmed orders, and receive returns that
					have arrived at the warehouse.
				</p>
			</PageHeader>

			{errorMessage ? (
				<ErrorState
					message={errorMessage}
					title="Warehouse queue unavailable"
				/>
			) : null}

			{selectedBranch ? (
				<BranchOrderQueue
					activeStatus={activeStatus}
					branch={selectedBranch}
					busyOrderId={busyOrderId}
					isExporting={isExporting}
					isLoading={isLoadingOrders}
					onAdvanceOrder={advanceOrder}
					onBack={() => {
						setOrders([]);
						router.push("/inventory/dispatch");
					}}
					onExport={exportBranch}
					onStatusChange={setActiveStatus}
					orders={visibleOrders}
				/>
			) : (
				<BranchList
					branches={branches}
					isLoading={isLoadingBranches}
					onSelect={(branchManagerCode) =>
						router.push(
							`/inventory/dispatch/${encodeURIComponent(branchManagerCode)}`
						)
					}
				/>
			)}
		</PageShell>
	);
}

function BranchList({
	branches,
	isLoading,
	onSelect,
}: {
	branches: BranchSummary[];
	isLoading: boolean;
	onSelect: (managerCode: string) => void;
}) {
	if (isLoading) {
		return (
			<div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
				{Array.from({ length: 3 }).map((_, index) => (
					<Skeleton
						className="h-48 rounded-2xl"
						key={`branch-skeleton-${index}`}
					/>
				))}
			</div>
		);
	}

	if (branches.length === 0) {
		return (
			<EmptyState title="No branches found">
				Admin branches will appear here after manager codes are assigned.
			</EmptyState>
		);
	}

	return (
		<section className="space-y-4">
			<SectionHeader title="Branches">
				Choose a branch to view its warehouse order queue.
			</SectionHeader>
			<div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
				{branches.map((branch) => (
					<button
						className="rounded-2xl border border-border/70 bg-card p-5 text-left shadow-sm transition hover:border-primary/40 hover:bg-muted/30"
						key={branch.adminUserId}
						onClick={() => onSelect(branch.managerCode)}
						type="button"
					>
						<div className="flex items-start justify-between gap-4">
							<div>
								<p className="font-semibold text-lg">{branch.managerCode}</p>
								<p className="text-muted-foreground text-sm">
									{branch.adminName}
								</p>
							</div>
							<WarehouseIcon className="size-5 text-muted-foreground" />
						</div>
						<div className="mt-5 grid grid-cols-2 gap-2 text-sm">
							<BranchCount label="Confirmed" value={branch.counts.confirmed} />
							<BranchCount
								label="Dispatched"
								value={branch.counts.dispatched}
							/>
							<BranchCount
								label="Return transit"
								value={branch.counts.returnInTransit}
							/>
							<BranchCount
								label="Return warehouse"
								value={branch.counts.returnInWarehouse}
							/>
						</div>
						<p className="mt-4 text-muted-foreground text-xs">
							{getBranchOrderCount(branch)} active warehouse orders
						</p>
					</button>
				))}
			</div>
		</section>
	);
}

function BranchCount({ label, value }: { label: string; value: number }) {
	return (
		<span className="rounded-xl bg-muted px-3 py-2">
			{label}: <strong>{value}</strong>
		</span>
	);
}

function BranchOrderQueue({
	activeStatus,
	branch,
	busyOrderId,
	isExporting,
	isLoading,
	onAdvanceOrder,
	onBack,
	onExport,
	onStatusChange,
	orders,
}: {
	activeStatus: WarehouseStatus;
	branch: BranchSummary;
	busyOrderId: string | null;
	isExporting: "booking" | "packing" | null;
	isLoading: boolean;
	onAdvanceOrder: (orderId: string, status: WarehouseStatus) => Promise<void>;
	onBack: () => void;
	onExport: (
		kind: "booking" | "packing",
		from?: Date,
		to?: Date
	) => Promise<void>;
	onStatusChange: (status: WarehouseStatus) => void;
	orders: WarehouseOrder[];
}) {
	const [dateFrom, setDateFrom] = useState<Date>();
	const [dateTo, setDateTo] = useState<Date>();
	const resetDateFilters = () => {
		setDateFrom(undefined);
		setDateTo(undefined);
	};

	return (
		<div className="space-y-5">
			<Surface className="space-y-4">
				<div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
					<div>
						<Button onClick={onBack} size="sm" variant="ghost">
							<ArrowLeftIcon />
							All branches
						</Button>
						<p className="mt-2 font-semibold text-lg">{branch.adminName}</p>
						<p className="text-muted-foreground text-sm">
							Branch {branch.managerCode}
						</p>
					</div>
					<div className="flex flex-wrap gap-2">
						<Button
							disabled={isExporting !== null}
							onClick={() =>
								onExport("packing", dateFrom, dateTo).catch(() => undefined)
							}
							variant="outline"
						>
							<DownloadIcon />
							{isExporting === "packing" ? "Downloading..." : "Packing CSV"}
						</Button>
						<Button
							disabled={isExporting !== null}
							onClick={() =>
								onExport("booking", dateFrom, dateTo).catch(() => undefined)
							}
							variant="outline"
						>
							<DownloadIcon />
							{isExporting === "booking" ? "Downloading..." : "Booking CSV"}
						</Button>
					</div>
				</div>
				<div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
					<div className="flex flex-wrap gap-2">
						{statusTabs.map(([status, label]) => (
							<Button
								key={status}
								onClick={() => onStatusChange(status)}
								size="sm"
								variant={activeStatus === status ? "default" : "outline"}
							>
								{label}
							</Button>
						))}
					</div>
					<div className="flex flex-wrap gap-2">
						<DatePicker
							className="w-44 bg-background"
							onChange={setDateFrom}
							placeholder="From date"
							value={dateFrom ?? null}
						/>
						<DatePicker
							className="w-44 bg-background"
							onChange={setDateTo}
							placeholder="To date"
							value={dateTo ?? null}
						/>
						<Button onClick={resetDateFilters} type="button" variant="outline">
							Reset
						</Button>
					</div>
				</div>
			</Surface>

			<Surface className="space-y-4">
				<SectionHeader
					action={<StatusPill>{orders.length} orders</StatusPill>}
					title={statusLabels[activeStatus]}
				>
					Only valid warehouse transitions are available.
				</SectionHeader>
				{isLoading ? (
					<Skeleton className="h-64 rounded-2xl" />
				) : (
					<WarehouseOrdersTable
						busyOrderId={busyOrderId}
						dateFrom={dateFrom}
						dateTo={dateTo}
						onAdvanceOrder={onAdvanceOrder}
						orders={orders}
					/>
				)}
			</Surface>
		</div>
	);
}

function WarehouseOrdersTable({
	busyOrderId,
	dateFrom,
	dateTo,
	onAdvanceOrder,
	orders,
}: {
	busyOrderId: string | null;
	dateFrom: Date | undefined;
	dateTo: Date | undefined;
	onAdvanceOrder: (orderId: string, status: WarehouseStatus) => Promise<void>;
	orders: WarehouseOrder[];
}) {
	const pageSizeOptions = [10, 25, 50] as const;
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] =
		useState<(typeof pageSizeOptions)[number]>(10);
	const filteredOrders = useMemo(() => {
		const lowerDate = dateFrom ? startOfDay(dateFrom).getTime() : null;
		const upperDate = dateTo ? endOfDay(dateTo).getTime() : null;

		return orders.filter((order) => {
			const orderTime = new Date(order.createdAt).getTime();
			if (lowerDate !== null && orderTime < lowerDate) {
				return false;
			}

			if (upperDate !== null && orderTime > upperDate) {
				return false;
			}

			return true;
		});
	}, [dateFrom, dateTo, orders]);
	const totalPages = Math.max(1, Math.ceil(filteredOrders.length / pageSize));
	const safeCurrentPage = Math.min(currentPage, totalPages);
	const pageStartIndex = (safeCurrentPage - 1) * pageSize;
	const paginatedOrders = filteredOrders.slice(
		pageStartIndex,
		pageStartIndex + pageSize
	);
	const fillerRows = Math.max(
		0,
		WAREHOUSE_TABLE_MIN_ROWS - paginatedOrders.length
	);
	const pageInputValue = String(safeCurrentPage);

	useEffect(() => {
		if (currentPage > totalPages) {
			setCurrentPage(totalPages);
		}
	}, [currentPage, totalPages]);

	return (
		<div className="overflow-hidden rounded-xl border">
			<div className="overflow-x-auto">
				<Table className="table-fixed">
					<colgroup>
						<col className="w-[14%]" />
						<col className="w-[15%]" />
						<col className="w-[28%]" />
						<col className="w-[14%]" />
						<col className="w-[12%]" />
						<col className="w-[10%]" />
						<col className="w-[12%]" />
					</colgroup>
					<TableHeader>
						<TableRow>
							<TableHead>Order</TableHead>
							<TableHead>Consignment</TableHead>
							<TableHead>Items</TableHead>
							<TableHead>Approved by</TableHead>
							<TableHead>Created</TableHead>
							<TableHead>Status</TableHead>
							<TableHead className="text-right">Action</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{paginatedOrders.length > 0 ? (
							paginatedOrders.map((order) => (
								<TableRow key={order.id}>
									<TableCell className="whitespace-normal text-wrap break-words">
										<div className="flex items-center gap-2">
											<TruckIcon className="size-4 shrink-0 text-muted-foreground" />
											<span className="font-medium">
												{order.orderId ?? "Pending ID"}
											</span>
										</div>
									</TableCell>
									<TableCell className="whitespace-normal text-wrap break-words font-mono text-xs">
										{order.consignmentNumber ?? "Not assigned"}
									</TableCell>
									<TableCell className="whitespace-normal text-wrap break-words text-muted-foreground text-sm leading-5">
										{order.items
											.map((item) => `${item.productName} x ${item.quantity}`)
											.join(", ")}
									</TableCell>
									<TableCell className="whitespace-normal text-wrap break-words">
										{order.approvedByName ?? "Not captured"}
									</TableCell>
									<TableCell className="whitespace-normal text-wrap break-words">
										{formatDate(order.createdAt)}
									</TableCell>
									<TableCell>
										<StatusPill>{statusLabels[order.status]}</StatusPill>
									</TableCell>
									<TableCell className="text-right">
										{order.nextStatus ? (
											<Button
												disabled={busyOrderId === order.id}
												onClick={() => {
													const { nextStatus } = order;
													if (nextStatus) {
														onAdvanceOrder(order.id, nextStatus).catch(
															() => undefined
														);
													}
												}}
												size="sm"
											>
												{order.nextStatus === "dispatched"
													? "Mark dispatched"
													: "Mark received"}
											</Button>
										) : (
											<span className="text-muted-foreground text-sm">
												No action
											</span>
										)}
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell className="h-16 text-muted-foreground" colSpan={7}>
									No orders match these filters.
								</TableCell>
							</TableRow>
						)}
						{Array.from({ length: fillerRows }).map((_, index) => (
							<TableRow
								aria-hidden
								className="hover:bg-transparent"
								key={`warehouse-filler-${index}`}
							>
								<TableCell className="h-16" colSpan={7}>
									&nbsp;
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
			</div>
			<div className="grid gap-3 border-border/70 border-t bg-muted/20 px-4 py-3 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
				<div className="text-muted-foreground text-sm">
					Showing {filteredOrders.length === 0 ? 0 : pageStartIndex + 1} to{" "}
					{Math.min(
						pageStartIndex + paginatedOrders.length,
						filteredOrders.length
					)}{" "}
					of {filteredOrders.length} orders
				</div>
				<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
					<PaginationContent>
						<PaginationItem>
							<PaginationPrevious
								disabled={safeCurrentPage === 1}
								onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
								type="button"
							/>
						</PaginationItem>
						<PaginationItem>
							<div className="flex h-9 items-center gap-2 px-2 text-sm">
								<span className="text-muted-foreground">Page</span>
								<Input
									className="h-8 w-16 text-center"
									inputMode="numeric"
									max={totalPages}
									min={1}
									onBlur={() => {
										setCurrentPage((value) => Math.min(totalPages, value));
									}}
									onChange={(event) => {
										const nextPage = Number(event.target.value);
										if (!Number.isInteger(nextPage)) {
											return;
										}

										setCurrentPage(Math.min(totalPages, Math.max(1, nextPage)));
									}}
									value={pageInputValue}
								/>
								<span className="text-muted-foreground">of {totalPages}</span>
							</div>
						</PaginationItem>
						<PaginationItem>
							<PaginationNext
								disabled={safeCurrentPage === totalPages}
								onClick={() =>
									setCurrentPage((page) => Math.min(totalPages, page + 1))
								}
								type="button"
							/>
						</PaginationItem>
					</PaginationContent>
				</Pagination>
				<div className="flex flex-wrap items-center gap-3 lg:justify-end">
					<div className="flex items-center gap-2">
						<span className="text-muted-foreground text-sm">Rows</span>
						<Select
							onValueChange={(value) => {
								setCurrentPage(1);
								setPageSize(Number(value) as (typeof pageSizeOptions)[number]);
							}}
							value={String(pageSize)}
						>
							<SelectTrigger className="h-9 w-20 bg-background">
								<SelectValue />
							</SelectTrigger>
							<SelectContent align="end">
								{pageSizeOptions.map((option) => (
									<SelectItem key={option} value={String(option)}>
										{option}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
					</div>
				</div>
			</div>
		</div>
	);
}

function formatDate(value: string) {
	return new Intl.DateTimeFormat("en-IN", {
		day: "2-digit",
		month: "short",
		timeZone: "Asia/Kolkata",
		year: "numeric",
	}).format(new Date(value));
}
