import InventoryDispatchPage from "../page";

export default async function InventoryDispatchBranchPage({
	params,
}: {
	params: Promise<{ managerCode: string }>;
}) {
	const { managerCode } = await params;

	return <InventoryDispatchPage managerCode={managerCode} />;
}
