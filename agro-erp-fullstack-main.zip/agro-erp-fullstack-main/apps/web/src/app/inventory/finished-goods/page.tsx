"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { RefreshCwIcon, SaveIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

import {
	EmptyState,
	ErrorState,
	LoadingState,
	MetricCard,
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
	Surface,
} from "@/components/ui-patterns";
import {
	fetchInventoryClientApi,
	patchInventoryClientApi,
} from "@/lib/api-client";

interface FinishedGood {
	batchNumber: null | string;
	dispatchableQuantity: number;
	expiryDate: null | string;
	id: string;
	lastInventoryUpdatedAt: null | string;
	minimumStockLevel: number;
	name: string;
	quantity: number;
	reservedQuantity: number;
	skuCode: null | string;
	warehouseLocation: null | string;
}

interface FinishedGoodsResponse {
	products: FinishedGood[];
	success: true;
}

export default function FinishedGoodsPage() {
	const router = useRouter();
	const [drafts, setDrafts] = useState<Record<string, FinishedGood>>({});
	const [errorMessage, setErrorMessage] = useState("");
	const [isLoading, setIsLoading] = useState(true);
	const [products, setProducts] = useState<FinishedGood[]>([]);
	const [savingProductId, setSavingProductId] = useState<string | null>(null);

	const loadProducts = useCallback(async () => {
		setIsLoading(true);
		setErrorMessage("");
		try {
			const data =
				await fetchInventoryClientApi<FinishedGoodsResponse>("/finished-goods");
			setProducts(data.products);
			setDrafts(
				Object.fromEntries(data.products.map((item) => [item.id, item]))
			);
		} catch (error) {
			setErrorMessage(
				error instanceof Error ? error.message : "Failed to load products"
			);
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		loadProducts().catch(() => undefined);
	}, [loadProducts]);

	const saveProduct = async (productId: string) => {
		const draft = drafts[productId];
		if (!draft) {
			return;
		}

		setSavingProductId(productId);
		try {
			await patchInventoryClientApi(`/finished-goods/${productId}`, {
				batchNumber: draft.batchNumber ?? "",
				expiryDate: draft.expiryDate || null,
				minimumStockLevel: draft.minimumStockLevel,
				skuCode: draft.skuCode ?? "",
				warehouseLocation: draft.warehouseLocation ?? "",
			});
			toast.success("Finished good updated");
			await loadProducts();
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to update product"
			);
		} finally {
			setSavingProductId(null);
		}
	};

	const updateDraft = (productId: string, values: Partial<FinishedGood>) => {
		setDrafts((current) => ({
			...current,
			[productId]: {
				...(current[productId] ??
					products.find((item) => item.id === productId)),
				...values,
			} as FinishedGood,
		}));
	};

	const totalDispatchable = products.reduce(
		(sum, item) => sum + item.dispatchableQuantity,
		0
	);
	const reserved = products.reduce(
		(sum, item) => sum + item.reservedQuantity,
		0
	);
	const lowStock = products.filter(
		(item) =>
			item.minimumStockLevel > 0 && item.quantity < item.minimumStockLevel
	).length;

	return (
		<PageShell width="wide">
			<PageHeader
				actions={
					<Button
						onClick={() => loadProducts().catch(() => undefined)}
						variant="outline"
					>
						<RefreshCwIcon className="size-4" />
						Refresh
					</Button>
				}
				backHref="/inventory"
				eyebrow="Inventory"
				title="Finished goods"
			>
				<p>
					Review dispatchable product stock and maintain SKU, batch, expiry,
					warehouse location, and alert thresholds.
				</p>
			</PageHeader>

			<section className="grid gap-4 md:grid-cols-3">
				<MetricCard label="Products" value={String(products.length)} />
				<MetricCard
					label="Dispatchable"
					trend="Current orderable stock"
					value={String(totalDispatchable)}
				/>
				<MetricCard
					label="Reserved"
					trend={`${lowStock} low stock`}
					value={String(reserved)}
				/>
			</section>

			<Surface className="space-y-5">
				<SectionHeader
					action={<StatusPill>{products.length} records</StatusPill>}
					title="Product inventory"
				>
					Stock quantity changes through orders, GRN, and outward entries.
				</SectionHeader>
				{renderFinishedGoodsContent({
					drafts,
					errorMessage,
					isLoading,
					products,
					saveProduct,
					savingProductId,
					updateDraft,
				})}
			</Surface>
		</PageShell>
	);
}

function renderFinishedGoodsContent({
	drafts,
	errorMessage,
	isLoading,
	products,
	saveProduct,
	savingProductId,
	updateDraft,
}: {
	drafts: Record<string, FinishedGood>;
	errorMessage: string;
	isLoading: boolean;
	products: FinishedGood[];
	saveProduct: (productId: string) => Promise<void>;
	savingProductId: null | string;
	updateDraft: (productId: string, values: Partial<FinishedGood>) => void;
}) {
	if (isLoading) {
		return <LoadingState message="Loading finished goods..." />;
	}

	if (errorMessage) {
		return (
			<ErrorState message={errorMessage} title="Failed to load products" />
		);
	}

	if (products.length === 0) {
		return (
			<EmptyState title="No finished goods">
				Product records created by the manager will appear here.
			</EmptyState>
		);
	}

	return (
		<div className="grid gap-4">
			{products.map((entry) => {
				const draft = drafts[entry.id] ?? entry;
				const isLowStock =
					entry.minimumStockLevel > 0 &&
					entry.quantity < entry.minimumStockLevel;

				return (
					<div
						className="rounded-3xl border border-border/70 bg-card p-5 shadow-sm"
						key={entry.id}
					>
						<div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
							<div>
								<h2 className="font-semibold text-lg">{entry.name}</h2>
								<p className="text-muted-foreground text-sm">
									{entry.skuCode ?? "No SKU"} ·{" "}
									{entry.warehouseLocation ?? "No warehouse location"}
								</p>
							</div>
							<StatusPill tone={isLowStock ? "danger" : "success"}>
								{isLowStock ? "Low stock" : "Ready"}
							</StatusPill>
						</div>

						<div className="mt-5 grid gap-3 md:grid-cols-3">
							<MetricCard
								label="Dispatchable"
								value={String(entry.dispatchableQuantity)}
							/>
							<MetricCard
								label="Reserved"
								value={String(entry.reservedQuantity)}
							/>
							<MetricCard
								label="Minimum"
								value={String(entry.minimumStockLevel)}
							/>
						</div>

						<div className="mt-5 grid gap-4 md:grid-cols-5">
							<Field label="SKU code">
								<Input
									onChange={(event) =>
										updateDraft(entry.id, { skuCode: event.target.value })
									}
									value={draft.skuCode ?? ""}
								/>
							</Field>
							<Field label="Minimum stock">
								<Input
									min="0"
									onChange={(event) =>
										updateDraft(entry.id, {
											minimumStockLevel: Number(event.target.value),
										})
									}
									type="number"
									value={draft.minimumStockLevel}
								/>
							</Field>
							<Field label="Batch number">
								<Input
									onChange={(event) =>
										updateDraft(entry.id, {
											batchNumber: event.target.value,
										})
									}
									value={draft.batchNumber ?? ""}
								/>
							</Field>
							<Field label="Expiry date">
								<Input
									onChange={(event) =>
										updateDraft(entry.id, {
											expiryDate: event.target.value || null,
										})
									}
									type="date"
									value={draft.expiryDate ?? ""}
								/>
							</Field>
							<Field label="Warehouse">
								<Input
									onChange={(event) =>
										updateDraft(entry.id, {
											warehouseLocation: event.target.value,
										})
									}
									value={draft.warehouseLocation ?? ""}
								/>
							</Field>
						</div>
						<div className="mt-5 flex justify-end">
							<Button
								disabled={savingProductId === entry.id}
								onClick={() => saveProduct(entry.id).catch(() => undefined)}
							>
								<SaveIcon className="size-4" />
								Save inventory details
							</Button>
						</div>
					</div>
				);
			})}
		</div>
	);
}

function Field({ children, label }: { children: ReactNode; label: string }) {
	return (
		<label className="space-y-2">
			<span className="font-medium text-sm">{label}</span>
			{children}
		</label>
	);
}
