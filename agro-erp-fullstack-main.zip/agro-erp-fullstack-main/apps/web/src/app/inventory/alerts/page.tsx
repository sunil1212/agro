import {
	EmptyState,
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
	Surface,
} from "@/components/ui-patterns";
import { fetchServerApi } from "@/lib/api-server";

export const dynamic = "force-dynamic";

interface InventoryAlert {
	activeAt: string;
	alertType: "expiring_product" | "low_stock";
	category: "finished_good" | "packing_material" | "raw_material";
	id: string;
	message: string;
	resolvedAt: null | string;
	status: "active" | "resolved";
	thresholdValue: string;
	triggeredValue: string;
}

interface AlertsResponse {
	alerts: InventoryAlert[];
	success: true;
}

const categoryLabels: Record<InventoryAlert["category"], string> = {
	finished_good: "Finished goods",
	packing_material: "Packing material",
	raw_material: "Raw material",
};

export default async function InventoryAlertsPage() {
	const data = await fetchServerApi<AlertsResponse>(
		"inventory",
		"/alerts?status=all"
	);
	const activeAlerts = data.alerts.filter((alert) => alert.status === "active");
	const resolvedAlerts = data.alerts.filter(
		(alert) => alert.status === "resolved"
	);

	return (
		<PageShell width="wide">
			<PageHeader backHref="/inventory" eyebrow="Inventory" title="Alerts">
				<p>
					Review active and resolved inventory alerts. Alert rows are retained
					for audit history.
				</p>
			</PageHeader>

			<section className="grid gap-6 xl:grid-cols-2">
				<AlertSection alerts={activeAlerts} title="Active alerts" />
				<AlertSection alerts={resolvedAlerts} title="Resolved alerts" />
			</section>
		</PageShell>
	);
}

function AlertSection({
	alerts,
	title,
}: {
	alerts: InventoryAlert[];
	title: string;
}) {
	return (
		<Surface className="space-y-5">
			<SectionHeader
				action={<StatusPill>{alerts.length} records</StatusPill>}
				title={title}
			/>
			{alerts.length > 0 ? (
				<div className="space-y-3">
					{alerts.map((alert) => (
						<div
							className="rounded-2xl border border-border/70 bg-card p-4 shadow-sm"
							key={alert.id}
						>
							<div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
								<div>
									<StatusPill tone={getAlertTone(alert)}>
										{alert.alertType.replaceAll("_", " ")}
									</StatusPill>
									<p className="mt-3 font-medium text-sm">{alert.message}</p>
									<p className="mt-1 text-muted-foreground text-sm">
										{categoryLabels[alert.category]}
									</p>
								</div>
								<div className="text-left text-sm sm:text-right">
									<p className="font-medium">
										{formatDate(
											alert.status === "resolved" && alert.resolvedAt
												? alert.resolvedAt
												: alert.activeAt
										)}
									</p>
									<p className="text-muted-foreground">
										{alert.triggeredValue} / {alert.thresholdValue}
									</p>
								</div>
							</div>
						</div>
					))}
				</div>
			) : (
				<EmptyState title={`No ${title.toLowerCase()}`}>
					Alert records will appear here as inventory thresholds change.
				</EmptyState>
			)}
		</Surface>
	);
}

function getAlertTone(alert: InventoryAlert) {
	if (alert.status === "resolved") {
		return "neutral" as const;
	}

	if (alert.alertType === "low_stock") {
		return "danger" as const;
	}

	return "warning" as const;
}

function formatDate(value: string) {
	return new Intl.DateTimeFormat("en-IN", {
		day: "2-digit",
		month: "short",
		timeZone: "Asia/Kolkata",
		year: "numeric",
	}).format(new Date(value));
}
