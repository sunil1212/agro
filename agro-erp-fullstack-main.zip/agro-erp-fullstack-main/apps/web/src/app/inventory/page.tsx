import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ArrowRightIcon, PackagePlusIcon, TruckIcon } from "lucide-react";
import type { Route } from "next";
import { headers } from "next/headers";
import Link from "next/link";
import { QuickActionCard } from "@/components/quick-action-card";
import { PageHeader, PageShell, Surface } from "@/components/ui-patterns";
import { authClient } from "@/lib/auth-client";

export const dynamic = "force-dynamic";

const actions = [
	{
		description:
			"Add new stock for a finished product, raw material, or packing material.",
		href: "/inventory/grn",
		icon: PackagePlusIcon,
		label: "Add stock",
		title: "Update product inventory",
	},
	{
		description:
			"Move orders through warehouse statuses and manage dispatch operations.",
		href: "/inventory/dispatch",
		icon: TruckIcon,
		label: "Update orders",
		title: "Branch order queues",
	},
] as const;

export default async function InventoryPage() {
	const requestHeaders = await headers();
	const session = await authClient.getSession({
		fetchOptions: {
			headers: { cookie: requestHeaders.get("cookie") ?? "" },
			throw: true,
		},
	});
	const userRole =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: null;
	const isWarehouse = userRole === "warehouse";

	return (
		<PageShell width="wide">
			<PageHeader eyebrow="Inventory" title="Inventory updates">
				<p>
					Update stock and manage order fulfillment from one focused screen.
				</p>
			</PageHeader>

			{isWarehouse ? (
				<Surface className="space-y-3">
					<h2 className="font-semibold text-xl">Warehouse shortcuts moved</h2>
					<p className="max-w-2xl text-muted-foreground text-sm leading-6">
						Use the dashboard for warehouse CTAs. Product inventory updates are
						available from the products page, and order status updates are under
						orders.
					</p>
					<div className="flex flex-wrap items-center gap-2">
						<Link
							className={cn(buttonVariants({ variant: "outline" }), "w-fit")}
							href={"/products" as Route}
						>
							Open products
							<ArrowRightIcon className="size-4" />
						</Link>
						<Link className={cn(buttonVariants(), "w-fit")} href="/dashboard">
							Open dashboard
							<ArrowRightIcon className="size-4" />
						</Link>
					</div>
				</Surface>
			) : (
				<section className="grid gap-4 md:grid-cols-2">
					{actions.map((action) => {
						const Icon = action.icon;

						return (
							<QuickActionCard
								actionLabel={action.label}
								description={action.description}
								href={action.href}
								icon={<Icon className="size-5" />}
								key={action.href}
								label="Inventory workflow"
								meta="Warehouse action"
								title={action.title}
								tone="solid"
								variant="tile"
							/>
						);
					})}
				</section>
			)}
		</PageShell>
	);
}
