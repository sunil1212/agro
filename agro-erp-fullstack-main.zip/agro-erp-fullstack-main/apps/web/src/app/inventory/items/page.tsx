"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { PackagePlusIcon, RefreshCwIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import {
	EmptyState,
	ErrorState,
	LoadingState,
	MetricCard,
	PageHeader,
	PageShell,
	SectionHeader,
	StatusPill,
	Surface,
} from "@/components/ui-patterns";
import {
	fetchInventoryClientApi,
	postInventoryClientApi,
} from "@/lib/api-client";

type InventoryCategory = "packing_material" | "raw_material";

interface InventoryItem {
	category: InventoryCategory;
	currentStock: string;
	id: string;
	itemCode: string;
	lastInventoryUpdatedAt: null | string;
	lowStockThreshold: string;
	name: string;
	supplierName: null | string;
	unit: string;
}

interface ItemsResponse {
	items: InventoryItem[];
	success: true;
}

const categoryLabels: Record<InventoryCategory, string> = {
	packing_material: "Packing material",
	raw_material: "Raw material",
};

const emptyForm = {
	category: "raw_material" as InventoryCategory,
	currentStock: "0",
	itemCode: "",
	lowStockThreshold: "0",
	name: "",
	supplierName: "",
	unit: "",
};

export default function InventoryItemsPage() {
	const router = useRouter();
	const [activeCategory, setActiveCategory] =
		useState<InventoryCategory>("raw_material");
	const [errorMessage, setErrorMessage] = useState("");
	const [form, setForm] = useState(emptyForm);
	const [isLoading, setIsLoading] = useState(true);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [items, setItems] = useState<InventoryItem[]>([]);

	const loadItems = useCallback(async () => {
		setIsLoading(true);
		setErrorMessage("");

		try {
			const data = await fetchInventoryClientApi<ItemsResponse>(
				`/items?category=${activeCategory}`
			);
			setItems(data.items);
		} catch (error) {
			setErrorMessage(
				error instanceof Error ? error.message : "Failed to load inventory"
			);
		} finally {
			setIsLoading(false);
		}
	}, [activeCategory]);

	useEffect(() => {
		loadItems().catch(() => undefined);
	}, [loadItems]);

	const totalStock = useMemo(
		() => items.reduce((sum, item) => sum + Number(item.currentStock), 0),
		[items]
	);
	const lowStockCount = useMemo(
		() =>
			items.filter(
				(item) => Number(item.currentStock) < Number(item.lowStockThreshold)
			).length,
		[items]
	);

	const submitItem = async () => {
		setIsSubmitting(true);
		try {
			await postInventoryClientApi("/items", {
				category: form.category,
				currentStock: Number(form.currentStock),
				itemCode: form.itemCode,
				lowStockThreshold: Number(form.lowStockThreshold),
				name: form.name,
				supplierName: form.supplierName || undefined,
				unit: form.unit,
			});
			toast.success("Inventory item created");
			setForm({ ...emptyForm, category: activeCategory });
			await loadItems();
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to create item"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<PageShell width="wide">
			<PageHeader
				actions={
					<Button
						onClick={() => loadItems().catch(() => undefined)}
						variant="outline"
					>
						<RefreshCwIcon className="size-4" />
						Refresh
					</Button>
				}
				backHref="/inventory"
				eyebrow="Inventory"
				title="Materials inventory"
			>
				<p>
					Create and review raw material and packing material stock records with
					category-specific thresholds.
				</p>
			</PageHeader>

			<div className="flex flex-wrap gap-2">
				{(["raw_material", "packing_material"] as const).map((category) => (
					<Button
						key={category}
						onClick={() => {
							setActiveCategory(category);
							setForm((current) => ({ ...current, category }));
						}}
						variant={activeCategory === category ? "default" : "outline"}
					>
						{categoryLabels[category]}
					</Button>
				))}
			</div>

			<section className="grid gap-4 md:grid-cols-3">
				<MetricCard label="Items" value={String(items.length)} />
				<MetricCard
					label="Current stock"
					trend={categoryLabels[activeCategory]}
					value={formatQuantity(totalStock)}
				/>
				<MetricCard
					label="Low stock"
					trend="Below threshold"
					value={String(lowStockCount)}
				/>
			</section>

			<section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_24rem]">
				<Surface className="space-y-5">
					<SectionHeader
						action={<StatusPill>{items.length} records</StatusPill>}
						title={categoryLabels[activeCategory]}
					>
						Stock values are updated by GRN and outward entries after creation.
					</SectionHeader>
					{renderItemsContent({
						activeCategory,
						errorMessage,
						isLoading,
						items,
					})}
				</Surface>

				<Surface className="space-y-5">
					<SectionHeader title="Create item">
						Add the item master record. Use GRN to add future stock.
					</SectionHeader>
					<div className="space-y-4">
						<Field label="Category">
							<select
								className={selectClassName}
								onChange={(event) =>
									setForm((current) => ({
										...current,
										category: event.target.value as InventoryCategory,
									}))
								}
								value={form.category}
							>
								<option value="raw_material">Raw material</option>
								<option value="packing_material">Packing material</option>
							</select>
						</Field>
						<Field label="Item name">
							<Input
								onChange={(event) =>
									setForm((current) => ({
										...current,
										name: event.target.value,
									}))
								}
								value={form.name}
							/>
						</Field>
						<Field label="Item code">
							<Input
								onChange={(event) =>
									setForm((current) => ({
										...current,
										itemCode: event.target.value,
									}))
								}
								value={form.itemCode}
							/>
						</Field>
						<Field label="Unit">
							<Input
								onChange={(event) =>
									setForm((current) => ({
										...current,
										unit: event.target.value,
									}))
								}
								placeholder="kg / ltr / unit"
								value={form.unit}
							/>
						</Field>
						<Field label="Opening stock">
							<Input
								min="0"
								onChange={(event) =>
									setForm((current) => ({
										...current,
										currentStock: event.target.value,
									}))
								}
								type="number"
								value={form.currentStock}
							/>
						</Field>
						<Field
							label={
								form.category === "raw_material"
									? "Minimum stock level"
									: "Reorder level"
							}
						>
							<Input
								min="0"
								onChange={(event) =>
									setForm((current) => ({
										...current,
										lowStockThreshold: event.target.value,
									}))
								}
								type="number"
								value={form.lowStockThreshold}
							/>
						</Field>
						<Field label="Supplier">
							<Input
								onChange={(event) =>
									setForm((current) => ({
										...current,
										supplierName: event.target.value,
									}))
								}
								value={form.supplierName}
							/>
						</Field>
					</div>
					<Button
						className="w-full"
						disabled={isSubmitting}
						onClick={submitItem}
					>
						<PackagePlusIcon className="size-4" />
						Create item
					</Button>
				</Surface>
			</section>
		</PageShell>
	);
}

function Field({ children, label }: { children: ReactNode; label: string }) {
	return (
		<label className="space-y-2">
			<span className="font-medium text-sm">{label}</span>
			{children}
		</label>
	);
}

function ValueTile({ label, value }: { label: string; value: string }) {
	return (
		<div className="rounded-2xl border border-border/70 bg-card p-3">
			<p className="font-medium text-muted-foreground text-xs uppercase tracking-[0.16em]">
				{label}
			</p>
			<p className="mt-2 font-medium text-sm">{value}</p>
		</div>
	);
}

function renderItemsContent({
	activeCategory,
	errorMessage,
	isLoading,
	items,
}: {
	activeCategory: InventoryCategory;
	errorMessage: string;
	isLoading: boolean;
	items: InventoryItem[];
}) {
	if (isLoading) {
		return <LoadingState message="Loading inventory items..." />;
	}

	if (errorMessage) {
		return <ErrorState message={errorMessage} title="Failed to load items" />;
	}

	if (items.length === 0) {
		return (
			<EmptyState title="No inventory items">
				Create the first {categoryLabels[activeCategory].toLowerCase()} item to
				start tracking stock.
			</EmptyState>
		);
	}

	return (
		<div className="grid gap-3">
			{items.map((item) => {
				const isLowStock =
					Number(item.currentStock) < Number(item.lowStockThreshold);
				return (
					<div
						className="rounded-2xl border border-border/70 bg-card p-4 shadow-sm"
						key={item.id}
					>
						<div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
							<div>
								<h2 className="font-semibold">{item.name}</h2>
								<p className="text-muted-foreground text-sm">
									{item.itemCode} · {item.unit}
								</p>
							</div>
							<StatusPill tone={isLowStock ? "danger" : "success"}>
								{isLowStock ? "Low stock" : "Healthy"}
							</StatusPill>
						</div>
						<div className="mt-4 grid gap-3 sm:grid-cols-3">
							<ValueTile
								label="Current"
								value={formatQuantity(Number(item.currentStock))}
							/>
							<ValueTile
								label={
									activeCategory === "raw_material" ? "Minimum" : "Reorder"
								}
								value={formatQuantity(Number(item.lowStockThreshold))}
							/>
							<ValueTile
								label="Supplier"
								value={item.supplierName ?? "Not set"}
							/>
						</div>
					</div>
				);
			})}
		</div>
	);
}

const selectClassName = cn(
	"h-10 w-full rounded-3xl border border-border bg-input/50 px-3 text-sm outline-none transition focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
);

function formatQuantity(value: number) {
	return Number.isInteger(value) ? String(value) : value.toFixed(3);
}
