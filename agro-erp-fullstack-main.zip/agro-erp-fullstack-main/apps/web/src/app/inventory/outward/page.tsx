"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ClipboardMinusIcon, RefreshCwIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import type { Dispatch, ReactNode, SetStateAction } from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import {
	ErrorState,
	LoadingState,
	MetricCard,
	PageHeader,
	PageShell,
	SectionHeader,
	Surface,
} from "@/components/ui-patterns";
import {
	fetchInventoryClientApi,
	postInventoryClientApi,
} from "@/lib/api-client";
import { authClient } from "@/lib/auth-client";

type InventoryCategory = "finished_good" | "packing_material" | "raw_material";

interface InventoryItem {
	category: "packing_material" | "raw_material";
	currentStock: string;
	id: string;
	name: string;
}

interface FinishedGood {
	id: string;
	name: string;
	quantity: number;
}

interface ItemsResponse {
	items: InventoryItem[];
	success: true;
}

interface FinishedGoodsResponse {
	products: FinishedGood[];
	success: true;
}

const emptyForm = {
	category: "finished_good" as InventoryCategory,
	inventoryItemId: "",
	productId: "",
	quantityReduced: "1",
	reason: "",
	remarks: "",
};

export default function OutwardPage() {
	const router = useRouter();
	const { data: session } = authClient.useSession();
	const [errorMessage, setErrorMessage] = useState("");
	const [finishedGoods, setFinishedGoods] = useState<FinishedGood[]>([]);
	const [form, setForm] = useState(emptyForm);
	const [items, setItems] = useState<InventoryItem[]>([]);
	const [isLoading, setIsLoading] = useState(true);
	const [isSubmitting, setIsSubmitting] = useState(false);

	const loadOptions = useCallback(async () => {
		setIsLoading(true);
		setErrorMessage("");
		try {
			const [rawItems, packingItems, products] = await Promise.all([
				fetchInventoryClientApi<ItemsResponse>("/items?category=raw_material"),
				fetchInventoryClientApi<ItemsResponse>(
					"/items?category=packing_material"
				),
				fetchInventoryClientApi<FinishedGoodsResponse>("/finished-goods"),
			]);
			setItems([...rawItems.items, ...packingItems.items]);
			setFinishedGoods(products.products);
		} catch (error) {
			setErrorMessage(
				error instanceof Error ? error.message : "Failed to load outward data"
			);
		} finally {
			setIsLoading(false);
		}
	}, []);

	useEffect(() => {
		loadOptions().catch(() => undefined);
	}, [loadOptions]);

	const selectedStock = useMemo(() => {
		if (form.category === "finished_good") {
			return (
				finishedGoods.find((item) => item.id === form.productId)?.quantity ?? 0
			);
		}

		return Number(
			items.find((item) => item.id === form.inventoryItemId)?.currentStock ?? 0
		);
	}, [
		finishedGoods,
		form.category,
		form.inventoryItemId,
		form.productId,
		items,
	]);
	const quantityReduced = Number(form.quantityReduced || 0);
	const resultingStock = Math.max(selectedStock - quantityReduced, 0);
	const selectableItems =
		form.category === "finished_good"
			? finishedGoods
			: items.filter((item) => item.category === form.category);
	const canSubmit =
		quantityReduced > 0 &&
		quantityReduced <= selectedStock &&
		form.reason.trim().length > 1 &&
		(form.category === "finished_good" ? form.productId : form.inventoryItemId);

	const submitOutward = async () => {
		const approvedByUserId = session?.user.id;
		if (!approvedByUserId) {
			toast.error("You must sign in first");
			return;
		}

		setIsSubmitting(true);
		try {
			await postInventoryClientApi("/outward", {
				approvedByUserId,
				category: form.category,
				inventoryItemId:
					form.category === "finished_good" ? undefined : form.inventoryItemId,
				productId:
					form.category === "finished_good" ? form.productId : undefined,
				quantityReduced,
				reason: form.reason,
				remarks: form.remarks || undefined,
			});
			toast.success("Stock outward recorded");
			setForm(emptyForm);
			await loadOptions();
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to reduce stock"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<PageShell>
			<PageHeader
				actions={
					<Button
						onClick={() => loadOptions().catch(() => undefined)}
						variant="outline"
					>
						<RefreshCwIcon className="size-4" />
						Refresh
					</Button>
				}
				backHref="/inventory"
				eyebrow="Inventory"
				title="Stock outward"
			>
				<p>
					Reduce stock for damage, expiry, or internal usage with approval
					attribution.
				</p>
			</PageHeader>

			{renderOutwardContent({
				canSubmit,
				errorMessage,
				form,
				isLoading,
				isSubmitting,
				quantityReduced,
				resultingStock,
				selectableItems,
				selectedStock,
				setForm,
				submitOutward,
			})}
		</PageShell>
	);
}

function renderOutwardContent({
	canSubmit,
	errorMessage,
	form,
	isLoading,
	isSubmitting,
	quantityReduced,
	resultingStock,
	selectableItems,
	selectedStock,
	setForm,
	submitOutward,
}: {
	canSubmit: false | string;
	errorMessage: string;
	form: typeof emptyForm;
	isLoading: boolean;
	isSubmitting: boolean;
	quantityReduced: number;
	resultingStock: number;
	selectableItems: Array<FinishedGood | InventoryItem>;
	selectedStock: number;
	setForm: Dispatch<SetStateAction<typeof emptyForm>>;
	submitOutward: () => Promise<void>;
}) {
	if (isLoading) {
		return <LoadingState message="Loading stock options..." />;
	}

	if (errorMessage) {
		return <ErrorState message={errorMessage} title="Failed to load outward" />;
	}

	return (
		<section className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
			<Surface className="space-y-5">
				<SectionHeader title="Outward entry">
					Reason is required. The approved-by user is your current account.
				</SectionHeader>
				<div className="grid gap-4 md:grid-cols-2">
					<Field label="Category">
						<select
							className={selectClassName}
							onChange={(event) =>
								setForm((current) => ({
									...current,
									category: event.target.value as InventoryCategory,
									inventoryItemId: "",
									productId: "",
								}))
							}
							value={form.category}
						>
							<option value="finished_good">Finished goods</option>
							<option value="raw_material">Raw material</option>
							<option value="packing_material">Packing material</option>
						</select>
					</Field>
					<Field label="Item name">
						<select
							className={selectClassName}
							onChange={(event) =>
								setForm((current) => ({
									...current,
									inventoryItemId:
										current.category === "finished_good"
											? current.inventoryItemId
											: event.target.value,
									productId:
										current.category === "finished_good"
											? event.target.value
											: current.productId,
								}))
							}
							value={
								form.category === "finished_good"
									? form.productId
									: form.inventoryItemId
							}
						>
							<option value="">Select item</option>
							{selectableItems.map((item) => (
								<option key={item.id} value={item.id}>
									{item.name}
								</option>
							))}
						</select>
					</Field>
					<Field label="Quantity reduced">
						<Input
							min="0"
							onChange={(event) =>
								setForm((current) => ({
									...current,
									quantityReduced: event.target.value,
								}))
							}
							type="number"
							value={form.quantityReduced}
						/>
					</Field>
					<Field label="Reason">
						<Input
							onChange={(event) =>
								setForm((current) => ({
									...current,
									reason: event.target.value,
								}))
							}
							placeholder="Damage / Expiry / Internal usage"
							value={form.reason}
						/>
					</Field>
					<label className="space-y-2 md:col-span-2">
						<span className="font-medium text-sm">Remarks</span>
						<Textarea
							onChange={(event) =>
								setForm((current) => ({
									...current,
									remarks: event.target.value,
								}))
							}
							value={form.remarks}
						/>
					</label>
				</div>
				<Button
					disabled={!canSubmit || isSubmitting}
					onClick={() => submitOutward().catch(() => undefined)}
					variant="destructive"
				>
					<ClipboardMinusIcon className="size-4" />
					Record stock outward
				</Button>
			</Surface>

			<Surface className="space-y-4">
				<SectionHeader title="Stock preview" />
				<MetricCard
					label="Current stock"
					value={formatQuantity(selectedStock)}
				/>
				<MetricCard
					label="Quantity reduced"
					value={formatQuantity(quantityReduced)}
				/>
				<MetricCard
					label="Resulting stock"
					value={formatQuantity(resultingStock)}
				/>
			</Surface>
		</section>
	);
}

function Field({ children, label }: { children: ReactNode; label: string }) {
	return (
		<label className="space-y-2">
			<span className="font-medium text-sm">{label}</span>
			{children}
		</label>
	);
}

const selectClassName = cn(
	"h-10 w-full rounded-3xl border border-border bg-input/50 px-3 text-sm outline-none transition focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
);

function formatQuantity(value: number) {
	if (!Number.isFinite(value)) {
		return "0";
	}

	return Number.isInteger(value) ? String(value) : value.toFixed(3);
}
