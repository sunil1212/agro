import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

interface SessionResponse {
	session?: unknown;
	user?: unknown;
}

const publicAssetPattern = /\.(.*)$/;

export async function proxy(request: NextRequest) {
	const { pathname } = request.nextUrl;

	if (isPublicAssetPath(pathname)) {
		return NextResponse.next();
	}

	const hasSession = await getHasSession(request);
	const isRootPath = pathname === "/";

	if (hasSession && isRootPath) {
		return NextResponse.redirect(new URL("/dashboard", request.url));
	}

	if (!(hasSession || isRootPath)) {
		return NextResponse.redirect(new URL("/", request.url));
	}

	return NextResponse.next();
}

export const config = {
	matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};

function isPublicAssetPath(pathname: string) {
	return (
		pathname.startsWith("/_next") ||
		pathname === "/favicon.ico" ||
		publicAssetPattern.test(pathname)
	);
}

async function getHasSession(request: NextRequest) {
	const authBaseUrl =
		process.env.API_INTERNAL_URL ?? process.env.NEXT_PUBLIC_SERVER_URL;
	if (!authBaseUrl) {
		return false;
	}

	try {
		const response = await fetch(
			new URL("/api/auth/get-session", authBaseUrl),
			{
				cache: "no-store",
				headers: {
					cookie: request.headers.get("cookie") ?? "",
				},
			}
		);

		if (!response.ok) {
			return false;
		}

		const session = (await response.json()) as SessionResponse | null;
		return Boolean(session?.user);
	} catch {
		return false;
	}
}
