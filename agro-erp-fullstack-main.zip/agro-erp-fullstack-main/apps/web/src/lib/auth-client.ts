import { createAuthClient } from "better-auth/react";

import { clientApiBaseUrl } from "./api-client";

export const authClient = createAuthClient(
	clientApiBaseUrl ? { baseURL: clientApiBaseUrl } : {}
);
