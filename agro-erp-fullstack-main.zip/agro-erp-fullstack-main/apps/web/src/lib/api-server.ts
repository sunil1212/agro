import "server-only";

import { cookies } from "next/headers";
import type { ApiResource } from "./api-client";

type HttpMethod = "PATCH" | "POST";

interface ApiErrorResponse {
	message?: string;
}

export const serverApiBaseUrl =
	process.env.API_INTERNAL_URL ??
	process.env.NEXT_PUBLIC_SERVER_URL ??
	"http://localhost:3000";

export async function fetchServerApi<TResponse>(
	resource: ApiResource,
	path = "",
	requestInit?: RequestInit
): Promise<TResponse> {
	const cookieStore = await cookies();
	const cookieHeader = cookieStore.toString();

	const response = await fetch(`${serverApiBaseUrl}/api/${resource}${path}`, {
		cache: "no-store",
		...requestInit,
		headers: {
			...(cookieHeader ? { Cookie: cookieHeader } : {}),
			...(requestInit?.headers ?? {}),
		},
	});

	if (!response.ok) {
		const errorBody = (await response
			.json()
			.catch(() => null)) as ApiErrorResponse | null;

		throw new Error(
			errorBody?.message ??
				`Failed to fetch ${resource.replaceAll("-", " ")} data`
		);
	}

	return (await response.json()) as TResponse;
}

const writeServerApi = <TResponse>(
	resource: ApiResource,
	path: string,
	method: HttpMethod,
	body: unknown
) =>
	fetchServerApi<TResponse>(resource, path, {
		body: JSON.stringify(body),
		headers: { "Content-Type": "application/json" },
		method,
	});

export const postServerApi = <TResponse>(
	resource: ApiResource,
	path: string,
	body: unknown
) => writeServerApi<TResponse>(resource, path, "POST", body);

export const patchServerApi = <TResponse>(
	resource: ApiResource,
	path: string,
	body: unknown
) => writeServerApi<TResponse>(resource, path, "PATCH", body);
