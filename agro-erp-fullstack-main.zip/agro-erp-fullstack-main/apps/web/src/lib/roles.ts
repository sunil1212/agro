export const roleLabels = {
	admin: "Admin",
	advisor: "Advisor",
	logistics: "Logistics Executive",
	superadmin: "Super Admin",
	team_leader: "Team Leader",
	warehouse: "Warehouse",
} as const;

export type RoleKey = keyof typeof roleLabels;

export const getRoleLabel = (role: string): string =>
	role in roleLabels ? roleLabels[role as RoleKey] : role;

export const advisorRoleValues = ["advisor"] as const;

export const isAdvisorRole = (role: string): boolean =>
	advisorRoleValues.some((advisorRole) => advisorRole === role);

export const isAdvisorLikeRole = (role: string): boolean => isAdvisorRole(role);
