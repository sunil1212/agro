export const clientApiBaseUrl = process.env.NEXT_PUBLIC_SERVER_URL ?? "";

export type ApiResource =
	| "accounts"
	| "advisor-tasks"
	| "analytics"
	| "branches"
	| "consignments"
	| "crops"
	| "farmers"
	| "inventory"
	| "orders"
	| "products";

type HttpMethod = "DELETE" | "PATCH" | "POST";

interface ApiErrorResponse {
	message?: string;
}

export const getClientApiUrl = (resource: ApiResource, path = "") =>
	`${clientApiBaseUrl}/api/${resource}${path}`;

export async function fetchClientApi<TResponse>(
	resource: ApiResource,
	path = "",
	requestInit?: RequestInit
): Promise<TResponse> {
	const response = await fetch(getClientApiUrl(resource, path), {
		cache: "no-store",
		credentials: "include",
		...requestInit,
		headers: {
			...(requestInit?.headers ?? {}),
		},
	});

	if (!response.ok) {
		const errorBody = (await response
			.json()
			.catch(() => null)) as ApiErrorResponse | null;

		throw new Error(
			errorBody?.message ??
				`Failed to fetch ${resource.replaceAll("-", " ")} data`
		);
	}

	return (await response.json()) as TResponse;
}

const writeClientApi = <TResponse>(
	resource: ApiResource,
	path: string,
	method: HttpMethod,
	body: unknown
) =>
	fetchClientApi<TResponse>(resource, path, {
		body: JSON.stringify(body),
		headers: { "Content-Type": "application/json" },
		method,
	});

export const postClientApi = <TResponse>(
	resource: ApiResource,
	path: string,
	body: unknown
) => writeClientApi<TResponse>(resource, path, "POST", body);

export const patchClientApi = <TResponse>(
	resource: ApiResource,
	path: string,
	body: unknown
) => writeClientApi<TResponse>(resource, path, "PATCH", body);

export const deleteClientApi = <TResponse>(
	resource: ApiResource,
	path: string
) => fetchClientApi<TResponse>(resource, path, { method: "DELETE" });

export const fetchInventoryClientApi = <TResponse>(path: string) =>
	fetchClientApi<TResponse>("inventory", path);

export const postInventoryClientApi = <TResponse>(
	path: string,
	body: unknown
) => postClientApi<TResponse>("inventory", path, body);

export const patchInventoryClientApi = <TResponse>(
	path: string,
	body: unknown
) => patchClientApi<TResponse>("inventory", path, body);

export const fetchOrdersClientApi = <TResponse>(
	path: string,
	requestInit?: RequestInit
) => fetchClientApi<TResponse>("orders", path, requestInit);

export const postOrdersClientApi = <TResponse>(path: string, body: unknown) =>
	postClientApi<TResponse>("orders", path, body);

export const patchOrdersClientApi = <TResponse>(path: string, body: unknown) =>
	patchClientApi<TResponse>("orders", path, body);
