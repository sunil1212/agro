let fallbackIdCounter = 0;

const createFallbackId = () => {
	fallbackIdCounter += 1;
	return [
		Date.now().toString(36),
		fallbackIdCounter.toString(36),
		Math.random().toString(36).slice(2),
	].join("-");
};

export const createClientId = () => {
	const webCrypto = globalThis.crypto;

	if (typeof webCrypto?.randomUUID === "function") {
		try {
			return webCrypto.randomUUID();
		} catch {
			return createFallbackId();
		}
	}

	if (typeof webCrypto?.getRandomValues === "function") {
		try {
			const values = new Uint32Array(4);
			webCrypto.getRandomValues(values);
			return Array.from(values, (value) =>
				value.toString(16).padStart(8, "0")
			).join("-");
		} catch {
			return createFallbackId();
		}
	}

	return createFallbackId();
};
