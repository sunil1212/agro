"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { Trash2Icon, UploadIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { postClientApi } from "@/lib/api-client";
import { createClientId } from "@/lib/client-id";
import type { ImportConsignmentsResponse } from "./consignment-types";

const pageSize = 25;
const consignmentNumberPattern = /^[a-zA-Z0-9/-]+$/;
const newlinePattern = /\r?\n/;

interface EditableConsignment {
	id: string;
	serialNumber: string;
	value: string;
}

const parseCsvRows = (text: string) =>
	text
		.split(newlinePattern)
		.map((row) => row.trim())
		.filter(Boolean)
		.slice(1)
		.map((row) => {
			const [firstValue = "", secondValue = ""] = row.split(",");
			const hasSecondColumn = secondValue.trim().length > 0;
			return {
				consignmentNumber: hasSecondColumn
					? secondValue.trim()
					: firstValue.trim(),
				serialNumber: hasSecondColumn ? firstValue.trim() : "",
			};
		})
		.filter(({ consignmentNumber, serialNumber }) =>
			Boolean(consignmentNumber || serialNumber)
		)
		.map(({ consignmentNumber, serialNumber }) => ({
			id: createClientId(),
			serialNumber,
			value: consignmentNumber.toUpperCase(),
		}));

const normalizeRows = (rows: EditableConsignment[]) => {
	const seenNumbers = new Set<string>();

	return rows.flatMap((row) => {
		const consignmentNumber = row.value.trim().toUpperCase();
		const serialNumber =
			row.serialNumber.trim().length > 0 ? Number(row.serialNumber) : undefined;

		if (!consignmentNumber || seenNumbers.has(consignmentNumber)) {
			return [];
		}

		seenNumbers.add(consignmentNumber);
		return [{ consignmentNumber, serialNumber }];
	});
};

export function ConsignmentImportEditor() {
	const router = useRouter();
	const [rows, setRows] = useState<EditableConsignment[]>([]);
	const [page, setPage] = useState(1);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
	const visibleRows = useMemo(() => {
		const startIndex = (page - 1) * pageSize;
		return rows.slice(startIndex, startIndex + pageSize);
	}, [page, rows]);

	const handleFileChange = async (
		event: React.ChangeEvent<HTMLInputElement>
	) => {
		const file = event.target.files?.[0];
		if (!file) {
			return;
		}

		const text = await file.text();
		const parsedRows = parseCsvRows(text);
		setRows(parsedRows);
		setPage(1);
		toast.success(`${parsedRows.length} rows loaded`);
	};

	const handleSerialNumberChange = (rowId: string, serialNumber: string) => {
		setRows((currentRows) =>
			currentRows.map((row) =>
				row.id === rowId ? { ...row, serialNumber } : row
			)
		);
	};

	const handleConsignmentNumberChange = (rowId: string, value: string) => {
		setRows((currentRows) =>
			currentRows.map((row) =>
				row.id === rowId ? { ...row, value: value.toUpperCase() } : row
			)
		);
	};

	const handleDeleteRow = (rowId: string) => {
		setRows((currentRows) => {
			const nextRows = currentRows.filter((row) => row.id !== rowId);
			const nextPageCount = Math.max(1, Math.ceil(nextRows.length / pageSize));
			setPage((currentPage) => Math.min(currentPage, nextPageCount));
			return nextRows;
		});
	};

	const handleSubmit = async () => {
		const consignments = normalizeRows(rows);
		const invalidSerialNumber = consignments.find(
			(row) =>
				row.serialNumber !== undefined &&
				(!Number.isInteger(row.serialNumber) || row.serialNumber <= 0)
		);
		const duplicateSerialNumber = consignments.find(
			(row, index, values) =>
				row.serialNumber !== undefined &&
				values.findIndex(
					(currentRow) => currentRow.serialNumber === row.serialNumber
				) !== index
		);
		const invalidNumber = consignments.find(
			(row) => !consignmentNumberPattern.test(row.consignmentNumber)
		);

		if (consignments.length === 0) {
			toast.error("Add at least one consignment number");
			return;
		}

		if (invalidSerialNumber) {
			toast.error("Serial numbers must be whole numbers greater than zero");
			return;
		}

		if (duplicateSerialNumber) {
			toast.error(
				`Serial number ${duplicateSerialNumber.serialNumber} appears more than once`
			);
			return;
		}

		if (invalidNumber) {
			toast.error(
				`${invalidNumber.consignmentNumber} has unsupported characters`
			);
			return;
		}

		setIsSubmitting(true);
		try {
			const result = await postClientApi<ImportConsignmentsResponse>(
				"consignments",
				"/import",
				{ consignments }
			);
			toast.success(
				`Imported ${result.inserted}, reactivated ${result.reactivated}, skipped ${result.skipped}`
			);
			setRows([]);
			setPage(1);
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Unable to import consignments"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<div className="space-y-5">
			<div className="flex flex-col gap-3 rounded-lg border bg-card p-4 sm:flex-row sm:items-center sm:justify-between">
				<div>
					<p className="font-medium text-sm">CSV file</p>
					<p className="text-muted-foreground text-sm">
						Use `serial number, consignment number` or only `consignment
						number`.
					</p>
				</div>
				<Input
					accept=".csv,text/csv"
					className="max-w-sm"
					onChange={handleFileChange}
					type="file"
				/>
			</div>

			<div className="overflow-hidden rounded-lg border bg-card">
				<Table>
					<TableHeader>
						<TableRow>
							<TableHead className="w-32">Serial number</TableHead>
							<TableHead>Consignment number</TableHead>
							<TableHead className="w-16 text-right">Delete</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{visibleRows.length > 0 ? (
							visibleRows.map((row, index) => (
								<TableRow className="group" key={row.id}>
									<TableCell className="text-muted-foreground">
										<Input
											aria-label={`Serial number ${
												(page - 1) * pageSize + index + 1
											}`}
											inputMode="numeric"
											onChange={(event) =>
												handleSerialNumberChange(row.id, event.target.value)
											}
											value={row.serialNumber}
										/>
									</TableCell>
									<TableCell>
										<Input
											aria-label={`Consignment number ${
												(page - 1) * pageSize + index + 1
											}`}
											className="font-mono"
											onChange={(event) =>
												handleConsignmentNumberChange(
													row.id,
													event.target.value
												)
											}
											value={row.value}
										/>
									</TableCell>
									<TableCell className="text-right">
										<Button
											aria-label={`Remove consignment row ${
												(page - 1) * pageSize + index + 1
											}`}
											className="opacity-0 transition focus-visible:opacity-100 group-hover:opacity-100"
											onClick={() => handleDeleteRow(row.id)}
											size="icon-sm"
											type="button"
											variant="destructive"
										>
											<Trash2Icon />
										</Button>
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell
									className="h-24 text-center text-muted-foreground"
									colSpan={3}
								>
									Select a CSV file to preview consignment numbers.
								</TableCell>
							</TableRow>
						)}
					</TableBody>
				</Table>
			</div>

			<div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
				<Pagination className="sm:mx-0 sm:w-auto">
					<PaginationContent>
						<PaginationItem>
							<PaginationPrevious
								disabled={page === 1}
								onClick={() => setPage((currentPage) => currentPage - 1)}
							/>
						</PaginationItem>
						<PaginationItem>
							<span className="px-3 text-muted-foreground text-sm">
								Page {page} of {pageCount}
							</span>
						</PaginationItem>
						<PaginationItem>
							<PaginationNext
								disabled={page === pageCount}
								onClick={() => setPage((currentPage) => currentPage + 1)}
							/>
						</PaginationItem>
					</PaginationContent>
				</Pagination>
				<Button
					disabled={isSubmitting || rows.length === 0}
					onClick={handleSubmit}
				>
					<UploadIcon />
					Import consignments
				</Button>
			</div>
		</div>
	);
}
