"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { ArrowDownIcon, ArrowUpIcon, Trash2Icon } from "lucide-react";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { StatusPill } from "@/components/ui-patterns";
import { deleteClientApi } from "@/lib/api-client";
import type { ConsignmentRecord } from "./consignment-types";

const pageSize = 25;
type ConsignmentSortKey = "addedAt" | "serialNumber" | "status";
type SortDirection = "asc" | "desc";

interface ConsignmentsTableProps {
	consignments: ConsignmentRecord[];
}

const formatAddedAt = (value: string) =>
	new Intl.DateTimeFormat("en-IN", {
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		month: "short",
		timeZone: "Asia/Kolkata",
		year: "numeric",
	}).format(new Date(value));

export function ConsignmentsTable({ consignments }: ConsignmentsTableProps) {
	const router = useRouter();
	const [currentConsignments, setCurrentConsignments] = useState(consignments);
	const [page, setPage] = useState(1);
	const [deletingId, setDeletingId] = useState<null | string>(null);
	const [sortBy, setSortBy] = useState<ConsignmentSortKey>("serialNumber");
	const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
	const filteredConsignments = useMemo(() => {
		const rows = [...currentConsignments];

		rows.sort((left, right) => {
			let comparison = 0;

			if (sortBy === "serialNumber") {
				comparison = left.serialNumber - right.serialNumber;
			} else if (sortBy === "addedAt") {
				comparison =
					new Date(left.addedAt).getTime() - new Date(right.addedAt).getTime();
			} else {
				comparison = Number(left.isActive) - Number(right.isActive);
			}

			return sortDirection === "asc" ? comparison : -comparison;
		});

		return rows;
	}, [currentConsignments, sortBy, sortDirection]);
	const pageCount = Math.max(
		1,
		Math.ceil(filteredConsignments.length / pageSize)
	);
	const visibleConsignments = useMemo(() => {
		const startIndex = (page - 1) * pageSize;
		return filteredConsignments.slice(startIndex, startIndex + pageSize);
	}, [filteredConsignments, page]);

	const toggleSort = (nextSortBy: ConsignmentSortKey) => {
		setPage(1);
		if (sortBy === nextSortBy) {
			setSortDirection((current) => (current === "asc" ? "desc" : "asc"));
			return;
		}

		setSortBy(nextSortBy);
		setSortDirection("asc");
	};

	const sortIcon = (column: ConsignmentSortKey) => {
		if (sortBy !== column) {
			return <ArrowDownIcon className="size-3 opacity-30" />;
		}

		return sortDirection === "asc" ? (
			<ArrowUpIcon className="size-3" />
		) : (
			<ArrowDownIcon className="size-3" />
		);
	};

	const handleDelete = async (currentConsignment: ConsignmentRecord) => {
		setDeletingId(currentConsignment.id);
		try {
			await deleteClientApi<{ success: true }>(
				"consignments",
				`/${currentConsignment.id}`
			);
			setCurrentConsignments((rows) => {
				const nextRows = rows.filter((row) => row.id !== currentConsignment.id);
				const nextPageCount = Math.max(
					1,
					Math.ceil(nextRows.length / pageSize)
				);
				setPage((currentPage) => Math.min(currentPage, nextPageCount));
				return nextRows;
			});
			toast.success("Consignment deleted");
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Unable to delete consignment"
			);
		} finally {
			setDeletingId(null);
		}
	};

	return (
		<div className="space-y-4">
			<div className="overflow-hidden rounded-lg border bg-card">
				<Table>
					<TableHeader>
						<TableRow>
							<TableHead className="w-28">
								<button
									className="inline-flex items-center gap-1 text-left font-medium"
									onClick={() => toggleSort("serialNumber")}
									type="button"
								>
									Serial number
									{sortIcon("serialNumber")}
								</button>
							</TableHead>
							<TableHead>Consignment number</TableHead>
							<TableHead>
								<button
									className="inline-flex items-center gap-1 text-left font-medium"
									onClick={() => toggleSort("addedAt")}
									type="button"
								>
									Added timestamp
									{sortIcon("addedAt")}
								</button>
							</TableHead>
							<TableHead>
								<button
									className="inline-flex items-center gap-1 text-left font-medium"
									onClick={() => toggleSort("status")}
									type="button"
								>
									Status
									{sortIcon("status")}
								</button>
							</TableHead>
							<TableHead className="w-16 text-right">Delete</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{visibleConsignments.length > 0 ? (
							visibleConsignments.map((currentConsignment) => (
								<TableRow className="group" key={currentConsignment.id}>
									<TableCell className="text-muted-foreground">
										{currentConsignment.serialNumber}
									</TableCell>
									<TableCell className="font-medium font-mono">
										{currentConsignment.consignmentNumber}
									</TableCell>
									<TableCell className="text-muted-foreground">
										{formatAddedAt(currentConsignment.addedAt)}
									</TableCell>
									<TableCell>
										<StatusPill>
											{currentConsignment.isActive ? "Active" : "Inactive"}
										</StatusPill>
									</TableCell>
									<TableCell className="text-right">
										<Button
											aria-label={`Delete ${currentConsignment.consignmentNumber}`}
											className="opacity-0 transition focus-visible:opacity-100 group-hover:opacity-100"
											disabled={deletingId === currentConsignment.id}
											onClick={() => {
												handleDelete(currentConsignment).catch(() => undefined);
											}}
											size="icon-sm"
											variant="destructive"
										>
											<Trash2Icon />
										</Button>
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell
									className="h-24 text-center text-muted-foreground"
									colSpan={5}
								>
									No consignment numbers remain.
								</TableCell>
							</TableRow>
						)}
					</TableBody>
				</Table>
			</div>
			<Pagination>
				<PaginationContent>
					<PaginationItem>
						<PaginationPrevious
							disabled={page === 1}
							onClick={() => setPage((currentPage) => currentPage - 1)}
						/>
					</PaginationItem>
					<PaginationItem>
						<span className="px-3 text-muted-foreground text-sm">
							Page {page} of {pageCount}
						</span>
					</PaginationItem>
					<PaginationItem>
						<PaginationNext
							disabled={page === pageCount}
							onClick={() => setPage((currentPage) => currentPage + 1)}
						/>
					</PaginationItem>
				</PaginationContent>
			</Pagination>
		</div>
	);
}
