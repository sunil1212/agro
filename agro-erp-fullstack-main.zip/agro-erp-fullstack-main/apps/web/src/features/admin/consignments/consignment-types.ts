export interface ConsignmentRecord {
	addedAt: string;
	consignmentNumber: string;
	id: string;
	isActive: boolean;
	serialNumber: number;
}

export interface ImportConsignmentsResponse {
	inserted: number;
	reactivated: number;
	received: number;
	skipped: number;
	success: true;
}
