export interface ProductImportRow {
	categoryCode: string;
	discount: number;
	mrp: number;
	packageQuantity: number;
	packageUnit: string;
	packagingType: string;
	packingCode: string;
	productCode: string;
	productName: string;
	sellingPrice: number;
	sku: string;
	stock: number;
}

export interface ImportProductsResponse {
	inserted: number;
	received: number;
	success: true;
	updated: number;
}
