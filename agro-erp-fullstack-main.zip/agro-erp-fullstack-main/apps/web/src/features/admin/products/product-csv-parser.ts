import type { ProductImportRow } from "./product-import-types";

const requiredHeaders = [
	"category_code",
	"product_code",
	"packing_code",
	"sku",
	"product_name",
	"size",
	"unit",
	"packaging_type",
	"mrp",
	"discount",
	"selling_prize",
	"stock_nos",
] as const;
export const productImportRequiredHeaders = requiredHeaders;

const maximumImportRows = 5000;
const integerPattern = /^\d+$/;
const trailingPercentPattern = /%$/;
const byteOrderMarkPattern = /^\uFEFF/;
const newlinePattern = /\r?\n/;
const whitespacePattern = /\s/;

export interface ParsedProductCsv {
	errors: string[];
	rows: ProductImportRow[];
}

const normalizeHeader = (value: string) =>
	value
		.trim()
		.toLowerCase()
		.replaceAll(/[\s-]+/g, "_")
		.replaceAll(/[^a-z0-9_]/g, "");

const headerAliases = new Map<string, (typeof requiredHeaders)[number]>([
	["category", "category_code"],
	["cat_code", "category_code"],
	["product", "product_name"],
	["productname", "product_name"],
	["pack_code", "packing_code"],
	["packing", "packing_code"],
	["sku_code", "sku"],
	["pack_size", "size"],
	["package_size", "size"],
	["package_unit", "unit"],
	["pack_unit", "unit"],
	["packaging", "packaging_type"],
	["selling_price", "selling_prize"],
	["sellingprice", "selling_prize"],
	["sale_price", "selling_prize"],
	["stock", "stock_nos"],
	["stock_no", "stock_nos"],
]);

const normalizeProductHeader = (value: string) => {
	const normalized = normalizeHeader(value);
	return headerAliases.get(normalized) ?? normalized;
};

const detectDelimiter = (headerLine: string) => {
	const candidates = [",", "\t", ";"] as const;
	let selectedDelimiter: (typeof candidates)[number] = ",";
	let selectedCount = 0;

	for (const delimiter of candidates) {
		const delimiterCount = headerLine.split(delimiter).length - 1;
		if (delimiterCount > selectedCount) {
			selectedDelimiter = delimiter;
			selectedCount = delimiterCount;
		}
	}

	return selectedDelimiter;
};

const hasExplicitDelimiter = (line: string) =>
	line.includes(",") || line.includes("\t") || line.includes(";");

const parseWhitespaceRows = (text: string) => {
	const rows: string[][] = [];
	let currentField = "";
	let currentRow: string[] = [];
	let isQuoted = false;

	const completeField = () => {
		if (currentField || currentRow.length > 0) {
			currentRow.push(currentField);
		}
		currentField = "";
	};

	const completeRow = () => {
		completeField();
		if (currentRow.some((field) => field.trim())) {
			rows.push(currentRow);
		}
		currentRow = [];
	};

	for (let index = 0; index < text.length; index += 1) {
		const character = text[index] ?? "";
		const nextCharacter = text[index + 1] ?? "";

		if (character === '"') {
			if (isQuoted && nextCharacter === '"') {
				currentField += '"';
				index += 1;
			} else {
				isQuoted = !isQuoted;
			}
			continue;
		}

		if ((character === "\n" || character === "\r") && !isQuoted) {
			if (character === "\r" && nextCharacter === "\n") {
				index += 1;
			}
			completeRow();
			continue;
		}

		if (whitespacePattern.test(character) && !isQuoted) {
			if (currentField) {
				completeField();
			}
			continue;
		}

		currentField += character;
	}

	completeRow();

	return rows;
};

const parseDelimitedRows = (text: string, delimiter: string) => {
	const rows: string[][] = [];
	let currentField = "";
	let currentRow: string[] = [];
	let isQuoted = false;

	const completeRow = () => {
		currentRow.push(currentField);
		if (currentRow.some((field) => field.trim())) {
			rows.push(currentRow);
		}
		currentField = "";
		currentRow = [];
	};

	for (let index = 0; index < text.length; index += 1) {
		const character = text[index] ?? "";
		const nextCharacter = text[index + 1] ?? "";

		if (character === '"') {
			if (isQuoted && nextCharacter === '"') {
				currentField += '"';
				index += 1;
			} else {
				isQuoted = !isQuoted;
			}
			continue;
		}

		if (character === delimiter && !isQuoted) {
			currentRow.push(currentField);
			currentField = "";
			continue;
		}

		if ((character === "\n" || character === "\r") && !isQuoted) {
			if (character === "\r" && nextCharacter === "\n") {
				index += 1;
			}
			completeRow();
			continue;
		}

		currentField += character;
	}

	completeRow();

	return rows;
};

const parseNumber = (
	value: string,
	label: string,
	rowNumber: number,
	errors: string[]
) => {
	const normalizedValue = value
		.trim()
		.replaceAll(",", "")
		.replace(trailingPercentPattern, "");
	const parsedValue = Number(normalizedValue);
	if (normalizedValue === "" || !Number.isFinite(parsedValue)) {
		errors.push(`Row ${rowNumber}: ${label} must be a valid number.`);
		return 0;
	}
	return parsedValue;
};

const getCell = (
	row: string[],
	headerIndexes: Map<string, number>,
	header: (typeof requiredHeaders)[number]
) => row[headerIndexes.get(header) ?? -1]?.trim() ?? "";

const validateRequiredText = (
	value: string,
	label: string,
	rowNumber: number,
	errors: string[]
) => {
	if (!value) {
		errors.push(`Row ${rowNumber}: ${label} is required.`);
	}
};

const parseProductRow = (
	row: string[],
	headerIndexes: Map<string, number>,
	rowNumber: number,
	seenSkus: Set<string>,
	errors: string[]
): ProductImportRow => {
	const sku = getCell(row, headerIndexes, "sku").toUpperCase();
	const productName = getCell(row, headerIndexes, "product_name").trim();
	const packageQuantity = parseNumber(
		getCell(row, headerIndexes, "size"),
		"Size",
		rowNumber,
		errors
	);
	const mrp = parseNumber(
		getCell(row, headerIndexes, "mrp"),
		"MRP",
		rowNumber,
		errors
	);
	const discount = parseNumber(
		getCell(row, headerIndexes, "discount"),
		"Discount",
		rowNumber,
		errors
	);
	const sellingPrice = parseNumber(
		getCell(row, headerIndexes, "selling_prize"),
		"Selling_Prize",
		rowNumber,
		errors
	);
	const stockValue = getCell(row, headerIndexes, "stock_nos");
	const stock = parseNumber(stockValue, "Stock_Nos", rowNumber, errors);
	const categoryCode = getCell(
		row,
		headerIndexes,
		"category_code"
	).toUpperCase();
	const productCode = getCell(row, headerIndexes, "product_code").toUpperCase();
	const packingCode = getCell(row, headerIndexes, "packing_code").toUpperCase();
	const packageUnit = getCell(row, headerIndexes, "unit").toUpperCase();
	const packagingType = getCell(
		row,
		headerIndexes,
		"packaging_type"
	).toUpperCase();

	if (!sku) {
		errors.push(`Row ${rowNumber}: SKU is required.`);
	} else if (seenSkus.has(sku)) {
		errors.push(`Row ${rowNumber}: SKU ${sku} appears more than once.`);
	}
	seenSkus.add(sku);

	if (!productName) {
		errors.push(`Row ${rowNumber}: Product_Name is required.`);
	}
	validateRequiredText(categoryCode, "Category_Code", rowNumber, errors);
	validateRequiredText(productCode, "Product_Code", rowNumber, errors);
	validateRequiredText(packingCode, "Packing_Code", rowNumber, errors);
	validateRequiredText(packageUnit, "Unit", rowNumber, errors);
	validateRequiredText(packagingType, "Packaging_Type", rowNumber, errors);
	if (packageQuantity <= 0) {
		errors.push(`Row ${rowNumber}: Size must be greater than zero.`);
	}
	if (mrp < 0 || sellingPrice < 0) {
		errors.push(`Row ${rowNumber}: prices cannot be negative.`);
	}
	if (discount < 0 || discount > 100) {
		errors.push(`Row ${rowNumber}: Discount must be between 0 and 100.`);
	}
	if (!(integerPattern.test(stockValue.trim()) && stock >= 0)) {
		errors.push(`Row ${rowNumber}: Stock_Nos must be a whole number.`);
	}

	return {
		categoryCode,
		discount,
		mrp,
		packageQuantity,
		packageUnit,
		packagingType,
		packingCode,
		productCode,
		productName,
		sellingPrice,
		sku,
		stock,
	};
};

const createPositionalHeaderIndexes = () =>
	new Map<string, number>(
		requiredHeaders.map((header, index) => [header, index])
	);

const getRecognizedHeaderCount = (headers: string[]) =>
	headers.filter((header) =>
		requiredHeaders.some((requiredHeader) => requiredHeader === header)
	).length;

const isNumberLikeCell = (value: string) => {
	const normalizedValue = value
		.trim()
		.replaceAll(",", "")
		.replace(trailingPercentPattern, "");
	return normalizedValue !== "" && Number.isFinite(Number(normalizedValue));
};

const looksLikeHeaderlessProductRow = (row: string[]) =>
	row.length >= requiredHeaders.length &&
	isNumberLikeCell(row[5] ?? "") &&
	isNumberLikeCell(row[8] ?? "") &&
	isNumberLikeCell(row[9] ?? "") &&
	isNumberLikeCell(row[10] ?? "") &&
	integerPattern.test((row[11] ?? "").trim());

export const parseProductCsv = (text: string): ParsedProductCsv => {
	const normalizedText = text.replace(byteOrderMarkPattern, "");
	const firstLine = normalizedText.split(newlinePattern, 1)[0] ?? "";
	const rows = hasExplicitDelimiter(firstLine)
		? parseDelimitedRows(normalizedText, detectDelimiter(firstLine))
		: parseWhitespaceRows(normalizedText);
	const [headerRow, ...dataRows] = rows;
	const errors: string[] = [];

	if (!headerRow) {
		return { errors: ["The file is empty."], rows: [] };
	}

	const normalizedHeaders = headerRow.map(normalizeProductHeader);
	const recognizedHeaderCount = getRecognizedHeaderCount(normalizedHeaders);
	const shouldUseHeaderlessRows =
		recognizedHeaderCount < requiredHeaders.length &&
		looksLikeHeaderlessProductRow(headerRow);
	const headerIndexes = shouldUseHeaderlessRows
		? createPositionalHeaderIndexes()
		: new Map(
				headerRow.map((header, index) => [
					normalizeProductHeader(header),
					index,
				])
			);
	const effectiveDataRows = shouldUseHeaderlessRows ? rows : dataRows;
	const missingHeaders = requiredHeaders.filter(
		(header) => !headerIndexes.has(header)
	);
	if (missingHeaders.length > 0) {
		return {
			errors: [
				`Missing columns: ${missingHeaders
					.map((header) => header.replaceAll("_", " "))
					.join(", ")}.`,
			],
			rows: [],
		};
	}

	if (effectiveDataRows.length > maximumImportRows) {
		return {
			errors: [`Import ${maximumImportRows} products or fewer at a time.`],
			rows: [],
		};
	}

	if (effectiveDataRows.length === 0) {
		return { errors: ["The file has no product rows."], rows: [] };
	}

	const parsedRows: ProductImportRow[] = [];
	const seenSkus = new Set<string>();

	for (const [index, row] of effectiveDataRows.entries()) {
		parsedRows.push(
			parseProductRow(
				row,
				headerIndexes,
				shouldUseHeaderlessRows ? index + 1 : index + 2,
				seenSkus,
				errors
			)
		);
	}

	return { errors, rows: parsedRows };
};
