"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import {
	AlertCircleIcon,
	CheckCircle2Icon,
	FileSpreadsheetIcon,
	UploadIcon,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { postClientApi } from "@/lib/api-client";
import {
	parseProductCsv,
	productImportRequiredHeaders,
} from "./product-csv-parser";
import type {
	ImportProductsResponse,
	ProductImportRow,
} from "./product-import-types";

const previewRowLimit = 50;
const productImportHeaderLine = productImportRequiredHeaders.join(",");

function ProductHeaderGuide() {
	return (
		<div className="mt-4 rounded-2xl bg-primary/8 p-3 text-xs ring-1 ring-primary/15">
			<p className="font-medium text-primary">Required columns</p>
			<p className="mt-1 break-words font-mono text-foreground">
				{productImportHeaderLine}
			</p>
			<p className="mt-2 text-muted-foreground">
				Header row is recommended, but pasted rows in this exact order are also
				accepted.
			</p>
		</div>
	);
}

export function ProductImportEditor() {
	const router = useRouter();
	const fileInputRef = useRef<HTMLInputElement>(null);
	const [fileName, setFileName] = useState("");
	const [sourceText, setSourceText] = useState("");
	const [rows, setRows] = useState<ProductImportRow[]>([]);
	const [errors, setErrors] = useState<string[]>([]);
	const [isSubmitting, setIsSubmitting] = useState(false);

	const loadFile = async (file: File) => {
		if (
			!(file.name.toLowerCase().endsWith(".csv") || file.type === "text/csv")
		) {
			setRows([]);
			setErrors(["Choose a .csv file."]);
			setFileName(file.name);
			return;
		}

		const text = await file.text();
		const result = parseProductCsv(text);
		setSourceText(text);
		setFileName(file.name);
		setRows(result.rows);
		setErrors(result.errors);

		if (result.errors.length === 0) {
			toast.success(`${result.rows.length} products ready to import`);
		}
	};

	const handleSubmit = async () => {
		if (rows.length === 0 || errors.length > 0) {
			return;
		}

		setIsSubmitting(true);
		try {
			const result = await postClientApi<ImportProductsResponse>(
				"products",
				"/import",
				{ products: rows }
			);
			toast.success(
				`Imported ${result.inserted} new products and updated ${result.updated}`
			);
			setFileName("");
			setSourceText("");
			setRows([]);
			setErrors([]);
			if (fileInputRef.current) {
				fileInputRef.current.value = "";
			}
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Unable to import products"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	const handleTextChange = (nextValue: string) => {
		setSourceText(nextValue);
		setFileName("");
		if (!nextValue.trim()) {
			setRows([]);
			setErrors([]);
			return;
		}

		const result = parseProductCsv(nextValue);
		setRows(result.rows);
		setErrors(result.errors);
	};

	return (
		<div className="space-y-5">
			<input
				accept=".csv,text/csv"
				className="sr-only"
				onChange={async (event) => {
					const file = event.target.files?.[0];
					if (file) {
						await loadFile(file);
					}
				}}
				ref={fileInputRef}
				type="file"
			/>
			<div className="rounded-3xl border border-border/70 bg-card p-5 sm:p-6">
				<div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
					<div>
						<h2 className="font-semibold text-lg">Paste product sheet</h2>
						<p className="mt-1 max-w-2xl text-muted-foreground text-sm leading-6">
							Paste directly from Excel/Sheets or upload a CSV. Existing SKUs
							are updated; new SKUs are created with opening stock.
						</p>
					</div>
					<Button
						onClick={() => fileInputRef.current?.click()}
						type="button"
						variant="outline"
					>
						<FileSpreadsheetIcon />
						Choose CSV
					</Button>
				</div>
				<ProductHeaderGuide />
				<Textarea
					aria-label="Product import data"
					className="mt-5 min-h-56 resize-y font-mono text-xs"
					onChange={(event) => handleTextChange(event.target.value)}
					placeholder={`${productImportHeaderLine}\nCAT,PROD,01,CATPROD01,Product Name,1,L,BOX,100,10,90,50`}
					value={sourceText}
				/>
				{fileName ? (
					<p className="mt-3 font-mono text-muted-foreground text-xs">
						{fileName}
					</p>
				) : null}
			</div>

			{errors.length > 0 ? (
				<div
					className="rounded-2xl bg-destructive/8 p-4 text-destructive ring-1 ring-destructive/20"
					role="alert"
				>
					<div className="flex items-center gap-2 font-medium text-sm">
						<AlertCircleIcon className="size-4" />
						Fix {errors.length} CSV issue{errors.length === 1 ? "" : "s"}
					</div>
					<ul className="mt-3 max-h-44 space-y-1 overflow-y-auto pl-6 text-sm">
						{errors.slice(0, 100).map((error) => (
							<li className="list-disc" key={error}>
								{error}
							</li>
						))}
					</ul>
				</div>
			) : null}

			{rows.length > 0 ? (
				<>
					<div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
						<div className="flex items-center gap-2 text-sm">
							<CheckCircle2Icon className="size-4 text-primary" />
							<span className="font-medium">
								{errors.length === 0
									? `${rows.length} valid products`
									: `${rows.length} products parsed`}
							</span>
							<span className="text-muted-foreground">
								Previewing {Math.min(rows.length, previewRowLimit)}
							</span>
						</div>
						<Button
							disabled={isSubmitting || errors.length > 0}
							onClick={handleSubmit}
						>
							<UploadIcon />
							{isSubmitting ? "Importing…" : `Import ${rows.length} products`}
						</Button>
					</div>

					<div className="overflow-hidden rounded-2xl border border-border/70 bg-card">
						<div className="overflow-x-auto">
							<Table>
								<TableHeader>
									<TableRow>
										<TableHead>SKU</TableHead>
										<TableHead>Product</TableHead>
										<TableHead>Pack</TableHead>
										<TableHead className="text-right">MRP</TableHead>
										<TableHead className="text-right">Discount</TableHead>
										<TableHead className="text-right">Selling price</TableHead>
										<TableHead className="text-right">Stock</TableHead>
									</TableRow>
								</TableHeader>
								<TableBody>
									{rows.slice(0, previewRowLimit).map((row) => (
										<TableRow key={row.sku}>
											<TableCell className="font-mono">{row.sku}</TableCell>
											<TableCell>
												<p className="font-medium">{row.productName}</p>
												<p className="text-muted-foreground text-xs">
													{row.categoryCode} / {row.productCode} /{" "}
													{row.packingCode}
												</p>
											</TableCell>
											<TableCell>
												{row.packageQuantity} {row.packageUnit} ·{" "}
												{row.packagingType}
											</TableCell>
											<TableCell className="text-right tabular-nums">
												₹{row.mrp}
											</TableCell>
											<TableCell className="text-right tabular-nums">
												{row.discount}%
											</TableCell>
											<TableCell className="text-right tabular-nums">
												₹{row.sellingPrice}
											</TableCell>
											<TableCell className="text-right tabular-nums">
												{row.stock}
											</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</div>
					</div>
				</>
			) : null}
		</div>
	);
}
