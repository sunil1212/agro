export interface FarmerImportRow {
	addressAt: string;
	advisorName: string;
	alternateNumber?: string;
	cropText?: string;
	date: string;
	district: string;
	farmerName: string;
	farmSize?: string;
	irrigation?: string;
	landmark?: string;
	mobileNumber: string;
	pincode?: string;
	post: string;
	referenceFarmerMobile?: string;
	rowNumber: number;
	state?: string;
	taluka: string;
}

export interface FarmerImportResultEntry {
	farmerName: string;
	mobileNumber: string;
	rowNumber: number;
}

export interface ImportFarmersResponse {
	created: FarmerImportResultEntry[];
	failed: Array<FarmerImportResultEntry & { message: string }>;
	received: number;
	skipped: Array<FarmerImportResultEntry & { message: string }>;
	success: true;
}
