import type { FarmerImportRow } from "./farmer-import-types";

const requiredHeaders = [
	"AGENT_NAME",
	"FARMER_NAME",
	"DATE",
	"MOBILE_NUMBER",
] as const;
export const farmerImportRequiredHeaders = requiredHeaders;
export const farmerImportOptionalHeaders = [
	"ALTERNATE_NUMBER",
	"AT",
	"LANDMARK",
	"POST",
	"TALUKA",
	"DISTRICT",
	"STATE",
	"PINCODE",
	"FARMSIZE",
	"IRRIGATION",
	"CROPS",
	"REFERENCE_FARMER_MOBILE",
] as const;
export const farmerImportHeaderLine = [
	...farmerImportRequiredHeaders,
	...farmerImportOptionalHeaders,
].join(",");
const maximumImportRows = 1000;
const byteOrderMarkPattern = /^\uFEFF/;
const nonDigitPattern = /\D/g;
const dateSeparatorPattern = /[/-]/;
const lineBreakPattern = /\r?\n/;

const parseRows = (text: string, delimiter: string) => {
	const rows: string[][] = [];
	let field = "";
	let row: string[] = [];
	let quoted = false;

	const finishRow = () => {
		row.push(field);
		if (row.some((value) => value.trim())) {
			rows.push(row);
		}
		field = "";
		row = [];
	};

	for (let index = 0; index < text.length; index += 1) {
		const character = text[index] ?? "";
		const nextCharacter = text[index + 1] ?? "";
		if (character === '"') {
			if (quoted && nextCharacter === '"') {
				field += '"';
				index += 1;
			} else {
				quoted = !quoted;
			}
		} else if (character === delimiter && !quoted) {
			row.push(field);
			field = "";
		} else if ((character === "\n" || character === "\r") && !quoted) {
			if (character === "\r" && nextCharacter === "\n") {
				index += 1;
			}
			finishRow();
		} else {
			field += character;
		}
	}
	finishRow();
	return rows;
};

const normalizeHeader = (value: string) =>
	value.trim().toUpperCase().replaceAll(" ", "_");

const toIsoDate = (value: string) => {
	const trimmed = value.trim();
	const parts = trimmed.split(dateSeparatorPattern).map(Number);
	if (parts.length !== 3) {
		return null;
	}
	const [month, day, year] = parts;
	if (!(month && day && year)) {
		return null;
	}
	const date = new Date(Date.UTC(year, month - 1, day));
	if (
		date.getUTCFullYear() !== year ||
		date.getUTCMonth() !== month - 1 ||
		date.getUTCDate() !== day
	) {
		return null;
	}
	return date.toISOString().slice(0, 10);
};

const normalizeMobile = (value: string) => value.replace(nonDigitPattern, "");

// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: row-level validation is clearer when each sheet rule is visible together
export const parseFarmerCsv = (text: string) => {
	const cleanText = text.replace(byteOrderMarkPattern, "");
	const firstLine = cleanText.split(lineBreakPattern, 1)[0] ?? "";
	const delimiter = firstLine.includes("\t") ? "\t" : ",";
	const rawRows = parseRows(cleanText, delimiter);
	const errors: string[] = [];
	const [headerRow, ...dataRows] = rawRows;

	if (!headerRow) {
		return { errors: [], rows: [] as FarmerImportRow[] };
	}

	const headerIndexes = new Map(
		headerRow.map((header, index) => [normalizeHeader(header), index])
	);
	for (const header of requiredHeaders) {
		if (!headerIndexes.has(header)) {
			errors.push(`Missing required column: ${header}`);
		}
	}
	if (errors.length > 0) {
		return { errors, rows: [] as FarmerImportRow[] };
	}

	const value = (row: string[], header: string) =>
		row[headerIndexes.get(header) ?? -1]?.trim() ?? "";
	const rows: FarmerImportRow[] = [];

	for (const [index, rawRow] of dataRows.entries()) {
		const rowNumber = index + 2;
		const date = toIsoDate(value(rawRow, "DATE"));
		const mobileNumber = normalizeMobile(value(rawRow, "MOBILE_NUMBER"));
		const pincode = normalizeMobile(value(rawRow, "PINCODE"));
		const farmerName = value(rawRow, "FARMER_NAME");

		if (!farmerName) {
			errors.push(`Row ${rowNumber}: FARMER_NAME is required.`);
		}
		if (!date) {
			errors.push(`Row ${rowNumber}: DATE must use M/D/YYYY format.`);
		}
		if (mobileNumber.length !== 10 && mobileNumber.length !== 12) {
			errors.push(`Row ${rowNumber}: MOBILE_NUMBER must be 10 digits.`);
		}
		if (pincode && pincode.length !== 6) {
			errors.push(`Row ${rowNumber}: PINCODE must be 6 digits.`);
		}
		if (!value(rawRow, "AGENT_NAME")) {
			errors.push(`Row ${rowNumber}: AGENT_NAME is required.`);
		}
		if (!(farmerName && date)) {
			continue;
		}

		rows.push({
			addressAt: value(rawRow, "AT"),
			advisorName: value(rawRow, "AGENT_NAME"),
			alternateNumber: normalizeMobile(value(rawRow, "ALTERNATE_NUMBER")),
			cropText: value(rawRow, "CROPS"),
			date,
			district: value(rawRow, "DISTRICT"),
			farmerName,
			farmSize: value(rawRow, "FARMSIZE"),
			irrigation: value(rawRow, "IRRIGATION"),
			landmark: value(rawRow, "LANDMARK"),
			mobileNumber,
			pincode,
			post: value(rawRow, "POST"),
			referenceFarmerMobile: normalizeMobile(
				value(rawRow, "REFERENCE_FARMER_MOBILE")
			),
			rowNumber,
			state: value(rawRow, "STATE"),
			taluka: value(rawRow, "TALUKA"),
		});
	}

	if (rows.length > maximumImportRows) {
		return {
			errors: [`Import ${maximumImportRows} farmers or fewer at a time.`],
			rows: [] as FarmerImportRow[],
		};
	}
	return { errors, rows };
};
