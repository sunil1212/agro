"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import {
	AlertCircleIcon,
	CheckCircle2Icon,
	FileSpreadsheetIcon,
	UploadIcon,
	XIcon,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { postClientApi } from "@/lib/api-client";
import {
	farmerImportHeaderLine,
	farmerImportOptionalHeaders,
	farmerImportRequiredHeaders,
	parseFarmerCsv,
} from "./farmer-csv-parser";
import type { ImportFarmersResponse } from "./farmer-import-types";

const previewLimit = 100;

function HeaderGuide({
	optionalHeaders,
	requiredHeaders,
}: {
	optionalHeaders: readonly string[];
	requiredHeaders: readonly string[];
}) {
	return (
		<div className="mt-4 grid gap-3 text-xs sm:grid-cols-2">
			<div className="rounded-2xl bg-primary/8 p-3 ring-1 ring-primary/15">
				<p className="font-medium text-primary">Required columns</p>
				<p className="mt-1 break-words font-mono text-foreground">
					{requiredHeaders.join(", ")}
				</p>
			</div>
			<div className="rounded-2xl bg-muted/60 p-3 ring-1 ring-border/70">
				<p className="font-medium text-foreground">Optional columns</p>
				<p className="mt-1 break-words font-mono text-muted-foreground">
					{optionalHeaders.join(", ")}
				</p>
			</div>
		</div>
	);
}

export function FarmerImportEditor() {
	const router = useRouter();
	const fileInputRef = useRef<HTMLInputElement>(null);
	const [sourceText, setSourceText] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [importReport, setImportReport] =
		useState<ImportFarmersResponse | null>(null);
	const parsed = parseFarmerCsv(sourceText);

	const loadFile = async (file: File) => {
		if (!file.name.toLowerCase().endsWith(".csv")) {
			toast.error("Choose a .csv file");
			return;
		}
		setSourceText(await file.text());
		setImportReport(null);
	};

	const submit = async () => {
		if (parsed.errors.length > 0 || parsed.rows.length === 0) {
			return;
		}
		setIsSubmitting(true);
		try {
			const result = await postClientApi<ImportFarmersResponse>(
				"farmers",
				"/import",
				{ rows: parsed.rows }
			);
			setImportReport(result);
			toast.success(`Created ${result.created.length} farmers`);
			if (result.skipped.length === 0 && result.failed.length === 0) {
				setSourceText("");
				if (fileInputRef.current) {
					fileInputRef.current.value = "";
				}
			}
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Unable to import farmers"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<div className="space-y-5">
			{importReport &&
			(importReport.skipped.length > 0 || importReport.failed.length > 0) ? (
				<section
					aria-labelledby="farmer-import-report-title"
					className="rounded-2xl bg-destructive/8 p-4 text-destructive ring-1 ring-destructive/20"
					role="alert"
				>
					<div className="flex items-start justify-between gap-4">
						<div>
							<h2
								className="flex items-center gap-2 font-semibold"
								id="farmer-import-report-title"
							>
								<AlertCircleIcon className="size-4 shrink-0" />
								{importReport.skipped.length + importReport.failed.length} rows
								were not imported
							</h2>
							<p className="mt-1 text-sm">
								{importReport.created.length} created,{" "}
								{importReport.skipped.length} skipped,{" "}
								{importReport.failed.length} failed.
							</p>
						</div>
						<Button
							aria-label="Dismiss import report"
							className="shrink-0"
							onClick={() => setImportReport(null)}
							size="icon-sm"
							type="button"
							variant="ghost"
						>
							<XIcon />
						</Button>
					</div>
					<div className="mt-4 max-h-72 overflow-auto rounded-xl bg-background/75 ring-1 ring-destructive/15">
						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>Row</TableHead>
									<TableHead>Farmer</TableHead>
									<TableHead>Mobile</TableHead>
									<TableHead>Reason</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{[...importReport.skipped, ...importReport.failed]
									.toSorted((left, right) => left.rowNumber - right.rowNumber)
									.map((entry) => (
										<TableRow key={`${entry.rowNumber}-${entry.mobileNumber}`}>
											<TableCell className="font-mono">
												{entry.rowNumber}
											</TableCell>
											<TableCell className="font-medium">
												{entry.farmerName}
											</TableCell>
											<TableCell className="font-mono">
												{entry.mobileNumber}
											</TableCell>
											<TableCell>{entry.message}</TableCell>
										</TableRow>
									))}
							</TableBody>
						</Table>
					</div>
				</section>
			) : null}
			<input
				accept=".csv,text/csv"
				className="sr-only"
				onChange={async (event) => {
					const file = event.target.files?.[0];
					if (file) {
						await loadFile(file);
					}
				}}
				ref={fileInputRef}
				type="file"
			/>
			<div className="rounded-3xl border border-border/70 bg-card p-5 sm:p-6">
				<div className="flex flex-wrap items-start justify-between gap-4">
					<div>
						<h2 className="font-semibold text-lg">Paste farmer sheet</h2>
						<p className="mt-1 text-muted-foreground text-sm">
							Paste directly from Excel/Sheets or upload a CSV with the provided
							column names.
						</p>
					</div>
					<Button
						onClick={() => fileInputRef.current?.click()}
						type="button"
						variant="outline"
					>
						<FileSpreadsheetIcon />
						Choose CSV
					</Button>
				</div>
				<HeaderGuide
					optionalHeaders={farmerImportOptionalHeaders}
					requiredHeaders={farmerImportRequiredHeaders}
				/>
				<Textarea
					aria-label="Farmer import data"
					className="mt-5 min-h-64 resize-y font-mono text-xs"
					onChange={(event) => {
						setSourceText(event.target.value);
						setImportReport(null);
					}}
					placeholder={`${farmerImportHeaderLine}\nAdvisor Name,Farmer Name,1/15/2026,9876543210,,,,,,,,,,`}
					value={sourceText}
				/>
			</div>

			<div className="rounded-2xl bg-amber-500/8 p-4 text-amber-900 text-sm ring-1 ring-amber-500/20">
				DATE sets created and updated timestamps. Location fields may be blank.
				CROPS is stored as plain crop text for imported legacy sheets;
				structured crop history still uses crop plus sowing date.
			</div>

			{parsed.errors.length > 0 ? (
				<div
					className="rounded-2xl bg-destructive/8 p-4 text-destructive ring-1 ring-destructive/20"
					role="alert"
				>
					<div className="flex items-center gap-2 font-medium">
						<AlertCircleIcon className="size-4" />
						Fix {parsed.errors.length} import issues
					</div>
					<ul className="mt-3 max-h-52 space-y-1 overflow-y-auto pl-6 text-sm">
						{parsed.errors.map((error) => (
							<li className="list-disc" key={error}>
								{error}
							</li>
						))}
					</ul>
				</div>
			) : null}

			{parsed.rows.length > 0 && parsed.errors.length === 0 ? (
				<>
					<div className="flex flex-wrap items-center justify-between gap-3">
						<div className="flex items-center gap-2 text-sm">
							<CheckCircle2Icon className="size-4 text-primary" />
							{parsed.rows.length} farmers ready
						</div>
						<Button disabled={isSubmitting} onClick={submit} type="button">
							<UploadIcon />
							{isSubmitting
								? "Importing…"
								: `Import ${parsed.rows.length} farmers`}
						</Button>
					</div>
					<div className="overflow-x-auto rounded-2xl border border-border/70">
						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>Advisor</TableHead>
									<TableHead>Farmer</TableHead>
									<TableHead>Date</TableHead>
									<TableHead>Mobile</TableHead>
									<TableHead>Location</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{parsed.rows.slice(0, previewLimit).map((row, index) => (
									<TableRow key={`${row.mobileNumber}-${index}`}>
										<TableCell>{row.advisorName}</TableCell>
										<TableCell className="font-medium">
											{row.farmerName}
										</TableCell>
										<TableCell>{row.date}</TableCell>
										<TableCell className="font-mono">
											{row.mobileNumber}
										</TableCell>
										<TableCell>
											{row.addressAt}, {row.taluka}, {row.district}
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</div>
				</>
			) : null}
		</div>
	);
}
