import type { OrderImportRow } from "./order-import-types";

const requiredHeaders = [
	"ORDER_ID",
	"DATE",
	"AGENT_NAME",
	"FARMER_NAME",
	"FARMER_PHONE",
	"SKUCODE",
	"PRODUCT_NAME",
	"SIZE",
	"QUANTITY",
	"PRODUCT_AMOUNT",
	"MODE_OF_PAYMENT",
	"REMANING_COD_PAYMENT",
	"ADVANCE_PAYMENT",
] as const;
const maximumImportRows = 5000;
const byteOrderMarkPattern = /^\uFEFF/;
const dateSeparatorPattern = /[/-]/;
const lineBreakPattern = /\r?\n/;
const paymentModePattern = /^(COD|PARTIAL(?:_PAYMENT)?|PREPAID)$/i;
const tenDigitPhonePattern = /^\d{10}$/;
const nonDigitPattern = /\D/g;
const orderIdPattern = /^([^-]+)-(\d+)$/;

const headerAliases = new Map([
	["REMAINING_COD_PAYMENT", "REMANING_COD_PAYMENT"],
	["SKU_CODE", "SKUCODE"],
	["UNIT", "SIZE_UNIT"],
]);

const parseRows = (text: string, delimiter: string) => {
	const rows: string[][] = [];
	let field = "";
	let row: string[] = [];
	let quoted = false;

	const finishRow = () => {
		row.push(field);
		if (row.some((value) => value.trim())) {
			rows.push(row);
		}
		field = "";
		row = [];
	};

	for (let index = 0; index < text.length; index += 1) {
		const character = text[index] ?? "";
		const nextCharacter = text[index + 1] ?? "";
		if (character === '"') {
			if (quoted && nextCharacter === '"') {
				field += '"';
				index += 1;
			} else {
				quoted = !quoted;
			}
		} else if (character === delimiter && !quoted) {
			row.push(field);
			field = "";
		} else if ((character === "\n" || character === "\r") && !quoted) {
			if (character === "\r" && nextCharacter === "\n") {
				index += 1;
			}
			finishRow();
		} else {
			field += character;
		}
	}
	finishRow();
	return rows;
};

const normalizeHeader = (value: string) => {
	const normalized = value.trim().toUpperCase().replaceAll(" ", "_");
	return headerAliases.get(normalized) ?? normalized;
};

const toIsoDate = (value: string) => {
	const parts = value.trim().split(dateSeparatorPattern).map(Number);
	if (parts.length !== 3) {
		return null;
	}
	const [month, day, year] = parts;
	if (!(month && day && year)) {
		return null;
	}
	const date = new Date(Date.UTC(year, month - 1, day));
	if (
		date.getUTCFullYear() !== year ||
		date.getUTCMonth() !== month - 1 ||
		date.getUTCDate() !== day
	) {
		return null;
	}
	return date.toISOString().slice(0, 10);
};

const toNumber = (value: string) => {
	const number = Number(value.trim());
	return Number.isFinite(number) ? number : null;
};

const normalizeOrderId = (value: string) => {
	const orderId = value.trim().toUpperCase();
	const match = orderId.match(orderIdPattern);
	if (!match) {
		return orderId;
	}

	const [, adminCode, sequenceText] = match;
	const sequence = Number(sequenceText);
	if (!(adminCode && Number.isSafeInteger(sequence))) {
		return orderId;
	}

	return `${adminCode}-${String(sequence).padStart(6, "0")}`;
};

const isLegacySheetLayout = (
	headerIndexes: Map<string, number>,
	firstDataRow: string[] | undefined
) => {
	if (
		!firstDataRow ||
		headerIndexes.has("SIZE_UNIT") ||
		!headerIndexes.has("TOTAL_AMOUNT")
	) {
		return false;
	}
	const quantityIndex = headerIndexes.get("QUANTITY") ?? -1;
	const paymentModeIndex = headerIndexes.get("MODE_OF_PAYMENT") ?? -1;
	return (
		toNumber(firstDataRow[quantityIndex] ?? "") === null &&
		paymentModePattern.test(firstDataRow[paymentModeIndex] ?? "")
	);
};

// biome-ignore lint/complexity/noExcessiveCognitiveComplexity: sheet validation is clearest when each column rule stays visible
export const parseOrderCsv = (text: string) => {
	const cleanText = text.replace(byteOrderMarkPattern, "");
	const firstLine = cleanText.split(lineBreakPattern, 1)[0] ?? "";
	const delimiter = firstLine.includes("\t") ? "\t" : ",";
	const rawRows = parseRows(cleanText, delimiter);
	const errors: string[] = [];
	const [headerRow, ...dataRows] = rawRows;

	if (!headerRow) {
		return { errors: [], isLegacyLayout: false, rows: [] as OrderImportRow[] };
	}

	const headerIndexes = new Map(
		headerRow.map((header, index) => [normalizeHeader(header), index])
	);
	for (const header of requiredHeaders) {
		if (!headerIndexes.has(header)) {
			errors.push(`Missing required column: ${header}`);
		}
	}
	if (errors.length > 0) {
		return { errors, isLegacyLayout: false, rows: [] as OrderImportRow[] };
	}

	const legacyLayout = isLegacySheetLayout(headerIndexes, dataRows[0]);
	const value = (row: string[], header: string) =>
		row[headerIndexes.get(header) ?? -1]?.trim() ?? "";
	const legacyValue = (row: string[], index: number) =>
		row[index]?.trim() ?? "";
	const rows: OrderImportRow[] = [];

	for (const [index, rawRow] of dataRows.entries()) {
		const rowNumber = index + 2;
		const get = (header: string) => value(rawRow, header);
		const date = toIsoDate(get("DATE"));
		const quantity = toNumber(
			legacyLayout ? legacyValue(rawRow, 9) : get("QUANTITY")
		);
		const productAmount = toNumber(
			legacyLayout ? legacyValue(rawRow, 10) : get("PRODUCT_AMOUNT")
		);
		const remainingCodPayment = toNumber(
			legacyLayout ? legacyValue(rawRow, 12) : get("REMANING_COD_PAYMENT")
		);
		const advancePayment = toNumber(
			legacyLayout ? legacyValue(rawRow, 16) : get("ADVANCE_PAYMENT")
		);
		const orderId = normalizeOrderId(get("ORDER_ID"));
		const skuCode = get("SKUCODE");

		if (!orderId) {
			errors.push(`Row ${rowNumber}: ORDER_ID is required.`);
		}
		if (!date) {
			errors.push(`Row ${rowNumber}: DATE must use M/D/YYYY format.`);
		}
		if (!get("AGENT_NAME")) {
			errors.push(`Row ${rowNumber}: AGENT_NAME is required.`);
		}
		if (!get("FARMER_NAME")) {
			errors.push(`Row ${rowNumber}: FARMER_NAME is required.`);
		}
		if (
			!tenDigitPhonePattern.test(
				get("FARMER_PHONE").replace(nonDigitPattern, "")
			)
		) {
			errors.push(`Row ${rowNumber}: FARMER_PHONE must be 10 digits.`);
		}
		if (!skuCode) {
			errors.push(`Row ${rowNumber}: SKUCODE is required.`);
		}
		if (!(quantity && Number.isInteger(quantity) && quantity > 0)) {
			errors.push(`Row ${rowNumber}: QUANTITY must be a positive integer.`);
		}
		if (productAmount === null || productAmount < 0) {
			errors.push(`Row ${rowNumber}: PRODUCT_AMOUNT cannot be negative.`);
		}
		if (remainingCodPayment === null || remainingCodPayment < 0) {
			errors.push(`Row ${rowNumber}: REMANING_COD_PAYMENT cannot be negative.`);
		}
		if (advancePayment === null || advancePayment < 0) {
			errors.push(`Row ${rowNumber}: ADVANCE_PAYMENT cannot be negative.`);
		}
		if (
			!paymentModePattern.test(
				legacyLayout ? legacyValue(rawRow, 11) : get("MODE_OF_PAYMENT")
			)
		) {
			errors.push(
				`Row ${rowNumber}: MODE_OF_PAYMENT must be COD, PARTIAL, or PREPAID.`
			);
		}
		if (
			!(
				orderId &&
				date &&
				skuCode &&
				quantity &&
				productAmount !== null &&
				remainingCodPayment !== null &&
				advancePayment !== null
			)
		) {
			continue;
		}

		rows.push({
			advancePayment,
			advisorName: get("AGENT_NAME"),
			date,
			farmerName: get("FARMER_NAME"),
			farmerPhone: get("FARMER_PHONE").replace(nonDigitPattern, ""),
			modeOfPayment: legacyLayout
				? legacyValue(rawRow, 11)
				: get("MODE_OF_PAYMENT"),
			orderId,
			productAmount,
			quantity,
			remainingCodPayment,
			remarkDelivered: legacyLayout
				? legacyValue(rawRow, 13)
				: get("REMARK_DELIVERED"),
			returnReason: legacyLayout
				? legacyValue(rawRow, 15)
				: get("RETURN_REASON"),
			returnStatus: legacyLayout ? legacyValue(rawRow, 14) : get("RETURN"),
			rowNumber,
			skuCode: skuCode.toUpperCase(),
		});
	}

	if (rows.length > maximumImportRows) {
		return {
			errors: [`Import ${maximumImportRows} order rows or fewer at a time.`],
			isLegacyLayout: legacyLayout,
			rows: [] as OrderImportRow[],
		};
	}

	return { errors, isLegacyLayout: legacyLayout, rows };
};
