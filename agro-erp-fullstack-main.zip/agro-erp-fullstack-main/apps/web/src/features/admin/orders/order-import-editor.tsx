"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import {
	AlertCircleIcon,
	CheckCircle2Icon,
	FileSpreadsheetIcon,
	UploadIcon,
	XIcon,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { postClientApi } from "@/lib/api-client";
import { parseOrderCsv } from "./order-csv-parser";
import type { ImportOrdersResponse } from "./order-import-types";

const previewLimit = 100;
const orderImportRequiredHeaders = [
	"ORDER_ID",
	"DATE",
	"AGENT_NAME",
	"FARMER_NAME",
	"FARMER_PHONE",
	"SKUCODE",
	"PRODUCT_NAME",
	"SIZE",
	"QUANTITY",
	"PRODUCT_AMOUNT",
	"MODE_OF_PAYMENT",
	"REMANING_COD_PAYMENT",
	"ADVANCE_PAYMENT",
] as const;
const orderImportOptionalHeaders = [
	"REMARK_DELIVERED",
	"RETURN",
	"RETURN_REASON",
] as const;
const orderImportHeaderLine = [
	...orderImportRequiredHeaders,
	...orderImportOptionalHeaders,
].join(",");

function HeaderGuide({
	optionalHeaders,
	requiredHeaders,
}: {
	optionalHeaders: readonly string[];
	requiredHeaders: readonly string[];
}) {
	return (
		<div className="mt-4 grid gap-3 text-xs sm:grid-cols-2">
			<div className="rounded-2xl bg-primary/8 p-3 ring-1 ring-primary/15">
				<p className="font-medium text-primary">Required columns</p>
				<p className="mt-1 break-words font-mono text-foreground">
					{requiredHeaders.join(", ")}
				</p>
			</div>
			<div className="rounded-2xl bg-muted/60 p-3 ring-1 ring-border/70">
				<p className="font-medium text-foreground">Optional columns</p>
				<p className="mt-1 break-words font-mono text-muted-foreground">
					{optionalHeaders.join(", ")}
				</p>
			</div>
		</div>
	);
}

export function OrderImportEditor() {
	const router = useRouter();
	const fileInputRef = useRef<HTMLInputElement>(null);
	const [sourceText, setSourceText] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [importReport, setImportReport] = useState<ImportOrdersResponse | null>(
		null
	);
	const parsed = parseOrderCsv(sourceText);
	const orderCount = new Set(parsed.rows.map((row) => row.orderId)).size;

	const loadFile = async (file: File) => {
		if (!file.name.toLowerCase().endsWith(".csv")) {
			toast.error("Choose a .csv file");
			return;
		}
		setSourceText(await file.text());
		setImportReport(null);
	};

	const submit = async () => {
		if (parsed.errors.length > 0 || parsed.rows.length === 0) {
			return;
		}
		setIsSubmitting(true);
		try {
			const result = await postClientApi<ImportOrdersResponse>(
				"orders",
				"/import",
				{ rows: parsed.rows }
			);
			setImportReport(result);
			toast.success(
				`Imported ${result.created.length + result.updated.length} orders`
			);
			if (result.skipped.length === 0 && result.failed.length === 0) {
				setSourceText("");
				if (fileInputRef.current) {
					fileInputRef.current.value = "";
				}
			}
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Unable to import orders"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	const importIssues = importReport
		? [...importReport.skipped, ...importReport.failed].toSorted(
				(left, right) => (left.rowNumbers[0] ?? 0) - (right.rowNumbers[0] ?? 0)
			)
		: [];

	return (
		<div className="space-y-5">
			{importReport && importIssues.length > 0 ? (
				<section
					aria-labelledby="order-import-report-title"
					className="rounded-2xl bg-destructive/8 p-4 text-destructive ring-1 ring-destructive/20"
					role="alert"
				>
					<div className="flex items-start justify-between gap-4">
						<div>
							<h2
								className="flex items-center gap-2 font-semibold"
								id="order-import-report-title"
							>
								<AlertCircleIcon className="size-4 shrink-0" />
								{importIssues.length} orders were not imported
							</h2>
							<p className="mt-1 text-sm">
								{importReport.created.length} created,{" "}
								{importReport.updated.length} appended,{" "}
								{importReport.skipped.length} skipped,{" "}
								{importReport.failed.length} failed.
							</p>
						</div>
						<Button
							aria-label="Dismiss import report"
							className="shrink-0"
							onClick={() => setImportReport(null)}
							size="icon-sm"
							type="button"
							variant="ghost"
						>
							<XIcon />
						</Button>
					</div>
					<div className="mt-4 max-h-72 overflow-auto rounded-xl bg-background/75 ring-1 ring-destructive/15">
						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>Rows</TableHead>
									<TableHead>Order</TableHead>
									<TableHead>Reason</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{importIssues.map((entry) => (
									<TableRow key={entry.orderId}>
										<TableCell className="font-mono">
											{entry.rowNumbers.join(", ")}
										</TableCell>
										<TableCell className="font-medium font-mono">
											{entry.orderId}
										</TableCell>
										<TableCell>{entry.message}</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</div>
				</section>
			) : null}

			<input
				accept=".csv,text/csv"
				className="sr-only"
				onChange={async (event) => {
					const file = event.target.files?.[0];
					if (file) {
						await loadFile(file);
					}
				}}
				ref={fileInputRef}
				type="file"
			/>

			<div className="rounded-3xl border border-border/70 bg-card p-5 sm:p-6">
				<div className="flex flex-wrap items-start justify-between gap-4">
					<div>
						<h2 className="font-semibold text-lg">Paste order sheet</h2>
						<p className="mt-1 text-muted-foreground text-sm">
							Paste directly from Excel/Sheets or upload a CSV. Repeated
							ORDER_ID rows become line items on one order.
						</p>
					</div>
					<Button
						onClick={() => fileInputRef.current?.click()}
						type="button"
						variant="outline"
					>
						<FileSpreadsheetIcon />
						Choose CSV
					</Button>
				</div>
				<HeaderGuide
					optionalHeaders={orderImportOptionalHeaders}
					requiredHeaders={orderImportRequiredHeaders}
				/>
				<Textarea
					aria-label="Order import data"
					className="mt-5 min-h-64 resize-y font-mono text-xs"
					onChange={(event) => {
						setSourceText(event.target.value);
						setImportReport(null);
					}}
					placeholder={`${orderImportHeaderLine}\nORD-1,1/15/2026,Advisor Name,Farmer Name,9876543210,SKU001,Product,1,1,100,COD,100,0,,`}
					value={sourceText}
				/>
			</div>

			<div className="rounded-2xl bg-amber-500/8 p-4 text-amber-950 text-sm ring-1 ring-amber-500/20">
				<p>
					Farmers are matched by phone, advisors by exact normalized name, and
					products by SKU. Existing order IDs receive new line items without
					recreating the order.
				</p>
				{parsed.isLegacyLayout ? (
					<p className="mt-2 font-medium">
						Legacy layout detected. Product name, pack size, and pack unit are
						ignored; SKU, quantity, and line amount are used.
					</p>
				) : null}
			</div>

			{parsed.errors.length > 0 ? (
				<div
					className="rounded-2xl bg-destructive/8 p-4 text-destructive ring-1 ring-destructive/20"
					role="alert"
				>
					<div className="flex items-center gap-2 font-medium">
						<AlertCircleIcon className="size-4" />
						Fix {parsed.errors.length} import issues
					</div>
					<ul className="mt-3 max-h-52 space-y-1 overflow-y-auto pl-6 text-sm">
						{parsed.errors.map((error) => (
							<li className="list-disc" key={error}>
								{error}
							</li>
						))}
					</ul>
				</div>
			) : null}

			{parsed.rows.length > 0 && parsed.errors.length === 0 ? (
				<>
					<div className="flex flex-wrap items-center justify-between gap-3">
						<div className="flex items-center gap-2 text-sm">
							<CheckCircle2Icon className="size-4 text-primary" />
							{orderCount} orders and {parsed.rows.length} line items ready
						</div>
						<Button disabled={isSubmitting} onClick={submit} type="button">
							<UploadIcon />
							{isSubmitting ? "Importing…" : `Import ${orderCount} orders`}
						</Button>
					</div>
					<div className="overflow-x-auto rounded-2xl border border-border/70">
						<Table>
							<TableHeader>
								<TableRow>
									<TableHead>Order</TableHead>
									<TableHead>Advisor</TableHead>
									<TableHead>Farmer</TableHead>
									<TableHead>SKU</TableHead>
									<TableHead className="text-right">Qty</TableHead>
									<TableHead className="text-right">Amount</TableHead>
									<TableHead>Status source</TableHead>
								</TableRow>
							</TableHeader>
							<TableBody>
								{parsed.rows.slice(0, previewLimit).map((row) => (
									<TableRow key={`${row.orderId}-${row.rowNumber}`}>
										<TableCell className="font-mono">{row.orderId}</TableCell>
										<TableCell>{row.advisorName}</TableCell>
										<TableCell>
											<p className="font-medium">{row.farmerName}</p>
											<p className="font-mono text-muted-foreground text-xs">
												{row.farmerPhone}
											</p>
										</TableCell>
										<TableCell className="font-mono">{row.skuCode}</TableCell>
										<TableCell className="text-right">{row.quantity}</TableCell>
										<TableCell className="text-right">
											{row.productAmount.toFixed(2)}
										</TableCell>
										<TableCell>
											{row.returnStatus ||
												row.remarkDelivered ||
												"No status supplied"}
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>
					</div>
				</>
			) : null}
		</div>
	);
}
