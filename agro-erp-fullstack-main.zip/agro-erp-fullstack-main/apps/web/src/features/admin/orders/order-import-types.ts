export interface OrderImportRow {
	advancePayment: number;
	advisorName: string;
	date: string;
	farmerName: string;
	farmerPhone: string;
	modeOfPayment: string;
	orderId: string;
	productAmount: number;
	quantity: number;
	remainingCodPayment: number;
	remarkDelivered?: string;
	returnReason?: string;
	returnStatus?: string;
	rowNumber: number;
	skuCode: string;
}

export interface OrderImportResultEntry {
	orderId: string;
	rowNumbers: number[];
}

export interface ImportOrdersResponse {
	created: OrderImportResultEntry[];
	failed: Array<OrderImportResultEntry & { message: string }>;
	receivedOrders: number;
	receivedRows: number;
	skipped: Array<OrderImportResultEntry & { message: string }>;
	success: true;
	updated: OrderImportResultEntry[];
}
