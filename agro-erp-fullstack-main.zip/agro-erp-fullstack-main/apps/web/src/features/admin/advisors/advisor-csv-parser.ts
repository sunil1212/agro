import {
	type AdvisorImportRow,
	advisorEmailDomain,
} from "./advisor-import-types";

const byteOrderMarkPattern = /^\uFEFF/;
const emailLocalPartPattern = /^[a-z0-9]+(?:\.[a-z0-9]+)*$/;
const headerNames = new Set(["agent", "agent name", "agent_name", "name"]);
const maximumImportRows = 500;
const whitespacePattern = /\s+/;

export interface ParsedAdvisorCsv {
	duplicatesRemoved: number;
	errors: string[];
	rows: AdvisorImportRow[];
}

const parseCsvRows = (text: string) => {
	const rows: string[][] = [];
	let currentField = "";
	let currentRow: string[] = [];
	let isQuoted = false;

	const completeRow = () => {
		currentRow.push(currentField);
		if (currentRow.some((field) => field.trim())) {
			rows.push(currentRow);
		}
		currentField = "";
		currentRow = [];
	};

	for (let index = 0; index < text.length; index += 1) {
		const character = text[index] ?? "";
		const nextCharacter = text[index + 1] ?? "";

		if (character === '"') {
			if (isQuoted && nextCharacter === '"') {
				currentField += '"';
				index += 1;
			} else {
				isQuoted = !isQuoted;
			}
			continue;
		}

		if (character === "," && !isQuoted) {
			currentRow.push(currentField);
			currentField = "";
			continue;
		}

		if ((character === "\n" || character === "\r") && !isQuoted) {
			if (character === "\r" && nextCharacter === "\n") {
				index += 1;
			}
			completeRow();
			continue;
		}

		currentField += character;
	}

	completeRow();
	return rows;
};

export const normalizeAdvisorName = (value: string) =>
	value.trim().split(whitespacePattern).filter(Boolean).join(" ");

const toAdvisorRow = (name: string): AdvisorImportRow => ({
	email: `${name.toLowerCase().split(" ").join(".")}@${advisorEmailDomain}`,
	name,
});

export const parseAdvisorCsv = (text: string): ParsedAdvisorCsv => {
	const csvRows = parseCsvRows(text.replace(byteOrderMarkPattern, ""));
	const errors: string[] = [];
	const uniqueNames = new Map<string, AdvisorImportRow>();
	let duplicateCount = 0;

	for (const [index, csvRow] of csvRows.entries()) {
		const rawName = csvRow[0] ?? "";
		const name = normalizeAdvisorName(rawName);
		const normalizedName = name.toLowerCase();
		const rowNumber = index + 1;

		if (!name || (index === 0 && headerNames.has(normalizedName))) {
			continue;
		}

		if (uniqueNames.has(normalizedName)) {
			duplicateCount += 1;
			continue;
		}

		const localPart = normalizedName.split(" ").join(".");
		if (!emailLocalPartPattern.test(localPart)) {
			errors.push(
				`Row ${rowNumber}: "${rawName.trim()}" cannot form a valid @${advisorEmailDomain} email.`
			);
			continue;
		}

		uniqueNames.set(normalizedName, toAdvisorRow(name));
	}

	const rows = [...uniqueNames.values()];
	if (rows.length > maximumImportRows) {
		return {
			duplicatesRemoved: duplicateCount,
			errors: [`Import ${maximumImportRows} advisors or fewer at a time.`],
			rows: [],
		};
	}

	if (csvRows.length > 0 && rows.length === 0 && errors.length === 0) {
		errors.push("No advisor names were found in the first CSV column.");
	}

	return {
		duplicatesRemoved: duplicateCount,
		errors,
		rows,
	};
};
