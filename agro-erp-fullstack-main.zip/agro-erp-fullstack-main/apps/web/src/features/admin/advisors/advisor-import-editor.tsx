"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import {
	AlertCircleIcon,
	CheckCircle2Icon,
	ClipboardPasteIcon,
	FileSpreadsheetIcon,
	UploadIcon,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { postClientApi } from "@/lib/api-client";
import { parseAdvisorCsv } from "./advisor-csv-parser";
import {
	advisorInitialPassword,
	type ImportAdvisorAccountsResponse,
} from "./advisor-import-types";

const previewRowLimit = 100;
const advisorImportRequiredHeaders = ["Agent Name"] as const;

function AdvisorHeaderGuide() {
	return (
		<div className="mt-4 rounded-2xl bg-primary/8 p-3 text-xs ring-1 ring-primary/15">
			<p className="font-medium text-primary">Required column</p>
			<p className="mt-1 break-words font-mono text-foreground">
				{advisorImportRequiredHeaders.join(", ")}
			</p>
			<p className="mt-2 text-muted-foreground">
				The header is optional. If present, use Agent Name or Name.
			</p>
		</div>
	);
}

export function AdvisorImportEditor() {
	const router = useRouter();
	const fileInputRef = useRef<HTMLInputElement>(null);
	const [csvText, setCsvText] = useState("");
	const [fileName, setFileName] = useState("");
	const [isDragging, setIsDragging] = useState(false);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const parsedCsv = parseAdvisorCsv(csvText);

	const loadFile = async (file: File) => {
		if (
			!(file.name.toLowerCase().endsWith(".csv") || file.type === "text/csv")
		) {
			toast.error("Choose a .csv file");
			return;
		}

		setCsvText(await file.text());
		setFileName(file.name);
	};

	const handleSubmit = async () => {
		if (parsedCsv.rows.length === 0 || parsedCsv.errors.length > 0) {
			return;
		}

		setIsSubmitting(true);
		try {
			const result = await postClientApi<ImportAdvisorAccountsResponse>(
				"accounts",
				"/import-advisors",
				{ names: parsedCsv.rows.map(({ name }) => name) }
			);

			if (result.failed.length > 0) {
				toast.error(
					`Created ${result.created.length}; ${result.failed.length} failed`
				);
			} else {
				toast.success(
					`Created ${result.created.length} advisor account${result.created.length === 1 ? "" : "s"}`
				);
			}

			if (result.skipped.length > 0) {
				toast.info(
					`Skipped ${result.skipped.length} existing account${result.skipped.length === 1 ? "" : "s"}`
				);
			}

			const unresolvedNames = result.failed.map(({ name }) => name).join("\n");
			setCsvText(unresolvedNames);
			if (result.failed.length === 0) {
				setFileName("");
				if (fileInputRef.current) {
					fileInputRef.current.value = "";
				}
			}
			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error
					? error.message
					: "Unable to import advisor accounts"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<div className="space-y-5">
			<input
				accept=".csv,text/csv"
				className="sr-only"
				onChange={async (event) => {
					const file = event.target.files?.[0];
					if (file) {
						await loadFile(file);
					}
				}}
				ref={fileInputRef}
				type="file"
			/>

			<div className="rounded-3xl border border-border/70 bg-card p-5 sm:p-6">
				<div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
					<div className="flex gap-3">
						<div className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
							<ClipboardPasteIcon className="size-5" />
						</div>
						<div>
							<h2 className="font-semibold text-lg">Paste advisor names</h2>
							<p className="mt-1 max-w-2xl text-muted-foreground text-sm leading-6">
								Use the first CSV column. A header named “Agent Name” or “Name”
								is optional.
							</p>
						</div>
					</div>
					<Button
						className={cn(isDragging && "border-primary bg-primary/5")}
						onClick={() => fileInputRef.current?.click()}
						onDragEnter={(event) => {
							event.preventDefault();
							setIsDragging(true);
						}}
						onDragLeave={(event) => {
							event.preventDefault();
							setIsDragging(false);
						}}
						onDragOver={(event) => event.preventDefault()}
						onDrop={async (event) => {
							event.preventDefault();
							setIsDragging(false);
							const file = event.dataTransfer.files[0];
							if (file) {
								await loadFile(file);
							}
						}}
						type="button"
						variant="outline"
					>
						<FileSpreadsheetIcon />
						Drop or choose CSV
					</Button>
				</div>
				<AdvisorHeaderGuide />

				<Textarea
					aria-label="Advisor names CSV"
					className="mt-5 min-h-56 resize-y font-mono text-sm"
					onChange={(event) => {
						setCsvText(event.target.value);
						setFileName("");
					}}
					placeholder={"Agent Name\nAman Verma\nPriya Sharma\nAman Verma"}
					value={csvText}
				/>
				<div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-muted-foreground text-xs">
					<span>
						Saved names keep their pasted casing. Emails and duplicate checks
						use lowercase.
					</span>
					{fileName ? <span className="font-mono">{fileName}</span> : null}
				</div>
			</div>

			<div
				className="rounded-2xl bg-amber-500/8 p-4 text-amber-900 ring-1 ring-amber-500/20"
				role="note"
			>
				<p className="font-medium text-sm">Shared initial password</p>
				<p className="mt-1 text-sm leading-6">
					Every imported advisor can sign in with{" "}
					<code className="rounded bg-amber-950/8 px-1.5 py-0.5 font-mono">
						{advisorInitialPassword}
					</code>
					. Send it only through an approved internal channel.
				</p>
			</div>

			{parsedCsv.errors.length > 0 ? (
				<div
					className="rounded-2xl bg-destructive/8 p-4 text-destructive ring-1 ring-destructive/20"
					role="alert"
				>
					<div className="flex items-center gap-2 font-medium text-sm">
						<AlertCircleIcon className="size-4" />
						Fix {parsedCsv.errors.length} CSV issue
						{parsedCsv.errors.length === 1 ? "" : "s"}
					</div>
					<ul className="mt-3 max-h-44 space-y-1 overflow-y-auto pl-6 text-sm">
						{parsedCsv.errors.map((error) => (
							<li className="list-disc" key={error}>
								{error}
							</li>
						))}
					</ul>
				</div>
			) : null}

			{parsedCsv.rows.length > 0 && parsedCsv.errors.length === 0 ? (
				<>
					<div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
						<div className="flex flex-wrap items-center gap-2 text-sm">
							<CheckCircle2Icon className="size-4 text-primary" />
							<span className="font-medium">
								{parsedCsv.rows.length} unique advisor
								{parsedCsv.rows.length === 1 ? "" : "s"}
							</span>
							{parsedCsv.duplicatesRemoved > 0 ? (
								<span className="text-muted-foreground">
									{parsedCsv.duplicatesRemoved} duplicate
									{parsedCsv.duplicatesRemoved === 1 ? "" : "s"} removed
								</span>
							) : null}
						</div>
						<Button
							disabled={isSubmitting}
							onClick={handleSubmit}
							type="button"
						>
							<UploadIcon />
							{isSubmitting
								? "Creating accounts…"
								: `Create ${parsedCsv.rows.length} accounts`}
						</Button>
					</div>

					<div className="overflow-hidden rounded-2xl border border-border/70 bg-card">
						<div className="overflow-x-auto">
							<Table>
								<TableHeader>
									<TableRow>
										<TableHead>Advisor name</TableHead>
										<TableHead>Email</TableHead>
										<TableHead>Role</TableHead>
									</TableRow>
								</TableHeader>
								<TableBody>
									{parsedCsv.rows.slice(0, previewRowLimit).map((row) => (
										<TableRow key={row.email}>
											<TableCell className="font-medium">{row.name}</TableCell>
											<TableCell className="font-mono">{row.email}</TableCell>
											<TableCell>advisor</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</div>
						{parsedCsv.rows.length > previewRowLimit ? (
							<p className="border-border/70 border-t px-4 py-3 text-muted-foreground text-xs">
								Showing the first {previewRowLimit} accounts.
							</p>
						) : null}
					</div>
				</>
			) : null}
		</div>
	);
}
