export const advisorEmailDomain = "growmize.org";
export const advisorInitialPassword = "qwerty123";

export interface AdvisorImportRow {
	email: string;
	name: string;
}

export interface AdvisorImportFailure extends AdvisorImportRow {
	message: string;
}

export interface ImportAdvisorAccountsResponse {
	created: AdvisorImportRow[];
	failed: AdvisorImportFailure[];
	received: number;
	skipped: AdvisorImportRow[];
	success: true;
	unique: number;
}
