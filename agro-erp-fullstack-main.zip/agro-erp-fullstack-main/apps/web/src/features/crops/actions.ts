"use client";

import { getClientApiUrl } from "@/lib/api-client";

export interface CreateCropInput {
	name: string;
	pdfFile?: File | null;
	schedules: Array<{
		endDay: number;
		instruction: string;
		startDay: number;
	}>;
}

export type CropActionResult =
	| {
			success: true;
			crop: {
				id: string;
				name: string;
			};
	  }
	| {
			success: false;
			message: string;
	  };

export async function createManagedCrop(
	input: CreateCropInput
): Promise<CropActionResult> {
	const body = input.pdfFile
		? (() => {
				const formData = new FormData();
				formData.set("name", input.name);
				formData.set("schedules", JSON.stringify(input.schedules));
				formData.set("pdf", input.pdfFile);
				return formData;
			})()
		: JSON.stringify({
				name: input.name,
				schedules: input.schedules,
			});
	const response = await fetch(getClientApiUrl("crops"), {
		body,
		credentials: "include",
		headers: input.pdfFile ? undefined : { "Content-Type": "application/json" },
		method: "POST",
	});

	return (await response.json()) as CropActionResult;
}

export async function updateManagedCrop(
	cropId: string,
	input: CreateCropInput
): Promise<CropActionResult> {
	const body = input.pdfFile
		? (() => {
				const formData = new FormData();
				formData.set("name", input.name);
				formData.set("schedules", JSON.stringify(input.schedules));
				formData.set("pdf", input.pdfFile);
				return formData;
			})()
		: JSON.stringify({
				name: input.name,
				schedules: input.schedules,
			});
	const response = await fetch(getClientApiUrl("crops", `/${cropId}`), {
		body,
		credentials: "include",
		headers: input.pdfFile ? undefined : { "Content-Type": "application/json" },
		method: "PATCH",
	});

	return (await response.json()) as CropActionResult;
}

export async function fetchCrops(): Promise<
	| { crops: import("./types").CropSummary[]; success: true }
	| { success: false; message: string }
> {
	try {
		const response = await fetch(getClientApiUrl("crops"), {
			credentials: "include",
		});
		return (await response.json()) as
			| { crops: import("./types").CropSummary[]; success: true }
			| { success: false; message: string };
	} catch {
		return { message: "Failed to fetch crops", success: false };
	}
}

export async function fetchCropDetail(
	cropId: string
): Promise<
	| { crop: import("./types").CropDetail; success: true }
	| { success: false; message: string }
> {
	try {
		const response = await fetch(getClientApiUrl("crops", `/${cropId}`), {
			credentials: "include",
		});
		return (await response.json()) as
			| { crop: import("./types").CropDetail; success: true }
			| { success: false; message: string };
	} catch {
		return { message: "Failed to fetch crop", success: false };
	}
}
