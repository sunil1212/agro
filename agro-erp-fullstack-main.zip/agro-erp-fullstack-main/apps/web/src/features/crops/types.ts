export interface ScheduleEntry {
	endDay: string;
	id: string;
	instruction: string;
	startDay: string;
}

export interface CropFormValues {
	name: string;
	pdfFile: File | null;
	schedules: ScheduleEntry[];
}

export interface CropSummary {
	hasPdf: boolean;
	id: string;
	isActive: boolean;
	name: string;
	pdfOriginalName: string | null;
	scheduleCount: number;
	updatedAt: string;
}

export interface CropScheduleRow {
	createdAt: string;
	cropId: string;
	endDay: number;
	id: string;
	instruction: string;
	isActive: boolean;
	startDay: number;
	updatedAt: string;
}

export interface CropDetail {
	createdAt: string;
	id: string;
	isActive: boolean;
	name: string;
	pdfFileName: string | null;
	pdfMimeType: string | null;
	pdfOriginalName: string | null;
	pdfSizeBytes: number | null;
	pdfUploadedAt: string | null;
	schedules: CropScheduleRow[];
	updatedAt: string;
}
