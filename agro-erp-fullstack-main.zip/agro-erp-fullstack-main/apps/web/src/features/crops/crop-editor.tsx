"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle,
} from "@agro-erp-fullstack/ui/components/card";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { PlusIcon, Trash2Icon } from "lucide-react";
import Link from "next/link";
import { useState } from "react";

import { createClientId } from "@/lib/client-id";

import type { CropFormValues, ScheduleEntry } from "./types";

interface CropEditorProps {
	backHref: string;
	initialData?: {
		name: string;
		pdfOriginalName: string | null;
		schedules: ScheduleEntry[];
	};
	isSubmitting: boolean;
	onSubmit: (values: CropFormValues) => void;
	submitLabel: string;
}

const createScheduleRow = (): ScheduleEntry => ({
	endDay: "",
	id: createClientId(),
	instruction: "",
	startDay: "",
});

export function CropEditor({
	backHref,
	initialData,
	isSubmitting,
	onSubmit,
	submitLabel,
}: CropEditorProps) {
	const [cropName, setCropName] = useState(initialData?.name ?? "");
	const [pdfFile, setPdfFile] = useState<File | null>(null);
	const [schedules, setSchedules] = useState<ScheduleEntry[]>(
		initialData?.schedules.length
			? initialData.schedules.map((s) => ({ ...s, id: createClientId() }))
			: [createScheduleRow()]
	);

	const updateSchedule = (
		rowId: string,
		key: keyof Omit<ScheduleEntry, "id">,
		value: string
	) => {
		setSchedules((current) =>
			current.map((schedule) =>
				schedule.id === rowId ? { ...schedule, [key]: value } : schedule
			)
		);
	};

	const removeSchedule = (rowId: string) => {
		setSchedules((current) =>
			current.length === 1
				? current
				: current.filter((schedule) => schedule.id !== rowId)
		);
	};

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		onSubmit({ name: cropName, pdfFile, schedules });
	};

	return (
		<Card>
			<CardHeader>
				<CardTitle>Crop schedule</CardTitle>
				<CardDescription>
					Each row creates one task window after sowing.
				</CardDescription>
			</CardHeader>
			<CardContent>
				<form className="space-y-6" onSubmit={handleSubmit}>
					<div className="space-y-2">
						<Label htmlFor="cropName">Crop name</Label>
						<Input
							id="cropName"
							onChange={(event) => setCropName(event.target.value)}
							placeholder="Sugarcane"
							value={cropName}
						/>
					</div>

					<div className="space-y-2">
						<Label htmlFor="cropPdf">
							Crop PDF
							{initialData?.pdfOriginalName ? (
								<span className="ml-2 font-normal text-muted-foreground text-sm">
									(current: {initialData.pdfOriginalName})
								</span>
							) : null}
						</Label>
						<Input
							accept="application/pdf"
							id="cropPdf"
							onChange={(event) => {
								setPdfFile(event.target.files?.[0] ?? null);
							}}
							type="file"
						/>
						<p className="text-muted-foreground text-sm">
							Optional PDF, maximum 50 MB. Upload a new file to replace the
							existing one.
						</p>
					</div>

					<div className="space-y-4">
						<div className="flex items-center justify-between gap-3">
							<div>
								<h2 className="font-semibold text-base">Schedule entries</h2>
								<p className="text-muted-foreground text-sm">
									Use day ranges like 15-30 days, then add the task text.
								</p>
							</div>
							<Button
								onClick={() =>
									setSchedules((current) => [...current, createScheduleRow()])
								}
								type="button"
								variant="outline"
							>
								<PlusIcon className="size-4" />
								Add row
							</Button>
						</div>

						<div className="space-y-3">
							{schedules.map((schedule, index) => (
								<div
									className="grid gap-3 rounded-2xl border border-border/70 bg-card p-4 shadow-sm md:grid-cols-[9rem_9rem_minmax(0,1fr)_auto]"
									key={schedule.id}
								>
									<div className="space-y-2">
										<Label htmlFor={`startDay-${schedule.id}`}>Start day</Label>
										<Input
											id={`startDay-${schedule.id}`}
											inputMode="numeric"
											min="1"
											onChange={(event) =>
												updateSchedule(
													schedule.id,
													"startDay",
													event.target.value
												)
											}
											placeholder="15"
											type="number"
											value={schedule.startDay}
										/>
									</div>
									<div className="space-y-2">
										<Label htmlFor={`endDay-${schedule.id}`}>End day</Label>
										<Input
											id={`endDay-${schedule.id}`}
											inputMode="numeric"
											min="1"
											onChange={(event) =>
												updateSchedule(
													schedule.id,
													"endDay",
													event.target.value
												)
											}
											placeholder="30"
											type="number"
											value={schedule.endDay}
										/>
									</div>
									<div className="space-y-2">
										<Label htmlFor={`instruction-${schedule.id}`}>
											Instruction
										</Label>
										<Textarea
											id={`instruction-${schedule.id}`}
											onChange={(event) =>
												updateSchedule(
													schedule.id,
													"instruction",
													event.target.value
												)
											}
											placeholder="Buy fertilizer X"
											value={schedule.instruction}
										/>
									</div>
									<div className="flex items-end">
										<Button
											aria-label={`Remove schedule row ${index + 1}`}
											disabled={schedules.length === 1}
											onClick={() => removeSchedule(schedule.id)}
											size="icon"
											type="button"
											variant="ghost"
										>
											<Trash2Icon className="size-4" />
										</Button>
									</div>
								</div>
							))}
						</div>
					</div>

					<div className="flex flex-wrap items-center gap-3">
						<Button disabled={isSubmitting} type="submit">
							{isSubmitting ? "Saving..." : submitLabel}
						</Button>
						<Link
							className="text-muted-foreground text-sm transition-colors hover:text-foreground"
							href={backHref as never}
						>
							Cancel
						</Link>
					</div>
				</form>
			</CardContent>
		</Card>
	);
}
