"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Checkbox } from "@agro-erp-fullstack/ui/components/checkbox";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@agro-erp-fullstack/ui/components/dialog";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuGroup,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from "@agro-erp-fullstack/ui/components/dropdown-menu";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import {
	ArrowUpDownIcon,
	EyeIcon,
	EyeOffIcon,
	KeyRoundIcon,
	MoreHorizontalIcon,
	PencilIcon,
	SearchIcon,
	ShieldCheckIcon,
	UserRoundCheckIcon,
	UsersRoundIcon,
} from "lucide-react";
import type { Route } from "next";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import { EmptyState, StatusPill } from "@/components/ui-patterns";
import { patchClientApi } from "@/lib/api-client";
import { isAdvisorRole } from "@/lib/roles";
import { EditTargetDialog } from "./edit-target-dialog";

export interface ManagedAccount {
	createdAt: string;
	dailySalesTarget: null | string;
	email: string;
	id: string;
	managerCode: null | string;
	monthlySalesTarget: null | string;
	name: string;
	role: string;
	teamLeaderId: null | string;
	teamLeaderName: null | string;
	title: string;
}

const formatDate = (value: string) =>
	new Intl.DateTimeFormat("en-IN", {
		day: "2-digit",
		month: "short",
		timeZone: "Asia/Kolkata",
		year: "numeric",
	}).format(new Date(value));

const formatTarget = (value: null | string) => {
	if (value === null) {
		return "Not configured";
	}

	return new Intl.NumberFormat("en-IN", {
		currency: "INR",
		maximumFractionDigits: 0,
		style: "currency",
	}).format(Number(value));
};

const UNASSIGNED_TEAM_LEADER_VALUE = "unassigned";

interface AssignTeamLeaderResponse {
	assignment: {
		advisorId: string;
		teamLeaderId: null | string;
		teamLeaderName: null | string;
	};
	success: true;
}

interface PromoteAdvisorResponse {
	account: {
		id: string;
		role: string;
		title: string;
	};
	success: true;
}

interface ResetPasswordResponse {
	account: {
		id: string;
	};
	success: true;
}

const passwordResettableRoles = ["advisor", "team_leader", "logistics"];

const canResetPassword = (role: string) =>
	passwordResettableRoles.some((resettableRole) => resettableRole === role);

type AccountsMode = "manager" | "superadmin" | "team_leader";
type AccountRoleFilter =
	| "all"
	| "team_leader"
	| "senior_advisor"
	| "advisor"
	| "logistics"
	| "warehouse"
	| "admin";

const ACCOUNT_TABLE_MIN_ROWS = 10;
const ACCOUNT_TABLE_PAGE_SIZE_OPTIONS = [10, 25, 50] as const;
const accountRoleFilterOrder: AccountRoleFilter[] = [
	"all",
	"team_leader",
	"senior_advisor",
	"advisor",
	"logistics",
	"warehouse",
	"admin",
];
const accountRoleFilterLabels = {
	admin: "Admins",
	advisor: "Advisors",
	all: "All roles",
	logistics: "Logistics",
	senior_advisor: "Senior Advisors",
	team_leader: "Team leaders",
	warehouse: "Warehouse",
} satisfies Record<AccountRoleFilter, string>;

const getAccountsTableColumnCount = (mode: AccountsMode) => {
	if (mode === "superadmin") {
		return 8;
	}

	if (mode === "team_leader") {
		return 5;
	}

	return 7;
};

const getAccountsEmptyState = (mode: AccountsMode) => {
	const createAccountHref: Route = "/accounts/create";

	if (mode === "team_leader") {
		return {
			actionHref: undefined as Route | undefined,
			actionLabel: undefined,
			description:
				"Assigned advisors will appear here once your admin links them to your team.",
			title: "No advisors assigned yet",
		};
	}

	return {
		actionHref: createAccountHref,
		actionLabel: "Create account",
		description:
			"Create the first advisor, warehouse, or logistics account to give the team access.",
		title: "No accounts yet",
	};
};

const matchesAccountRoleFilter = (
	account: ManagedAccount,
	filter: AccountRoleFilter
) => {
	if (filter === "all") {
		return true;
	}

	if (filter === "senior_advisor") {
		return isAdvisorRole(account.role) && account.title === "Senior Advisor";
	}

	if (filter === "advisor") {
		return isAdvisorRole(account.role) && account.title !== "Senior Advisor";
	}

	return account.role === filter;
};

function AccountsTableColumns({ mode }: { mode: AccountsMode }) {
	return (
		<colgroup>
			<col className="w-[24%]" />
			<col className="w-[12%]" />
			{mode === "superadmin" ? <col className="w-[10%]" /> : null}
			<col className="w-[10%]" />
			<col className="w-[10%]" />
			{mode === "team_leader" ? null : <col className="w-[16%]" />}
			<col className="w-[10%]" />
			{mode === "team_leader" ? null : <col className="w-[8%]" />}
		</colgroup>
	);
}

function AccountsTableHeader({
	mode,
	onCycleRoleFilter,
}: {
	mode: AccountsMode;
	onCycleRoleFilter: () => void;
}) {
	return (
		<TableHeader className="bg-muted/70">
			<TableRow className="hover:bg-muted/70">
				<TableHead>Name / Email</TableHead>
				<TableHead>
					<Button
						className="h-auto gap-1 px-0 py-0 font-medium text-muted-foreground text-sm hover:bg-transparent hover:text-foreground"
						onClick={onCycleRoleFilter}
						size="sm"
						type="button"
						variant="ghost"
					>
						Role
						<ArrowUpDownIcon className="size-3.5" />
					</Button>
				</TableHead>
				{mode === "superadmin" ? <TableHead>Branch</TableHead> : null}
				<TableHead>Daily target</TableHead>
				<TableHead>Monthly target</TableHead>
				{mode === "team_leader" ? null : <TableHead>Team leader</TableHead>}
				<TableHead>Created</TableHead>
				{mode === "team_leader" ? null : <TableHead className="w-32" />}
			</TableRow>
		</TableHeader>
	);
}

export function AccountsDataTable({
	accounts,
	mode = "manager",
}: {
	accounts: ManagedAccount[];
	mode?: AccountsMode;
}) {
	const router = useRouter();
	const refreshRoute = () => {
		router.refresh();
	};
	const [assigningAccount, setAssigningAccount] =
		useState<ManagedAccount | null>(null);
	const [assigningTeamLeaderAccount, setAssigningTeamLeaderAccount] =
		useState<ManagedAccount | null>(null);
	const [editingAccount, setEditingAccount] = useState<ManagedAccount | null>(
		null
	);
	const [resettingPasswordAccount, setResettingPasswordAccount] =
		useState<ManagedAccount | null>(null);
	const [localAccounts, setLocalAccounts] = useState(accounts);
	const [page, setPage] = useState(1);
	const [pageSize, setPageSize] = useState(ACCOUNT_TABLE_MIN_ROWS);
	const [roleFilter, setRoleFilter] = useState<AccountRoleFilter>("all");
	const tableColumnCount = getAccountsTableColumnCount(mode);
	const emptyState = getAccountsEmptyState(mode);

	const handleTargetsUpdated = (
		accountId: string,
		dailySalesTarget: null | string,
		monthlySalesTarget: null | string
	) => {
		setLocalAccounts((previous) =>
			previous.map((account) =>
				account.id === accountId
					? { ...account, dailySalesTarget, monthlySalesTarget }
					: account
			)
		);
	};

	const teamLeaderOptions = localAccounts
		.filter((account) => account.role === "team_leader")
		.sort((left, right) => left.name.localeCompare(right.name));

	const getTeamLeaderName = (account: ManagedAccount) =>
		account.teamLeaderName ??
		teamLeaderOptions.find(
			(teamLeader) => teamLeader.id === account.teamLeaderId
		)?.name ??
		"No team leader";

	const handleTeamLeaderChanged = async (
		account: ManagedAccount,
		teamLeaderId: null | string
	) => {
		const nextTeamLeaderId =
			teamLeaderId === UNASSIGNED_TEAM_LEADER_VALUE ? null : teamLeaderId;

		try {
			const result = await patchClientApi<AssignTeamLeaderResponse>(
				"accounts",
				`/${account.id}/team-leader`,
				{ teamLeaderId: nextTeamLeaderId }
			);

			setLocalAccounts((previous) =>
				previous.map((currentAccount) =>
					currentAccount.id === account.id
						? {
								...currentAccount,
								teamLeaderId: result.assignment.teamLeaderId,
								teamLeaderName: result.assignment.teamLeaderName,
							}
						: currentAccount
				)
			);
			toast.success("Team leader updated");
			refreshRoute();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to update team leader"
			);
		}
	};

	const handleTeamLeaderAdvisorAssignments = async (
		teamLeader: ManagedAccount,
		selectedAdvisorIds: string[]
	) => {
		const selectedAdvisorIdSet = new Set(selectedAdvisorIds);
		const editableAdvisors = localAccounts.filter(
			(account) =>
				isAdvisorRole(account.role) &&
				account.managerCode === teamLeader.managerCode &&
				(account.teamLeaderId === null ||
					account.teamLeaderId === teamLeader.id)
		);
		const changedAdvisors = editableAdvisors.filter((advisor) => {
			const shouldBeAssigned = selectedAdvisorIdSet.has(advisor.id);
			return shouldBeAssigned !== (advisor.teamLeaderId === teamLeader.id);
		});

		if (changedAdvisors.length === 0) {
			return;
		}

		try {
			const assignments = await Promise.all(
				changedAdvisors.map((advisor) =>
					patchClientApi<AssignTeamLeaderResponse>(
						"accounts",
						`/${advisor.id}/team-leader`,
						{
							teamLeaderId: selectedAdvisorIdSet.has(advisor.id)
								? teamLeader.id
								: null,
						}
					)
				)
			);
			const assignmentByAdvisorId = new Map(
				assignments.map((result) => [
					result.assignment.advisorId,
					result.assignment,
				])
			);

			setLocalAccounts((previous) =>
				previous.map((account) => {
					const assignment = assignmentByAdvisorId.get(account.id);
					if (!assignment) {
						return account;
					}

					return {
						...account,
						teamLeaderId: assignment.teamLeaderId,
						teamLeaderName: assignment.teamLeaderName,
					};
				})
			);
			toast.success("Advisor assignments updated");
			refreshRoute();
			setAssigningTeamLeaderAccount(null);
		} catch (error) {
			toast.error(
				error instanceof Error
					? error.message
					: "Failed to update advisor assignments"
			);
		}
	};

	const handlePromoteAdvisor = async (account: ManagedAccount) => {
		try {
			const result = await patchClientApi<PromoteAdvisorResponse>(
				"accounts",
				`/${account.id}/promote-senior`,
				{}
			);

			setLocalAccounts((previous) =>
				previous.map((currentAccount) =>
					currentAccount.id === account.id
						? {
								...currentAccount,
								role: result.account.role,
								title: result.account.title,
							}
						: currentAccount
				)
			);
			toast.success("Advisor promoted to Senior Advisor");
			refreshRoute();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to promote advisor"
			);
		}
	};

	const handlePasswordReset = async (
		account: ManagedAccount,
		password: string
	) => {
		try {
			await patchClientApi<ResetPasswordResponse>(
				"accounts",
				`/${account.id}/password`,
				{ password }
			);
			toast.success("Password reset");
			refreshRoute();
			setResettingPasswordAccount(null);
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to reset password"
			);
		}
	};

	if (localAccounts.length === 0) {
		return (
			<EmptyState
				actionHref={emptyState.actionHref}
				actionLabel={emptyState.actionLabel}
				title={emptyState.title}
			>
				{emptyState.description}
			</EmptyState>
		);
	}

	const availableRoleFilters = accountRoleFilterOrder.filter(
		(filter) =>
			filter === "all" ||
			localAccounts.some((account) => matchesAccountRoleFilter(account, filter))
	);
	const filteredAccounts = localAccounts.filter((account) =>
		matchesAccountRoleFilter(account, roleFilter)
	);
	const pageCount = Math.max(1, Math.ceil(filteredAccounts.length / pageSize));
	const safePage = Math.min(page, pageCount);
	const startIndex = (safePage - 1) * pageSize;
	const paginatedAccounts = filteredAccounts.slice(
		startIndex,
		startIndex + pageSize
	);
	const fillerRows = Math.max(
		0,
		ACCOUNT_TABLE_MIN_ROWS - paginatedAccounts.length
	);
	const pageInputValue = String(safePage);

	const cycleRoleFilter = () => {
		const currentIndex = availableRoleFilters.indexOf(roleFilter);
		const nextIndex =
			currentIndex === -1 || currentIndex === availableRoleFilters.length - 1
				? 0
				: currentIndex + 1;
		setRoleFilter(availableRoleFilters[nextIndex] ?? "all");
		setPage(1);
	};

	return (
		<>
			<div className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
				<Table className="table-fixed">
					<AccountsTableColumns mode={mode} />
					<AccountsTableHeader
						mode={mode}
						onCycleRoleFilter={cycleRoleFilter}
					/>
					<TableBody>
						{paginatedAccounts.map((account) => (
							<TableRow className="bg-card hover:bg-muted/35" key={account.id}>
								<TableCell>
									<p className="max-w-full break-words font-medium text-foreground">
										{account.name}
									</p>
									<p className="max-w-full break-words text-muted-foreground text-sm">
										{account.email}
									</p>
								</TableCell>
								<TableCell>
									<span className="block max-w-full break-words text-sm">
										{account.title}
									</span>
								</TableCell>
								{mode === "superadmin" ? (
									<TableCell>
										{account.managerCode ? (
											<StatusPill>{account.managerCode}</StatusPill>
										) : (
											<span className="text-muted-foreground text-sm">
												&mdash;
											</span>
										)}
									</TableCell>
								) : null}
								<TableCell className="text-sm">
									{isAdvisorRole(account.role) || account.role === "team_leader"
										? formatTarget(account.dailySalesTarget)
										: "—"}
								</TableCell>
								<TableCell className="text-sm">
									{isAdvisorRole(account.role) || account.role === "team_leader"
										? formatTarget(account.monthlySalesTarget)
										: "—"}
								</TableCell>
								{mode === "team_leader" ? null : (
									<TableCell>
										{isAdvisorRole(account.role) ? (
											<span className="block max-w-full break-words text-sm">
												{getTeamLeaderName(account)}
											</span>
										) : (
											<span className="text-muted-foreground text-sm">
												&mdash;
											</span>
										)}
									</TableCell>
								)}
								<TableCell className="text-muted-foreground text-sm">
									{formatDate(account.createdAt)}
								</TableCell>
								{mode === "team_leader" ? null : (
									<TableCell>
										<AccountActionsMenu
											account={account}
											mode={mode}
											onAssignAdvisors={setAssigningTeamLeaderAccount}
											onAssignTeamLeader={setAssigningAccount}
											onEditTargets={setEditingAccount}
											onPromoteAdvisor={handlePromoteAdvisor}
											onResetPassword={setResettingPasswordAccount}
										/>
									</TableCell>
								)}
							</TableRow>
						))}
						{filteredAccounts.length === 0 ? (
							<TableRow>
								<TableCell
									className="h-16 text-center text-muted-foreground"
									colSpan={tableColumnCount}
								>
									No accounts match this role filter.
								</TableCell>
							</TableRow>
						) : null}
						{Array.from({
							length:
								filteredAccounts.length === 0
									? ACCOUNT_TABLE_MIN_ROWS - 1
									: fillerRows,
						}).map((_, index) => (
							<TableRow
								aria-hidden
								className="hover:bg-transparent"
								key={`account-filler-${index}`}
							>
								<TableCell className="h-16" colSpan={tableColumnCount}>
									&nbsp;
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
				<div className="grid gap-3 border-t px-4 py-4 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
					<p className="text-muted-foreground text-sm">
						Showing {filteredAccounts.length === 0 ? 0 : startIndex + 1} to{" "}
						{Math.min(
							startIndex + paginatedAccounts.length,
							filteredAccounts.length
						)}{" "}
						of {filteredAccounts.length} accounts
						{roleFilter === "all"
							? ""
							: ` · ${accountRoleFilterLabels[roleFilter]}`}
					</p>
					<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
						<PaginationContent>
							<PaginationItem>
								<PaginationPrevious
									disabled={safePage <= 1}
									onClick={() => setPage((value) => Math.max(1, value - 1))}
									type="button"
								/>
							</PaginationItem>
							<PaginationItem>
								<div className="flex h-9 items-center gap-2 px-2 text-sm">
									<span className="text-muted-foreground">Page</span>
									<Input
										className="h-8 w-16 text-center"
										inputMode="numeric"
										max={pageCount}
										min={1}
										onBlur={() => {
											setPage((value) => Math.min(pageCount, value));
										}}
										onChange={(event) => {
											const nextPage = Number(event.target.value);
											if (!Number.isInteger(nextPage)) {
												return;
											}

											setPage(Math.min(pageCount, Math.max(1, nextPage)));
										}}
										value={pageInputValue}
									/>
									<span className="text-muted-foreground">of {pageCount}</span>
								</div>
							</PaginationItem>
							<PaginationItem>
								<PaginationNext
									disabled={safePage >= pageCount}
									onClick={() =>
										setPage((value) => Math.min(pageCount, value + 1))
									}
									type="button"
								/>
							</PaginationItem>
						</PaginationContent>
					</Pagination>
					<div className="flex flex-wrap items-center gap-3 lg:justify-end">
						<div className="flex items-center gap-2">
							<span className="text-muted-foreground text-sm">Rows</span>
							<Select
								onValueChange={(value) => {
									setPage(1);
									setPageSize(Number(value));
								}}
								value={String(pageSize)}
							>
								<SelectTrigger className="h-9 w-20">
									<SelectValue>{pageSize}</SelectValue>
								</SelectTrigger>
								<SelectContent align="end">
									{ACCOUNT_TABLE_PAGE_SIZE_OPTIONS.map((option) => (
										<SelectItem key={option} value={String(option)}>
											{option}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
					</div>
				</div>
			</div>

			{editingAccount ? (
				<EditTargetDialog
					account={editingAccount}
					onClose={() => setEditingAccount(null)}
					onSaved={handleTargetsUpdated}
				/>
			) : null}

			{assigningAccount ? (
				<AssignTeamLeaderDialog
					account={assigningAccount}
					onAssign={handleTeamLeaderChanged}
					onClose={() => setAssigningAccount(null)}
					teamLeaders={teamLeaderOptions}
				/>
			) : null}

			{assigningTeamLeaderAccount ? (
				<AssignAdvisorsDialog
					advisors={localAccounts.filter(
						(account) =>
							isAdvisorRole(account.role) &&
							account.managerCode === assigningTeamLeaderAccount.managerCode
					)}
					onClose={() => setAssigningTeamLeaderAccount(null)}
					onSave={handleTeamLeaderAdvisorAssignments}
					teamLeader={assigningTeamLeaderAccount}
				/>
			) : null}

			{resettingPasswordAccount ? (
				<ResetPasswordDialog
					account={resettingPasswordAccount}
					onClose={() => setResettingPasswordAccount(null)}
					onReset={handlePasswordReset}
				/>
			) : null}
		</>
	);
}

function AccountActionsMenu({
	account,
	onAssignAdvisors,
	onAssignTeamLeader,
	onEditTargets,
	onPromoteAdvisor,
	onResetPassword,
	mode,
}: {
	account: ManagedAccount;
	onAssignAdvisors: (account: ManagedAccount) => void;
	onAssignTeamLeader: (account: ManagedAccount) => void;
	onEditTargets: (account: ManagedAccount) => void;
	onPromoteAdvisor: (account: ManagedAccount) => void;
	onResetPassword: (account: ManagedAccount) => void;
	mode: AccountsMode;
}) {
	if (mode === "manager" && !canResetPassword(account.role)) {
		return null;
	}

	if (mode === "superadmin" && !["admin", "warehouse"].includes(account.role)) {
		return null;
	}

	const isAdvisorAccount = isAdvisorRole(account.role);
	const isTeamLeaderAccount = account.role === "team_leader";
	const canPromoteAdvisor =
		isAdvisorAccount && account.title !== "Senior Advisor";

	return (
		<DropdownMenu>
			<DropdownMenuTrigger
				render={
					<Button
						className="ml-auto"
						size="icon"
						title="Open account actions"
						variant="ghost"
					/>
				}
			>
				<MoreHorizontalIcon className="size-4" />
			</DropdownMenuTrigger>
			<DropdownMenuContent align="end" className="bg-card">
				<DropdownMenuGroup>
					<DropdownMenuLabel className="px-2 py-1.5">Actions</DropdownMenuLabel>
					<DropdownMenuSeparator />
					{mode === "manager" && isTeamLeaderAccount ? (
						<DropdownMenuItem onClick={() => onAssignAdvisors(account)}>
							<UsersRoundIcon className="size-4" />
							Assign advisors
						</DropdownMenuItem>
					) : null}
					{mode === "manager" && isAdvisorAccount ? (
						<DropdownMenuItem onClick={() => onAssignTeamLeader(account)}>
							<UserRoundCheckIcon className="size-4" />
							Assign team leader
						</DropdownMenuItem>
					) : null}
					{mode === "manager" && canPromoteAdvisor ? (
						<DropdownMenuItem onClick={() => onPromoteAdvisor(account)}>
							<ShieldCheckIcon className="size-4" />
							Promote to Senior Advisor
						</DropdownMenuItem>
					) : null}
					{mode === "manager" && isAdvisorAccount ? (
						<DropdownMenuItem onClick={() => onEditTargets(account)}>
							<PencilIcon className="size-4" />
							Edit targets
						</DropdownMenuItem>
					) : null}
					<DropdownMenuItem onClick={() => onResetPassword(account)}>
						<KeyRoundIcon className="size-4" />
						Reset password
					</DropdownMenuItem>
				</DropdownMenuGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}

function AssignTeamLeaderDialog({
	account,
	onAssign,
	onClose,
	teamLeaders,
}: {
	account: ManagedAccount;
	onAssign: (account: ManagedAccount, teamLeaderId: string) => Promise<void>;
	onClose: () => void;
	teamLeaders: ManagedAccount[];
}) {
	const [searchQuery, setSearchQuery] = useState("");
	const [selectedTeamLeaderId, setSelectedTeamLeaderId] = useState(
		account.teamLeaderId ?? UNASSIGNED_TEAM_LEADER_VALUE
	);

	const normalizedSearchQuery = searchQuery.trim().toLowerCase();
	const branchTeamLeaders = teamLeaders.filter(
		(teamLeader) => teamLeader.managerCode === account.managerCode
	);
	const visibleTeamLeaders = branchTeamLeaders.filter((teamLeader) => {
		if (!normalizedSearchQuery) {
			return true;
		}

		return `${teamLeader.name} ${teamLeader.email}`
			.toLowerCase()
			.includes(normalizedSearchQuery);
	});

	const handleApprove = async () => {
		await onAssign(account, selectedTeamLeaderId);
		onClose();
	};

	return (
		<Dialog onOpenChange={onClose} open>
			<DialogContent>
				<DialogHeader>
					<DialogTitle>Assign team leader</DialogTitle>
					<DialogDescription>
						Choose a team leader from {account.managerCode ?? "this branch"}.
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-3">
					<div className="relative">
						<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
						<Input
							className="pl-9"
							onChange={(event) => setSearchQuery(event.target.value)}
							placeholder="Search team leaders..."
							value={searchQuery}
						/>
					</div>

					<div className="max-h-72 space-y-2 overflow-y-auto">
						{visibleTeamLeaders.map((teamLeader) => (
							<label
								className={cn(
									"flex cursor-pointer items-start gap-3 rounded-xl border border-border/70 bg-card p-3 transition hover:bg-muted/40",
									teamLeader.id === selectedTeamLeaderId &&
										"border-primary/50 bg-primary/5"
								)}
								key={teamLeader.id}
							>
								<input
									checked={teamLeader.id === selectedTeamLeaderId}
									className="mt-1 size-4 accent-primary"
									name="teamLeaderId"
									onChange={() => setSelectedTeamLeaderId(teamLeader.id)}
									type="radio"
									value={teamLeader.id}
								/>
								<div>
									<p className="font-medium">{teamLeader.name}</p>
									<p className="text-muted-foreground text-xs">
										{teamLeader.email}
									</p>
								</div>
							</label>
						))}
						{visibleTeamLeaders.length === 0 ? (
							<p className="rounded-lg border border-dashed p-4 text-center text-muted-foreground text-sm">
								No team leaders found.
							</p>
						) : null}
					</div>
				</div>

				<DialogFooter className="gap-2 sm:justify-between">
					<Button
						onClick={async () => {
							await onAssign(account, UNASSIGNED_TEAM_LEADER_VALUE);
							onClose();
						}}
						variant="destructive"
					>
						Do not link to a team leader
					</Button>
					<Button onClick={handleApprove}>Assign</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}

function haveSameSelectedAdvisors(left: string[], right: string[]) {
	if (left.length !== right.length) {
		return false;
	}

	const rightSet = new Set(right);
	return left.every((value) => rightSet.has(value));
}

function AssignAdvisorsDialog({
	advisors,
	onClose,
	onSave,
	teamLeader,
}: {
	advisors: ManagedAccount[];
	onClose: () => void;
	onSave: (
		teamLeader: ManagedAccount,
		selectedAdvisorIds: string[]
	) => Promise<void>;
	teamLeader: ManagedAccount;
}) {
	const [searchQuery, setSearchQuery] = useState("");
	const initialAdvisorIds = advisors
		.filter((advisor) => advisor.teamLeaderId === teamLeader.id)
		.map((advisor) => advisor.id)
		.sort();
	const [selectedAdvisorIds, setSelectedAdvisorIds] =
		useState(initialAdvisorIds);
	const normalizedSearchQuery = searchQuery.trim().toLowerCase();
	const visibleAdvisors = advisors
		.filter((advisor) => {
			if (!normalizedSearchQuery) {
				return true;
			}

			return `${advisor.name} ${advisor.email}`
				.toLowerCase()
				.includes(normalizedSearchQuery);
		})
		.sort((left, right) => left.name.localeCompare(right.name));
	const hasChanges = !haveSameSelectedAdvisors(
		initialAdvisorIds,
		[...selectedAdvisorIds].sort()
	);

	const toggleAdvisor = (advisor: ManagedAccount) => {
		if (advisor.teamLeaderId && advisor.teamLeaderId !== teamLeader.id) {
			return;
		}

		setSelectedAdvisorIds((current) =>
			current.includes(advisor.id)
				? current.filter((id) => id !== advisor.id)
				: [...current, advisor.id]
		);
	};

	return (
		<Dialog onOpenChange={onClose} open>
			<DialogContent>
				<DialogHeader>
					<DialogTitle>Assign advisors</DialogTitle>
					<DialogDescription>
						Choose advisors for {teamLeader.name}. Advisors assigned to another
						team leader cannot be changed here.
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-3">
					<div className="relative">
						<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
						<Input
							className="pl-9"
							onChange={(event) => setSearchQuery(event.target.value)}
							placeholder="Search advisors..."
							value={searchQuery}
						/>
					</div>

					<div className="max-h-80 space-y-2 overflow-y-auto">
						{visibleAdvisors.map((advisor) => {
							const isAssignedElsewhere =
								advisor.teamLeaderId !== null &&
								advisor.teamLeaderId !== teamLeader.id;
							const isSelected = selectedAdvisorIds.includes(advisor.id);

							return (
								<label
									className={cn(
										"flex items-start gap-3 rounded-xl border border-border/70 bg-card p-3 transition",
										isAssignedElsewhere
											? "cursor-not-allowed opacity-50"
											: "cursor-pointer hover:bg-muted/40",
										isSelected && "border-primary/50 bg-primary/5"
									)}
									key={advisor.id}
								>
									<Checkbox
										checked={isSelected}
										className="mt-1"
										disabled={isAssignedElsewhere}
										onCheckedChange={() => toggleAdvisor(advisor)}
									/>
									<div className="min-w-0">
										<p className="font-medium">{advisor.name}</p>
										<p className="truncate text-muted-foreground text-xs">
											{advisor.email}
										</p>
										{isAssignedElsewhere ? (
											<p className="mt-1 text-muted-foreground text-xs">
												Assigned to{" "}
												{advisor.teamLeaderName ?? "another team leader"}
											</p>
										) : null}
									</div>
								</label>
							);
						})}
						{visibleAdvisors.length === 0 ? (
							<p className="rounded-lg border border-dashed p-4 text-center text-muted-foreground text-sm">
								No advisors found.
							</p>
						) : null}
					</div>
				</div>

				<DialogFooter>
					<Button
						disabled={!hasChanges}
						onClick={() => onSave(teamLeader, selectedAdvisorIds)}
					>
						Save
					</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}

function ResetPasswordDialog({
	account,
	onClose,
	onReset,
}: {
	account: ManagedAccount;
	onClose: () => void;
	onReset: (account: ManagedAccount, password: string) => Promise<void>;
}) {
	const [password, setPassword] = useState("");
	const [isPasswordVisible, setIsPasswordVisible] = useState(false);

	const handleReset = async () => {
		await onReset(account, password);
	};

	return (
		<Dialog onOpenChange={onClose} open>
			<DialogContent>
				<DialogHeader>
					<DialogTitle>Reset password</DialogTitle>
					<DialogDescription>
						Set a new password for {account.name}. Existing sessions for this
						account will be signed out.
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-2">
					<div className="relative">
						<Input
							className="pr-10"
							onChange={(event) => setPassword(event.target.value)}
							placeholder="Enter new password"
							type={isPasswordVisible ? "text" : "password"}
							value={password}
						/>
						<Button
							className="absolute top-1/2 right-1 size-7 -translate-y-1/2"
							onClick={() => setIsPasswordVisible((value) => !value)}
							size="icon-xs"
							title={isPasswordVisible ? "Hide password" : "Show password"}
							type="button"
							variant="ghost"
						>
							{isPasswordVisible ? (
								<EyeOffIcon className="size-4" />
							) : (
								<EyeIcon className="size-4" />
							)}
						</Button>
					</div>
					<p className="text-muted-foreground text-xs">
						Password must be at least 8 characters.
					</p>
				</div>

				<DialogFooter>
					<Button disabled={password.length < 8} onClick={handleReset}>
						Reset password
					</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}
