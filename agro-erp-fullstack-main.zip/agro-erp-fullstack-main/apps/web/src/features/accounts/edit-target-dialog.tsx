"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@agro-erp-fullstack/ui/components/dialog";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import { useForm } from "@tanstack/react-form";
import { Loader2Icon } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import { patchClientApi } from "@/lib/api-client";
import type { ManagedAccount } from "./accounts-data-table";

interface EditTargetDialogProperties {
	account: ManagedAccount;
	onClose: () => void;
	onSaved: (
		accountId: string,
		dailySalesTarget: null | string,
		monthlySalesTarget: null | string
	) => void;
}

interface UpdateTargetsResponse {
	account: {
		dailySalesTarget: null | string;
		id: string;
		monthlySalesTarget: null | string;
	};
	success: true;
}

export function EditTargetDialog({
	account,
	onClose,
	onSaved,
}: EditTargetDialogProperties) {
	const router = useRouter();
	const [isSubmitting, setIsSubmitting] = useState(false);

	const form = useForm({
		defaultValues: {
			dailySalesTarget:
				account.dailySalesTarget === null
					? null
					: Number(account.dailySalesTarget),
			monthlySalesTarget:
				account.monthlySalesTarget === null
					? null
					: Number(account.monthlySalesTarget),
		},
		onSubmit: async ({ value }) => {
			setIsSubmitting(true);

			try {
				const result = await patchClientApi<UpdateTargetsResponse>(
					"accounts",
					`/${account.id}/targets`,
					{
						dailySalesTarget: value.dailySalesTarget,
						monthlySalesTarget: value.monthlySalesTarget,
					}
				);

				onSaved(
					account.id,
					result.account.dailySalesTarget,
					result.account.monthlySalesTarget
				);
				toast.success("Targets updated");
				router.refresh();
				onClose();
			} catch (error) {
				toast.error(
					error instanceof Error ? error.message : "Failed to update targets"
				);
			} finally {
				setIsSubmitting(false);
			}
		},
	});

	return (
		<Dialog onOpenChange={onClose} open>
			<DialogContent>
				<DialogHeader>
					<DialogTitle>Edit targets</DialogTitle>
					<DialogDescription>
						Update daily and monthly sales targets for {account.name}.
					</DialogDescription>
				</DialogHeader>

				<form
					className="space-y-5"
					onSubmit={(event) => {
						event.preventDefault();
						event.stopPropagation();
						form.handleSubmit();
					}}
				>
					<form.Field name="dailySalesTarget">
						{(field) => (
							<div className="space-y-2">
								<Label htmlFor={field.name}>Daily sales target</Label>
								<Input
									id={field.name}
									min="0"
									name={field.name}
									onBlur={field.handleBlur}
									onChange={(event) =>
										field.handleChange(
											event.target.value === ""
												? null
												: Number(event.target.value)
										)
									}
									placeholder="Leave empty for not configured"
									step="0.01"
									type="number"
									value={field.state.value ?? ""}
								/>
								{(field.state.meta.errors as unknown as string[]).map(
									(error) => (
										<p className="text-destructive text-sm" key={error}>
											{error}
										</p>
									)
								)}
								<p className="text-muted-foreground text-xs">
									Leave empty to mark as not configured.
								</p>
							</div>
						)}
					</form.Field>

					<form.Field name="monthlySalesTarget">
						{(field) => (
							<div className="space-y-2">
								<Label htmlFor={field.name}>Monthly sales target</Label>
								<Input
									id={field.name}
									min="0"
									name={field.name}
									onBlur={field.handleBlur}
									onChange={(event) =>
										field.handleChange(
											event.target.value === ""
												? null
												: Number(event.target.value)
										)
									}
									placeholder="Leave empty for not configured"
									step="0.01"
									type="number"
									value={field.state.value ?? ""}
								/>
								{(field.state.meta.errors as unknown as string[]).map(
									(error) => (
										<p className="text-destructive text-sm" key={error}>
											{error}
										</p>
									)
								)}
								<p className="text-muted-foreground text-xs">
									Leave empty to mark as not configured.
								</p>
							</div>
						)}
					</form.Field>

					<DialogFooter>
						<Button onClick={onClose} type="button" variant="outline">
							Cancel
						</Button>
						<form.Subscribe
							selector={(state) => ({
								canSubmit: state.canSubmit,
								isSubmitting: state.isSubmitting,
							})}
						>
							{({ canSubmit }) => (
								<Button disabled={!canSubmit || isSubmitting} type="submit">
									{isSubmitting ? (
										<>
											<Loader2Icon className="size-4 animate-spin" />
											Saving...
										</>
									) : (
										"Save targets"
									)}
								</Button>
							)}
						</form.Subscribe>
					</DialogFooter>
				</form>
			</DialogContent>
		</Dialog>
	);
}
