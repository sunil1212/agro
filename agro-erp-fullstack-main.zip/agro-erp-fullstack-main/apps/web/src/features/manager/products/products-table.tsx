"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuGroup,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from "@agro-erp-fullstack/ui/components/dropdown-menu";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import { LiteDebouncer } from "@tanstack/pacer-lite/lite-debouncer";
import {
	ChevronDownIcon,
	ChevronRightIcon,
	MoreHorizontalIcon,
	PencilIcon,
	SearchIcon,
} from "lucide-react";
import type { Route } from "next";
import { useRouter } from "next/navigation";
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { StatusPill } from "@/components/ui-patterns";
import { getClientApiUrl } from "@/lib/api-client";

const currencyFormatter = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2,
});

const defaultRowsPerPage = 10;
const rowsPerPageOptions = [10, 20, 50] as const;

export interface ManagedSubProduct {
	additionalNotes: null | string;
	costPerUnit: string;
	discount: string;
	id: string;
	isActive: boolean;
	offerPrice: string;
	packageQuantity: null | string;
	packageUnit: null | string;
	packagingType: null | string;
	packingCode: null | string;
	quantity: number;
	reservedQuantity: number;
	skuCode: null | string;
}

export interface ManagedProduct {
	additionalNotes: null | string;
	categoryCode: null | string;
	createdAt: string;
	id: string;
	isActive: boolean;
	name: string;
	productCode: null | string;
	variants: ManagedSubProduct[];
}

const formatPackSize = (variant: ManagedSubProduct) =>
	[
		variant.packageQuantity ? Number(variant.packageQuantity).toString() : "",
		variant.packageUnit ?? "",
	]
		.filter(Boolean)
		.join(" ");

function ProductActionsMenu({
	isActive,
	onToggleActive,
	productId,
}: {
	isActive: boolean;
	onToggleActive: (productId: string, nextActive: boolean) => Promise<void>;
	productId: string;
}) {
	const router = useRouter();
	const editHref = `/products/${productId}/edit` as Route;

	return (
		<DropdownMenu>
			<DropdownMenuTrigger
				render={
					<Button size="icon" title="Open product actions" variant="ghost" />
				}
			>
				<MoreHorizontalIcon className="size-4" />
			</DropdownMenuTrigger>
			<DropdownMenuContent align="end" className="bg-card">
				<DropdownMenuGroup>
					<DropdownMenuLabel className="px-2 py-1.5">Actions</DropdownMenuLabel>
					<DropdownMenuSeparator />
					<DropdownMenuItem
						disabled={!isActive}
						onClick={() => {
							if (isActive) {
								router.push(editHref);
							}
						}}
					>
						<PencilIcon className="size-4" />
						Edit product
					</DropdownMenuItem>
					<DropdownMenuItem
						onClick={() =>
							onToggleActive(productId, !isActive).catch(() => undefined)
						}
					>
						{isActive ? "Deactivate product" : "Reactivate product"}
					</DropdownMenuItem>
				</DropdownMenuGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}

export function ProductsTable({ products }: { products: ManagedProduct[] }) {
	const router = useRouter();
	const [items, setItems] = useState(products);
	const [query, setQuery] = useState("");
	const [debouncedQuery, setDebouncedQuery] = useState("");
	const [expandedIds, setExpandedIds] = useState<ReadonlySet<string>>(
		() => new Set(items.slice(0, 3).map((product) => product.id))
	);
	const [page, setPage] = useState(1);
	const [rowsPerPage, setRowsPerPage] =
		useState<(typeof rowsPerPageOptions)[number]>(defaultRowsPerPage);
	const debouncerRef = useRef<LiteDebouncer<(value: string) => void> | null>(
		null
	);

	if (!debouncerRef.current) {
		debouncerRef.current = new LiteDebouncer(
			(nextValue: string) => setDebouncedQuery(nextValue),
			{ wait: 180 }
		);
	}

	useEffect(
		() => () => {
			debouncerRef.current?.cancel();
		},
		[]
	);

	useEffect(() => {
		setItems(products);
	}, [products]);

	const filteredProducts = useMemo(() => {
		const normalizedQuery = debouncedQuery.trim().toLowerCase();
		if (!normalizedQuery) {
			return items;
		}

		return items.filter((entry) => {
			const haystack = [
				entry.categoryCode ?? "",
				entry.productCode ?? "",
				entry.name,
				entry.additionalNotes ?? "",
				...entry.variants.flatMap((variant) => [
					variant.skuCode ?? "",
					variant.packingCode ?? "",
					variant.packagingType ?? "",
					formatPackSize(variant),
					variant.offerPrice,
				]),
			]
				.join(" ")
				.toLowerCase();
			return haystack.includes(normalizedQuery);
		});
	}, [debouncedQuery, items]);

	const totalPages = Math.max(
		1,
		Math.ceil(filteredProducts.length / rowsPerPage)
	);

	useEffect(() => {
		if (page > totalPages) {
			setPage(totalPages);
		}
	}, [page, totalPages]);

	const pagedProducts = useMemo(() => {
		const startIndex = (page - 1) * rowsPerPage;
		return filteredProducts.slice(startIndex, startIndex + rowsPerPage);
	}, [filteredProducts, page, rowsPerPage]);

	const updateProductActiveState = async (
		productId: string,
		nextActive: boolean
	) => {
		const path = nextActive ? "reactivate" : "deactivate";
		const response = await fetch(
			getClientApiUrl("products", `/${productId}/${path}`),
			{
				credentials: "include",
				method: "POST",
			}
		);
		const data = (await response.json().catch(() => null)) as {
			message?: string;
			success?: boolean;
		} | null;

		if (!(response.ok && data?.success)) {
			throw new Error(
				data?.message ??
					(nextActive
						? "Failed to reactivate product"
						: "Failed to deactivate product")
			);
		}

		setItems((currentItems) =>
			currentItems.map((product) =>
				product.id === productId
					? {
							...product,
							isActive: nextActive,
							variants: product.variants.map((variant) => ({
								...variant,
								isActive: nextActive,
							})),
						}
					: product
			)
		);
		toast.success(nextActive ? "Product reactivated" : "Product deactivated");
		router.refresh();
	};

	const toggleExpanded = (productId: string) => {
		setExpandedIds((currentIds) => {
			const nextIds = new Set(currentIds);
			if (nextIds.has(productId)) {
				nextIds.delete(productId);
			} else {
				nextIds.add(productId);
			}
			return nextIds;
		});
	};

	return (
		<div className="space-y-4">
			<div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
				<h2 className="font-semibold text-xl leading-tight">Product Catalog</h2>
				<div className="relative w-full sm:w-80">
					<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
					<Input
						className="pl-9"
						onChange={(event) => {
							const nextValue = event.target.value;
							setPage(1);
							setQuery(nextValue);
							debouncerRef.current?.maybeExecute(nextValue);
						}}
						placeholder="Search SKU, pack, name..."
						value={query}
					/>
				</div>
			</div>

			{filteredProducts.length > 0 ? (
				<>
					<div className="-mx-5 overflow-x-auto sm:-mx-6">
						<div className="min-w-[1120px] px-5 sm:px-6">
							<table className="w-full border-separate border-spacing-0 text-sm">
								<thead>
									<tr className="text-left">
										{[
											"Product",
											"Code",
											"Variants",
											"Stock / Price",
											"Status",
											"Actions",
										].map((heading) => (
											<th
												className="border-border/70 border-b bg-muted/70 px-4 py-3 font-medium text-muted-foreground text-xs uppercase tracking-[0.16em] first:rounded-l-2xl last:rounded-r-2xl"
												key={heading}
											>
												{heading}
											</th>
										))}
									</tr>
								</thead>
								<tbody>
									{pagedProducts.map((entry) => {
										const isExpanded = expandedIds.has(entry.id);

										return (
											<Fragment key={entry.id}>
												<tr className="group">
													<td className="border-border/50 border-b px-4 py-4">
														<button
															className="inline-flex items-center gap-2 font-semibold text-foreground"
															onClick={() => toggleExpanded(entry.id)}
															type="button"
														>
															{isExpanded ? (
																<ChevronDownIcon className="size-4" />
															) : (
																<ChevronRightIcon className="size-4" />
															)}
															{entry.name}
														</button>
														{entry.additionalNotes ? (
															<p className="mt-1 max-w-[42ch] text-muted-foreground text-xs leading-5">
																{entry.additionalNotes}
															</p>
														) : null}
													</td>
													<td className="border-border/50 border-b px-4 py-4 font-medium">
														{entry.categoryCode ?? "-"} /{" "}
														{entry.productCode ?? "-"}
													</td>
													<td className="border-border/50 border-b px-4 py-4">
														{entry.variants.length}
													</td>
													<td className="border-border/50 border-b px-4 py-4 text-muted-foreground">
														—
													</td>
													<td className="border-border/50 border-b px-4 py-4">
														<StatusPill>
															{entry.isActive ? "Active" : "Inactive"}
														</StatusPill>
													</td>
													<td className="border-border/50 border-b px-4 py-4 text-center">
														<ProductActionsMenu
															isActive={entry.isActive}
															onToggleActive={updateProductActiveState}
															productId={entry.id}
														/>
													</td>
												</tr>
												{isExpanded
													? entry.variants.map((variant) => (
															<tr key={variant.id}>
																<td className="border-border/30 border-b px-4 py-3 pl-10 text-muted-foreground">
																	<span className="font-medium text-foreground">
																		{formatPackSize(variant) || "-"}
																	</span>{" "}
																	{variant.packagingType ?? "-"}
																</td>
																<td className="border-border/30 border-b px-4 py-3">
																	<span className="inline-flex rounded-full bg-primary/8 px-2.5 py-1 font-medium text-primary text-xs ring-1 ring-primary/15">
																		{variant.skuCode ?? "-"}
																	</span>
																</td>
																<td className="border-border/30 border-b px-4 py-3">
																	{variant.packingCode ?? "-"}
																</td>
																<td className="border-border/30 border-b px-4 py-3">
																	<span className="font-medium">
																		{variant.quantity}
																	</span>
																	<span className="mx-1 text-muted-foreground">
																		/
																	</span>
																	<span className="text-muted-foreground">
																		{currencyFormatter.format(
																			Number(variant.offerPrice)
																		)}
																	</span>
																</td>
																<td className="border-border/30 border-b px-4 py-3">
																	<StatusPill>
																		{variant.isActive ? "Active" : "Inactive"}
																	</StatusPill>
																</td>
																<td className="border-border/30 border-b px-4 py-3 text-center">
																	<span className="text-muted-foreground text-sm">
																		—
																	</span>
																</td>
															</tr>
														))
													: null}
											</Fragment>
										);
									})}
								</tbody>
							</table>
						</div>
					</div>

					<div className="grid gap-3 border-border/50 border-t pt-2 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
						<p className="text-muted-foreground text-sm">
							Page {page} of {totalPages}
						</p>
						<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
							<PaginationContent>
								<PaginationItem>
									<PaginationPrevious
										disabled={page <= 1}
										onClick={() =>
											setPage((currentPage) => Math.max(1, currentPage - 1))
										}
										type="button"
									/>
								</PaginationItem>
								<PaginationItem>
									<div className="flex h-9 items-center gap-2 px-2 text-sm">
										<span className="text-muted-foreground">Page</span>
										<span className="font-medium">{page}</span>
										<span className="text-muted-foreground">
											of {totalPages}
										</span>
									</div>
								</PaginationItem>
								<PaginationItem>
									<PaginationNext
										disabled={page >= totalPages}
										onClick={() =>
											setPage((currentPage) =>
												Math.min(totalPages, currentPage + 1)
											)
										}
										type="button"
									/>
								</PaginationItem>
							</PaginationContent>
						</Pagination>
						<div className="flex items-center gap-2 lg:justify-end">
							<span className="text-muted-foreground text-sm">Rows</span>
							<Select
								onValueChange={(value) => {
									setPage(1);
									setRowsPerPage(
										Number(value) as (typeof rowsPerPageOptions)[number]
									);
								}}
								value={String(rowsPerPage)}
							>
								<SelectTrigger className="h-9 w-20 bg-background">
									<SelectValue />
								</SelectTrigger>
								<SelectContent align="end">
									{rowsPerPageOptions.map((option) => (
										<SelectItem key={option} value={String(option)}>
											{option}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
					</div>
				</>
			) : (
				<div className="rounded-2xl border border-border/60 px-4 py-8 text-center text-muted-foreground text-sm">
					No products match this search.
				</div>
			)}
		</div>
	);
}
