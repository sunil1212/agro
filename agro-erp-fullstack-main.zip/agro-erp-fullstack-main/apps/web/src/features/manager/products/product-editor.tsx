"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { PlusIcon, Trash2Icon } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import z from "zod";
import {
	createManagedProduct,
	type ProductVariantInput,
	updateManagedProduct,
} from "@/app/products/create/actions";
import {
	PageHeader,
	PageShell,
	SectionHeader,
	Surface,
} from "@/components/ui-patterns";
import {
	buildSkuCode,
	calculateDiscount,
	calculateSellingPrice,
	getCreateProductErrorMessage,
	getUpdateProductErrorMessage,
	numberFromInput,
	packagingTypes,
	packUnits,
	sanitizeCode,
} from "@/features/manager/products/product-form-model";
import { createClientId } from "@/lib/client-id";

export interface ProductEditorVariant {
	additionalNotes: string;
	costPerUnit: number;
	discount: number;
	id: string;
	isActive: boolean;
	offerPrice: number;
	packageQuantity: number;
	packageUnit: string;
	packagingType: string;
	packingCode: string;
	quantity: number;
	skuCode: string;
}

export interface ProductEditorInitialValues {
	additionalNotes: string;
	categoryCode: string;
	isActive?: boolean;
	name: string;
	productCode: string;
	variants: ProductEditorVariant[];
}

interface ProductEditorProps {
	initialValues?: ProductEditorInitialValues;
	isActive?: boolean;
	mode: "create" | "edit";
	productId?: string;
}

const parentSchema = z.object({
	additionalNotes: z.string().trim(),
	categoryCode: z.string().trim().min(1, "Category code is required"),
	name: z.string().trim().min(2, "Product name must be at least 2 characters"),
	productCode: z.string().trim().min(1, "Product code is required"),
});

const variantSchema = z.object({
	additionalNotes: z.string().trim(),
	costPerUnit: z.number().nonnegative("MRP cannot be negative"),
	discount: z.number().min(0).max(100),
	offerPrice: z.number().nonnegative("Selling price cannot be negative"),
	packageQuantity: z.number().positive("Pack quantity must be greater than 0"),
	packageUnit: z.string().trim().min(1, "Pack unit is required"),
	packagingType: z.string().trim().min(2, "Packaging type is required"),
	packingCode: z.string().trim().min(1, "Packing code is required"),
	quantity: z.number().int().nonnegative("Opening stock cannot be negative"),
	skuCode: z.string().trim(),
});

const createVariantRow = (): ProductEditorVariant => ({
	additionalNotes: "",
	costPerUnit: 0,
	discount: 0,
	id: createClientId(),
	isActive: true,
	offerPrice: 0,
	packageQuantity: 1,
	packageUnit: "ML",
	packagingType: "BOTTLE",
	packingCode: "",
	quantity: 0,
	skuCode: "",
});

const getDefaultInitialValues = (): ProductEditorInitialValues => ({
	additionalNotes: "",
	categoryCode: "",
	name: "",
	productCode: "",
	variants: [createVariantRow()],
});

export function ProductEditor({
	initialValues,
	isActive = true,
	mode,
	productId,
}: ProductEditorProps) {
	const router = useRouter();
	const defaults = initialValues ?? getDefaultInitialValues();
	const [categoryCode, setCategoryCode] = useState(defaults.categoryCode);
	const [productCode, setProductCode] = useState(defaults.productCode);
	const [name, setName] = useState(defaults.name);
	const [additionalNotes, setAdditionalNotes] = useState(
		defaults.additionalNotes
	);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [variants, setVariants] = useState<ProductEditorVariant[]>(
		defaults.variants.length > 0 ? defaults.variants : [createVariantRow()]
	);
	let submitButtonLabel = "Save product";
	if (mode === "create") {
		submitButtonLabel = "Create product";
	}
	if (isSubmitting) {
		submitButtonLabel = mode === "create" ? "Creating..." : "Saving...";
	}
	if (mode === "edit" && !isActive) {
		submitButtonLabel = "Product disabled";
	}

	const updateVariant = <TKey extends keyof ProductEditorVariant>(
		rowId: string,
		key: TKey,
		value: ProductEditorVariant[TKey]
	) => {
		setVariants((currentRows) =>
			currentRows.map((row) =>
				row.id === rowId ? { ...row, [key]: value } : row
			)
		);
	};

	const removeVariant = (rowId: string) => {
		setVariants((currentRows) =>
			currentRows.length === 1
				? currentRows
				: currentRows.filter((row) => row.id !== rowId)
		);
	};

	const toggleVariantActiveState = (rowId: string) => {
		setVariants((currentRows) =>
			currentRows.map((row) =>
				row.id === rowId ? { ...row, isActive: !row.isActive } : row
			)
		);
	};

	const resetForm = () => {
		const nextDefaults = getDefaultInitialValues();
		setCategoryCode(nextDefaults.categoryCode);
		setProductCode(nextDefaults.productCode);
		setName(nextDefaults.name);
		setAdditionalNotes(nextDefaults.additionalNotes);
		setVariants(nextDefaults.variants);
	};

	const submitProduct = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		const parentValues = {
			additionalNotes,
			categoryCode,
			name,
			productCode,
		};
		const parsedParent = parentSchema.safeParse(parentValues);
		if (!parsedParent.success) {
			toast.error(
				parsedParent.error.issues[0]?.message ?? "Check product details"
			);
			return;
		}

		const parsedVariants = z.array(variantSchema).safeParse(variants);
		if (!parsedVariants.success) {
			toast.error(
				parsedVariants.error.issues[0]?.message ?? "Check variant details"
			);
			return;
		}

		const variantInputs = parsedVariants.data.map<ProductVariantInput>(
			(row, index) => ({
				...row,
				id: mode === "edit" ? variants[index]?.id : undefined,
				isActive: mode === "edit" ? (variants[index]?.isActive ?? true) : true,
				packingCode: row.packingCode.replaceAll(/\s+/g, ""),
				skuCode:
					sanitizeCode(row.skuCode) ||
					buildSkuCode(
						parsedParent.data.categoryCode,
						parsedParent.data.productCode,
						row.packingCode
					),
			})
		);
		const firstVariant = variantInputs[0];
		if (!firstVariant) {
			toast.error("Add at least one variant");
			return;
		}

		setIsSubmitting(true);
		try {
			if (mode === "create") {
				const result = await createManagedProduct({
					...parsedParent.data,
					...firstVariant,
					variants: variantInputs,
				});

				if (!result.success) {
					toast.error(getCreateProductErrorMessage(result));
					return;
				}

				toast.success("Product created");
				resetForm();
				router.refresh();
				return;
			}

			if (!productId) {
				toast.error("Missing product id");
				return;
			}

			const result = await updateManagedProduct(productId, {
				...parsedParent.data,
				...firstVariant,
				id: firstVariant.id,
				variants: variantInputs,
			});

			if (!result.success) {
				toast.error(getUpdateProductErrorMessage(result));
				return;
			}

			toast.success("Product updated");
			router.refresh();
		} catch {
			toast.error("Unable to save the product right now. Please try again");
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<PageShell width="wide">
			<PageHeader
				backHref="/products"
				eyebrow="Products"
				title={mode === "create" ? "Create product" : "Edit product"}
			>
				<p>
					{mode === "create"
						? "Add one parent product and define every pack/SKU variant below it."
						: "Update the parent product and edit every pack/SKU variant in one place."}
				</p>
				{mode === "edit" && !isActive ? (
					<p className="text-muted-foreground text-sm">
						This product is inactive. Reactivate it from the products table to
						edit it.
					</p>
				) : null}
			</PageHeader>

			<Surface className="space-y-6">
				<form className="space-y-8" onSubmit={submitProduct}>
					<fieldset
						className="space-y-8"
						disabled={mode === "edit" && !isActive}
					>
						<section className="space-y-4">
							<SectionHeader title="Parent product" />
							<div className="grid gap-5 lg:grid-cols-4">
								<div className="space-y-2">
									<Label htmlFor="categoryCode">Category code</Label>
									<Input
										id="categoryCode"
										onChange={(event) =>
											setCategoryCode(sanitizeCode(event.target.value))
										}
										placeholder="BS"
										value={categoryCode}
									/>
								</div>
								<div className="space-y-2">
									<Label htmlFor="productCode">Product code</Label>
									<Input
										id="productCode"
										onChange={(event) =>
											setProductCode(sanitizeCode(event.target.value))
										}
										placeholder="11"
										value={productCode}
									/>
								</div>
								<div className="space-y-2 lg:col-span-2">
									<Label htmlFor="productName">Product name</Label>
									<Input
										id="productName"
										onChange={(event) => setName(event.target.value)}
										placeholder="Carboshine"
										value={name}
									/>
								</div>
								<div className="space-y-2 lg:col-span-4">
									<Label htmlFor="additionalNotes">Notes</Label>
									<Textarea
										id="additionalNotes"
										onChange={(event) => setAdditionalNotes(event.target.value)}
										placeholder="Product-level notes"
										value={additionalNotes}
									/>
								</div>
							</div>
						</section>

						<section className="space-y-4">
							<div className="flex flex-wrap items-center justify-between gap-3">
								<SectionHeader title="Variants" />
								<Button
									onClick={() =>
										setVariants((currentRows) => [
											...currentRows,
											createVariantRow(),
										])
									}
									type="button"
									variant="outline"
								>
									<PlusIcon className="size-4" />
									Add variant
								</Button>
							</div>

							<div className="space-y-0 rounded-lg border border-border bg-card">
								{variants.map((variant, index) => {
									const generatedSku = buildSkuCode(
										categoryCode,
										productCode,
										variant.packingCode
									);
									const isEditMode = mode === "edit";
									let variantActionLabel = "Remove";
									if (isEditMode) {
										variantActionLabel = variant.isActive
											? "Deactivate"
											: "Reactivate";
									}

									return (
										<div
											className="border-border border-b p-4 last:border-b-0"
											key={variant.id}
										>
											<div className="mb-3 flex items-center justify-between">
												<span className="font-medium text-muted-foreground text-xs uppercase tracking-[0.14em]">
													Variant {index + 1}
												</span>
												<Button
													aria-label={`Delete variant ${index + 1}`}
													className="-mr-1 h-7 px-2 text-destructive text-xs hover:bg-destructive/10 hover:text-destructive"
													disabled={!isEditMode && variants.length === 1}
													onClick={() => {
														if (isEditMode) {
															toggleVariantActiveState(variant.id);
															return;
														}

														removeVariant(variant.id);
													}}
													size="sm"
													type="button"
													variant="ghost"
												>
													<Trash2Icon className="mr-1 size-3" />
													{variantActionLabel}
												</Button>
											</div>

											<div className="grid gap-3 xl:grid-cols-[6rem_1fr_6rem_6rem_7rem_6rem_6rem_6rem_6rem]">
												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`packingCode-${variant.id}`}
													>
														Pack code
													</Label>
													<Input
														id={`packingCode-${variant.id}`}
														onChange={(event) =>
															updateVariant(
																variant.id,
																"packingCode",
																event.target.value.replaceAll(/\s+/g, "")
															)
														}
														placeholder="01"
														value={variant.packingCode}
													/>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`sku-${variant.id}`}
													>
														SKU
													</Label>
													<Input
														id={`sku-${variant.id}`}
														onChange={(event) =>
															updateVariant(
																variant.id,
																"skuCode",
																sanitizeCode(event.target.value)
															)
														}
														placeholder={generatedSku || "BS1101"}
														value={variant.skuCode}
													/>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`packSize-${variant.id}`}
													>
														Pack size
													</Label>
													<Input
														id={`packSize-${variant.id}`}
														min="0.001"
														onChange={(event) =>
															updateVariant(
																variant.id,
																"packageQuantity",
																numberFromInput(event.target.value)
															)
														}
														step="0.001"
														type="number"
														value={String(variant.packageQuantity)}
													/>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`packUnit-${variant.id}`}
													>
														Unit
													</Label>
													<select
														className="h-9 w-full rounded-lg border border-border bg-input/35 px-3 text-sm"
														id={`packUnit-${variant.id}`}
														onChange={(event) =>
															updateVariant(
																variant.id,
																"packageUnit",
																event.target.value
															)
														}
														value={variant.packageUnit}
													>
														{packUnits.map((unit) => (
															<option key={unit} value={unit}>
																{unit}
															</option>
														))}
													</select>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`packaging-${variant.id}`}
													>
														Package
													</Label>
													<select
														className="h-9 w-full rounded-lg border border-border bg-input/35 px-3 text-sm"
														id={`packaging-${variant.id}`}
														onChange={(event) =>
															updateVariant(
																variant.id,
																"packagingType",
																event.target.value
															)
														}
														value={variant.packagingType}
													>
														{packagingTypes.map((type) => (
															<option key={type} value={type}>
																{type}
															</option>
														))}
													</select>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`mrp-${variant.id}`}
													>
														MRP
													</Label>
													<Input
														id={`mrp-${variant.id}`}
														min="0"
														onChange={(event) => {
															const nextMrp = numberFromInput(
																event.target.value
															);
															updateVariant(variant.id, "costPerUnit", nextMrp);
															updateVariant(
																variant.id,
																"discount",
																calculateDiscount(nextMrp, variant.offerPrice)
															);
														}}
														step="0.01"
														type="number"
														value={String(variant.costPerUnit)}
													/>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`price-${variant.id}`}
													>
														Price
													</Label>
													<Input
														id={`price-${variant.id}`}
														min="0"
														onChange={(event) => {
															const nextPrice = numberFromInput(
																event.target.value
															);
															updateVariant(
																variant.id,
																"offerPrice",
																nextPrice
															);
															updateVariant(
																variant.id,
																"discount",
																calculateDiscount(
																	variant.costPerUnit,
																	nextPrice
																)
															);
														}}
														step="0.01"
														type="number"
														value={String(variant.offerPrice)}
													/>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`discount-${variant.id}`}
													>
														Disc %
													</Label>
													<Input
														id={`discount-${variant.id}`}
														max="100"
														min="0"
														onChange={(event) => {
															const nextDiscount = Math.min(
																Math.max(
																	numberFromInput(event.target.value),
																	0
																),
																100
															);
															updateVariant(
																variant.id,
																"discount",
																nextDiscount
															);
															updateVariant(
																variant.id,
																"offerPrice",
																calculateSellingPrice(
																	variant.costPerUnit,
																	nextDiscount
																)
															);
														}}
														step="0.01"
														type="number"
														value={String(variant.discount)}
													/>
												</div>

												<div className="space-y-1.5">
													<Label
														className="text-xs"
														htmlFor={`stock-${variant.id}`}
													>
														Stock
													</Label>
													<Input
														id={`stock-${variant.id}`}
														min="0"
														onChange={(event) =>
															updateVariant(
																variant.id,
																"quantity",
																numberFromInput(event.target.value)
															)
														}
														type="number"
														value={String(variant.quantity)}
													/>
												</div>
											</div>

											<div className="mt-3 space-y-1.5">
												<Label
													className="text-xs"
													htmlFor={`notes-${variant.id}`}
												>
													Notes
												</Label>
												<Input
													id={`notes-${variant.id}`}
													onChange={(event) =>
														updateVariant(
															variant.id,
															"additionalNotes",
															event.target.value
														)
													}
													placeholder="Optional variant notes"
													value={variant.additionalNotes}
												/>
											</div>
										</div>
									);
								})}
							</div>
						</section>

						<div className="flex flex-wrap items-center gap-3 border-border/60 border-t pt-4">
							<Button
								disabled={isSubmitting || (mode === "edit" && !isActive)}
								type="submit"
							>
								{submitButtonLabel}
							</Button>
							{mode === "create" ? (
								<Button onClick={resetForm} type="button" variant="outline">
									Reset form
								</Button>
							) : null}
							<Link
								className="text-muted-foreground text-sm transition-colors hover:text-foreground"
								href="/products"
							>
								Back to products
							</Link>
						</div>
					</fieldset>
				</form>
			</Surface>
		</PageShell>
	);
}
