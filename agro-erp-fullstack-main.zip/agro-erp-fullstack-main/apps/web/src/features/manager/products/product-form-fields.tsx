"use client";

import {
	Tooltip,
	TooltipContent,
	TooltipTrigger,
} from "@agro-erp-fullstack/ui/components/tooltip";
import { InfoIcon } from "lucide-react";

export function FieldErrors({
	errors,
}: {
	errors: Array<{ message?: string } | undefined>;
}) {
	return errors.map((error) =>
		error?.message ? (
			<p className="text-destructive text-sm" key={error.message}>
				{error.message}
			</p>
		) : null
	);
}

export function FieldLabel({ hint, label }: { hint: string; label: string }) {
	return (
		<span className="inline-flex items-center gap-2">
			<span>{label}</span>
			<Tooltip>
				<TooltipTrigger
					aria-label={`More information about ${label}`}
					render={
						<button
							className="inline-flex size-4 items-center justify-center rounded-full text-muted-foreground transition hover:text-foreground"
							type="button"
						/>
					}
				>
					<InfoIcon className="size-3.5" />
				</TooltipTrigger>
				<TooltipContent>{hint}</TooltipContent>
			</Tooltip>
		</span>
	);
}
