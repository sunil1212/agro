"use client";

import {
	ProductEditor,
	type ProductEditorInitialValues,
} from "@/features/manager/products/product-editor";

export function EditProductForm({
	product,
}: {
	product: ProductEditorInitialValues & { id: string; isActive: boolean };
}) {
	return (
		<ProductEditor
			initialValues={product}
			isActive={product.isActive}
			mode="edit"
			productId={product.id}
		/>
	);
}
