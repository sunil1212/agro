"use client";

import { ProductEditor } from "@/features/manager/products/product-editor";

export default function CreateProductPage() {
	return <ProductEditor mode="create" />;
}
