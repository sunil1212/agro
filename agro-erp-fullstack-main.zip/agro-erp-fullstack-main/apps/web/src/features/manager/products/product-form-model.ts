import type { DropTextOption } from "@agro-erp-fullstack/ui/components/drop-text";
import z from "zod";
import type {
	CreateProductInput,
	CreateProductResult,
	UpdateProductResult,
} from "@/app/products/create/actions";

export type PricingField = "discount" | "offerPrice";

export const packagingTypes = [
	"BOTTLE",
	"PACKET",
	"BOX",
	"BAG",
	"CAN",
] as const;
export const packUnits = ["ML", "LTR", "GM", "KG", "MG", "NOS"] as const;
export const packUnitOptions: readonly DropTextOption[] = packUnits.map(
	(unit) => ({
		label: unit,
		value: unit,
	})
);

const digitsOnlyPattern = /^\d+$/;
const trailingDecimalZeroPattern = /\.?0+$/;

export const productSchema = z.object({
	additionalNotes: z.string().trim(),
	categoryCode: z
		.string()
		.trim()
		.min(1, "Category code is required")
		.max(12, "Category code must be 12 characters or fewer"),
	costPerUnit: z.number().nonnegative("MRP cannot be negative"),
	discount: z
		.number()
		.min(0, "Discount cannot be negative")
		.max(100, "Discount cannot exceed 100%"),
	name: z.string().trim().min(2, "Product name must be at least 2 characters"),
	offerPrice: z.number().nonnegative("Selling price cannot be negative"),
	packageQuantity: z.number().positive("Pack quantity must be greater than 0"),
	packageUnit: z.string().trim().min(1, "Pack unit is required"),
	packagingType: z.string().trim().min(2, "Packaging type is required"),
	packingCode: z
		.string()
		.trim()
		.min(1, "Packing code is required")
		.max(12, "Packing code must be 12 characters or fewer"),
	productCode: z
		.string()
		.trim()
		.min(1, "Product code is required")
		.max(12, "Product code must be 12 characters or fewer"),
	quantity: z.number().int().nonnegative("Opening stock cannot be negative"),
	skuCode: z.string().trim().max(32, "SKU must be 32 characters or fewer"),
});

export const editProductSchema = productSchema.omit({ quantity: true });

export const getCreateProductErrorMessage = (result: CreateProductResult) =>
	result.success ? "Unable to create product" : result.message;

export const getUpdateProductErrorMessage = (result: UpdateProductResult) =>
	result.success ? "Unable to update product" : result.message;

export const numberFromInput = (value: string) => {
	if (!value) {
		return 0;
	}

	return Number(value);
};

const textFromFormData = (
	formData: FormData,
	name: keyof CreateProductInput,
	fallback: string
) => {
	const value = formData.get(name);
	return typeof value === "string" ? value : fallback;
};

const numberFromFormData = (
	formData: FormData,
	name: keyof CreateProductInput,
	fallback: number
) => {
	const value = formData.get(name);
	return typeof value === "string" ? numberFromInput(value) : fallback;
};

export const sanitizeCode = (value: string) =>
	value.replaceAll(/\s+/g, "").toUpperCase().slice(0, 12);

export const normalizePackingCode = (value: string) => {
	const trimmedValue = value.trim();
	if (!trimmedValue) {
		return "";
	}

	return digitsOnlyPattern.test(trimmedValue)
		? trimmedValue.padStart(2, "0")
		: trimmedValue.toUpperCase();
};

export const buildSkuCode = (
	categoryCode: string,
	productCode: string,
	packingCode: string
) => {
	const normalizedCategoryCode = sanitizeCode(categoryCode);
	const normalizedProductCode = sanitizeCode(productCode);
	const normalizedPackingCode = normalizePackingCode(packingCode);

	return `${normalizedCategoryCode}${normalizedProductCode}${normalizedPackingCode}`;
};

export const calculateDiscount = (mrp: number, sellingPrice: number) => {
	if (mrp <= 0 || sellingPrice <= 0 || sellingPrice >= mrp) {
		return 0;
	}

	return Number((((mrp - sellingPrice) / mrp) * 100).toFixed(2));
};

export const calculateSellingPrice = (mrp: number, discount: number) => {
	if (mrp <= 0) {
		return 0;
	}

	const safeDiscount = Math.min(Math.max(discount, 0), 100);
	return Number((mrp * (1 - safeDiscount / 100)).toFixed(2));
};

export const buildProductSubmissionValues = (
	formElement: HTMLFormElement,
	fallback: CreateProductInput,
	lastEditedPricingField: PricingField | null
) => {
	const formData = new FormData(formElement);
	const costPerUnit = numberFromFormData(
		formData,
		"costPerUnit",
		fallback.costPerUnit
	);
	const rawDiscount = numberFromFormData(
		formData,
		"discount",
		fallback.discount
	);
	const rawOfferPrice = numberFromFormData(
		formData,
		"offerPrice",
		fallback.offerPrice
	);
	const discount =
		lastEditedPricingField === "discount"
			? Math.min(Math.max(rawDiscount, 0), 100)
			: calculateDiscount(costPerUnit, rawOfferPrice);
	const offerPrice =
		lastEditedPricingField === "discount"
			? calculateSellingPrice(costPerUnit, discount)
			: rawOfferPrice;

	return {
		additionalNotes: textFromFormData(
			formData,
			"additionalNotes",
			fallback.additionalNotes
		),
		categoryCode: sanitizeCode(
			textFromFormData(formData, "categoryCode", fallback.categoryCode)
		),
		costPerUnit,
		discount,
		name: textFromFormData(formData, "name", fallback.name),
		offerPrice,
		packageQuantity: numberFromFormData(
			formData,
			"packageQuantity",
			fallback.packageQuantity
		),
		packageUnit: fallback.packageUnit,
		packagingType: fallback.packagingType,
		packingCode: textFromFormData(
			formData,
			"packingCode",
			fallback.packingCode
		).replaceAll(/\s+/g, ""),
		productCode: sanitizeCode(
			textFromFormData(formData, "productCode", fallback.productCode)
		),
		quantity: numberFromFormData(formData, "quantity", fallback.quantity),
		skuCode: sanitizeCode(
			textFromFormData(formData, "skuCode", fallback.skuCode)
		),
	} satisfies CreateProductInput;
};

const formatPackageQuantity = (value: number) =>
	Number.isInteger(value)
		? String(value)
		: value.toFixed(3).replace(trailingDecimalZeroPattern, "");

export const buildProductDisplayName = (
	baseName: string,
	packageQuantity: number,
	packageUnit: string
) => {
	const trimmedName = baseName.trim();
	if (!trimmedName) {
		return "";
	}

	return `${trimmedName} | ${formatPackageQuantity(packageQuantity)} ${packageUnit}`;
};
