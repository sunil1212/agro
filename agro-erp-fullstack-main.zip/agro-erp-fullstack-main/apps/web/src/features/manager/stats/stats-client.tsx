"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Card,
	CardContent,
	CardDescription,
	CardHeader,
	CardTitle,
} from "@agro-erp-fullstack/ui/components/card";
import {
	type ChartConfig,
	ChartContainer,
	ChartLegend,
	ChartLegendContent,
	ChartTooltip,
	ChartTooltipContent,
} from "@agro-erp-fullstack/ui/components/chart";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import {
	CalendarRangeIcon,
	DownloadIcon,
	IndianRupeeIcon,
	ShoppingCartIcon,
} from "lucide-react";
import type { Route } from "next";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import {
	Area,
	AreaChart,
	Bar,
	BarChart,
	CartesianGrid,
	XAxis,
	YAxis,
} from "recharts";
import { PageHeader, PageShell, StatusPill } from "@/components/ui-patterns";
import { fetchClientApi } from "@/lib/api-client";
import { authClient } from "@/lib/auth-client";
import { getRoleLabel } from "@/lib/roles";

interface TargetProgress {
	progress: number | null;
	sales: number;
	target: number;
}

interface SalesActorStat {
	dailyProgress: null | TargetProgress;
	dailySalesTarget: null | string;
	email: string;
	id: string;
	monthlyDeliveredCount: number;
	monthlyDeliveredRate: number;
	monthlyProgress: null | TargetProgress;
	monthlyReturnCount: number;
	monthlyReturnRate: number;
	monthlySalesTarget: null | string;
	name: string;
	orderCount: number;
	role: "admin" | "advisor" | "team_leader";
	totalSales: number;
}

interface PeriodStat {
	label: string;
	orders: number;
	sales: number;
}

interface StatusPeriodStat {
	label: string;
	orders: number;
	sales: number;
	status: string;
}

export interface ManagerStatsResponse {
	actors: SalesActorStat[];
	periods: Record<"daily" | "monthly", PeriodStat[]>;
	statuses: Record<"daily" | "monthly", StatusPeriodStat[]>;
	success: true;
	summary: {
		actorCount: number;
		dailySalesTarget?: null | string;
		monthlySalesTarget?: null | string;
		orderCount: number;
		totalSales: number;
	};
}

interface ManagerStatsTrendsResponse {
	periods: Record<"daily" | "monthly", PeriodStat[]>;
	statuses: Record<"daily" | "monthly", StatusPeriodStat[]>;
	success: true;
}

type DatePreset = "today" | "this-month" | "last-30" | "last-90" | "custom";

const currencyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 0,
	style: "currency",
});

const numberFormatter = new Intl.NumberFormat("en-IN");
const percentageFormatter = new Intl.NumberFormat("en-IN", {
	maximumFractionDigits: 1,
	style: "percent",
});

type SalesTrendRange = "90d" | "30d" | "7d";

const salesTrendRangeLabels = {
	"7d": "Last 7 days",
	"30d": "Last 30 days",
	"90d": "Last 3 months",
} satisfies Record<SalesTrendRange, string>;

const datePresetLabels = {
	custom: "Custom range",
	"last-30": "Last 30 days",
	"last-90": "Last 90 days",
	"this-month": "This month",
	today: "Today",
} satisfies Record<DatePreset, string>;

const ALL_FILTER_VALUE = "all";
const ACTOR_TABLE_MIN_ROWS = 10;
const ACTOR_TABLE_PAGE_SIZE_OPTIONS = [10, 25, 50] as const;
const SALES_TREND_AREA_COLOR = "oklch(0.527 0.154 150.069)";
const SALES_TREND_STROKE_COLOR = "oklch(0.39 0.13 150.069)";
const ORDER_STATUSES = [
	"created",
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
	"cancelled",
] as const;
const SALE_STATUSES = new Set([
	"confirmed",
	"dispatched",
	"delivered",
	"return_in_transit",
	"return_in_warehouse",
]);
const STATUS_COLOR_BY_NAME = {
	cancelled: "#b4b8c4",
	confirmed: "#93c5fd",
	created: "#fcd38d",
	delivered: "#86d39e",
	dispatched: "#c4b5fd",
	return_in_transit: "#fca5a5",
	return_in_warehouse: "#f9a8d4",
} as const satisfies Record<(typeof ORDER_STATUSES)[number], string>;

type OrderStatus = (typeof ORDER_STATUSES)[number];

const isOrderStatus = (value: string): value is OrderStatus =>
	ORDER_STATUSES.includes(value as OrderStatus);

const getFilterStatusLabel = (value: string) =>
	value ? formatStatus(value) : "All statuses";

const getDateFromIso = (value: string) => {
	if (!value) {
		return;
	}

	const [year, month, day] = value.split("-").map(Number);
	if (!(year && month && day)) {
		return;
	}

	return new Date(year, month - 1, day);
};

const getIsoFromDate = (date?: Date) => {
	if (!date) {
		return "";
	}

	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
};

const getTrendStartDate = (endDate: Date, timeRange: SalesTrendRange) => {
	const startDate = new Date(endDate);
	startDate.setDate(startDate.getDate() - (getSalesTrendDays(timeRange) - 1));
	return startDate;
};

const getSalesTrendDays = (timeRange: SalesTrendRange) => {
	if (timeRange === "30d") {
		return 30;
	}

	if (timeRange === "7d") {
		return 7;
	}

	return 90;
};

function downloadCsv<T extends object>(fileName: string, rows: T[]): void {
	if (rows.length === 0) {
		return;
	}

	const headers = Object.keys(rows[0] ?? {}) as (keyof T)[];
	const csv = [
		headers.join(","),
		...rows.map((row) =>
			headers
				.map((header) => {
					const value = row[header] ?? "";
					return `"${String(value).replaceAll('"', '""')}"`;
				})
				.join(",")
		),
	].join("\n");
	const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = fileName;
	link.click();
	URL.revokeObjectURL(url);
}

const formatProgress = (progress: null | TargetProgress): string => {
	if (!progress || progress.progress === null) {
		return "No target";
	}

	return `${Math.round(progress.progress * 100)}%`;
};

const formatAmountLeft = (progress: null | TargetProgress): string => {
	if (!progress) {
		return "No target";
	}

	return currencyFormatter.format(
		Math.max(progress.target - progress.sales, 0)
	);
};

const formatPercentage = (rate: number): string =>
	percentageFormatter.format(rate);

function formatStatus(status: string) {
	return status
		.split("_")
		.map((part) => `${part[0]?.toUpperCase() ?? ""}${part.slice(1)}`)
		.join(" ");
}

function formatTarget(
	role: SalesActorStat["role"],
	target: string | null
): string {
	if (role === "admin") {
		return "—";
	}
	if (target === null) {
		return "Not configured";
	}
	return currencyFormatter.format(Number(target));
}

function PeriodExportButton({
	canDownload,
	period,
	rows,
}: {
	canDownload: boolean;
	period: string;
	rows: Record<string, number | string>[];
}) {
	if (!canDownload) {
		return null;
	}

	return (
		<Button
			className="bg-card shadow-sm"
			onClick={() => downloadCsv(`${period}-sales.csv`, rows)}
			size="sm"
			variant="outline"
		>
			<DownloadIcon />
			Export CSV
		</Button>
	);
}

function getGraphExportRows(
	periods: PeriodStat[],
	statuses: StatusPeriodStat[]
) {
	const statusesByDate = statuses.reduce(
		(accumulator, statusEntry) => {
			const dateBucket = accumulator[statusEntry.label] ?? {};
			dateBucket[statusEntry.status] = statusEntry;
			accumulator[statusEntry.label] = dateBucket;
			return accumulator;
		},
		{} as Record<string, Record<string, StatusPeriodStat>>
	);

	return periods.map((period) => {
		const row: Record<string, number | string> = {
			date: period.label,
			ordersCount: period.orders,
			"total sales value": period.sales,
		};

		for (const status of ORDER_STATUSES) {
			const statusLabel = formatStatus(status);
			const statusEntry = statusesByDate[period.label]?.[status];
			row[`${statusLabel} Orders Count`] = statusEntry?.orders ?? 0;
			row[`${statusLabel} Sales Total`] = statusEntry?.sales ?? 0;
		}

		return row;
	});
}

function getActorExportRows(actors: SalesActorStat[]) {
	return actors.map((actor) => ({
		name: actor.name,
		email: actor.email,
		role: getRoleLabel(actor.role),
		orders: actor.orderCount,
		totalSalesForSelectedPeriod: actor.totalSales,
		dailySales: actor.dailyProgress?.sales ?? 0,
		dailyTarget:
			actor.role === "admin" || actor.dailySalesTarget === null
				? ""
				: Number(actor.dailySalesTarget),
		dailyProgress:
			actor.role === "admin" ? "" : formatProgress(actor.dailyProgress),
		monthlySales: actor.monthlyProgress?.sales ?? 0,
		monthlyTarget:
			actor.role === "admin" || actor.monthlySalesTarget === null
				? ""
				: Number(actor.monthlySalesTarget),
		monthlyProgress:
			actor.role === "admin" ? "" : formatProgress(actor.monthlyProgress),
		monthlyDelivered: actor.monthlyDeliveredCount,
		monthlyDeliveredPercentage: formatPercentage(actor.monthlyDeliveredRate),
		monthlyReturns: actor.monthlyReturnCount,
		monthlyReturnPercentage: formatPercentage(actor.monthlyReturnRate),
	}));
}

function SalesActorsExportButton({
	actors,
	canDownload,
}: {
	actors: SalesActorStat[];
	canDownload: boolean;
}) {
	if (!(canDownload && actors.length > 0)) {
		return null;
	}

	return (
		<Button
			className="bg-card shadow-sm"
			onClick={() =>
				downloadCsv("sales-actors.csv", getActorExportRows(actors))
			}
			size="sm"
			variant="outline"
		>
			<DownloadIcon />
			Export CSV
		</Button>
	);
}

function getSessionRole(
	session: ReturnType<typeof authClient.useSession>["data"]
) {
	if (!(session?.user && "role" in session.user)) {
		return "";
	}

	return typeof session.user.role === "string" ? session.user.role : "";
}

function SalesTrendChart({
	canDownload,
	trendApiPath,
}: {
	canDownload: boolean;
	trendApiPath: string;
}) {
	const [timeRange, setTimeRange] = useState<SalesTrendRange>("7d");
	const [periods, setPeriods] = useState<ManagerStatsResponse["periods"]>({
		daily: [],
		monthly: [],
	});
	const [statuses, setStatuses] = useState<ManagerStatsResponse["statuses"]>({
		daily: [],
		monthly: [],
	});
	const [isLoading, setIsLoading] = useState(true);
	const [loadError, setLoadError] = useState("");

	useEffect(() => {
		const params = new URLSearchParams();
		const endDate = new Date();
		const trendStartDate = getTrendStartDate(endDate, timeRange);

		params.set("from", getIsoFromDate(trendStartDate));
		params.set("to", getIsoFromDate(endDate));

		const requestPath = `${trendApiPath}?${params.toString()}`;
		let isCancelled = false;
		setIsLoading(true);
		setLoadError("");

		fetchClientApi<ManagerStatsTrendsResponse>("analytics", requestPath)
			.then((response) => {
				if (isCancelled) {
					return;
				}
				setPeriods(response.periods);
				setStatuses(response.statuses);
			})
			.catch((error: unknown) => {
				if (isCancelled) {
					return;
				}
				setLoadError(
					error instanceof Error ? error.message : "Unable to load sales trends"
				);
			})
			.finally(() => {
				if (isCancelled) {
					return;
				}
				setIsLoading(false);
			});

		return () => {
			isCancelled = true;
		};
	}, [timeRange, trendApiPath]);

	const filteredData = periods.daily;
	const graphExportRows = getGraphExportRows(filteredData, statuses.daily);
	const salesChartConfig = {
		sales: {
			color: SALES_TREND_STROKE_COLOR,
			label: "Sales",
		},
	} satisfies ChartConfig;
	const visibleStatuses = ORDER_STATUSES.filter((status) =>
		statuses.daily.some((entry) => entry.status === status)
	);
	const statusChartConfig = {
		...Object.fromEntries(
			visibleStatuses.map((status) => [
				status,
				{
					color: STATUS_COLOR_BY_NAME[status],
					label: formatStatus(status),
				},
			])
		),
	} satisfies ChartConfig;
	const statusSalesByDay = statuses.daily.reduce(
		(accumulator, entry) => {
			if (!isOrderStatus(entry.status)) {
				return accumulator;
			}
			const bucket = accumulator[entry.label] ?? { label: entry.label };
			bucket[entry.status] = entry.sales;
			accumulator[entry.label] = bucket;
			return accumulator;
		},
		{} as Record<
			string,
			{ label: string } & Partial<Record<OrderStatus, number>>
		>
	);
	const statusChartData = filteredData.map((period) => ({
		label: period.label,
		...Object.fromEntries(
			visibleStatuses.map((status) => [
				status,
				statusSalesByDay[period.label]?.[status] ?? 0,
			])
		),
	}));
	const chartDescription =
		timeRange === "90d"
			? "Total for the last 3 months"
			: salesTrendRangeLabels[timeRange];
	let salesEmptyStateContent = (
		<p className="flex h-72 items-center justify-center text-muted-foreground text-sm">
			No sales activity in this period.
		</p>
	);
	let statusEmptyStateContent = (
		<p className="flex h-72 items-center justify-center text-muted-foreground text-sm">
			No status sales data in this period.
		</p>
	);

	if (isLoading) {
		salesEmptyStateContent = (
			<p className="flex h-72 items-center justify-center text-muted-foreground text-sm">
				Loading sales trends...
			</p>
		);
		statusEmptyStateContent = salesEmptyStateContent;
	} else if (loadError) {
		salesEmptyStateContent = (
			<p className="flex h-72 items-center justify-center text-destructive text-sm">
				{loadError}
			</p>
		);
		statusEmptyStateContent = salesEmptyStateContent;
	}

	let salesChartContent = (
		<ChartContainer
			className="aspect-auto h-[250px] w-full"
			config={salesChartConfig}
		>
			<AreaChart
				accessibilityLayer
				data={filteredData}
				margin={{ left: 8, right: 12 }}
			>
				<defs>
					<linearGradient id="fillSalesTrendSales" x1="0" x2="0" y1="0" y2="1">
						<stop
							offset="5%"
							stopColor={SALES_TREND_AREA_COLOR}
							stopOpacity={0.42}
						/>
						<stop
							offset="95%"
							stopColor={SALES_TREND_AREA_COLOR}
							stopOpacity={0.1}
						/>
					</linearGradient>
				</defs>
				<CartesianGrid vertical={false} />
				<XAxis
					axisLine={false}
					dataKey="label"
					minTickGap={32}
					tickFormatter={(value) =>
						new Date(String(value)).toLocaleDateString("en-US", {
							day: "numeric",
							month: "short",
						})
					}
					tickLine={false}
					tickMargin={8}
				/>
				<YAxis
					axisLine={false}
					domain={[0, "auto"]}
					tickFormatter={(value) => currencyFormatter.format(Number(value))}
					tickLine={false}
					tickMargin={8}
					width={64}
				/>
				<ChartTooltip
					content={
						<ChartTooltipContent
							formatter={(value) => currencyFormatter.format(Number(value))}
							labelFormatter={(value) =>
								new Date(String(value)).toLocaleDateString("en-US", {
									day: "numeric",
									month: "short",
								})
							}
						/>
					}
					cursor={false}
				/>
				<Area
					dataKey="sales"
					fill="url(#fillSalesTrendSales)"
					stroke={SALES_TREND_STROKE_COLOR}
					strokeLinecap="round"
					strokeLinejoin="round"
					strokeWidth={1}
					type="linear"
				/>
			</AreaChart>
		</ChartContainer>
	);
	let statusChartContent = (
		<ChartContainer
			className="aspect-auto h-[320px] w-full"
			config={statusChartConfig}
		>
			<BarChart accessibilityLayer data={statusChartData}>
				<CartesianGrid vertical={false} />
				<XAxis
					axisLine={false}
					dataKey="label"
					tickFormatter={(value) =>
						new Date(String(value)).toLocaleDateString("en-US", {
							day: "numeric",
							month: "short",
						})
					}
					tickLine={false}
					tickMargin={10}
				/>
				<YAxis
					axisLine={false}
					tickFormatter={(value) => currencyFormatter.format(Number(value))}
					tickLine={false}
					tickMargin={8}
				/>
				<ChartTooltip
					content={
						<ChartTooltipContent
							formatter={(value) => currencyFormatter.format(Number(value))}
							hideLabel
						/>
					}
				/>
				<ChartLegend content={<ChartLegendContent />} />
				{visibleStatuses.map((status) => (
					<Bar
						dataKey={status}
						fill={STATUS_COLOR_BY_NAME[status]}
						key={status}
						stackId="status-sales"
					/>
				))}
			</BarChart>
		</ChartContainer>
	);

	if (loadError) {
		salesChartContent = (
			<p className="flex h-[250px] items-center justify-center text-destructive text-sm">
				{loadError}
			</p>
		);
		statusChartContent = (
			<p className="flex h-[250px] items-center justify-center text-destructive text-sm">
				{loadError}
			</p>
		);
	} else if (isLoading) {
		salesChartContent = (
			<p className="flex h-[250px] items-center justify-center text-muted-foreground text-sm">
				Loading sales trends...
			</p>
		);
		statusChartContent = (
			<p className="flex h-[250px] items-center justify-center text-muted-foreground text-sm">
				Loading status sales...
			</p>
		);
	}

	if (filteredData.length === 0) {
		return (
			<section className="-mx-4 space-y-4 px-4 py-6 sm:-mx-6 sm:px-6">
				<PageHeader
					actions={
						<GraphicalAnalyticsActions
							canDownload={canDownload}
							graphExportRows={graphExportRows}
							setTimeRange={setTimeRange}
							timeRange={timeRange}
						/>
					}
					title="Graphical Analytics"
				>
					<p>
						These charts use their own graph range. Report filters above do not
						change this data.
					</p>
				</PageHeader>
				<Card className="@container/card">
					<CardHeader>
						<CardTitle>Sales trends</CardTitle>
						<CardDescription>{chartDescription}</CardDescription>
					</CardHeader>
					<CardContent>{salesEmptyStateContent}</CardContent>
				</Card>
				<Card>
					<CardHeader>
						<CardTitle>Daily sales by status</CardTitle>
						<CardDescription>
							Stacked status-wise sales amounts for each day
						</CardDescription>
					</CardHeader>
					<CardContent>{statusEmptyStateContent}</CardContent>
				</Card>
			</section>
		);
	}

	return (
		<section className="-mx-4 space-y-4 px-4 py-6 sm:-mx-6 sm:px-6">
			<PageHeader
				actions={
					<GraphicalAnalyticsActions
						canDownload={canDownload}
						graphExportRows={graphExportRows}
						setTimeRange={setTimeRange}
						timeRange={timeRange}
					/>
				}
				title="Graphical Analytics"
			>
				<p>
					These charts use their own graph range. Report filters above do not
					change this data.
				</p>
			</PageHeader>
			<Card className="@container/card border-0">
				<CardHeader>
					<CardTitle>Sales trends</CardTitle>
					<CardDescription>
						<span className="@[540px]/card:block hidden">
							{chartDescription}
						</span>
						<span className="@[540px]/card:hidden">{chartDescription}</span>
					</CardDescription>
				</CardHeader>
				<CardContent className="px-2 pt-4 sm:px-6">
					{salesChartContent}
				</CardContent>
			</Card>
			<Card>
				<CardHeader>
					<CardTitle>Daily sales by status</CardTitle>
					<CardDescription>
						Stacked status-wise sales amounts for each day
					</CardDescription>
				</CardHeader>
				<CardContent className="px-2 pt-4 sm:px-6">
					{statusChartContent}
				</CardContent>
			</Card>
		</section>
	);
}

function GraphicalAnalyticsActions({
	canDownload,
	graphExportRows,
	setTimeRange,
	timeRange,
}: {
	canDownload: boolean;
	graphExportRows: Record<string, number | string>[];
	setTimeRange: (value: SalesTrendRange) => void;
	timeRange: SalesTrendRange;
}) {
	return (
		<div className="flex flex-wrap items-center gap-2">
			<SalesTrendRangeControl
				setTimeRange={setTimeRange}
				timeRange={timeRange}
			/>
			<PeriodExportButton
				canDownload={canDownload}
				period={timeRange}
				rows={graphExportRows}
			/>
		</div>
	);
}

function CurrentStatusTotalsCard({
	currentStatusTotals,
}: {
	currentStatusTotals: Array<{ orders: number; sales: number; status: string }>;
}) {
	const shouldSplitStatusTotals = currentStatusTotals.length > 4;
	const statusTotalsMidpoint = Math.ceil(currentStatusTotals.length / 2);
	const statusTotalsColumns = shouldSplitStatusTotals
		? [
				currentStatusTotals.slice(0, statusTotalsMidpoint),
				currentStatusTotals.slice(statusTotalsMidpoint),
			]
		: [currentStatusTotals];

	return (
		<Card className="h-full border-border/70 bg-card shadow-sm">
			<CardContent className="h-full p-0">
				{currentStatusTotals.length === 0 ? (
					<div className="px-6 py-10 text-center text-muted-foreground">
						No orders match these filters.
					</div>
				) : (
					<div
						className={
							shouldSplitStatusTotals
								? "grid gap-0 xl:grid-cols-2"
								: "grid grid-cols-1"
						}
					>
						{statusTotalsColumns.map((column, index) => (
							<div
								className={
									shouldSplitStatusTotals && index === 1
										? "border-border/70 xl:border-l"
										: ""
								}
								key={`status-column-${index}`}
							>
								<Table>
									<TableHeader>
										<TableRow>
											<TableHead>Status</TableHead>
											<TableHead>Orders</TableHead>
											<TableHead>Sales</TableHead>
										</TableRow>
									</TableHeader>
									<TableBody>
										{column.map((entry) => (
											<TableRow key={entry.status}>
												<TableCell>
													<div className="flex items-center gap-3">
														<StatusPill>
															{formatStatus(entry.status)}
														</StatusPill>
														<span className="text-muted-foreground text-xs">
															{SALE_STATUSES.has(entry.status)
																? "Counts toward sales"
																: "Excluded from sales"}
														</span>
													</div>
												</TableCell>
												<TableCell>
													{numberFormatter.format(entry.orders)}
												</TableCell>
												<TableCell>
													{currencyFormatter.format(entry.sales)}
												</TableCell>
											</TableRow>
										))}
									</TableBody>
								</Table>
							</div>
						))}
					</div>
				)}
			</CardContent>
		</Card>
	);
}

function SalesTrendRangeControl({
	setTimeRange,
	timeRange,
}: {
	setTimeRange: (value: SalesTrendRange) => void;
	timeRange: SalesTrendRange;
}) {
	return (
		<div className="inline-flex max-w-full overflow-hidden rounded-lg border border-border/70 bg-card shadow-sm">
			{(Object.keys(salesTrendRangeLabels) as SalesTrendRange[]).map(
				(value) => (
					<Button
						aria-pressed={timeRange === value}
						className="h-9 min-w-0 rounded-none border-border/70 border-r bg-card px-3 text-xs last:border-r-0 sm:px-4 sm:text-sm"
						key={value}
						onClick={() => setTimeRange(value)}
						size="sm"
						type="button"
						variant={timeRange === value ? "secondary" : "ghost"}
					>
						{salesTrendRangeLabels[value]}
					</Button>
				)
			)}
		</div>
	);
}

function SalesActorsTable({
	actors,
	canDownload,
}: {
	actors: SalesActorStat[];
	canDownload: boolean;
}) {
	const [page, setPage] = useState(1);
	const [pageSize, setPageSize] = useState(ACTOR_TABLE_MIN_ROWS);
	const pageCount = Math.max(1, Math.ceil(actors.length / pageSize));
	const safePage = Math.min(page, pageCount);
	const startIndex = (safePage - 1) * pageSize;
	const paginatedActors = actors.slice(startIndex, startIndex + pageSize);
	const fillerRows = Math.max(0, ACTOR_TABLE_MIN_ROWS - paginatedActors.length);

	return (
		<Card>
			<CardContent className="space-y-4">
				<Table>
					<TableHeader>
						<TableRow>
							<TableHead>Actor</TableHead>
							<TableHead>Role</TableHead>
							<TableHead>Orders</TableHead>
							<TableHead>
								<span className="block">Monthly delivered</span>
								<span className="block">count (%)</span>
							</TableHead>
							<TableHead>
								<span className="block">Monthly return</span>
								<span className="block">count (%)</span>
							</TableHead>
							<TableHead>
								<span className="block">Total sales</span>
								<span className="block">for selected period</span>
							</TableHead>
							<TableHead>Daily sales</TableHead>
							<TableHead>Daily target</TableHead>
							<TableHead>Daily progress</TableHead>
							<TableHead>Monthly sales</TableHead>
							<TableHead>Monthly target</TableHead>
							<TableHead>Monthly progress</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{paginatedActors.map((actor) => (
							<TableRow key={actor.id}>
								<TableCell>
									<div>
										<p className="font-medium">{actor.name}</p>
										<p className="text-muted-foreground text-xs">
											{actor.email}
										</p>
									</div>
								</TableCell>
								<TableCell>
									<StatusPill>{getRoleLabel(actor.role)}</StatusPill>
								</TableCell>
								<TableCell>
									{numberFormatter.format(actor.orderCount)}
								</TableCell>
								<TableCell>
									<div className="space-y-1 tabular-nums">
										<div>
											{numberFormatter.format(actor.monthlyDeliveredCount)}
										</div>
										<p className="text-muted-foreground text-xs">
											{formatPercentage(actor.monthlyDeliveredRate)}
										</p>
									</div>
								</TableCell>
								<TableCell>
									<div className="space-y-1 tabular-nums">
										<div>
											{numberFormatter.format(actor.monthlyReturnCount)}
										</div>
										<p className="text-muted-foreground text-xs">
											{formatPercentage(actor.monthlyReturnRate)}
										</p>
									</div>
								</TableCell>
								<TableCell>
									{currencyFormatter.format(actor.totalSales)}
								</TableCell>
								<TableCell>
									{currencyFormatter.format(actor.dailyProgress?.sales ?? 0)}
								</TableCell>
								<TableCell>
									<div className="space-y-1">
										<div>
											{formatTarget(actor.role, actor.dailySalesTarget)}
										</div>
										<p className="text-muted-foreground text-xs">
											Left{" "}
											{actor.role === "admin"
												? "—"
												: formatAmountLeft(actor.dailyProgress)}
										</p>
									</div>
								</TableCell>
								<TableCell>
									{actor.role === "admin" ? (
										"—"
									) : (
										<div className="space-y-1">
											<StatusPill>
												{formatProgress(actor.dailyProgress)}
											</StatusPill>
											<p className="text-muted-foreground text-xs">
												{formatAmountLeft(actor.dailyProgress)} left
											</p>
										</div>
									)}
								</TableCell>
								<TableCell>
									{currencyFormatter.format(actor.monthlyProgress?.sales ?? 0)}
								</TableCell>
								<TableCell>
									<div className="space-y-1">
										<div>
											{formatTarget(actor.role, actor.monthlySalesTarget)}
										</div>
										<p className="text-muted-foreground text-xs">
											Left{" "}
											{actor.role === "admin"
												? "—"
												: formatAmountLeft(actor.monthlyProgress)}
										</p>
									</div>
								</TableCell>
								<TableCell>
									{actor.role === "admin" ? (
										"—"
									) : (
										<div className="space-y-1">
											<StatusPill>
												{formatProgress(actor.monthlyProgress)}
											</StatusPill>
											<p className="text-muted-foreground text-xs">
												{formatAmountLeft(actor.monthlyProgress)} left
											</p>
										</div>
									)}
								</TableCell>
							</TableRow>
						))}
						{actors.length === 0 ? (
							<TableRow>
								<TableCell
									className="h-16 text-center text-muted-foreground"
									colSpan={12}
								>
									No sales actors match these filters.
								</TableCell>
							</TableRow>
						) : null}
						{Array.from({
							length:
								actors.length === 0 ? ACTOR_TABLE_MIN_ROWS - 1 : fillerRows,
						}).map((_, index) => (
							<TableRow
								aria-hidden
								className="hover:bg-transparent"
								key={`actor-filler-${index}`}
							>
								<TableCell className="h-16" colSpan={10}>
									&nbsp;
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
				<div className="grid gap-3 border-t pt-4 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
					<p className="text-muted-foreground text-sm">
						Showing {actors.length === 0 ? 0 : startIndex + 1} to{" "}
						{Math.min(startIndex + paginatedActors.length, actors.length)} of{" "}
						{numberFormatter.format(actors.length)} actors
					</p>
					<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
						<PaginationContent>
							<PaginationItem>
								<PaginationPrevious
									disabled={safePage <= 1}
									onClick={() => setPage((value) => Math.max(1, value - 1))}
									type="button"
								/>
							</PaginationItem>
							<PaginationItem>
								<div className="flex h-9 items-center gap-2 px-2 text-sm">
									<span className="text-muted-foreground">Page</span>
									<Input
										className="h-8 w-16 text-center"
										inputMode="numeric"
										max={pageCount}
										min={1}
										onBlur={() => {
											setPage((value) =>
												Math.min(pageCount, Math.max(1, value))
											);
										}}
										onChange={(event) => {
											const nextPage = Number(event.target.value);
											if (!Number.isInteger(nextPage)) {
												return;
											}

											setPage(Math.min(pageCount, Math.max(1, nextPage)));
										}}
										value={String(safePage)}
									/>
									<span className="text-muted-foreground">of {pageCount}</span>
								</div>
							</PaginationItem>
							<PaginationItem>
								<PaginationNext
									disabled={safePage >= pageCount}
									onClick={() =>
										setPage((value) => Math.min(pageCount, value + 1))
									}
									type="button"
								/>
							</PaginationItem>
						</PaginationContent>
					</Pagination>
					<div className="flex flex-wrap items-center gap-3 lg:justify-end">
						<div className="flex items-center gap-2">
							<span className="text-muted-foreground text-sm">Rows</span>
							<Select
								onValueChange={(value) => {
									setPage(1);
									setPageSize(Number(value));
								}}
								value={String(pageSize)}
							>
								<SelectTrigger className="h-9 w-20">
									<SelectValue>{pageSize}</SelectValue>
								</SelectTrigger>
								<SelectContent align="end">
									{ACTOR_TABLE_PAGE_SIZE_OPTIONS.map((option) => (
										<SelectItem key={option} value={String(option)}>
											{option}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
						<SalesActorsExportButton
							actors={actors}
							canDownload={canDownload}
						/>
					</div>
				</div>
			</CardContent>
		</Card>
	);
}

export function ManagerStatsClient({
	data,
	filterPath = "/stats",
	contextLabel = "Admin",
	trendApiPath = "/trends",
}: {
	data: ManagerStatsResponse;
	filterPath?: string;
	contextLabel?: string;
	trendApiPath?: string;
}) {
	const router = useRouter();
	const searchParams = useSearchParams();
	const { data: session } = authClient.useSession();
	const userRole = getSessionRole(session);
	const canDownload = userRole !== "team_leader";

	const preset =
		(searchParams.get("preset") as DatePreset | null) ?? "this-month";
	const actorId = searchParams.get("actorId") ?? "";
	const statusFilter = searchParams.get("status") ?? "";
	const selectedActor = data.actors.find((actor) => actor.id === actorId);
	const actorFilterLabel = selectedActor
		? `${selectedActor.name} (${getRoleLabel(selectedActor.role)})`
		: "All actors";
	const [customFrom, setCustomFrom] = useState(searchParams.get("from") ?? "");
	const [customTo, setCustomTo] = useState(searchParams.get("to") ?? "");
	const setFilter = useCallback(
		(key: string, value: string | null) => {
			const params = new URLSearchParams(searchParams.toString());
			if (value && value !== ALL_FILTER_VALUE) {
				params.set(key, value);
			} else {
				params.delete(key);
			}
			// Reset the page URL to trigger a server re-fetch.
			const query = params.toString();
			router.push((query ? `${filterPath}?${query}` : filterPath) as Route);
		},
		[filterPath, router, searchParams]
	);

	const clearFilters = useCallback(() => {
		router.push(filterPath as Route);
	}, [filterPath, router]);

	const setDatePreset = useCallback(
		(value: DatePreset) => {
			const params = new URLSearchParams(searchParams.toString());
			params.delete("from");
			params.delete("to");
			if (value === "this-month") {
				params.delete("preset");
			} else {
				params.set("preset", value);
			}
			const query = params.toString();
			router.push((query ? `${filterPath}?${query}` : filterPath) as Route);
		},
		[filterPath, router, searchParams]
	);

	const applyCustomRange = useCallback(() => {
		if (!(customFrom && customTo)) {
			return;
		}

		const params = new URLSearchParams(searchParams.toString());
		params.set("preset", "custom");
		params.set("from", customFrom);
		params.set("to", customTo);
		router.push(`${filterPath}?${params.toString()}` as Route);
	}, [customFrom, customTo, filterPath, router, searchParams]);

	const isFiltered =
		preset !== "this-month" ||
		!!actorId ||
		!!statusFilter ||
		!!searchParams.get("from") ||
		!!searchParams.get("to");

	const visibleActors = actorId
		? data.actors.filter((actor) => actor.id === actorId)
		: data.actors;

	// Current status totals (independent of month grouping).
	const currentStatusTotals = Object.values(
		data.statuses.monthly.reduce(
			(acc, entry) => {
				if (!acc[entry.status]) {
					acc[entry.status] = { orders: 0, sales: 0, status: entry.status };
				}
				acc[entry.status].orders += entry.orders;
				acc[entry.status].sales += entry.sales;
				return acc;
			},
			Object.fromEntries(
				ORDER_STATUSES.map((status) => [
					status,
					{ orders: 0, sales: 0, status },
				])
			) as Record<string, { orders: number; sales: number; status: string }>
		)
	).sort(
		(left, right) =>
			ORDER_STATUSES.indexOf(left.status as (typeof ORDER_STATUSES)[number]) -
			ORDER_STATUSES.indexOf(right.status as (typeof ORDER_STATUSES)[number])
	);

	return (
		<PageShell width="wide">
			<PageHeader eyebrow={contextLabel} title="Sales analytics">
				<p>
					Review branch sales, order lifecycle movement, and advisor target
					progress for the selected period.
				</p>
			</PageHeader>

			<section className="space-y-5">
				<Card className="bg-card shadow-sm">
					<CardContent className="grid gap-5 p-5 lg:grid-cols-[minmax(12rem,18rem)_1fr] lg:items-end">
						<div className="flex items-start gap-3">
							<div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
								<CalendarRangeIcon className="size-4" />
							</div>
							<div className="space-y-1">
								<CardTitle className="text-base">Report filters</CardTitle>
								<p className="text-muted-foreground text-sm">
									Refine period, actor, and lifecycle status for the report
									tables. Graphs use the range control below.
								</p>
							</div>
						</div>

						<div className="flex flex-wrap items-end gap-3 lg:justify-end">
							<div className="space-y-1.5">
								<label
									className="text-muted-foreground text-xs"
									htmlFor="status"
								>
									Status
								</label>
								<Select
									onValueChange={(value) => setFilter("status", value)}
									value={statusFilter || ALL_FILTER_VALUE}
								>
									<SelectTrigger className="h-9 w-40" id="status">
										<SelectValue>
											{getFilterStatusLabel(statusFilter)}
										</SelectValue>
									</SelectTrigger>
									<SelectContent align="start">
										<SelectItem value={ALL_FILTER_VALUE}>
											All statuses
										</SelectItem>
										{ORDER_STATUSES.map((s) => (
											<SelectItem key={s} value={s}>
												{formatStatus(s)}
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-1.5">
								<label
									className="text-muted-foreground text-xs"
									htmlFor="actor"
								>
									Actor
								</label>
								<Select
									onValueChange={(value) => setFilter("actorId", value)}
									value={actorId || ALL_FILTER_VALUE}
								>
									<SelectTrigger
										className="h-9 w-64 max-w-[calc(100vw-3rem)]"
										id="actor"
									>
										<SelectValue>{actorFilterLabel}</SelectValue>
									</SelectTrigger>
									<SelectContent
										align="start"
										className="min-w-72 max-w-[calc(100vw-2rem)]"
									>
										<SelectItem value={ALL_FILTER_VALUE}>All actors</SelectItem>
										{data.actors.map((actor) => (
											<SelectItem key={actor.id} value={actor.id}>
												{actor.name} ({getRoleLabel(actor.role)})
											</SelectItem>
										))}
									</SelectContent>
								</Select>
							</div>

							<div className="space-y-1.5">
								<label
									className="text-muted-foreground text-xs"
									htmlFor="preset"
								>
									Period
								</label>
								<Select
									onValueChange={(value) => setDatePreset(value as DatePreset)}
									value={preset}
								>
									<SelectTrigger className="h-9 w-36" id="preset">
										<SelectValue>{datePresetLabels[preset]}</SelectValue>
									</SelectTrigger>
									<SelectContent align="start">
										<SelectItem value="today">Today</SelectItem>
										<SelectItem value="this-month">This month</SelectItem>
										<SelectItem value="last-30">Last 30 days</SelectItem>
										<SelectItem value="last-90">Last 90 days</SelectItem>
										<SelectItem value="custom">Custom range</SelectItem>
									</SelectContent>
								</Select>
							</div>

							{preset === "custom" ? (
								<>
									<div className="space-y-1.5">
										<label
											className="text-muted-foreground text-xs"
											htmlFor="stats-from"
										>
											From
										</label>
										<DatePicker
											className="h-9 w-40"
											displayFormat="dd/MM/yyyy"
											id="stats-from"
											onChange={(date) => setCustomFrom(getIsoFromDate(date))}
											placeholder="dd/mm/yyyy"
											value={getDateFromIso(customFrom)}
										/>
									</div>
									<div className="space-y-1.5">
										<label
											className="text-muted-foreground text-xs"
											htmlFor="stats-to"
										>
											To
										</label>
										<DatePicker
											className="h-9 w-40"
											displayFormat="dd/MM/yyyy"
											id="stats-to"
											onChange={(date) => setCustomTo(getIsoFromDate(date))}
											placeholder="dd/mm/yyyy"
											value={getDateFromIso(customTo)}
										/>
									</div>
								</>
							) : null}

							<div className="flex items-end gap-2">
								{preset === "custom" ? (
									<Button
										className="h-9"
										disabled={
											!(customFrom && customTo) || customFrom > customTo
										}
										onClick={applyCustomRange}
										size="sm"
										type="button"
									>
										Apply range
									</Button>
								) : null}
								{isFiltered ? (
									<Button
										className="h-9 self-end"
										onClick={clearFilters}
										size="sm"
										variant="ghost"
									>
										Clear filters
									</Button>
								) : null}
							</div>
						</div>
					</CardContent>
				</Card>

				<section className="space-y-4">
					<div className="grid items-stretch gap-4 xl:grid-cols-[280px_minmax(0,1fr)]">
						<div className="grid h-full gap-4 xl:grid-rows-2">
							<MetricStackCard
								icon={<IndianRupeeIcon className="size-4" />}
								label="Total sales for selected period"
								supportingText="Created through delivered orders"
								value={currencyFormatter.format(data.summary.totalSales)}
							/>
							<MetricStackCard
								icon={<ShoppingCartIcon className="size-4" />}
								label="Orders"
								supportingText="All lifecycle statuses in this view"
								value={numberFormatter.format(data.summary.orderCount)}
							/>
						</div>
						<CurrentStatusTotalsCard
							currentStatusTotals={currentStatusTotals}
						/>
					</div>
				</section>

				<section className="space-y-4">
					<SalesActorsTable actors={visibleActors} canDownload={canDownload} />
				</section>
			</section>
			<SalesTrendChart canDownload={canDownload} trendApiPath={trendApiPath} />
		</PageShell>
	);
}

function MetricStackCard({
	icon,
	label,
	supportingText,
	value,
}: {
	icon: React.ReactNode;
	label: string;
	supportingText: string;
	value: string;
}) {
	return (
		<div className="flex h-full min-h-32 flex-col justify-center rounded-2xl border border-border/70 bg-card p-4 shadow-sm">
			<div className="flex items-center gap-2 text-muted-foreground">
				{icon}
				<p className="font-medium text-xs">{label}</p>
			</div>
			<p className="mt-2 font-semibold text-2xl tabular-nums leading-none">
				{value}
			</p>
			<p className="mt-2 text-muted-foreground text-xs">{supportingText}</p>
		</div>
	);
}
