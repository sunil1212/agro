"use client";

import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import type { Route } from "next";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useState } from "react";
import { EmptyState, StatusPill } from "@/components/ui-patterns";
import { CompleteTaskDialog } from "./complete-task-dialog";

export interface FarmerCropTaskItem {
	completedAt: string | null;
	createdAt: string;
	cropName: string;
	cropScheduleEndDay: number;
	cropScheduleStartDay: number;
	farmerCropId: string;
	farmerId: string;
	farmerName: string;
	id: string;
	instruction: string;
	isCompleted: boolean;
	scheduledFor: string;
	taskRemark: string | null;
}

export interface TasksByCategory {
	all: FarmerCropTaskItem[];
	backlog: FarmerCropTaskItem[];
	current: FarmerCropTaskItem[];
}

type TaskCategory = "all" | "backlog" | "current";

const CATEGORIES: { key: TaskCategory; label: string }[] = [
	{ key: "current", label: "Current" },
	{ key: "backlog", label: "Backlog" },
	{ key: "all", label: "All" },
];

const EMPTY_MESSAGES: Record<TaskCategory, string> = {
	current: "All current crop follow-ups are complete. Great work!",
	backlog: "No overdue tasks. Everything is on track.",
	all: "No tasks available yet. They appear after farmers are onboarded with crops.",
};

function CompletionFeedback({ task }: { task: FarmerCropTaskItem }) {
	if (!task.isCompleted) {
		return <span className="text-muted-foreground text-sm">—</span>;
	}

	if (!task.completedAt) {
		return <span className="text-muted-foreground text-sm">-</span>;
	}

	const feedback = task.taskRemark?.trim()
		? task.taskRemark
		: "No feedback added";

	return <span className="text-muted-foreground text-sm">{feedback}</span>;
}

function EmptyCategoryMessage({ category }: { category: TaskCategory }) {
	return <>{EMPTY_MESSAGES[category]}</>;
}

export function TasksClient({
	tasksByCategory,
}: {
	tasksByCategory: TasksByCategory;
}) {
	const searchParams = useSearchParams();
	const router = useRouter();
	const activeCategory = (searchParams.get("category") ??
		"current") as TaskCategory;
	const [completingTask, setCompletingTask] =
		useState<FarmerCropTaskItem | null>(null);

	const visibleTasks = tasksByCategory[activeCategory] ?? [];

	const setCategory = useCallback(
		(category: TaskCategory) => {
			const params = new URLSearchParams(searchParams);
			if (category === "current") {
				params.delete("category");
			} else {
				params.set("category", category);
			}
			const query = params.toString();
			router.push((query ? `?${query}` : window.location.pathname) as Route);
		},
		[router, searchParams]
	);

	const handleCompleted = useCallback(() => {
		setCompletingTask(null);
		router.refresh();
	}, [router]);

	return (
		<>
			<div
				aria-label="Task categories"
				className="flex flex-wrap gap-2"
				role="tablist"
			>
				{CATEGORIES.map(({ key, label }) => {
					const count = tasksByCategory[key].length;
					return (
						<button
							aria-selected={activeCategory === key}
							className={cn(
								"inline-flex h-11 items-center gap-2 rounded-full border px-5 py-2 font-medium text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
								activeCategory === key
									? "border-primary bg-primary text-primary-foreground"
									: "border-border bg-card text-muted-foreground hover:bg-accent hover:text-foreground"
							)}
							key={key}
							onClick={() => setCategory(key)}
							role="tab"
							type="button"
						>
							{label}
							<span
								className={cn(
									"inline-flex size-5 items-center justify-center rounded-full text-xs tabular-nums",
									activeCategory === key
										? "bg-primary-foreground/20 text-primary-foreground"
										: "bg-muted text-muted-foreground"
								)}
							>
								{count}
							</span>
						</button>
					);
				})}
			</div>

			<section className="overflow-hidden rounded-4xl border bg-card shadow-md ring-1 ring-foreground/5">
				<div className="overflow-x-auto">
					<Table>
						<TableHeader>
							<TableRow className="hover:bg-transparent">
								<TableHead>Farmer</TableHead>
								<TableHead>Crop</TableHead>
								<TableHead>Instruction</TableHead>
								<TableHead>Active window</TableHead>
								<TableHead>Status</TableHead>
								<TableHead>Completion feedback</TableHead>
								<TableHead className="w-0">Action</TableHead>
							</TableRow>
						</TableHeader>
						<TableBody>
							{visibleTasks.length > 0 ? (
								visibleTasks.map((task) => (
									<TableRow id={`task-${task.id}`} key={task.id}>
										<TableCell>
											<Link
												className="inline-flex min-h-11 items-center font-medium underline-offset-4 hover:underline"
												href={`/farmers/${task.farmerId}`}
											>
												{task.farmerName}
											</Link>
										</TableCell>
										<TableCell className="min-h-11">{task.cropName}</TableCell>
										<TableCell className="min-h-11 max-w-xs whitespace-normal">
											{task.instruction}
										</TableCell>
										<TableCell className="min-h-11 whitespace-nowrap">
											Day {task.cropScheduleStartDay}–{task.cropScheduleEndDay}
										</TableCell>
										<TableCell className="min-h-11">
											<StatusPill
												tone={task.isCompleted ? "success" : "warning"}
											>
												{task.isCompleted ? "Completed" : "Pending"}
											</StatusPill>
										</TableCell>
										<TableCell className="min-h-11 max-w-48 whitespace-normal">
											<CompletionFeedback task={task} />
										</TableCell>
										<TableCell className="min-h-11">
											{!task.isCompleted && (
												<button
													className="inline-flex h-11 cursor-pointer items-center rounded-xl border border-input bg-background px-4 font-medium text-foreground text-sm transition-colors hover:bg-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
													onClick={() => setCompletingTask(task)}
													type="button"
												>
													Complete task
												</button>
											)}
										</TableCell>
									</TableRow>
								))
							) : (
								<TableRow>
									<TableCell colSpan={7}>
										<EmptyState title="No tasks in this category">
											<EmptyCategoryMessage category={activeCategory} />
										</EmptyState>
									</TableCell>
								</TableRow>
							)}
						</TableBody>
					</Table>
				</div>
			</section>

			{completingTask && (
				<CompleteTaskDialog
					onClose={() => setCompletingTask(null)}
					onCompleted={handleCompleted}
					task={{
						cropName: completingTask.cropName,
						farmerName: completingTask.farmerName,
						id: completingTask.id,
						instruction: completingTask.instruction,
					}}
				/>
			)}
		</>
	);
}
