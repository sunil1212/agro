"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@agro-erp-fullstack/ui/components/dialog";
import { Textarea } from "@agro-erp-fullstack/ui/components/textarea";
import { Loader2Icon } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import { patchClientApi } from "@/lib/api-client";

interface TaskSummary {
	cropName: string;
	farmerName: string;
	id: string;
	instruction: string;
}

interface CompleteTaskResponse {
	success: true;
	task: {
		completedAt: string;
		id: string;
		isCompleted: true;
		taskRemark: string | null;
	};
}

interface CompleteTaskDialogProperties {
	onClose: () => void;
	onCompleted: () => void;
	task: TaskSummary;
}

export function CompleteTaskDialog({
	onClose,
	onCompleted,
	task,
}: CompleteTaskDialogProperties) {
	const router = useRouter();
	const [remark, setRemark] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);

	const submit = async (finalRemark: string | null) => {
		setIsSubmitting(true);
		try {
			await patchClientApi<CompleteTaskResponse>(
				"advisor-tasks",
				`/tasks/${task.id}/complete`,
				{ remark: finalRemark }
			);
			toast.success("Task completed");
			router.refresh();
			onCompleted();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to complete task"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<Dialog onOpenChange={onClose} open>
			<DialogContent>
				<DialogHeader>
					<DialogTitle>Complete task</DialogTitle>
					<DialogDescription>
						{task.farmerName} &mdash; {task.cropName}
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-4">
					<div className="rounded-xl border bg-muted/30 p-3 text-muted-foreground text-sm leading-relaxed">
						{task.instruction}
					</div>

					<div className="space-y-2">
						<label className="font-medium text-sm" htmlFor="completion-remark">
							Feedback{" "}
							<span className="font-normal text-muted-foreground">
								(optional)
							</span>
						</label>
						<Textarea
							disabled={isSubmitting}
							id="completion-remark"
							onChange={(event) => setRemark(event.target.value)}
							placeholder="Notes on how this task was completed…"
							value={remark}
						/>
					</div>
				</div>

				<DialogFooter className="gap-2 sm:gap-0">
					<Button
						disabled={isSubmitting}
						onClick={onClose}
						type="button"
						variant="outline"
					>
						Cancel
					</Button>
					<Button
						disabled={isSubmitting}
						onClick={() => submit(remark.trim() === "" ? null : remark.trim())}
						type="button"
					>
						{isSubmitting ? (
							<>
								<Loader2Icon className="size-4 animate-spin" />
								Completing...
							</>
						) : (
							"Complete with remark"
						)}
					</Button>
					<Button
						disabled={isSubmitting}
						onClick={() => submit(null)}
						type="button"
						variant="secondary"
					>
						{isSubmitting ? (
							<>
								<Loader2Icon className="size-4 animate-spin" />
								Completing...
							</>
						) : (
							"Skip and complete"
						)}
					</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}
