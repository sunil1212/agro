"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { AddFarmerCropDialog } from "./add-farmer-crop-dialog";
import { FarmerCropHistory } from "./farmer-crop-history";
import type { FarmerDetailsResponse } from "./farmer-details-types";
import { FarmerOrderHistory } from "./farmer-order-history";
import { FarmerSummarySection } from "./farmer-summary-section";
import { FarmerTaskPreview } from "./farmer-task-preview";

interface FarmerDetailsClientProperties {
	data: FarmerDetailsResponse;
	farmerId: string;
}

export function FarmerDetailsClient({
	data,
	farmerId,
}: FarmerDetailsClientProperties) {
	const router = useRouter();
	const [showAddCrop, setShowAddCrop] = useState(false);

	return (
		<>
			<div className="grid gap-6 lg:grid-cols-2">
				<FarmerSummarySection farmer={data.farmer} />
				<FarmerTaskPreview
					farmerId={farmerId}
					taskSummary={data.taskSummary}
					tasks={data.tasks}
				/>
			</div>

			<div className="grid gap-6">
				<FarmerCropHistory
					cropHistory={data.cropHistory}
					onAddCrop={() => setShowAddCrop(true)}
				/>

				<FarmerOrderHistory orderHistory={data.orderHistory} />
			</div>

			{showAddCrop ? (
				<AddFarmerCropDialog
					farmerId={farmerId}
					onClose={() => setShowAddCrop(false)}
					onSuccess={() => {
						router.refresh();
					}}
				/>
			) : null}
		</>
	);
}
