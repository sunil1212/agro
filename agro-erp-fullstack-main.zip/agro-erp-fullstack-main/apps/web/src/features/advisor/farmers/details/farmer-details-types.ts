export interface FarmerDetail {
	addressAt: string;
	canViewPhoneNumber: boolean;
	district: string;
	farmSize: string;
	id: string;
	irrigation: string;
	lastOrderDate: string | null;
	name: string;
	nearbyLandmark: string | null;
	pincode: string;
	post: string;
	primaryMobileNumber: string | null;
	secondaryMobileNumber: string | null;
	state: string;
	taluka: string;
}

export interface CropHistoryItem {
	createdAt: string;
	cropId: string;
	cropName: string;
	currentStage: string | null;
	dateOfSowing: string;
	id: string;
	taskCount: number;
}

export interface OrderHistoryItem {
	consignmentNumber: string | null;
	createdAt: string;
	createdByName: string;
	id: string;
	orderId: string | null;
	status: string;
	totalAmount: string;
}

export interface TaskItem {
	completedAt: string | null;
	createdAt: string;
	cropName: string;
	cropScheduleEndDay: number;
	cropScheduleStartDay: number;
	id: string;
	instruction: string;
	isCompleted: boolean;
	scheduledFor: string;
	taskEnd: string;
	taskStart: string;
}

export interface TaskSummary {
	completed: number;
	total: number;
}

export interface FarmerDetailsResponse {
	cropHistory: CropHistoryItem[];
	farmer: FarmerDetail;
	orderHistory: OrderHistoryItem[];
	success: true;
	taskSummary: TaskSummary;
	tasks: TaskItem[];
}
