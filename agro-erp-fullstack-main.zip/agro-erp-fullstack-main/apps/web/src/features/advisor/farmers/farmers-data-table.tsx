"use client";

import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { LiteDebouncer } from "@tanstack/pacer-lite/lite-debouncer";
import { ArrowDownIcon, ArrowUpIcon, SearchIcon } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { StatusPill } from "@/components/ui-patterns";

type FarmerSortKey =
	| "lastOrderDate"
	| "notificationCount"
	| "totalPurchaseToDate";
type SortDirection = "asc" | "desc";
const MIN_VISIBLE_ROWS = 10;

export interface AdvisorFarmerListItem {
	id: string;
	lastOrderDate: string | null;
	name: string;
	notificationCount: number;
	totalPurchaseToDate: string;
}

const formatDate = (value: string | null) =>
	value
		? new Intl.DateTimeFormat("en-IN", {
				day: "2-digit",
				month: "short",
				timeZone: "Asia/Kolkata",
				year: "numeric",
			}).format(new Date(value))
		: "-";

const formatMoney = (value: string) =>
	new Intl.NumberFormat("en-IN", {
		currency: "INR",
		maximumFractionDigits: 2,
		minimumFractionDigits: 2,
		style: "currency",
	}).format(Number(value));

const numericValueByKey = (item: AdvisorFarmerListItem, key: FarmerSortKey) => {
	if (key === "lastOrderDate") {
		return item.lastOrderDate ? new Date(item.lastOrderDate).getTime() : 0;
	}

	if (key === "totalPurchaseToDate") {
		return Number(item.totalPurchaseToDate);
	}

	return item.notificationCount;
};

export function FarmersDataTable({
	farmers,
}: {
	farmers: AdvisorFarmerListItem[];
}) {
	const pageSizeOptions = [5, 10, 20] as const;
	const [searchQuery, setSearchQuery] = useState("");
	const [debouncedQuery, setDebouncedQuery] = useState("");
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] =
		useState<(typeof pageSizeOptions)[number]>(10);
	const [sortBy, setSortBy] = useState<FarmerSortKey>("lastOrderDate");
	const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
	const debouncerRef = useRef<LiteDebouncer<
		(nextValue: string) => void
	> | null>(null);

	if (!debouncerRef.current) {
		debouncerRef.current = new LiteDebouncer(
			(nextValue: string) => setDebouncedQuery(nextValue),
			{ wait: 180 }
		);
	}

	useEffect(
		() => () => {
			debouncerRef.current?.cancel();
		},
		[]
	);

	const normalizedQuery = debouncedQuery.trim().toLowerCase();
	const filteredFarmers = useMemo(
		() =>
			farmers.filter((item) => {
				if (!normalizedQuery) {
					return true;
				}

				return item.name.toLowerCase().includes(normalizedQuery);
			}),
		[farmers, normalizedQuery]
	);

	const sortedFarmers = useMemo(() => {
		const sorted = [...filteredFarmers];

		sorted.sort((firstItem, secondItem) => {
			const firstValue = numericValueByKey(firstItem, sortBy);
			const secondValue = numericValueByKey(secondItem, sortBy);

			if (sortDirection === "asc") {
				return firstValue - secondValue;
			}

			return secondValue - firstValue;
		});

		return sorted;
	}, [filteredFarmers, sortBy, sortDirection]);

	const totalPages = Math.max(1, Math.ceil(sortedFarmers.length / pageSize));
	const safeCurrentPage = Math.min(currentPage, totalPages);
	const pageStartIndex = (safeCurrentPage - 1) * pageSize;
	const paginatedFarmers = sortedFarmers.slice(
		pageStartIndex,
		pageStartIndex + pageSize
	);
	const fillerRows = Math.max(0, MIN_VISIBLE_ROWS - paginatedFarmers.length);

	useEffect(() => {
		if (currentPage > totalPages) {
			setCurrentPage(totalPages);
		}
	}, [currentPage, totalPages]);

	const toggleSort = (nextSortBy: FarmerSortKey) => {
		setCurrentPage(1);
		if (nextSortBy === sortBy) {
			setSortDirection((currentDirection) =>
				currentDirection === "asc" ? "desc" : "asc"
			);
			return;
		}

		setSortBy(nextSortBy);
		setSortDirection("desc");
	};

	const sortIcon = (column: FarmerSortKey) => {
		if (sortBy !== column) {
			return <ArrowDownIcon className="size-3 opacity-30" />;
		}

		return sortDirection === "asc" ? (
			<ArrowUpIcon className="size-3" />
		) : (
			<ArrowDownIcon className="size-3" />
		);
	};

	return (
		<div className="space-y-4">
			<div className="relative w-full max-w-sm">
				<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
				<Input
					className="border-border bg-card pl-9 shadow-sm"
					onChange={(event) => {
						const nextValue = event.target.value;
						setCurrentPage(1);
						setSearchQuery(nextValue);
						debouncerRef.current?.maybeExecute(nextValue);
					}}
					placeholder="Search farmers by name..."
					value={searchQuery}
				/>
			</div>
			<div className="overflow-hidden rounded-4xl border bg-card shadow-md ring-1 ring-foreground/5">
				<Table>
					<TableHeader>
						<TableRow className="hover:bg-transparent">
							<TableHead>Farmer Name</TableHead>
							<TableHead>
								<button
									className="inline-flex items-center gap-1 text-left font-medium"
									onClick={() => toggleSort("lastOrderDate")}
									type="button"
								>
									Last order date
									{sortIcon("lastOrderDate")}
								</button>
							</TableHead>
							<TableHead>
								<button
									className="inline-flex items-center gap-1 text-left font-medium"
									onClick={() => toggleSort("totalPurchaseToDate")}
									type="button"
								>
									Total purchase
									{sortIcon("totalPurchaseToDate")}
								</button>
							</TableHead>
							<TableHead className="text-right">
								<button
									className="inline-flex items-center gap-1 text-right font-medium"
									onClick={() => toggleSort("notificationCount")}
									type="button"
								>
									Tasks
									{sortIcon("notificationCount")}
								</button>
							</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{paginatedFarmers.length > 0 ? (
							paginatedFarmers.map((item) => (
								<TableRow key={item.id}>
									<TableCell>
										<div className="space-y-1">
											<Link
												className="font-medium underline-offset-4 hover:underline"
												href={`/farmers/${item.id}`}
											>
												{item.name}
											</Link>
										</div>
									</TableCell>
									<TableCell className="text-muted-foreground">
										{formatDate(item.lastOrderDate)}
									</TableCell>
									<TableCell className="text-muted-foreground">
										{formatMoney(item.totalPurchaseToDate)}
									</TableCell>
									<TableCell className="text-right">
										<StatusPill>{item.notificationCount}</StatusPill>
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell className="text-muted-foreground" colSpan={4}>
									No farmers match this search.
								</TableCell>
							</TableRow>
						)}
						{Array.from({ length: fillerRows }).map((_, index) => (
							<TableRow
								aria-hidden
								className="hover:bg-transparent"
								key={index}
							>
								<TableCell className="h-16" colSpan={4}>
									&nbsp;
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
				<div className="grid gap-3 border-border/70 border-t bg-muted/20 px-4 py-3 md:grid-cols-[1fr_auto_1fr] md:items-center">
					<div className="text-muted-foreground text-sm">
						{sortedFarmers.length}{" "}
						{sortedFarmers.length === 1 ? "record" : "records"}
					</div>
					<Pagination className="mx-0 w-auto justify-center md:col-start-2">
						<PaginationContent>
							<PaginationItem>
								<PaginationPrevious
									disabled={safeCurrentPage === 1}
									onClick={() =>
										setCurrentPage((page) => Math.max(1, page - 1))
									}
									type="button"
								/>
							</PaginationItem>
							<PaginationItem>
								<div className="flex h-9 items-center gap-2 px-2 text-sm">
									<span className="text-muted-foreground">Page</span>
									<Input
										className="h-8 w-16 text-center"
										inputMode="numeric"
										max={totalPages}
										min={1}
										onBlur={() => {
											setCurrentPage((value) => Math.min(totalPages, value));
										}}
										onChange={(event) => {
											const nextPage = Number(event.target.value);
											if (!Number.isInteger(nextPage)) {
												return;
											}

											setCurrentPage(
												Math.min(totalPages, Math.max(1, nextPage))
											);
										}}
										value={String(safeCurrentPage)}
									/>
									<span className="text-muted-foreground">of {totalPages}</span>
								</div>
							</PaginationItem>
							<PaginationItem>
								<PaginationNext
									disabled={safeCurrentPage === totalPages}
									onClick={() =>
										setCurrentPage((page) => Math.min(totalPages, page + 1))
									}
									type="button"
								/>
							</PaginationItem>
						</PaginationContent>
					</Pagination>
					<div className="flex items-center gap-2 md:justify-end">
						<span className="text-muted-foreground text-sm">Rows per page</span>
						<Select
							onValueChange={(value) => {
								setCurrentPage(1);
								setPageSize(Number(value) as (typeof pageSizeOptions)[number]);
							}}
							value={String(pageSize)}
						>
							<SelectTrigger className="w-20 bg-background">
								<SelectValue />
							</SelectTrigger>
							<SelectContent>
								{pageSizeOptions.map((option) => (
									<SelectItem key={option} value={String(option)}>
										{option}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
					</div>
				</div>
			</div>
		</div>
	);
}
