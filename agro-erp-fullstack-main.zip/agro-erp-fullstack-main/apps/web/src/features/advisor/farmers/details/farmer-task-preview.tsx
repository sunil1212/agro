"use client";

import { Card, CardContent } from "@agro-erp-fullstack/ui/components/card";
import Link from "next/link";
import { StatusPill } from "@/components/ui-patterns";
import type { TaskItem, TaskSummary } from "./farmer-details-types";

interface FarmerTaskPreviewProperties {
	farmerId: string;
	taskSummary: TaskSummary;
	tasks: TaskItem[];
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

export function FarmerTaskPreview({
	farmerId,
	tasks,
	taskSummary,
}: FarmerTaskPreviewProperties) {
	const today = new Intl.DateTimeFormat("en-CA", {
		timeZone: "Asia/Kolkata",
	}).format(new Date());
	const currentTasks = tasks.filter(
		(task) =>
			!task.isCompleted && task.scheduledFor <= today && today <= task.taskEnd
	);
	const backlogTasks = tasks.filter(
		(task) => !task.isCompleted && task.taskEnd < today
	);
	const sorted = [...currentTasks, ...backlogTasks];

	const preview = sorted.slice(0, 5);

	return (
		<Card>
			<CardContent className="space-y-4">
				<div className="flex items-end justify-between">
					<div className="space-y-1">
						<h2 className="font-semibold text-lg leading-tight">Tasks</h2>
						<p className="text-muted-foreground text-sm leading-6">
							{taskSummary.completed} of {taskSummary.total} completed
						</p>
					</div>
					<Link
						className="font-medium text-primary text-sm underline-offset-4 hover:underline"
						href={`/tasks?farmerId=${farmerId}`}
					>
						View all tasks
					</Link>
				</div>

				{preview.length === 0 ? (
					<div className="text-muted-foreground text-sm">
						No tasks for this farmer.
					</div>
				) : (
					<div className="grid gap-2">
						{preview.map((task) => (
							<Link
								className="group block rounded-3xl focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring/30"
								href={`/tasks?category=all&farmerId=${farmerId}&taskId=${task.id}#task-${task.id}`}
								key={task.id}
							>
								<Card size="sm">
									<CardContent className="flex flex-col gap-2 py-2 text-sm transition group-hover:bg-muted/30 sm:flex-row sm:items-center sm:justify-between">
										<div className="min-w-0 space-y-0.5">
											<span className="font-medium">{task.cropName}</span>
											<p className="truncate text-muted-foreground text-xs">
												{task.instruction}
											</p>
										</div>
										<div className="flex shrink-0 items-center gap-2 text-xs">
											<span className="text-muted-foreground">
												Day {task.cropScheduleStartDay}-
												{task.cropScheduleEndDay}
											</span>
											<span className="text-muted-foreground">
												{dateFormatter.format(new Date(task.scheduledFor))}
											</span>
											<StatusPill
												tone={task.taskEnd < today ? "danger" : "warning"}
											>
												{task.taskEnd < today ? "Backlog" : "Current"}
											</StatusPill>
										</div>
									</CardContent>
								</Card>
							</Link>
						))}
					</div>
				)}
			</CardContent>
		</Card>
	);
}
