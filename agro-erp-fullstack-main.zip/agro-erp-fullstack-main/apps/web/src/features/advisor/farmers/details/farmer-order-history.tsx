import { Card, CardContent } from "@agro-erp-fullstack/ui/components/card";
import Link from "next/link";
import { StatusPill } from "@/components/ui-patterns";
import type { OrderHistoryItem } from "./farmer-details-types";

interface FarmerOrderHistoryProperties {
	orderHistory: OrderHistoryItem[];
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	dateStyle: "medium",
	timeStyle: "short",
	timeZone: "Asia/Kolkata",
});
const currencyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 2,
	style: "currency",
});

export function FarmerOrderHistory({
	orderHistory,
}: FarmerOrderHistoryProperties) {
	return (
		<Card className="lg:col-span-2">
			<CardContent className="space-y-4">
				<div className="flex items-end justify-between">
					<div className="space-y-1">
						<h2 className="font-semibold text-lg leading-tight">
							Order history
						</h2>
						<p className="text-muted-foreground text-sm leading-6">
							{orderHistory.length} order
							{orderHistory.length === 1 ? "" : "s"}
						</p>
					</div>
				</div>

				{orderHistory.length === 0 ? (
					<div className="text-muted-foreground text-sm">No orders yet.</div>
				) : (
					<div className="grid gap-3">
						{orderHistory.map((order) => (
							<Link
								className="group block rounded-4xl focus-visible:outline-none focus-visible:ring-3 focus-visible:ring-ring/30"
								href={`/orders/${order.id}`}
								key={order.id}
							>
								<Card size="sm">
									<CardContent className="flex flex-col gap-3 py-1 transition group-hover:bg-muted/30 sm:flex-row sm:items-center sm:justify-between">
										<div className="space-y-1">
											<p className="font-semibold">
												{order.orderId ?? "Pending confirmation"}
											</p>
											<p className="text-muted-foreground text-xs">
												Created by {order.createdByName}
											</p>
										</div>
										<div className="flex flex-wrap items-center gap-3 text-sm">
											{order.consignmentNumber ? (
												<StatusPill>{order.consignmentNumber}</StatusPill>
											) : null}
											<StatusPill>{order.status}</StatusPill>
											<span className="font-medium">
												{currencyFormatter.format(Number(order.totalAmount))}
											</span>
											<span className="text-muted-foreground text-xs">
												{dateFormatter.format(new Date(order.createdAt))}
											</span>
										</div>
									</CardContent>
								</Card>
							</Link>
						))}
					</div>
				)}
			</CardContent>
		</Card>
	);
}
