"use client";

import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { LiteDebouncer } from "@tanstack/pacer-lite/lite-debouncer";
import { SearchIcon } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";

export interface FarmerDirectoryListItem {
	address: string;
	id: string;
	name: string;
	pincode: null | string;
	productName: null | string;
	productSku: null | string;
}

export function FarmersDirectoryDataTable({
	farmers,
}: {
	farmers: FarmerDirectoryListItem[];
}) {
	const pageSizeOptions = [5, 10, 20] as const;
	const [searchQuery, setSearchQuery] = useState("");
	const [debouncedQuery, setDebouncedQuery] = useState("");
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] =
		useState<(typeof pageSizeOptions)[number]>(10);
	const debouncerRef = useRef<LiteDebouncer<
		(nextValue: string) => void
	> | null>(null);

	if (!debouncerRef.current) {
		debouncerRef.current = new LiteDebouncer(
			(nextValue: string) => setDebouncedQuery(nextValue),
			{ wait: 180 }
		);
	}

	useEffect(
		() => () => {
			debouncerRef.current?.cancel();
		},
		[]
	);

	const normalizedQuery = debouncedQuery.trim().toLowerCase();
	const filteredFarmers = useMemo(
		() =>
			farmers.filter((item) => {
				if (!normalizedQuery) {
					return true;
				}

				return (item.pincode ?? "").toLowerCase().includes(normalizedQuery);
			}),
		[farmers, normalizedQuery]
	);

	const totalPages = Math.max(1, Math.ceil(filteredFarmers.length / pageSize));
	const safeCurrentPage = Math.min(currentPage, totalPages);
	const pageStartIndex = (safeCurrentPage - 1) * pageSize;
	const paginatedFarmers = filteredFarmers.slice(
		pageStartIndex,
		pageStartIndex + pageSize
	);
	const fillerRows = Math.max(0, 10 - paginatedFarmers.length);

	useEffect(() => {
		if (currentPage > totalPages) {
			setCurrentPage(totalPages);
		}
	}, [currentPage, totalPages]);

	return (
		<div className="space-y-4">
			<div className="relative w-full max-w-sm">
				<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
				<Input
					className="border-border bg-card pl-9 shadow-sm"
					onChange={(event) => {
						const nextValue = event.target.value;
						setCurrentPage(1);
						setSearchQuery(nextValue);
						debouncerRef.current?.maybeExecute(nextValue);
					}}
					placeholder="Search farmers by pincode..."
					value={searchQuery}
				/>
			</div>
			<div className="overflow-hidden rounded-4xl border bg-card shadow-md ring-1 ring-foreground/5">
				<Table className="table-fixed">
					<TableHeader>
						<TableRow className="hover:bg-transparent">
							<TableHead className="w-[24%]">Farmer name</TableHead>
							<TableHead className="w-[48%]">Farmer address</TableHead>
							<TableHead className="w-[28%]">Product</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{paginatedFarmers.length > 0 ? (
							paginatedFarmers.map((item) => (
								<TableRow key={item.id}>
									<TableCell className="whitespace-normal break-words font-medium">
										{item.name}
									</TableCell>
									<TableCell className="whitespace-normal break-words text-muted-foreground">
										{item.address || "-"}
									</TableCell>
									<TableCell className="whitespace-normal break-words text-muted-foreground">
										{item.productName ?? item.productSku ?? "-"}
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell className="text-muted-foreground" colSpan={3}>
									No farmers match this search.
								</TableCell>
							</TableRow>
						)}
						{Array.from({ length: fillerRows }).map((_, index) => (
							<TableRow
								aria-hidden
								className="hover:bg-transparent"
								key={index}
							>
								<TableCell className="h-16" colSpan={3}>
									&nbsp;
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
				<div className="grid gap-3 border-border/70 border-t bg-muted/20 px-4 py-3 md:grid-cols-[1fr_auto_1fr] md:items-center">
					<div className="text-muted-foreground text-sm">
						{filteredFarmers.length}{" "}
						{filteredFarmers.length === 1 ? "record" : "records"}
					</div>
					<Pagination className="mx-0 w-auto justify-center md:col-start-2">
						<PaginationContent>
							<PaginationItem>
								<PaginationPrevious
									disabled={safeCurrentPage === 1}
									onClick={() =>
										setCurrentPage((page) => Math.max(1, page - 1))
									}
									type="button"
								/>
							</PaginationItem>
							<PaginationItem>
								<div className="flex h-9 items-center gap-2 px-2 text-sm">
									<span className="text-muted-foreground">Page</span>
									<Input
										className="h-8 w-16 text-center"
										inputMode="numeric"
										max={totalPages}
										min={1}
										onBlur={() => {
											setCurrentPage((value) => Math.min(totalPages, value));
										}}
										onChange={(event) => {
											const nextPage = Number(event.target.value);
											if (!Number.isInteger(nextPage)) {
												return;
											}

											setCurrentPage(
												Math.min(totalPages, Math.max(1, nextPage))
											);
										}}
										value={String(safeCurrentPage)}
									/>
									<span className="text-muted-foreground">of {totalPages}</span>
								</div>
							</PaginationItem>
							<PaginationItem>
								<PaginationNext
									disabled={safeCurrentPage === totalPages}
									onClick={() =>
										setCurrentPage((page) => Math.min(totalPages, page + 1))
									}
									type="button"
								/>
							</PaginationItem>
						</PaginationContent>
					</Pagination>
					<div className="flex items-center gap-2 md:justify-end">
						<span className="text-muted-foreground text-sm">Rows per page</span>
						<Select
							onValueChange={(value) => {
								setCurrentPage(1);
								setPageSize(Number(value) as (typeof pageSizeOptions)[number]);
							}}
							value={String(pageSize)}
						>
							<SelectTrigger className="w-20 bg-background">
								<SelectValue />
							</SelectTrigger>
							<SelectContent>
								{pageSizeOptions.map((option) => (
									<SelectItem key={option} value={String(option)}>
										{option}
									</SelectItem>
								))}
							</SelectContent>
						</Select>
					</div>
				</div>
			</div>
		</div>
	);
}
