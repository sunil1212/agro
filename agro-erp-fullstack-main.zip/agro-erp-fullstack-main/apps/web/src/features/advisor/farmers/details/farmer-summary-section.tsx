import { Card, CardContent } from "@agro-erp-fullstack/ui/components/card";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { SectionHeader } from "@/components/ui-patterns";
import type { FarmerDetail } from "./farmer-details-types";

interface FarmerSummarySectionProperties {
	farmer: FarmerDetail;
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	dateStyle: "medium",
	timeStyle: "short",
	timeZone: "Asia/Kolkata",
});

function DetailRow({ label, value }: { label: string; value: string }) {
	return (
		<div className="flex items-baseline justify-between gap-4">
			<span className="shrink-0 text-muted-foreground text-xs uppercase tracking-wider">
				{label}
			</span>
			<span className="text-right font-medium text-sm">{value}</span>
		</div>
	);
}

export function FarmerSummarySection({
	farmer,
}: FarmerSummarySectionProperties) {
	return (
		<Card>
			<CardContent className="space-y-4">
				<SectionHeader title="Summary" />
				<div className="grid gap-3 text-sm">
					<div className="rounded-xl bg-muted/20 p-3 leading-relaxed">
						{farmer.addressAt}
						{farmer.nearbyLandmark ? (
							<>
								<br />
								<span className="text-muted-foreground">
									Near: {farmer.nearbyLandmark}
								</span>
							</>
						) : null}
					</div>

					<div className="grid gap-2.5">
						<DetailRow label="Post" value={farmer.post} />
						<DetailRow label="Taluka" value={farmer.taluka} />
						<DetailRow label="District" value={farmer.district} />
						<DetailRow label="State" value={farmer.state} />
						<DetailRow label="Pincode" value={farmer.pincode} />
					</div>

					<div className={cn("h-px bg-border/60")} />

					<div className="grid gap-2.5">
						<DetailRow
							label="Primary phone"
							value={farmer.primaryMobileNumber ?? "Hidden for this advisor"}
						/>
						<DetailRow
							label="Secondary phone"
							value={
								farmer.canViewPhoneNumber
									? (farmer.secondaryMobileNumber ?? "Not available")
									: "Hidden for this advisor"
							}
						/>
					</div>

					<div className={cn("h-px bg-border/60")} />

					<div className="grid gap-2.5">
						<DetailRow label="Farm size" value={farmer.farmSize} />
						<DetailRow label="Irrigation" value={farmer.irrigation} />
					</div>

					<div className={cn("h-px bg-border/60")} />

					<div className="flex items-baseline justify-between gap-4">
						<span className="shrink-0 text-muted-foreground text-xs uppercase tracking-wider">
							Last order
						</span>
						<span className="text-right font-medium text-sm">
							{farmer.lastOrderDate
								? dateFormatter.format(new Date(farmer.lastOrderDate))
								: "No orders yet"}
						</span>
					</div>
				</div>
			</CardContent>
		</Card>
	);
}
