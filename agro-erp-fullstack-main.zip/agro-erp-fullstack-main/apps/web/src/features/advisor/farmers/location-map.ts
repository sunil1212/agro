/**
 * Re-export shared farmer location data for the advisor farmer form.
 *
 * This module re-exports from the shared db package so that
 * the server and web share exactly one canonical data source.
 */

export type {
	DistrictOption,
	StateOption,
	TalukaOption,
} from "@agro-erp-fullstack/db/data/farmer-locations";
export { FARMER_LOCATION_MAP } from "@agro-erp-fullstack/db/data/farmer-locations";
