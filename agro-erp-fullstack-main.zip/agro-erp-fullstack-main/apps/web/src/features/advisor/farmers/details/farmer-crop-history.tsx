"use client";

import { Card, CardContent } from "@agro-erp-fullstack/ui/components/card";
import { StatusPill } from "@/components/ui-patterns";
import type { CropHistoryItem } from "./farmer-details-types";

interface FarmerCropHistoryProperties {
	cropHistory: CropHistoryItem[];
	onAddCrop: () => void;
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

export function FarmerCropHistory({
	cropHistory,
	onAddCrop,
}: FarmerCropHistoryProperties) {
	const sorted = [...cropHistory].sort(
		(a, b) =>
			new Date(b.dateOfSowing).getTime() - new Date(a.dateOfSowing).getTime()
	);

	return (
		<Card>
			<CardContent className="space-y-4">
				<div className="flex items-end justify-between">
					<div className="space-y-1">
						<h2 className="font-semibold text-lg leading-tight">
							Crop history
						</h2>
						<p className="text-muted-foreground text-sm leading-6">
							{cropHistory.length} sowing{cropHistory.length === 1 ? "" : "s"}{" "}
							recorded
						</p>
					</div>
					<button
						className="font-medium text-primary text-sm underline-offset-4 hover:underline"
						onClick={onAddCrop}
						type="button"
					>
						Add crop
					</button>
				</div>

				{sorted.length === 0 ? (
					<div className="text-muted-foreground text-sm">
						No crops recorded for this farmer.
					</div>
				) : (
					<div className="grid gap-2">
						{sorted.map((entry) => (
							<Card key={entry.id} size="sm">
								<CardContent className="flex flex-col gap-1.5 py-2.5 text-sm">
									<div className="flex items-center justify-between">
										<span className="font-medium">{entry.cropName}</span>
										{entry.currentStage ? (
											<StatusPill>{entry.currentStage}</StatusPill>
										) : null}
									</div>
									<div className="flex items-center gap-3 text-muted-foreground text-xs">
										<span>
											Sown {dateFormatter.format(new Date(entry.dateOfSowing))}
										</span>
										<span aria-hidden>&middot;</span>
										<span>
											Added {dateFormatter.format(new Date(entry.createdAt))}
										</span>
										<span aria-hidden>&middot;</span>
										<span>
											{entry.taskCount} task
											{entry.taskCount === 1 ? "" : "s"}
										</span>
									</div>
								</CardContent>
							</Card>
						))}
					</div>
				)}
			</CardContent>
		</Card>
	);
}
