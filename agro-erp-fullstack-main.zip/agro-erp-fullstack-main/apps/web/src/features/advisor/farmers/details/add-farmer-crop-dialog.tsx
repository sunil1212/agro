"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@agro-erp-fullstack/ui/components/dialog";
import { Label } from "@agro-erp-fullstack/ui/components/label";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import { Loader2Icon, TriangleAlertIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { fetchCrops } from "@/features/crops/actions";
import type { CropSummary } from "@/features/crops/types";
import { postClientApi } from "@/lib/api-client";

interface AddFarmerCropDialogProperties {
	farmerId: string;
	onClose: () => void;
	onSuccess: () => void;
}

interface AddFarmerCropResponse {
	success: true;
}

const formatDateOnly = (date: Date): string => {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");

	return `${year}-${month}-${day}`;
};

export function AddFarmerCropDialog({
	farmerId,
	onClose,
	onSuccess,
}: AddFarmerCropDialogProperties) {
	const router = useRouter();
	const [crops, setCrops] = useState<CropSummary[]>([]);
	const [selectedCropId, setSelectedCropId] = useState("");
	const [sowingDate, setSowingDate] = useState<Date | undefined>(undefined);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [isLoadingCrops, setIsLoadingCrops] = useState(true);
	const [error, setError] = useState("");

	useEffect(() => {
		fetchCrops().then((result) => {
			setIsLoadingCrops(false);
			if (result.success) {
				setCrops(result.crops.filter((c) => c.isActive));
			}
		});
	}, []);

	const activeCrops = crops.filter((c) => c.isActive);
	const selectedCropName = crops.find((c) => c.id === selectedCropId)?.name;
	const duplicateWarning =
		selectedCropId && sowingDate
			? "A farmer may plant the same crop in multiple seasons, but duplicate farmer + crop + sowing date combinations are not allowed."
			: null;

	const handleSubmit = async () => {
		if (!(selectedCropId && sowingDate)) {
			setError("Please select both a crop and a sowing date.");
			return;
		}

		setIsSubmitting(true);
		setError("");

		try {
			await postClientApi<AddFarmerCropResponse>(
				"farmers",
				`/${farmerId}/crops`,
				{
					cropId: selectedCropId,
					dateOfSowing: formatDateOnly(sowingDate),
				}
			);
			toast.success("Crop added to farmer");
			router.refresh();
			onSuccess();
			onClose();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Failed to add crop");
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<Dialog onOpenChange={onClose} open>
			<DialogContent>
				<DialogHeader>
					<DialogTitle>Add crop</DialogTitle>
					<DialogDescription>
						Record a new sowing for this farmer.
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-5">
					<div className="space-y-2">
						<Label htmlFor="crop-select">Crop</Label>
						{isLoadingCrops ? (
							<div className="flex items-center gap-2 text-muted-foreground text-sm">
								<Loader2Icon className="size-4 animate-spin" />
								Loading crops...
							</div>
						) : (
							<Select
								onValueChange={(value) => {
									if (value) {
										setSelectedCropId(value);
										setError("");
									}
								}}
								value={selectedCropId}
							>
								<SelectTrigger className="w-full" id="crop-select">
									<SelectValue placeholder="Select an active crop">
										{selectedCropName}
									</SelectValue>
								</SelectTrigger>
								<SelectContent>
									{activeCrops.length === 0 ? (
										<div className="px-3 py-6 text-center text-muted-foreground text-sm">
											No active crops available.
										</div>
									) : (
										activeCrops.map((crop) => (
											<SelectItem key={crop.id} value={crop.id}>
												{crop.name}
											</SelectItem>
										))
									)}
								</SelectContent>
							</Select>
						)}
					</div>

					<div className="space-y-2">
						<Label htmlFor="sowing-date">Date of sowing</Label>
						<DatePicker
							id="sowing-date"
							onChange={(date) => {
								setSowingDate(date);
								setError("");
							}}
							placeholder="Select sowing date"
							value={sowingDate}
						/>
					</div>

					{error ? (
						<div className="flex items-center gap-2 rounded-xl bg-destructive/10 p-3 text-destructive text-sm">
							<TriangleAlertIcon className="size-4 shrink-0" />
							{error}
						</div>
					) : null}

					{duplicateWarning ? (
						<div className="flex items-start gap-2 rounded-xl bg-amber-500/10 p-3 text-amber-700 text-sm">
							<TriangleAlertIcon className="mt-0.5 size-4 shrink-0" />
							<span>{duplicateWarning}</span>
						</div>
					) : null}
				</div>

				<DialogFooter className="gap-2 sm:gap-0">
					<Button
						disabled={isSubmitting}
						onClick={onClose}
						type="button"
						variant="outline"
					>
						Cancel
					</Button>
					<Button
						disabled={isSubmitting || !selectedCropId || !sowingDate}
						onClick={handleSubmit}
						type="button"
					>
						{isSubmitting ? (
							<>
								<Loader2Icon className="size-4 animate-spin" />
								Adding...
							</>
						) : (
							"Add crop"
						)}
					</Button>
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
}
