"use client";

import {
	Dialog,
	DialogContent,
	DialogTitle,
	DialogTrigger,
} from "@agro-erp-fullstack/ui/components/dialog";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import Image from "next/image";

export function PaymentScreenshotDialog({
	src,
	thumbnailClassName,
	thumbnailSize = 40,
}: {
	src: string;
	thumbnailClassName?: string;
	thumbnailSize?: number;
}) {
	return (
		<Dialog>
			<DialogTrigger
				render={
					<button
						className={cn(
							"relative overflow-hidden border border-border bg-card",
							thumbnailClassName
						)}
						type="button"
					/>
				}
			>
				<Image
					alt="Transaction screenshot thumbnail"
					className="size-full object-cover"
					height={thumbnailSize}
					src={src}
					unoptimized
					width={thumbnailSize}
				/>
			</DialogTrigger>
			<DialogContent className="w-fit max-w-[calc(100vw-2rem)] gap-3 rounded-3xl p-3 shadow-xl sm:max-w-fit [&_[data-slot=dialog-close]]:top-2 [&_[data-slot=dialog-close]]:right-2">
				<DialogTitle className="sr-only">Transaction screenshot</DialogTitle>
				<Image
					alt="Transaction screenshot"
					className="h-[50vh] w-auto max-w-[calc(100vw-3.5rem)] rounded-2xl object-contain"
					height={1000}
					src={src}
					unoptimized
					width={1000}
				/>
			</DialogContent>
		</Dialog>
	);
}
