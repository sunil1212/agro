export interface FarmerOption {
	id: string;
	name: string;
	pincode: string | null;
	primaryMobileNumber: string;
}

export interface ProductOption {
	availableQuantity: number;
	costPerUnit: string;
	dispatchableQuantity: number;
	id: string;
	name: string;
	offerPrice: string;
	quantity: number;
	reservedQuantity: number;
}

export interface OrderOptionsResponse {
	coupons: Array<{
		code: string;
		description: string | null;
		id: string;
		name: string;
	}>;
	farmers: FarmerOption[];
	primaryFarmers: FarmerOption[];
	products: ProductOption[];
	selectedFarmer: FarmerOption | null;
	success: true;
}

export type OrderStep = "farmer" | "products" | "review";
