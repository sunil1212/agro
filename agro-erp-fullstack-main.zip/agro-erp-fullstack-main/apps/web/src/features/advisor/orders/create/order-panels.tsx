"use client";

import {
	Accordion,
	AccordionContent,
	AccordionItem,
	AccordionTrigger,
} from "@agro-erp-fullstack/ui/components/accordion";
import { Button } from "@agro-erp-fullstack/ui/components/button";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
} from "@agro-erp-fullstack/ui/components/select";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import {
	CheckIcon,
	ImagePlusIcon,
	MinusIcon,
	PlusIcon,
	SearchIcon,
	TagIcon,
	TractorIcon,
	Trash2Icon,
} from "lucide-react";
import { useState } from "react";
import { PaymentScreenshotDialog } from "../payment-screenshot-dialog";
import type { FarmerOption, OrderStep, ProductOption } from "./order-types";
import type { OrderDraftItem, PaymentMode } from "./use-order-draft-store";

const currencyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 2,
	minimumFractionDigits: 2,
	style: "currency",
});

export function OrderAccordion({
	activeFarmer,
	activeStep,
	cartCount,
	couponCode,
	expandAll = false,
	allowFarmerSelection,
	lockFarmerSelection = false,
	farmers,
	primaryFarmers,
	reviewItems,
	lineTotalInputValues,
	onAddProduct,
	onCouponCodeChange,
	onLineTotalChange,
	onPaymentScreenshotChange,
	onPaidAmountChange,
	onQuantityChange,
	onRemoveItem,
	onPaymentModeChange,
	onSelectFarmer,
	onStepChange,
	onTransactionUtrChange,
	paidAmount,
	paymentMode,
	products,
	onShippingChargesChange,
	shippingCharges,
	subtotal,
	actualSubtotal,
	totalDiscountGiven,
	transactionScreenshotBase64,
	transactionUtr,
}: {
	activeFarmer: FarmerOption | null;
	activeStep: OrderStep;
	cartCount: number;
	couponCode: string;
	expandAll?: boolean;
	allowFarmerSelection: boolean;
	lockFarmerSelection?: boolean;
	farmers: FarmerOption[];
	primaryFarmers: FarmerOption[];
	reviewItems: Array<
		OrderDraftItem & {
			lineTotal: number;
			maxQuantity: number;
			unitPrice: number;
		}
	>;
	lineTotalInputValues: Record<string, string>;
	onAddProduct: (product: ProductOption) => void;
	onCouponCodeChange: (nextValue: string) => void;
	onLineTotalChange: (productId: string, nextValue: string) => void;
	onPaymentScreenshotChange: (nextValue: string) => void;
	onPaidAmountChange: (nextValue: number) => void;
	onQuantityChange: (productId: string, quantity: number) => void;
	onRemoveItem: (productId: string) => void;
	onPaymentModeChange: (nextValue: PaymentMode) => void;
	onSelectFarmer: (farmerId: string) => void;
	onStepChange: (step: OrderStep) => void;
	onTransactionUtrChange: (nextValue: string) => void;
	paidAmount: number;
	paymentMode: PaymentMode;
	products: ProductOption[];
	onShippingChargesChange: (nextValue: number) => void;
	shippingCharges: number;
	subtotal: number;
	actualSubtotal: number;
	totalDiscountGiven: number;
	transactionScreenshotBase64: string;
	transactionUtr: string;
}) {
	let activeStepValues: OrderStep[];
	if (expandAll) {
		activeStepValues = ["farmer", "review"];
	} else if (lockFarmerSelection) {
		activeStepValues = ["review"];
	} else {
		activeStepValues = [activeStep === "products" ? "review" : activeStep];
	}
	const grandTotal = subtotal + shippingCharges;
	const computedPaidAmount = getComputedPaidAmount(
		paymentMode,
		paidAmount,
		grandTotal
	);
	const totalCodAmount = getTotalCodAmount(
		paymentMode,
		computedPaidAmount,
		grandTotal
	);
	return (
		<Accordion
			className="border-border/70 bg-card shadow-sm"
			multiple={expandAll}
			onValueChange={(value) => {
				if (expandAll) {
					return;
				}
				const nextStep = value[0];
				if (nextStep) {
					onStepChange(nextStep);
				}
			}}
			value={activeStepValues}
		>
			<AccordionItem className="bg-[#fdfcfb]" value="farmer">
				<AccordionTrigger
					className="px-4 py-4 hover:no-underline"
					disabled={lockFarmerSelection}
					onClick={
						lockFarmerSelection ? undefined : () => onStepChange("farmer")
					}
				>
					<SectionHeader
						subtitle={activeFarmer?.name ?? "No farmer selected"}
						title="Farmer selection"
					/>
				</AccordionTrigger>
				<AccordionContent
					className={cn("pt-5", lockFarmerSelection && "hidden")}
				>
					<FarmerPanel
						activeFarmer={activeFarmer}
						allowFarmerSelection={allowFarmerSelection}
						farmers={farmers}
						onContinue={() => onStepChange("review")}
						onSelectFarmer={onSelectFarmer}
						primaryFarmers={primaryFarmers}
					/>
				</AccordionContent>
			</AccordionItem>

			<AccordionItem className="bg-[#fdfcfb]" value="review">
				<AccordionTrigger
					className="px-4 py-4 hover:no-underline"
					onClick={() => onStepChange("review")}
				>
					<SectionHeader
						subtitle={formatMoney(grandTotal)}
						title="Review and checkout"
					/>
				</AccordionTrigger>
				<AccordionContent className="pt-5">
					<ReviewPanel
						activeFarmer={activeFarmer}
						actualSubtotal={actualSubtotal}
						cartCount={cartCount}
						computedPaidAmount={computedPaidAmount}
						couponCode={couponCode}
						items={reviewItems}
						lineTotalInputValues={lineTotalInputValues}
						onAddProduct={onAddProduct}
						onCouponCodeChange={onCouponCodeChange}
						onLineTotalChange={onLineTotalChange}
						onPaidAmountChange={onPaidAmountChange}
						onPaymentModeChange={onPaymentModeChange}
						onPaymentScreenshotChange={onPaymentScreenshotChange}
						onQuantityChange={onQuantityChange}
						onRemoveItem={onRemoveItem}
						onShippingChargesChange={onShippingChargesChange}
						onTransactionUtrChange={onTransactionUtrChange}
						paymentMode={paymentMode}
						products={products}
						shippingCharges={shippingCharges}
						subtotal={subtotal}
						totalCodAmount={totalCodAmount}
						totalDiscountGiven={totalDiscountGiven}
						transactionScreenshotBase64={transactionScreenshotBase64}
						transactionUtr={transactionUtr}
					/>
				</AccordionContent>
			</AccordionItem>
		</Accordion>
	);
}

function FarmerPanel({
	activeFarmer,
	allowFarmerSelection,
	farmers,
	onContinue,
	onSelectFarmer,
	primaryFarmers,
}: {
	activeFarmer: FarmerOption | null;
	allowFarmerSelection: boolean;
	farmers: FarmerOption[];
	onContinue: () => void;
	onSelectFarmer: (farmerId: string) => void;
	primaryFarmers: FarmerOption[];
}) {
	const [query, setQuery] = useState("");
	const [isOpen, setIsOpen] = useState(false);
	const normalizedQuery = query.trim().toLowerCase();
	const filteredFarmers = farmers.filter((farmer) => {
		if (!normalizedQuery) {
			return true;
		}

		return `${farmer.name} ${farmer.primaryMobileNumber}`
			.concat(` ${farmer.pincode ?? ""}`)
			.toLowerCase()
			.includes(normalizedQuery);
	});
	const displayedPrimaryFarmers =
		activeFarmer &&
		!primaryFarmers.some((farmer) => farmer.id === activeFarmer.id)
			? [activeFarmer, ...primaryFarmers]
			: primaryFarmers;

	return (
		<div className="space-y-5 px-4 pb-4">
			<div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_auto]">
				<div className="relative space-y-2">
					<div className="relative">
						<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
						<Input
							className="h-11 pr-4 pl-9"
							onBlur={() => {
								window.setTimeout(() => setIsOpen(false), 120);
							}}
							onChange={(event) => {
								setQuery(event.target.value);
								setIsOpen(true);
							}}
							onFocus={() => setIsOpen(true)}
							placeholder="Search all farmers by name, phone, or pincode"
							readOnly={!allowFarmerSelection}
							value={query}
						/>
					</div>
					{allowFarmerSelection && isOpen ? (
						<div className="absolute top-[calc(100%+0.5rem)] z-20 max-h-80 w-full overflow-y-auto rounded-3xl border border-border/70 bg-background p-2 shadow-lg">
							{filteredFarmers.length === 0 ? (
								<div className="rounded-2xl border border-border/70 border-dashed px-4 py-6 text-center text-muted-foreground text-sm">
									No farmers found.
								</div>
							) : (
								<div className="space-y-1.5">
									{filteredFarmers.map((farmer) => (
										<button
											className="flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-left transition hover:bg-muted/60"
											key={farmer.id}
											onMouseDown={(event) => {
												event.preventDefault();
												onSelectFarmer(farmer.id);
												setQuery("");
												setIsOpen(false);
											}}
											type="button"
										>
											<FarmerAvatar name={farmer.name} />
											<div className="min-w-0">
												<div className="truncate font-medium text-sm">
													{farmer.name}
												</div>
												<div className="text-muted-foreground text-xs">
													{farmer.primaryMobileNumber}
													{farmer.pincode ? ` · ${farmer.pincode}` : ""}
												</div>
											</div>
										</button>
									))}
								</div>
							)}
						</div>
					) : null}
				</div>
				<Button
					className="mt-auto h-11"
					disabled={!(activeFarmer && allowFarmerSelection)}
					onClick={onContinue}
				>
					Continue
				</Button>
			</div>
			<div className="space-y-3">
				<div>
					<h3 className="font-medium text-sm">Your farmers</h3>
					<p className="text-muted-foreground text-xs">
						Farmers created by or assigned to this advisor.
					</p>
				</div>
				{displayedPrimaryFarmers.length === 0 ? (
					<div className="rounded-2xl border border-border/70 border-dashed px-4 py-6 text-center text-muted-foreground text-sm">
						No farmers are assigned yet. Use search to select from the branch
						farmer list.
					</div>
				) : (
					<div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
						{displayedPrimaryFarmers.map((farmer) => {
							const isSelected = farmer.id === activeFarmer?.id;

							return (
								<button
									className={cn(
										"rounded-2xl border bg-card px-3 py-3 text-left shadow-sm transition hover:border-primary/40 hover:bg-muted/40",
										isSelected
											? "border-primary ring-2 ring-primary/15"
											: "border-border/70"
									)}
									disabled={!allowFarmerSelection}
									key={farmer.id}
									onClick={
										allowFarmerSelection
											? () => onSelectFarmer(farmer.id)
											: undefined
									}
									type="button"
								>
									<div className="flex items-start justify-between gap-2">
										<div className="flex min-w-0 items-center gap-2">
											<FarmerAvatar name={farmer.name} />
											<div className="min-w-0">
												<div className="truncate font-semibold text-sm leading-tight">
													{farmer.name}
												</div>
												<div className="truncate text-muted-foreground text-xs leading-tight">
													{farmer.primaryMobileNumber}
													{farmer.pincode ? ` · ${farmer.pincode}` : ""}
												</div>
											</div>
										</div>
										{isSelected ? (
											<div className="flex size-5 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
												<CheckIcon className="size-3.5" />
											</div>
										) : null}
									</div>
								</button>
							);
						})}
					</div>
				)}
			</div>
		</div>
	);
}

function ReviewPanel({
	activeFarmer,
	cartCount,
	computedPaidAmount,
	couponCode,
	items,
	lineTotalInputValues,
	onAddProduct,
	onCouponCodeChange,
	onLineTotalChange,
	onPaymentScreenshotChange,
	onPaidAmountChange,
	onQuantityChange,
	onRemoveItem,
	onPaymentModeChange,
	onTransactionUtrChange,
	paymentMode,
	onShippingChargesChange,
	products,
	shippingCharges,
	subtotal,
	actualSubtotal,
	totalCodAmount,
	totalDiscountGiven,
	transactionScreenshotBase64,
	transactionUtr,
}: {
	activeFarmer: FarmerOption | null;
	cartCount: number;
	computedPaidAmount: number;
	couponCode: string;
	items: Array<
		OrderDraftItem & {
			lineTotal: number;
			maxQuantity: number;
			unitPrice: number;
		}
	>;
	lineTotalInputValues: Record<string, string>;
	onAddProduct: (product: ProductOption) => void;
	onCouponCodeChange: (nextValue: string) => void;
	onLineTotalChange: (productId: string, nextValue: string) => void;
	onPaymentScreenshotChange: (nextValue: string) => void;
	onPaidAmountChange: (nextValue: number) => void;
	onQuantityChange: (productId: string, quantity: number) => void;
	onRemoveItem: (productId: string) => void;
	onPaymentModeChange: (nextValue: PaymentMode) => void;
	onTransactionUtrChange: (nextValue: string) => void;
	paymentMode: PaymentMode;
	onShippingChargesChange: (nextValue: number) => void;
	products: ProductOption[];
	shippingCharges: number;
	subtotal: number;
	actualSubtotal: number;
	totalCodAmount: number;
	totalDiscountGiven: number;
	transactionScreenshotBase64: string;
	transactionUtr: string;
}) {
	return (
		<div className="grid gap-5 px-4 pb-4 xl:grid-cols-[minmax(0,1fr)_360px]">
			<div className="space-y-4">
				<div className="rounded-2xl border border-border/70 bg-background p-4">
					<div className="flex items-start gap-3">
						<div className="flex size-10 items-center justify-center rounded-2xl bg-primary/10 text-primary">
							<TractorIcon className="size-4" />
						</div>
						<div>
							<p className="font-semibold">
								{activeFarmer?.name ?? "No farmer selected"}
							</p>
							<p className="text-muted-foreground text-sm">
								{activeFarmer?.primaryMobileNumber ?? "Select farmer first"}
							</p>
						</div>
					</div>
				</div>
				<ReviewProductSearch
					items={items}
					onAddProduct={onAddProduct}
					products={products}
				/>
				<div className="overflow-x-auto rounded-2xl border border-border/70 bg-background">
					<table className="w-full min-w-[760px] text-sm">
						<thead className="border-border/70 border-b bg-muted/40 text-muted-foreground">
							<tr>
								<th className="px-4 py-3 text-left font-medium">Product</th>
								<th className="px-4 py-3 text-left font-medium">Quantity</th>
								<th className="px-4 py-3 text-left font-medium">Unit price</th>
								<th className="px-4 py-3 text-left font-medium">Line total</th>
								<th className="px-4 py-3 text-right font-medium">Action</th>
							</tr>
						</thead>
						<tbody>
							{items.map((item) => (
								<tr
									className="border-border/70 border-b last:border-b-0"
									key={item.productId}
								>
									<td className="px-4 py-3 font-medium">{item.name}</td>
									<td className="px-4 py-3">
										<div className="flex items-center gap-2">
											<StepperButton
												ariaLabel={`Decrease quantity for ${item.name}`}
												onClick={() =>
													onQuantityChange(
														item.productId,
														Math.max(item.quantity - 1, 0)
													)
												}
											>
												<MinusIcon className="size-4" />
											</StepperButton>
											<Input
												className="h-9 w-16 bg-white text-center"
												inputMode="numeric"
												onChange={(event) =>
													onQuantityChange(
														item.productId,
														clampQuantity(
															Number(event.target.value) || 1,
															item.maxQuantity
														)
													)
												}
												pattern="[0-9]*"
												type="text"
												value={item.quantity}
											/>
											<StepperButton
												ariaLabel={`Increase quantity for ${item.name}`}
												onClick={() =>
													onQuantityChange(
														item.productId,
														clampQuantity(item.quantity + 1, item.maxQuantity)
													)
												}
											>
												<PlusIcon className="size-4" />
											</StepperButton>
										</div>
									</td>
									<td className="px-4 py-3">
										<Input
											aria-label={`Unit price for ${item.name}`}
											className="h-9 w-32"
											readOnly
											value={formatEditableMoney(item.unitPrice)}
										/>
									</td>
									<td className="px-4 py-3">
										<Input
											aria-label={`Line total for ${item.name}`}
											className="h-9 w-36 bg-white"
											inputMode="decimal"
											onChange={(event) =>
												onLineTotalChange(item.productId, event.target.value)
											}
											onFocus={selectInputValue}
											onMouseDown={focusAndSelectIfNeeded}
											pattern="[0-9]*[.]?[0-9]*"
											type="text"
											value={
												lineTotalInputValues[item.productId] ??
												formatEditableMoney(item.lineTotal)
											}
										/>
									</td>
									<td className="px-4 py-3 text-right">
										<Button
											onClick={() => onRemoveItem(item.productId)}
											size="sm"
											variant="destructive"
										>
											Remove
										</Button>
									</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			</div>
			<CheckoutAside
				actualSubtotal={actualSubtotal}
				cartCount={cartCount}
				computedPaidAmount={computedPaidAmount}
				couponCode={couponCode}
				onCouponCodeChange={onCouponCodeChange}
				onPaidAmountChange={onPaidAmountChange}
				onPaymentModeChange={onPaymentModeChange}
				onPaymentScreenshotChange={onPaymentScreenshotChange}
				onShippingChargesChange={onShippingChargesChange}
				onTransactionUtrChange={onTransactionUtrChange}
				paymentMode={paymentMode}
				shippingCharges={shippingCharges}
				subtotal={subtotal}
				totalCodAmount={totalCodAmount}
				totalDiscountGiven={totalDiscountGiven}
				transactionScreenshotBase64={transactionScreenshotBase64}
				transactionUtr={transactionUtr}
			/>
		</div>
	);
}

function ReviewProductSearch({
	items,
	onAddProduct,
	products,
}: {
	items: OrderDraftItem[];
	onAddProduct: (product: ProductOption) => void;
	products: ProductOption[];
}) {
	const [query, setQuery] = useState("");
	const [isOpen, setIsOpen] = useState(false);
	const normalizedQuery = query.trim().toLowerCase();
	const filteredProducts = products.filter((product) => {
		if (!normalizedQuery) {
			return true;
		}

		return `${product.name} ${product.offerPrice} ${product.costPerUnit}`
			.toLowerCase()
			.includes(normalizedQuery);
	});

	return (
		<div className="relative">
			<div className="relative">
				<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
				<Input
					className="h-11 pr-4 pl-9"
					onBlur={() => {
						window.setTimeout(() => setIsOpen(false), 120);
					}}
					onChange={(event) => {
						setQuery(event.target.value);
						setIsOpen(true);
					}}
					onFocus={() => setIsOpen(true)}
					placeholder="Search product"
					value={query}
				/>
			</div>
			{isOpen ? (
				<div className="absolute top-[calc(100%+0.5rem)] z-20 max-h-80 w-full overflow-y-auto rounded-3xl border border-border/70 bg-background p-2 shadow-lg">
					{filteredProducts.length === 0 ? (
						<div className="rounded-2xl border border-border/70 border-dashed px-4 py-6 text-center text-muted-foreground text-sm">
							No products found.
						</div>
					) : (
						<div className="space-y-1.5">
							{filteredProducts.map((product) => {
								const cartItem =
									items.find((item) => item.productId === product.id) ?? null;
								const remainingQuantity = Math.max(
									product.dispatchableQuantity - (cartItem?.quantity ?? 0),
									0
								);
								const unitPrice = Number(
									product.offerPrice || product.costPerUnit
								);

								return (
									<button
										className={cn(
											"flex w-full items-start justify-between gap-3 rounded-2xl px-4 py-3 text-left transition hover:bg-muted/60",
											remainingQuantity <= 0 &&
												"cursor-not-allowed opacity-60 hover:bg-transparent"
										)}
										disabled={remainingQuantity <= 0}
										key={product.id}
										onMouseDown={(event) => {
											event.preventDefault();
											if (remainingQuantity <= 0) {
												return;
											}

											onAddProduct(product);
											setQuery("");
											setIsOpen(false);
										}}
										type="button"
									>
										<div className="min-w-0">
											<div className="truncate font-medium text-sm">
												{product.name}
											</div>
											<div className="mt-1 text-muted-foreground text-xs">
												Unit price {formatMoney(unitPrice)}
											</div>
										</div>
										<StatusPill
											tone={remainingQuantity > 0 ? "success" : "warning"}
										>
											{remainingQuantity > 0
												? `${remainingQuantity} left`
												: "Out"}
										</StatusPill>
									</button>
								);
							})}
						</div>
					)}
				</div>
			) : null}
		</div>
	);
}

function CheckoutAside({
	cartCount,
	computedPaidAmount,
	couponCode,
	onCouponCodeChange,
	onPaymentScreenshotChange,
	onPaidAmountChange,
	onPaymentModeChange,
	onTransactionUtrChange,
	onShippingChargesChange,
	paymentMode,
	shippingCharges,
	subtotal,
	actualSubtotal,
	totalCodAmount,
	totalDiscountGiven,
	transactionScreenshotBase64,
	transactionUtr,
}: {
	cartCount: number;
	computedPaidAmount: number;
	couponCode: string;
	onCouponCodeChange: (nextValue: string) => void;
	onPaymentScreenshotChange: (nextValue: string) => void;
	onPaidAmountChange: (nextValue: number) => void;
	onPaymentModeChange: (nextValue: PaymentMode) => void;
	onTransactionUtrChange: (nextValue: string) => void;
	onShippingChargesChange: (nextValue: number) => void;
	paymentMode: PaymentMode;
	shippingCharges: number;
	subtotal: number;
	actualSubtotal: number;
	totalCodAmount: number;
	totalDiscountGiven: number;
	transactionScreenshotBase64: string;
	transactionUtr: string;
}) {
	const [screenshotInputKey, setScreenshotInputKey] = useState(0);

	const handleScreenshotDelete = () => {
		onPaymentScreenshotChange("");
		setScreenshotInputKey((currentKey) => currentKey + 1);
	};

	return (
		<aside className="xl:sticky xl:top-20 xl:self-start">
			<div className="space-y-4 rounded-2xl border border-border/70 bg-background p-4 shadow-sm">
				<div>
					<h3 className="font-semibold">Checkout</h3>
					<p className="text-muted-foreground text-sm">
						Editable totals and payment details.
					</p>
				</div>
				<div className="rounded-xl border border-border/70 bg-card p-4">
					<SummaryRow label="Items" value={String(cartCount)} />
					<SummaryRow
						label="Original item total"
						value={formatMoney(actualSubtotal)}
					/>
					<SummaryRow label="Subtotal" value={formatMoney(subtotal)} />
					<SummaryRow
						label="Discount given"
						value={formatMoney(totalDiscountGiven)}
					/>
					<SummaryRow
						label="Shipping charges"
						value={formatMoney(shippingCharges)}
					/>
					<SummaryRow
						label="Paid amount"
						value={formatMoney(computedPaidAmount)}
					/>
					<SummaryRow label="COD amount" value={formatMoney(totalCodAmount)} />
					<div className="mt-4 border-border/70 border-t pt-4">
						<div className="text-muted-foreground text-sm">Cart total</div>
						<div className="font-semibold text-2xl">
							{formatMoney(subtotal + shippingCharges)}
						</div>
					</div>
				</div>
				<div className="rounded-xl border border-border/70 bg-card p-4">
					<div className="grid gap-4">
						<div className="grid gap-2">
							<label className="text-muted-foreground text-sm">
								Coupon code
							</label>
							<div className="relative">
								<TagIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
								<Input
									className="h-10 pl-9"
									onChange={(event) => onCouponCodeChange(event.target.value)}
									placeholder="Add coupon code"
									value={couponCode}
								/>
							</div>
						</div>
						<div className="grid gap-2">
							<label className="text-muted-foreground text-sm">
								Shipping charges
							</label>
							<Input
								className="h-10"
								inputMode="numeric"
								onChange={(event) =>
									onShippingChargesChange(parseAmount(event.target.value))
								}
								placeholder="0.00"
								value={shippingCharges}
							/>
						</div>
						<div className="grid gap-2">
							<label className="text-muted-foreground text-sm">
								Payment mode
							</label>
							<Select
								onValueChange={(value) =>
									onPaymentModeChange(value as PaymentMode)
								}
								value={paymentMode}
							>
								<SelectTrigger className="h-10 w-full">
									<span className="truncate">
										{getPaymentModeLabel(paymentMode)}
									</span>
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="cod">COD</SelectItem>
									<SelectItem value="partial_payment">
										Partial Payment
									</SelectItem>
									<SelectItem value="prepaid">Prepaid Payment</SelectItem>
								</SelectContent>
							</Select>
						</div>
						{paymentMode === "partial_payment" ? (
							<div className="grid gap-2">
								<label className="text-muted-foreground text-sm">
									Paid amount
								</label>
								<Input
									className="h-10"
									inputMode="numeric"
									onChange={(event) =>
										onPaidAmountChange(parseAmount(event.target.value))
									}
									placeholder="0.00"
									value={computedPaidAmount}
								/>
							</div>
						) : null}
						{paymentMode === "partial_payment" || paymentMode === "prepaid" ? (
							<>
								<div className="grid gap-2">
									<label className="text-muted-foreground text-sm">
										Transaction UTR
									</label>
									<Input
										className="h-10"
										onChange={(event) =>
											onTransactionUtrChange(event.target.value)
										}
										placeholder="Enter UTR/reference id"
										value={transactionUtr}
									/>
								</div>
								<div className="grid gap-2">
									<label className="text-muted-foreground text-sm">
										Transaction screenshot
									</label>
									{transactionScreenshotBase64 ? (
										<div className="flex items-center gap-3 rounded-3xl border border-border/70 bg-input/50 p-2">
											<PaymentScreenshotDialog
												src={transactionScreenshotBase64}
												thumbnailClassName="size-14 rounded-2xl bg-background"
												thumbnailSize={56}
											/>
											<div className="min-w-0 flex-1">
												<div className="truncate font-medium text-sm">
													Image attached
												</div>
												<div className="text-muted-foreground text-xs">
													Tap preview to open
												</div>
											</div>
											<Button
												aria-label="Remove transaction screenshot"
												className="size-8 rounded-full"
												onClick={handleScreenshotDelete}
												size="icon-xs"
												type="button"
												variant="ghost"
											>
												<Trash2Icon className="size-4 text-destructive" />
											</Button>
										</div>
									) : (
										<label className="flex h-10 cursor-pointer items-center gap-2 rounded-3xl border border-border/70 bg-input/50 px-3 text-muted-foreground text-sm">
											<ImagePlusIcon className="size-4" />
											<span>Upload image</span>
											<input
												accept="image/*"
												className="sr-only"
												key={screenshotInputKey}
												onChange={(event) => {
													const file = event.target.files?.[0];
													if (!file) {
														onPaymentScreenshotChange("");
														return;
													}

													const reader = new FileReader();
													reader.onloadend = () => {
														const result = reader.result;
														onPaymentScreenshotChange(
															typeof result === "string" ? result : ""
														);
													};
													reader.readAsDataURL(file);
												}}
												type="file"
											/>
										</label>
									)}
								</div>
							</>
						) : null}
					</div>
				</div>
				<PaymentBadge paymentMode={paymentMode} />
			</div>
		</aside>
	);
}

function PaymentBadge({ paymentMode }: { paymentMode: PaymentMode }) {
	return (
		<div className="rounded-xl border border-border/70 bg-card px-4 py-3 text-sm shadow-sm">
			<div className="text-muted-foreground">Payment mode</div>
			<div className="font-medium">{getPaymentModeLabel(paymentMode)}</div>
		</div>
	);
}

function getPaymentModeLabel(paymentMode: PaymentMode) {
	if (paymentMode === "cod") {
		return "COD";
	}

	if (paymentMode === "partial_payment") {
		return "Partial Payment";
	}

	return "Prepaid Payment";
}

function SectionHeader({
	subtitle,
	title,
}: {
	subtitle: string;
	title: string;
}) {
	return (
		<div className="space-y-1 text-left">
			<h2 className="font-semibold text-base">{title}</h2>
			<p className="text-muted-foreground text-sm leading-5">{subtitle}</p>
		</div>
	);
}

function SummaryRow({ label, value }: { label: string; value: string }) {
	return (
		<div className="mt-3 flex items-center justify-between gap-4 text-sm first:mt-0">
			<span className="text-muted-foreground">{label}</span>
			<span className="font-medium">{value}</span>
		</div>
	);
}

function StatusPill({
	children,
	tone = "neutral",
}: {
	children: React.ReactNode;
	tone?: "neutral" | "success" | "warning";
}) {
	return (
		<span
			className={cn(
				"inline-flex h-6 min-w-6 items-center justify-center rounded-full px-2 font-medium text-[11px]",
				tone === "success" &&
					"bg-emerald-100 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-300",
				tone === "warning" &&
					"bg-amber-100 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300",
				tone === "neutral" && "bg-muted text-muted-foreground"
			)}
		>
			{children}
		</span>
	);
}

function StepperButton({
	ariaLabel,
	children,
	disabled,
	onClick,
}: {
	ariaLabel: string;
	children: React.ReactNode;
	disabled?: boolean;
	onClick: () => void;
}) {
	return (
		<button
			aria-label={ariaLabel}
			className="flex size-9 items-center justify-center rounded-full border border-border bg-background text-foreground shadow-sm transition hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
			disabled={disabled}
			onClick={onClick}
			type="button"
		>
			{children}
		</button>
	);
}

function focusAndSelectIfNeeded({
	currentTarget,
}: {
	currentTarget: HTMLInputElement;
}) {
	currentTarget.select();
}

function selectInputValue({
	currentTarget,
}: {
	currentTarget: HTMLInputElement;
}) {
	currentTarget.select();
}

export function clampQuantity(value: number, maxQuantity: number) {
	return Math.max(1, Math.min(value, maxQuantity));
}

function formatEditableMoney(value: number) {
	return value.toFixed(2);
}

function formatMoney(value: number) {
	return currencyFormatter.format(value);
}

export function parseAmount(value: string) {
	const sanitizedValue = value.replaceAll(/[^0-9.]/g, "");
	const numericValue = Number(sanitizedValue);
	return Number.isFinite(numericValue) ? numericValue : 0;
}

export function getComputedPaidAmount(
	paymentMode: PaymentMode,
	paidAmount: number,
	grandTotal: number
) {
	if (paymentMode === "prepaid") {
		return grandTotal;
	}

	if (paymentMode === "cod") {
		return 0;
	}

	return Math.max(0, Math.min(paidAmount, grandTotal));
}

function getInitials(name: string) {
	return name
		.split(" ")
		.map((part) => part[0])
		.join("")
		.slice(0, 2)
		.toUpperCase();
}

function FarmerAvatar({ name }: { name: string }) {
	return (
		<div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-secondary font-medium text-[10px] text-secondary-foreground">
			{getInitials(name)}
		</div>
	);
}

function getTotalCodAmount(
	paymentMode: PaymentMode,
	paidAmount: number,
	grandTotal: number
) {
	if (paymentMode === "prepaid") {
		return 0;
	}

	if (paymentMode === "cod") {
		return grandTotal;
	}

	return Math.max(grandTotal - paidAmount, 0);
}
