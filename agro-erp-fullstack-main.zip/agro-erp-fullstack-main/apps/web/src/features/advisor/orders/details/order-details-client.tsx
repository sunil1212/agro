"use client";

import {
	BadgeCheckIcon,
	CalendarDaysIcon,
	Package2Icon,
	ReceiptTextIcon,
	TractorIcon,
	UserRoundIcon,
	WalletCardsIcon,
} from "lucide-react";
import type { ReactNode } from "react";

import { PageHeader, PageShell, StatusPill } from "@/components/ui-patterns";
import { PaymentScreenshotDialog } from "../payment-screenshot-dialog";

interface OrderDetailsClientProps {
	data: {
		canCancel: boolean;
		items: Array<{
			id: string;
			lineTotalAmount: string;
			productName: string;
			productSku: string;
			quantity: number;
			sellingPricePerUnit: string;
			unitPricePerUnit: string;
		}>;
		order: {
			approvedAt: string | null;
			approvedByName: string | null;
			cashbackAmount: string;
			cancelledAt: string | null;
			cancelledByName: string | null;
			consignmentNumber: string | null;
			couponCode: string | null;
			couponDiscountAmount: string;
			createdAt: string;
			createdByName: string;
			estimatedDeliveryTat: string | null;
			farmerMobile: string;
			farmerName: string;
			grandTotalAmount: string;
			id: string;
			orderId: null | string;
			paidAmount: string;
			paymentMode: string;
			pointsDiscountAmount: string;
			pointsUsed: number;
			promoDiscount: string;
			shippingCharges: string;
			status: string;
			subtotalAmount: string;
			totalCodAmount: string;
			totalDiscountAmount: string;
			transactionScreenshotBase64: string | null;
			transactionUtr: string | null;
		};
		success: true;
	};
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

const dateTimeFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	hour: "2-digit",
	minute: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

const moneyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 2,
	minimumFractionDigits: 2,
	style: "currency",
});

export function OrderDetailsClient({ data }: OrderDetailsClientProps) {
	const { order } = data;
	const itemDiscountTotal = data.items.reduce(
		(total, item) => total + getItemDiscount(item),
		0
	);

	return (
		<PageShell className="lg:max-w-[72vw]" width="wide">
			<PageHeader
				actions={
					<div className="flex flex-wrap items-center gap-2">
						<StatusPill tone={getStatusTone(order.status)}>
							{formatStatus(order.status)}
						</StatusPill>
						<StatusPill>{getPaymentModeLabel(order.paymentMode)}</StatusPill>
					</div>
				}
				backHref="/orders"
				eyebrow="Order details"
				title={order.orderId ?? "Pending confirmation"}
			>
				<p>
					Review farmer, payment, item, and checkout details for this order.
				</p>
			</PageHeader>

			<section className="rounded-[2rem] border border-border/70 bg-card p-5 shadow-sm ring-1 ring-foreground/5 sm:p-6">
				<div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-6">
					<InfoTile
						icon={<TractorIcon className="size-4" />}
						label="Farmer Name"
						title={order.farmerName}
						value={order.farmerMobile}
					/>
					<InfoTile
						icon={<UserRoundIcon className="size-4" />}
						label="Created By"
						title={order.createdByName}
						value={dateFormatter.format(new Date(order.createdAt))}
					/>
					<InfoTile
						icon={<WalletCardsIcon className="size-4" />}
						label="Payment Mode"
						title={getPaymentModeLabel(order.paymentMode)}
						value={`Paid ${formatMoney(order.paidAmount)}`}
					/>
					<InfoTile
						icon={<CalendarDaysIcon className="size-4" />}
						label="Delivery TAT"
						title={order.estimatedDeliveryTat ?? "TBD"}
						value="Estimated dispatch window"
					/>
					<InfoTile
						icon={<ReceiptTextIcon className="size-4" />}
						label="Consignment Number"
						title={order.consignmentNumber ?? "Not assigned"}
						value="Assigned when logistics confirms the order"
					/>
					<InfoTile
						icon={<BadgeCheckIcon className="size-4" />}
						label="Order Status"
						title={formatStatus(order.status)}
						value={getStatusHelperText(order.status)}
					/>
					<InfoTile
						icon={<UserRoundIcon className="size-4" />}
						label="Approved By"
						title={order.approvedByName ?? "Not approved"}
						value={
							order.approvedAt
								? dateTimeFormatter.format(new Date(order.approvedAt))
								: "Awaiting approval"
						}
					/>
					<InfoTile
						icon={<CalendarDaysIcon className="size-4" />}
						label="Cancelled By"
						title={order.cancelledByName ?? "No cancellation recorded"}
						value={
							order.cancelledAt
								? dateTimeFormatter.format(new Date(order.cancelledAt))
								: "Not cancelled"
						}
					/>
				</div>
			</section>

			<div className="grid gap-6 lg:grid-cols-[minmax(0,7fr)_minmax(320px,3fr)] lg:items-stretch">
				<section className="flex flex-col rounded-[2rem] border border-border/70 bg-card shadow-sm ring-1 ring-foreground/5">
					<div className="flex items-center justify-between gap-3 px-5 pt-5 pb-4 sm:px-6 sm:pt-6">
						<div>
							<h2 className="font-semibold text-lg">Items</h2>
							<p className="text-muted-foreground text-sm">
								{data.items.length} {data.items.length === 1 ? "item" : "items"}{" "}
								in this order
							</p>
						</div>
						<div className="flex size-10 items-center justify-center rounded-2xl bg-primary/10 text-primary">
							<Package2Icon className="size-5" />
						</div>
					</div>
					<div className="flex-1 overflow-x-auto">
						<table className="w-full min-w-[720px] text-sm">
							<thead className="border-border/70 border-y bg-muted/40 text-muted-foreground">
								<tr>
									<th className="px-5 py-3 text-left font-medium sm:px-6">
										Product
									</th>
									<th className="px-4 py-3 text-left font-medium">Quantity</th>
									<th className="px-4 py-3 text-left font-medium">
										Unit price
									</th>
									<th className="px-4 py-3 text-left font-medium">
										Selling price
									</th>
									<th className="px-4 py-3 text-left font-medium">Discount</th>
									<th className="px-5 py-3 text-right font-medium sm:px-6">
										Total cost
									</th>
								</tr>
							</thead>
							<tbody>
								{data.items.map((item) => (
									<tr
										className="border-border/70 border-b last:border-b-0"
										key={item.id}
									>
										<td className="px-5 py-4 font-medium sm:px-6">
											{item.productName}
										</td>
										<td className="px-4 py-4">
											<StatusPill>{item.quantity}</StatusPill>
										</td>
										<td className="px-4 py-4">
											{formatMoney(item.unitPricePerUnit)}
										</td>
										<td className="px-4 py-4">
											{formatMoney(item.sellingPricePerUnit)}
										</td>
										<td className="px-4 py-4">{formatItemDiscount(item)}</td>
										<td className="px-5 py-4 text-right font-semibold sm:px-6">
											{formatMoney(item.lineTotalAmount)}
										</td>
									</tr>
								))}
							</tbody>
						</table>
					</div>
				</section>

				<aside className="lg:sticky lg:top-20">
					<section className="h-full rounded-[2rem] border border-border/70 bg-card p-5 shadow-sm ring-1 ring-foreground/5">
						<div className="mb-4 flex items-center justify-between gap-3">
							<div>
								<h2 className="font-semibold text-lg">Checkout</h2>
								<p className="text-muted-foreground text-sm">
									Final billing summary
								</p>
							</div>
							<div className="flex size-10 items-center justify-center rounded-2xl bg-primary/10 text-primary">
								<ReceiptTextIcon className="size-5" />
							</div>
						</div>
						<div className="rounded-2xl border border-border/70 bg-background p-4">
							<SummaryRow
								label="Subtotal"
								value={formatMoney(order.subtotalAmount)}
							/>
							<SummaryRow
								label="Promo discount"
								value={formatMoney(order.promoDiscount)}
							/>
							<SummaryRow
								label="Points used"
								value={String(order.pointsUsed)}
							/>
							<SummaryRow
								label="Points discount"
								value={formatMoney(order.pointsDiscountAmount)}
							/>
							<SummaryRow
								label="Coupon discount"
								value={formatMoney(order.couponDiscountAmount)}
							/>
							<SummaryRow
								label="Product discount"
								value={formatMoney(String(itemDiscountTotal))}
							/>
							<SummaryRow
								label="Total discount"
								value={formatMoney(
									String(Number(order.totalDiscountAmount) + itemDiscountTotal)
								)}
							/>
							<SummaryRow
								label="Cashback"
								value={formatMoney(order.cashbackAmount)}
							/>
							<SummaryRow
								label="Shipping"
								value={formatMoney(order.shippingCharges)}
							/>
							<div className="mt-4 border-border/70 border-t pt-4">
								<p className="text-muted-foreground text-sm">Grand total</p>
								<p className="font-semibold text-2xl leading-tight">
									{formatMoney(order.grandTotalAmount)}
								</p>
							</div>
						</div>
						<div className="mt-4 grid gap-3 rounded-2xl border border-border/70 bg-background p-4">
							<SummaryRow label="Paid" value={formatMoney(order.paidAmount)} />
							<SummaryRow
								label="COD"
								value={formatMoney(order.totalCodAmount)}
							/>
							<SummaryRow
								label="Coupon"
								value={order.couponCode ?? "Not applied"}
							/>
							<SummaryRow
								label="UTR"
								value={order.transactionUtr ?? "Not provided"}
							/>
							<div className="mt-3 flex items-center justify-between gap-4 text-sm first:mt-0">
								<span className="text-muted-foreground">Payment proof</span>
								{order.transactionScreenshotBase64 ? (
									<PaymentScreenshotDialog
										src={order.transactionScreenshotBase64}
										thumbnailClassName="size-12 rounded-2xl"
										thumbnailSize={48}
									/>
								) : (
									<span className="text-right font-medium">Not provided</span>
								)}
							</div>
						</div>
					</section>
				</aside>
			</div>
		</PageShell>
	);
}

function InfoTile({
	icon,
	label,
	title,
	value,
}: {
	icon: ReactNode;
	label: string;
	title: string;
	value: string;
}) {
	return (
		<div className="rounded-2xl border border-border/70 bg-background p-4">
			<div className="mb-4 flex items-center justify-between gap-3">
				<p className="text-muted-foreground text-xs uppercase tracking-[0.16em]">
					{label}
				</p>
				<div className="flex size-8 items-center justify-center rounded-full bg-primary/10 text-primary">
					{icon}
				</div>
			</div>
			<p className="truncate font-semibold">{title}</p>
			<p className="mt-1 truncate text-muted-foreground text-sm">{value}</p>
		</div>
	);
}

function SummaryRow({ label, value }: { label: string; value: string }) {
	return (
		<div className="mt-3 flex items-center justify-between gap-4 text-sm first:mt-0">
			<span className="text-muted-foreground">{label}</span>
			<span className="text-right font-medium">{value}</span>
		</div>
	);
}

function formatMoney(value: string) {
	const numericValue = Number(value);
	return Number.isFinite(numericValue)
		? moneyFormatter.format(numericValue)
		: value;
}

function getItemDiscount(item: {
	quantity: number;
	sellingPricePerUnit: string;
	unitPricePerUnit: string;
}): number {
	return (
		Math.max(
			Number(item.unitPricePerUnit) - Number(item.sellingPricePerUnit),
			0
		) * item.quantity
	);
}

function formatItemDiscount(item: {
	quantity: number;
	sellingPricePerUnit: string;
	unitPricePerUnit: string;
}): string {
	const discount = getItemDiscount(item);
	const unitPrice = Number(item.unitPricePerUnit);
	const rate =
		unitPrice > 0
			? Math.max(
					Number(item.unitPricePerUnit) - Number(item.sellingPricePerUnit),
					0
				) / unitPrice
			: 0;
	return discount > 0
		? `${formatMoney(String(discount))} (${Math.round(rate * 100)}%)`
		: "—";
}

function formatStatus(status: string) {
	return status.replaceAll("_", " ");
}

function getPaymentModeLabel(paymentMode: string) {
	if (paymentMode === "cod") {
		return "COD";
	}

	if (paymentMode === "partial_payment") {
		return "Partial Payment";
	}

	if (paymentMode === "prepaid") {
		return "Prepaid Payment";
	}

	return formatStatus(paymentMode);
}

function getStatusTone(status: string) {
	if (status === "delivered") {
		return "success";
	}

	if (
		status === "cancelled" ||
		status === "return_in_transit" ||
		status === "return_in_warehouse"
	) {
		return "danger";
	}

	if (status === "created") {
		return "warning";
	}

	return "neutral";
}

function getStatusHelperText(status: string) {
	if (status === "created") {
		return "Awaiting logistics review";
	}

	if (status === "confirmed") {
		return "Confirmed and awaiting warehouse dispatch";
	}

	if (status === "dispatched") {
		return "Sent from warehouse";
	}

	if (status === "delivered") {
		return "Delivered to farmer";
	}

	if (status === "cancelled") {
		return "Order has been cancelled";
	}

	if (status === "return_in_transit") {
		return "Return is being shipped back";
	}

	if (status === "return_in_warehouse") {
		return "Return has reached the warehouse";
	}

	return "Status updated";
}
