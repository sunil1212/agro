"use client";

import { LiteDebouncer } from "@tanstack/pacer-lite/lite-debouncer";
import type { Route } from "next";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { useOrderEditDraftStore } from "../edit/use-order-edit-draft-store";
import {
	getComputedPaidAmount,
	OrderAccordion,
	parseAmount,
} from "./order-panels";
import type { OrderOptionsResponse, OrderStep } from "./order-types";
import { useOrderDraftStore } from "./use-order-draft-store";

interface CreateSubmitInput {
	farmerId: string;
	items: Array<{
		lineTotalAmount: number;
		productId: string;
		quantity: number;
		sellingPricePerUnit: number;
		unitPricePerUnit: number;
	}>;
	paidAmount?: number;
	paymentMode: "cod" | "partial_payment" | "prepaid";
	shippingCharges: number;
	transactionScreenshotBase64?: string;
	transactionUtr?: string;
}

interface EditSubmitInput {
	farmerId: string;
	items: Array<{
		lineTotalAmount: number;
		productId: string;
		quantity: number;
		sellingPricePerUnit: number;
		unitPricePerUnit: number;
	}>;
	paidAmount?: number;
	paymentMode: "cod" | "partial_payment" | "prepaid";
	shippingCharges: number;
	transactionScreenshotBase64?: string;
	transactionUtr?: string;
}

export type OrderWorkspaceMode =
	| { kind: "create"; onSubmit: (input: CreateSubmitInput) => Promise<void> }
	| {
			kind: "edit";
			initialData: {
				farmerId: string;
				items: Array<{
					costPerUnit: number;
					lineTotalAmount: number;
					name: string;
					productId: string;
					quantity: number;
					unitPricePerUnit: number;
				}>;
				paidAmount: number;
				paymentMode: "cod" | "partial_payment" | "prepaid";
				shippingCharges: number;
				transactionScreenshotBase64: string;
				transactionUtr: string;
			};
			orderId: string;
			onSubmit: (input: EditSubmitInput) => Promise<void>;
			redirectHref?: Route;
	  };

const getSubmitButtonLabel = (
	isSubmitting: boolean,
	mode: OrderWorkspaceMode
): string => {
	if (isSubmitting) {
		return "Saving...";
	}
	return mode.kind === "edit" ? "Save order" : "Confirm order";
};

export function OrderWorkspace({
	data,
	mode,
}: {
	data: OrderOptionsResponse;
	mode: OrderWorkspaceMode;
}) {
	const router = useRouter();
	const [activeStep, setActiveStep] = useState<OrderStep>(
		mode.kind === "edit" ? "review" : "farmer"
	);
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [couponCode, setCouponCode] = useState("");
	const [transactionUtr, setTransactionUtr] = useState("");
	const [transactionScreenshotBase64, setTransactionScreenshotBase64] =
		useState("");
	const [lineTotalInputValues, setLineTotalInputValues] = useState<
		Record<string, string>
	>({});
	const [lineTotalOverrides, setLineTotalOverrides] = useState<
		Record<string, number>
	>({});
	const lineTotalDebouncersRef = useRef<
		Map<string, LiteDebouncer<(nextValue: string) => void>>
	>(new Map());
	const initializedEditOrderIdRef = useRef<string | null>(null);
	const createDraft = useOrderDraftStore();
	const editDraft = useOrderEditDraftStore();
	const {
		addItem,
		farmerId,
		items,
		paidAmount,
		paymentMode,
		removeItem,
		reset,
		setFarmerId,
		setPaidAmount,
		setPaymentMode,
		setShippingCharges,
		shippingCharges,
		updateItemQuantity,
	} = mode.kind === "edit" ? editDraft : createDraft;

	useEffect(() => {
		if (
			mode.kind !== "edit" ||
			initializedEditOrderIdRef.current === mode.orderId
		) {
			return;
		}

		editDraft.reset();
		editDraft.setFarmerId(mode.initialData.farmerId);
		editDraft.setPaidAmount(mode.initialData.paidAmount);
		editDraft.setPaymentMode(mode.initialData.paymentMode);
		editDraft.setShippingCharges(mode.initialData.shippingCharges);
		for (const item of mode.initialData.items) {
			editDraft.addItem({
				costPerUnit: item.costPerUnit,
				lineTotalOverride: item.lineTotalAmount,
				name: item.name,
				productId: item.productId,
				quantity: item.quantity,
				unitPricePerUnit: item.unitPricePerUnit,
			});
		}
		setLineTotalOverrides(
			Object.fromEntries(
				mode.initialData.items.map((item) => [
					item.productId,
					item.lineTotalAmount,
				])
			)
		);
		setTransactionScreenshotBase64(
			mode.initialData.transactionScreenshotBase64
		);
		setTransactionUtr(mode.initialData.transactionUtr);
		initializedEditOrderIdRef.current = mode.orderId;
	}, [editDraft, mode]);

	useEffect(
		() => () => {
			for (const debouncer of lineTotalDebouncersRef.current.values()) {
				debouncer.cancel();
			}
			lineTotalDebouncersRef.current.clear();
		},
		[]
	);

	const activeFarmer =
		data.farmers.find((farmer) => farmer.id === farmerId) ??
		data.selectedFarmer;

	const reviewItems = useMemo(
		() =>
			items.map((item) => {
				const product = data.products.find(
					(entry) => entry.id === item.productId
				);

				return {
					...item,
					lineTotal:
						lineTotalOverrides[item.productId] ??
						item.quantity * item.costPerUnit,
					maxQuantity: product?.dispatchableQuantity ?? item.quantity,
					sellingPrice: item.costPerUnit,
					unitPrice: item.unitPricePerUnit ?? item.costPerUnit,
				};
			}),
		[data.products, items, lineTotalOverrides]
	);

	const subtotal = reviewItems.reduce((sum, item) => sum + item.lineTotal, 0);
	const actualSubtotal = reviewItems.reduce(
		(sum, item) => sum + item.quantity * item.unitPrice,
		0
	);
	const totalDiscountGiven = Math.max(actualSubtotal - subtotal, 0);
	const submitButtonLabel = getSubmitButtonLabel(isSubmitting, mode);

	const onAddProduct = (productId: string) => {
		const product = data.products.find((entry) => entry.id === productId);
		if (!product) {
			return;
		}

		const cartItem = items.find((item) => item.productId === product.id);
		const remainingQuantity = Math.max(
			product.dispatchableQuantity - (cartItem?.quantity ?? 0),
			0
		);

		if (remainingQuantity <= 0) {
			return;
		}

		addItem({
			costPerUnit: Number(product.offerPrice || product.costPerUnit),
			name: product.name,
			productId: product.id,
			quantity: 1,
			unitPricePerUnit: Number(product.costPerUnit),
		});
	};

	const onQuantityChange = (productId: string, nextQuantity: number) => {
		const product = data.products.find((entry) => entry.id === productId);
		const maxQuantity = product?.dispatchableQuantity ?? nextQuantity;
		lineTotalDebouncersRef.current.get(productId)?.cancel();
		lineTotalDebouncersRef.current.delete(productId);
		setLineTotalOverrides((currentOverrides) => {
			if (!(productId in currentOverrides)) {
				return currentOverrides;
			}

			const nextOverrides = { ...currentOverrides };
			delete nextOverrides[productId];
			return nextOverrides;
		});
		setLineTotalInputValues((currentValues) => {
			if (!(productId in currentValues)) {
				return currentValues;
			}

			const nextValues = { ...currentValues };
			delete nextValues[productId];
			return nextValues;
		});
		updateItemQuantity(
			productId,
			Math.max(0, Math.min(nextQuantity, maxQuantity))
		);
	};

	const onLineTotalChange = (productId: string, nextValue: string) => {
		setLineTotalInputValues((currentValues) => ({
			...currentValues,
			[productId]: nextValue,
		}));

		const existingDebouncer = lineTotalDebouncersRef.current.get(productId);
		if (existingDebouncer) {
			existingDebouncer.cancel();
		}

		const nextDebouncer = new LiteDebouncer(
			(value: string) => {
				setLineTotalOverrides((currentOverrides) => ({
					...currentOverrides,
					[productId]: Math.max(0, parseAmount(value)),
				}));
			},
			{ wait: 350 }
		);
		lineTotalDebouncersRef.current.set(productId, nextDebouncer);
		nextDebouncer.maybeExecute(nextValue);
	};

	const submitOrder = async () => {
		if (!farmerId || items.length === 0) {
			return;
		}

		setIsSubmitting(true);

		const orderPayload = {
			farmerId,
			items: items.map((item) => ({
				lineTotalAmount:
					lineTotalOverrides[item.productId] ??
					item.quantity * item.costPerUnit,
				productId: item.productId,
				quantity: item.quantity,
				sellingPricePerUnit: item.costPerUnit,
				unitPricePerUnit: item.unitPricePerUnit ?? item.costPerUnit,
			})),
			paidAmount:
				paymentMode === "partial_payment"
					? getComputedPaidAmount(
							paymentMode,
							paidAmount,
							subtotal + shippingCharges
						)
					: undefined,
			paymentMode,
			shippingCharges,
			transactionScreenshotBase64:
				paymentMode === "cod" ? undefined : transactionScreenshotBase64,
			transactionUtr: paymentMode === "cod" ? undefined : transactionUtr,
		};

		try {
			await mode.onSubmit(orderPayload);

			reset();
			toast.success(mode.kind === "edit" ? "Order saved" : "Order created");

			if (mode.kind === "edit") {
				router.push(mode.redirectHref ?? "/orders/verification");
			} else {
				router.push("/orders");
			}

			router.refresh();
		} catch (error) {
			toast.error(
				error instanceof Error ? error.message : "Failed to save order"
			);
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<div className="space-y-4">
			<OrderAccordion
				activeFarmer={activeFarmer}
				activeStep={activeStep}
				actualSubtotal={actualSubtotal}
				allowFarmerSelection={mode.kind !== "edit"}
				cartCount={items.length}
				couponCode={couponCode}
				farmers={data.farmers}
				lineTotalInputValues={lineTotalInputValues}
				lockFarmerSelection={mode.kind === "edit"}
				onAddProduct={(product) => onAddProduct(product.id)}
				onCouponCodeChange={setCouponCode}
				onLineTotalChange={onLineTotalChange}
				onPaidAmountChange={setPaidAmount}
				onPaymentModeChange={setPaymentMode}
				onPaymentScreenshotChange={setTransactionScreenshotBase64}
				onQuantityChange={onQuantityChange}
				onRemoveItem={removeItem}
				onSelectFarmer={setFarmerId}
				onShippingChargesChange={setShippingCharges}
				onStepChange={setActiveStep}
				onTransactionUtrChange={setTransactionUtr}
				paidAmount={paidAmount}
				paymentMode={paymentMode}
				primaryFarmers={data.primaryFarmers}
				products={data.products}
				reviewItems={reviewItems}
				shippingCharges={shippingCharges}
				subtotal={subtotal}
				totalDiscountGiven={totalDiscountGiven}
				transactionScreenshotBase64={transactionScreenshotBase64}
				transactionUtr={transactionUtr}
			/>
			<div className="flex justify-end">
				<button
					className="rounded-full bg-primary px-5 py-2 font-medium text-primary-foreground text-sm transition hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
					disabled={isSubmitting || items.length === 0}
					onClick={submitOrder}
					type="button"
				>
					{submitButtonLabel}
				</button>
			</div>
		</div>
	);
}
