"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuGroup,
	DropdownMenuItem,
	DropdownMenuLabel,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from "@agro-erp-fullstack/ui/components/dropdown-menu";
import { Input } from "@agro-erp-fullstack/ui/components/input";
import {
	Pagination,
	PaginationContent,
	PaginationItem,
	PaginationNext,
	PaginationPrevious,
} from "@agro-erp-fullstack/ui/components/pagination";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@agro-erp-fullstack/ui/components/select";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import {
	ArrowDownIcon,
	ArrowUpDownIcon,
	ArrowUpIcon,
	DownloadIcon,
	MoreHorizontalIcon,
	PencilIcon,
	SearchIcon,
} from "lucide-react";
import type { Route } from "next";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { StatusPill } from "@/components/ui-patterns";
import { authClient } from "@/lib/auth-client";
import { PaymentScreenshotDialog } from "./payment-screenshot-dialog";

type OrderSortKey =
	| "advisorName"
	| "createdAt"
	| "orderId"
	| "status"
	| "totalAmount";
type SortDirection = "asc" | "desc";
type OrderStatusFilter = "all" | string;

export interface AdvisorOrderListItem {
	advisorName?: string;
	cancelledReason?: null | string;
	consignmentNumber: null | string;
	createdAt: string;
	farmerName: string;
	id: string;
	orderId: null | string;
	status: string;
	totalAmount: null | string;
	transactionScreenshotBase64: string | null;
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

const moneyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 0,
	minimumFractionDigits: 0,
	style: "currency",
});

const formatOrderStatus = (status: string) => status.replaceAll("_", " ");
const editableTeamLeaderOrderStatuses = new Set(["created"]);
const ORDER_TABLE_MIN_ROWS = 10;
const wrappingCellClassName = "whitespace-normal break-words text-wrap";
const wrappingHeadClassName = "whitespace-normal break-words text-wrap";
const csvValueEscapePattern = /[",\n\r]/;

const formatDateOnly = (date: Date): string => {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
};

const sanitizeFileSegment = (value: string) =>
	value
		.trim()
		.toLowerCase()
		.replaceAll(/[^a-z0-9_-]+/g, "_")
		.replaceAll(/^_+|_+$/g, "");

const getDefaultExportFileName = (
	adminFirstName: string,
	fromDate?: Date,
	toDate?: Date
) => {
	const name = sanitizeFileSegment(adminFirstName) || "admin";
	if (!(fromDate && toDate)) {
		return `${name}_orders_export.csv`;
	}

	return `${name}_orders_export_${formatDateOnly(fromDate)}_${formatDateOnly(toDate)}.csv`;
};

const escapeCsvValue = (value: null | number | string) => {
	const text = value === null ? "" : String(value);
	if (!csvValueEscapePattern.test(text)) {
		return text;
	}

	return `"${text.replaceAll('"', '""')}"`;
};

const downloadCsv = (fileName: string, rows: AdvisorOrderListItem[]) => {
	const headers = [
		"Order ID",
		"Advisor",
		"Farmer",
		"Status",
		"Total",
		"Date",
		"Consignment",
	];
	const csvRows = [
		headers,
		...rows.map((order) => [
			order.orderId ?? "Pending confirmation",
			order.advisorName ?? "",
			order.farmerName,
			formatOrderStatus(order.status),
			order.totalAmount ?? "0",
			new Date(order.createdAt).toISOString(),
			order.consignmentNumber ?? "",
		]),
	];
	const csv = `\uFEFF${csvRows
		.map((row) => row.map(escapeCsvValue).join(","))
		.join("\n")}`;
	const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
	const objectUrl = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = objectUrl;
	link.download = fileName;
	link.click();
	URL.revokeObjectURL(objectUrl);
};

const startOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(0, 0, 0, 0);
	return nextDate;
};

const endOfDay = (date: Date) => {
	const nextDate = new Date(date);
	nextDate.setHours(23, 59, 59, 999);
	return nextDate;
};

const sortValue = (item: AdvisorOrderListItem, key: OrderSortKey) => {
	if (key === "createdAt") {
		return new Date(item.createdAt).getTime();
	}

	if (key === "totalAmount") {
		return Number(item.totalAmount ?? 0);
	}

	if (key === "status") {
		return item.status;
	}

	if (key === "advisorName") {
		return item.advisorName ?? "";
	}

	return item.orderId ?? "";
};

const getOrderStatusBadgeClasses = (status: string) => {
	if (status === "delivered") {
		return "border-emerald-300 bg-emerald-100 text-emerald-800";
	}

	if (
		status === "cancelled" ||
		status === "return_in_transit" ||
		status === "return_in_warehouse"
	) {
		return "border-rose-300 bg-rose-100 text-rose-800";
	}

	if (status === "created") {
		return "border-amber-300 bg-amber-100 text-amber-800";
	}

	if (status === "confirmed") {
		return "border-sky-300 bg-sky-100 text-sky-800";
	}

	if (status === "dispatched") {
		return "border-indigo-300 bg-indigo-100 text-indigo-800";
	}

	return "border-border bg-muted text-foreground";
};

function OrderActionsMenu({ order }: { order: AdvisorOrderListItem }) {
	const router = useRouter();
	const canEditOrder = editableTeamLeaderOrderStatuses.has(order.status);
	const editHref = `/orders/${order.id}/edit` as Route;

	if (!canEditOrder) {
		return (
			<Button
				aria-label="Order actions unavailable"
				disabled
				size="icon"
				title="Only created orders can be edited"
				variant="ghost"
			>
				<MoreHorizontalIcon className="size-4" />
			</Button>
		);
	}

	return (
		<DropdownMenu>
			<DropdownMenuTrigger
				render={
					<Button size="icon" title="Open order actions" variant="ghost" />
				}
			>
				<MoreHorizontalIcon className="size-4" />
			</DropdownMenuTrigger>
			<DropdownMenuContent align="end" className="bg-card">
				<DropdownMenuGroup>
					<DropdownMenuLabel className="px-2 py-1.5">Actions</DropdownMenuLabel>
					<DropdownMenuSeparator />
					<DropdownMenuItem onClick={() => router.push(editHref)}>
						<PencilIcon className="size-4" />
						Edit order
					</DropdownMenuItem>
				</DropdownMenuGroup>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}

function OrderTableRow({
	canEditOrders,
	order,
	showActionsColumn,
	showAdvisorColumn,
}: {
	canEditOrders: boolean;
	order: AdvisorOrderListItem;
	showActionsColumn: boolean;
	showAdvisorColumn: boolean;
}) {
	return (
		<TableRow>
			<TableCell
				className={`${wrappingCellClassName} w-[180px] min-w-[180px] max-w-[180px]`}
			>
				<Link
					className="block max-w-full break-words font-medium underline-offset-4 hover:underline"
					href={`/orders/${order.id}`}
				>
					{order.orderId ?? "Pending confirmation"}
				</Link>
			</TableCell>
			{showAdvisorColumn ? (
				<TableCell
					className={`${wrappingCellClassName} max-w-full text-muted-foreground`}
				>
					{order.advisorName ?? "—"}
				</TableCell>
			) : null}
			<TableCell
				className={`${wrappingCellClassName} max-w-full text-muted-foreground`}
			>
				{order.farmerName}
			</TableCell>
			<TableCell className={wrappingCellClassName}>
				<div className="flex flex-wrap items-center gap-2">
					<span
						className={`inline-flex items-center rounded-full border px-3 py-1 font-semibold text-xs uppercase ${getOrderStatusBadgeClasses(
							order.status
						)}`}
					>
						{formatOrderStatus(order.status)}
					</span>
					{order.status === "cancelled" && order.cancelledReason ? (
						<span className="min-w-0 text-wrap text-muted-foreground text-sm">
							{order.cancelledReason}
						</span>
					) : null}
				</div>
			</TableCell>
			<TableCell
				className={`${wrappingCellClassName} font-medium tabular-nums`}
			>
				{moneyFormatter.format(Number(order.totalAmount ?? 0))}
			</TableCell>
			<TableCell
				className={`${wrappingCellClassName} text-muted-foreground tabular-nums`}
			>
				{dateFormatter.format(new Date(order.createdAt))}
			</TableCell>
			<TableCell className={wrappingCellClassName}>
				{order.consignmentNumber ? (
					<StatusPill>{order.consignmentNumber}</StatusPill>
				) : (
					<span className="text-muted-foreground text-sm">—</span>
				)}
			</TableCell>
			<TableCell className={wrappingCellClassName}>
				{order.transactionScreenshotBase64 ? (
					<PaymentScreenshotDialog
						src={order.transactionScreenshotBase64}
						thumbnailClassName="size-10 rounded-xl"
					/>
				) : (
					<span className="text-muted-foreground text-sm">—</span>
				)}
			</TableCell>
			<OrderRowActionCell
				canEditOrders={canEditOrders}
				order={order}
				showActionsColumn={showActionsColumn}
			/>
		</TableRow>
	);
}

function OrderRowActionCell({
	canEditOrders,
	order,
	showActionsColumn,
}: {
	canEditOrders: boolean;
	order: AdvisorOrderListItem;
	showActionsColumn: boolean;
}) {
	if (showActionsColumn) {
		return (
			<TableCell className={wrappingCellClassName}>
				<OrderActionsMenu order={order} />
			</TableCell>
		);
	}

	if (!canEditOrders) {
		return null;
	}

	return (
		<TableCell className={wrappingCellClassName}>
			{editableTeamLeaderOrderStatuses.has(order.status) ? (
				<Link
					className="inline-flex h-8 items-center rounded-md px-3 text-sm transition-colors hover:bg-muted hover:text-foreground"
					href={`/orders/${order.id}/edit`}
				>
					Edit
				</Link>
			) : null}
		</TableCell>
	);
}

function OrderTableColumns({
	hasActionColumn,
	showAdvisorColumn,
}: {
	hasActionColumn: boolean;
	showAdvisorColumn: boolean;
}) {
	return (
		<colgroup>
			<col className={showAdvisorColumn ? "w-[12%]" : "w-[14%]"} />
			{showAdvisorColumn ? <col className="w-[14%]" /> : null}
			<col className={showAdvisorColumn ? "w-[18%]" : "w-[22%]"} />
			<col className={showAdvisorColumn ? "w-[12%]" : "w-[14%]"} />
			<col className="w-[12%]" />
			<col className={showAdvisorColumn ? "w-[12%]" : "w-[14%]"} />
			<col className="w-[12%]" />
			<col className="w-[10%]" />
			{hasActionColumn ? <col className="w-[6%]" /> : null}
		</colgroup>
	);
}

function OrderTableHeader({
	hasActionColumn,
	onCycleStatusFilter,
	onToggleSort,
	showAdvisorColumn,
	sortBy,
	sortDirection,
	statusFilter,
}: {
	hasActionColumn: boolean;
	onCycleStatusFilter: () => void;
	onToggleSort: (nextSortBy: OrderSortKey) => void;
	showAdvisorColumn: boolean;
	sortBy: OrderSortKey;
	sortDirection: SortDirection;
	statusFilter: OrderStatusFilter;
}) {
	const sortIcon = (column: OrderSortKey) => {
		if (sortBy !== column) {
			return <ArrowDownIcon className="size-3 opacity-30" />;
		}

		return sortDirection === "asc" ? (
			<ArrowUpIcon className="size-3" />
		) : (
			<ArrowDownIcon className="size-3" />
		);
	};

	return (
		<TableHeader>
			<TableRow className="hover:bg-transparent">
				<TableHead className={wrappingHeadClassName}>
					<button
						className="inline-flex items-center gap-1 text-left font-medium"
						onClick={() => onToggleSort("orderId")}
						type="button"
					>
						Order ID
						{sortIcon("orderId")}
					</button>
				</TableHead>
				{showAdvisorColumn ? (
					<TableHead className={wrappingHeadClassName}>
						<button
							className="inline-flex items-center gap-1 text-left font-medium"
							onClick={() => onToggleSort("advisorName")}
							type="button"
						>
							Advisor
							{sortIcon("advisorName")}
						</button>
					</TableHead>
				) : null}
				<TableHead className={wrappingHeadClassName}>Farmer</TableHead>
				<TableHead
					className={`${wrappingHeadClassName} w-[180px] min-w-[180px] max-w-[180px]`}
				>
					<button
						className="inline-flex items-center gap-1 text-left font-medium"
						onClick={onCycleStatusFilter}
						type="button"
					>
						Status
						<ArrowUpDownIcon
							className={`size-3 ${statusFilter === "all" ? "opacity-30" : ""}`}
						/>
					</button>
				</TableHead>
				<TableHead className={wrappingHeadClassName}>
					<button
						className="inline-flex items-center gap-1 text-left font-medium"
						onClick={() => onToggleSort("totalAmount")}
						type="button"
					>
						Total
						{sortIcon("totalAmount")}
					</button>
				</TableHead>
				<TableHead className={wrappingHeadClassName}>
					<button
						className="inline-flex items-center gap-1 text-left font-medium"
						onClick={() => onToggleSort("createdAt")}
						type="button"
					>
						Date
						{sortIcon("createdAt")}
					</button>
				</TableHead>
				<TableHead className={wrappingHeadClassName}>Consignment</TableHead>
				<TableHead className={wrappingHeadClassName}>Payment</TableHead>
				{hasActionColumn ? (
					<TableHead className={`${wrappingHeadClassName} w-20`}>
						Actions
					</TableHead>
				) : null}
			</TableRow>
		</TableHeader>
	);
}

export function OrdersDataTable({
	adminFirstName,
	orders,
	showAdvisorColumn = false,
}: {
	adminFirstName?: string;
	orders: AdvisorOrderListItem[];
	showAdvisorColumn?: boolean;
}) {
	const { data: session } = authClient.useSession();
	const userRole =
		session?.user &&
		"role" in session.user &&
		typeof session.user.role === "string"
			? session.user.role
			: "";
	const canEditOrders = userRole === "team_leader";
	const showActionsColumn = canEditOrders && showAdvisorColumn;
	const hasActionColumn = showActionsColumn || canEditOrders;
	const pageSizeOptions = [5, 10, 20] as const;
	const [sortBy, setSortBy] = useState<OrderSortKey>("createdAt");
	const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] =
		useState<(typeof pageSizeOptions)[number]>(10);
	const [statusFilter, setStatusFilter] = useState<OrderStatusFilter>("all");
	const [searchQuery, setSearchQuery] = useState("");
	const [dateFrom, setDateFrom] = useState<Date>();
	const [dateTo, setDateTo] = useState<Date>();
	const isAdminOrderList = userRole === "admin";

	const sortedOrders = useMemo(() => {
		const sorted = [...orders];

		sorted.sort((firstItem, secondItem) => {
			const firstValue = sortValue(firstItem, sortBy);
			const secondValue = sortValue(secondItem, sortBy);

			if (typeof firstValue === "number" && typeof secondValue === "number") {
				return sortDirection === "asc"
					? firstValue - secondValue
					: secondValue - firstValue;
			}

			const cmp = String(firstValue).localeCompare(String(secondValue));

			return sortDirection === "asc" ? cmp : -cmp;
		});

		return sorted;
	}, [orders, sortBy, sortDirection]);
	const availableStatusFilters = useMemo(() => {
		const statuses = [...new Set(sortedOrders.map((order) => order.status))];
		return ["all", ...statuses];
	}, [sortedOrders]);
	const filteredOrders = useMemo(() => {
		const normalizedQuery = searchQuery.trim().toLowerCase();
		const lowerDate = dateFrom ? startOfDay(dateFrom).getTime() : null;
		const upperDate = dateTo ? endOfDay(dateTo).getTime() : null;

		return sortedOrders.filter((order) => {
			if (statusFilter !== "all" && order.status !== statusFilter) {
				return false;
			}

			const orderTime = new Date(order.createdAt).getTime();
			if (lowerDate !== null && orderTime < lowerDate) {
				return false;
			}

			if (upperDate !== null && orderTime > upperDate) {
				return false;
			}

			if (!normalizedQuery) {
				return true;
			}

			const orderIdText = (order.orderId ?? "").toLowerCase();
			const advisorNameText = (order.advisorName ?? "").toLowerCase();
			const farmerNameText = order.farmerName.toLowerCase();
			return (
				advisorNameText.includes(normalizedQuery) ||
				orderIdText.includes(normalizedQuery) ||
				farmerNameText.includes(normalizedQuery)
			);
		});
	}, [dateFrom, dateTo, searchQuery, sortedOrders, statusFilter]);

	const totalPages = Math.max(1, Math.ceil(filteredOrders.length / pageSize));
	const safeCurrentPage = Math.min(currentPage, totalPages);
	const pageStartIndex = (safeCurrentPage - 1) * pageSize;
	const paginatedOrders = filteredOrders.slice(
		pageStartIndex,
		pageStartIndex + pageSize
	);
	const pageInputValue = String(safeCurrentPage);
	const fillerRows = Math.max(0, ORDER_TABLE_MIN_ROWS - paginatedOrders.length);
	const tableColumnCount =
		(hasActionColumn ? 8 : 7) + (showAdvisorColumn ? 1 : 0);

	useEffect(() => {
		if (currentPage > totalPages) {
			setCurrentPage(totalPages);
		}
	}, [currentPage, totalPages]);

	const cycleStatusFilter = () => {
		const currentIndex = availableStatusFilters.indexOf(statusFilter);
		const nextIndex =
			currentIndex === -1 || currentIndex === availableStatusFilters.length - 1
				? 0
				: currentIndex + 1;

		setStatusFilter(availableStatusFilters[nextIndex] ?? "all");
		setCurrentPage(1);
	};

	const toggleSort = (nextSortBy: OrderSortKey) => {
		setCurrentPage(1);
		if (nextSortBy === sortBy) {
			setSortDirection((currentDirection) =>
				currentDirection === "asc" ? "desc" : "asc"
			);
			return;
		}

		setSortBy(nextSortBy);
		setSortDirection("desc");
	};

	const resetFilters = () => {
		setCurrentPage(1);
		setSearchQuery("");
		setStatusFilter("all");
		setDateFrom(undefined);
		setDateTo(undefined);
	};

	const exportFilteredOrders = () => {
		downloadCsv(
			getDefaultExportFileName(adminFirstName ?? "admin", dateFrom, dateTo),
			filteredOrders
		);
	};

	return (
		<div className="space-y-4">
			<div className="flex flex-wrap items-end gap-3">
				<div className="relative min-w-64 flex-1">
					<SearchIcon className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
					<Input
						className="border-border bg-card pl-9 shadow-sm"
						onChange={(event) => {
							setCurrentPage(1);
							setSearchQuery(event.target.value);
						}}
						placeholder="Search by order ID or farmer name..."
						value={searchQuery}
					/>
				</div>
				<Select
					onValueChange={(value) => {
						setCurrentPage(1);
						setStatusFilter(value ?? "all");
					}}
					value={statusFilter}
				>
					<SelectTrigger className="w-44 bg-card">
						<SelectValue>
							{statusFilter === "all"
								? "All statuses"
								: formatOrderStatus(statusFilter)}
						</SelectValue>
					</SelectTrigger>
					<SelectContent>
						{availableStatusFilters.map((status) => (
							<SelectItem key={status} value={status}>
								{status === "all" ? "All statuses" : formatOrderStatus(status)}
							</SelectItem>
						))}
					</SelectContent>
				</Select>
				<DatePicker
					className="w-44 bg-card"
					onChange={(value) => {
						setCurrentPage(1);
						setDateFrom(value);
					}}
					placeholder="From date"
					value={dateFrom}
				/>
				<DatePicker
					className="w-44 bg-card"
					onChange={(value) => {
						setCurrentPage(1);
						setDateTo(value);
					}}
					placeholder="To date"
					value={dateTo}
				/>
				<Button onClick={resetFilters} type="button" variant="outline">
					Reset
				</Button>
				{isAdminOrderList ? (
					<Button
						disabled={filteredOrders.length === 0}
						onClick={exportFilteredOrders}
						type="button"
						variant="outline"
					>
						<DownloadIcon />
						Export CSV
					</Button>
				) : null}
			</div>
			<div className="overflow-hidden rounded-4xl border bg-card shadow-md ring-1 ring-foreground/5">
				<Table className="table-fixed">
					<OrderTableColumns
						hasActionColumn={hasActionColumn}
						showAdvisorColumn={showAdvisorColumn}
					/>
					<OrderTableHeader
						hasActionColumn={hasActionColumn}
						onCycleStatusFilter={cycleStatusFilter}
						onToggleSort={toggleSort}
						showAdvisorColumn={showAdvisorColumn}
						sortBy={sortBy}
						sortDirection={sortDirection}
						statusFilter={statusFilter}
					/>
					<TableBody>
						{paginatedOrders.length > 0 ? (
							paginatedOrders.map((order) => (
								<OrderTableRow
									canEditOrders={canEditOrders}
									key={order.id}
									order={order}
									showActionsColumn={showActionsColumn}
									showAdvisorColumn={showAdvisorColumn}
								/>
							))
						) : (
							<TableRow>
								<TableCell
									className="text-muted-foreground"
									colSpan={tableColumnCount}
								>
									No orders yet.
								</TableCell>
							</TableRow>
						)}
						{Array.from({ length: fillerRows }).map((_, index) => (
							<TableRow
								aria-hidden
								className="hover:bg-transparent"
								key={index}
							>
								<TableCell className="h-16" colSpan={tableColumnCount}>
									&nbsp;
								</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
				<div className="grid gap-3 border-border/70 border-t bg-muted/20 px-4 py-3 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
					<div className="text-muted-foreground text-sm">
						{filteredOrders.length}{" "}
						{filteredOrders.length === 1 ? "record" : "records"}
						{statusFilter === "all"
							? ""
							: ` · ${formatOrderStatus(statusFilter)}`}
					</div>
					<Pagination className="mx-0 w-auto justify-center lg:col-start-2">
						<PaginationContent>
							<PaginationItem>
								<PaginationPrevious
									disabled={safeCurrentPage === 1}
									onClick={() =>
										setCurrentPage((page) => Math.max(1, page - 1))
									}
									type="button"
								/>
							</PaginationItem>
							<PaginationItem>
								<div className="flex h-9 items-center gap-2 px-2 text-sm">
									<span className="text-muted-foreground">Page</span>
									<Input
										className="h-8 w-16 text-center"
										inputMode="numeric"
										max={totalPages}
										min={1}
										onBlur={() => {
											setCurrentPage((value) => Math.min(totalPages, value));
										}}
										onChange={(event) => {
											const nextPage = Number(event.target.value);
											if (!Number.isInteger(nextPage)) {
												return;
											}

											setCurrentPage(
												Math.min(totalPages, Math.max(1, nextPage))
											);
										}}
										value={pageInputValue}
									/>
									<span className="text-muted-foreground">of {totalPages}</span>
								</div>
							</PaginationItem>
							<PaginationItem>
								<PaginationNext
									disabled={safeCurrentPage === totalPages}
									onClick={() =>
										setCurrentPage((page) => Math.min(totalPages, page + 1))
									}
									type="button"
								/>
							</PaginationItem>
						</PaginationContent>
					</Pagination>
					<div className="flex flex-wrap items-center gap-3 lg:justify-end">
						<div className="flex items-center gap-2">
							<span className="text-muted-foreground text-sm">
								Rows per page
							</span>
							<Select
								onValueChange={(value) => {
									setCurrentPage(1);
									setPageSize(
										Number(value) as (typeof pageSizeOptions)[number]
									);
								}}
								value={String(pageSize)}
							>
								<SelectTrigger className="w-20 bg-background" size="sm">
									<SelectValue />
								</SelectTrigger>
								<SelectContent>
									{pageSizeOptions.map((option) => (
										<SelectItem key={option} value={String(option)}>
											{option}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
}
