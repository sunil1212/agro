"use client";

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export interface OrderDraftItem {
	costPerUnit: number;
	name: string;
	productId: string;
	quantity: number;
	unitPricePerUnit: number;
}

export type PaymentMode = "cod" | "partial_payment" | "prepaid";

interface OrderDraftState {
	addItem: (item: OrderDraftItem) => void;
	couponCode: string;
	farmerId: string;
	hasHydrated: boolean;
	items: OrderDraftItem[];
	paidAmount: number;
	paymentMode: PaymentMode;
	removeItem: (productId: string) => void;
	reset: () => void;
	setCouponCode: (couponCode: string) => void;
	setFarmerId: (farmerId: string) => void;
	setHasHydrated: (hasHydrated: boolean) => void;
	setPaidAmount: (paidAmount: number) => void;
	setPaymentMode: (paymentMode: PaymentMode) => void;
	setShippingCharges: (shippingCharges: number) => void;
	shippingCharges: number;
	updateItemQuantity: (productId: string, quantity: number) => void;
}

const defaultDraftState = {
	couponCode: "",
	farmerId: "",
	hasHydrated: false,
	items: [],
	paidAmount: 0,
	paymentMode: "cod" as PaymentMode,
	shippingCharges: 0,
};

export const useOrderDraftStore = create<OrderDraftState>()(
	persist(
		(set, get) => ({
			...defaultDraftState,
			addItem: (item) => {
				const existingItem = get().items.find(
					(entry) => entry.productId === item.productId
				);

				if (existingItem) {
					set((state) => ({
						items: state.items.map((entry) =>
							entry.productId === item.productId
								? { ...entry, quantity: entry.quantity + item.quantity }
								: entry
						),
					}));
					return;
				}

				set((state) => ({ items: [...state.items, item] }));
			},
			removeItem: (productId) =>
				set((state) => ({
					items: state.items.filter((item) => item.productId !== productId),
				})),
			reset: () =>
				set({
					...defaultDraftState,
					hasHydrated: true,
				}),
			setCouponCode: (couponCode) => set({ couponCode }),
			setFarmerId: (farmerId) => set({ farmerId }),
			setHasHydrated: (hasHydrated) => set({ hasHydrated }),
			setPaidAmount: (paidAmount) => set({ paidAmount }),
			setPaymentMode: (paymentMode) => set({ paymentMode }),
			setShippingCharges: (shippingCharges) => set({ shippingCharges }),
			updateItemQuantity: (productId, quantity) =>
				set((state) => ({
					items:
						quantity <= 0
							? state.items.filter((item) => item.productId !== productId)
							: state.items.map((item) =>
									item.productId === productId ? { ...item, quantity } : item
								),
				})),
		}),
		{
			name: "advisor-order-draft",
			onRehydrateStorage: () => (state) => {
				state?.setHasHydrated(true);
			},
			partialize: (state) => ({
				couponCode: state.couponCode,
				farmerId: state.farmerId,
				items: state.items,
				paidAmount: state.paidAmount,
				paymentMode: state.paymentMode,
				shippingCharges: state.shippingCharges,
			}),
			storage: createJSONStorage(() => sessionStorage),
		}
	)
);
