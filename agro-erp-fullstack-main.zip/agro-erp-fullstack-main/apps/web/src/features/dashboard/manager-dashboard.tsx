"use client";

import { Button } from "@agro-erp-fullstack/ui/components/button";
import { DatePicker } from "@agro-erp-fullstack/ui/components/date-picker";
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from "@agro-erp-fullstack/ui/components/dialog";
import {
	BarChart3Icon,
	DownloadIcon,
	FileSpreadsheetIcon,
	PackagePlus,
	SproutIcon,
	UserRoundPlus,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { QuickActionCard } from "@/components/quick-action-card";
import { getClientApiUrl } from "@/lib/api-client";

const contentDispositionFileNamePattern = /filename="(.+)"/;
type ExportKind = "booking" | "packing";

const getDateOnly = (date: Date): string => {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
};

const downloadAuthenticatedFile = async (
	url: string,
	fallbackFileName: string
): Promise<void> => {
	const response = await fetch(url, { credentials: "include" });
	if (!response.ok) {
		const error = await response.json().catch(() => null);
		throw new Error(error?.message ?? "Export failed");
	}

	const blob = await response.blob();
	const objectUrl = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = objectUrl;

	const disposition = response.headers.get("Content-Disposition");
	const match = disposition?.match(contentDispositionFileNamePattern);
	link.download = match?.[1] ?? fallbackFileName;

	link.click();
	URL.revokeObjectURL(objectUrl);
};

export function ManagerDashboard({ isAdmin = false }: { isAdmin?: boolean }) {
	const [isPackingExporting, setIsPackingExporting] = useState(false);
	const [isBookingExporting, setIsBookingExporting] = useState(false);
	const [pendingExportKind, setPendingExportKind] = useState<ExportKind | null>(
		null
	);
	const [exportFrom, setExportFrom] = useState<Date>();
	const [exportTo, setExportTo] = useState<Date>();

	const handleExport = async (
		kind: ExportKind,
		from: Date,
		to: Date
	): Promise<void> => {
		const setIsExporting =
			kind === "packing" ? setIsPackingExporting : setIsBookingExporting;
		setIsExporting(true);
		try {
			const query = new URLSearchParams({
				from: getDateOnly(from),
				to: getDateOnly(to),
			});
			await downloadAuthenticatedFile(
				getClientApiUrl("orders", `/exports/${kind}.csv?${query.toString()}`),
				`${kind}-sheet.csv`
			);
			toast.success(
				`${kind === "packing" ? "Packing" : "Booking"} CSV downloaded`
			);
			setPendingExportKind(null);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Export failed");
		} finally {
			setIsExporting(false);
		}
	};

	return (
		<div className="space-y-4">
			<div className="grid gap-4 md:grid-cols-2">
				<QuickActionCard
					actionLabel="Add user"
					description="Create advisor, team leader, or logistics access for your branch."
					href="/accounts/create"
					icon={<UserRoundPlus className="size-5" />}
					label="Team access"
					meta="Routine admin task"
					size="lg"
					title="Create account"
					tone="solid"
					variant="tile"
				/>
				<QuickActionCard
					actionLabel="Review"
					description="Check advisor sales, order movement, and export-ready reports."
					href="/stats"
					icon={<BarChart3Icon className="size-5" />}
					label="Reporting"
					meta="Branch performance"
					size="lg"
					title="Sales reports"
					tone="solid"
					variant="tile"
				/>
			</div>
			<div className="grid gap-4 md:grid-cols-2">
				<div className="rounded-2xl border bg-card p-5 shadow-sm">
					<div className="flex items-start justify-between gap-4">
						<div className="space-y-1">
							<p className="font-medium text-muted-foreground text-xs uppercase tracking-[0.18em]">
								Order exports
							</p>
							<h3 className="font-semibold text-lg">Packing & booking</h3>
							<p className="max-w-sm text-muted-foreground text-sm">
								Download confirmed orders as packing sheets or carrier booking
								CSV files.
							</p>
						</div>
						<div className="flex shrink-0 items-center gap-2">
							<FileSpreadsheetIcon className="size-5 text-muted-foreground" />
						</div>
					</div>
					<div className="mt-4 flex flex-wrap items-center gap-2">
						<button
							className="inline-flex items-center gap-2 rounded-xl border border-input bg-background px-4 py-2 font-medium text-sm shadow-sm transition-colors hover:bg-accent disabled:pointer-events-none disabled:opacity-50"
							disabled={isPackingExporting}
							onClick={() => setPendingExportKind("packing")}
							type="button"
						>
							<DownloadIcon className="size-4" />
							{isPackingExporting ? "Downloading..." : "Download packing CSV"}
						</button>
						<button
							className="inline-flex items-center gap-2 rounded-xl border border-input bg-background px-4 py-2 font-medium text-sm shadow-sm transition-colors hover:bg-accent disabled:pointer-events-none disabled:opacity-50"
							disabled={isBookingExporting}
							onClick={() => setPendingExportKind("booking")}
							type="button"
						>
							<DownloadIcon className="size-4" />
							{isBookingExporting ? "Downloading..." : "Download booking CSV"}
						</button>
					</div>
				</div>
				{isAdmin ? null : (
					<QuickActionCard
						actionLabel="Add item"
						description="Set up catalog pricing, stock quantity, and product variants."
						headingLevel="h3"
						href="/products/create"
						icon={<PackagePlus className="size-5" />}
						label="Catalog setup"
						meta="Admin-only setup"
						size="md"
						title="Create product"
						tone="soft"
						variant="tile"
					/>
				)}
				{isAdmin ? null : (
					<QuickActionCard
						actionLabel="Add template"
						description="Build crop schedules with day-range instructions for follow-up tasks."
						headingLevel="h3"
						href="/crops/create"
						icon={<SproutIcon className="size-4" />}
						label="Crop setup"
						meta="Admin-only setup"
						size="md"
						title="Create crop"
						tone="soft"
						variant="tile"
					/>
				)}
			</div>
			<Dialog
				onOpenChange={(open) => {
					if (!open) {
						setPendingExportKind(null);
					}
				}}
				open={pendingExportKind !== null}
			>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Choose export date range</DialogTitle>
						<DialogDescription>
							Select the order creation dates to include in this CSV.
						</DialogDescription>
					</DialogHeader>
					<div className="grid gap-4 sm:grid-cols-2">
						<div className="space-y-2">
							<label className="font-medium text-sm" htmlFor="export-from">
								Start date
							</label>
							<DatePicker
								id="export-from"
								onChange={setExportFrom}
								placeholder="Start date"
								value={exportFrom}
							/>
						</div>
						<div className="space-y-2">
							<label className="font-medium text-sm" htmlFor="export-to">
								End date
							</label>
							<DatePicker
								id="export-to"
								onChange={setExportTo}
								placeholder="End date"
								value={exportTo}
							/>
						</div>
					</div>
					<DialogFooter>
						<Button
							disabled={
								!(pendingExportKind && exportFrom && exportTo) ||
								exportFrom > exportTo
							}
							onClick={() => {
								if (!(pendingExportKind && exportFrom && exportTo)) {
									return;
								}
								handleExport(pendingExportKind, exportFrom, exportTo).catch(
									() => undefined
								);
							}}
							type="button"
						>
							<DownloadIcon />
							Download CSV
						</Button>
					</DialogFooter>
				</DialogContent>
			</Dialog>
		</div>
	);
}
