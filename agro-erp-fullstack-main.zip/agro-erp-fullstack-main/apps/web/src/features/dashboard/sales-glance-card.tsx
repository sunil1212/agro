"use client";

import {
	Card,
	CardContent,
	CardHeader,
	CardTitle,
} from "@agro-erp-fullstack/ui/components/card";
import {
	type ChartConfig,
	ChartContainer,
	ChartTooltip,
	ChartTooltipContent,
} from "@agro-erp-fullstack/ui/components/chart";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts";

const STATUS_COLORS = {
	cancelled: "#b4b8c4",
	confirmed: "#93c5fd",
	created: "#fcd38d",
	delivered: "#86d39e",
	dispatched: "#c4b5fd",
	return_in_transit: "#fca5a5",
	return_in_warehouse: "#f9a8d4",
} as const;

export interface SalesGlanceBucket {
	amountByStatus: Record<string, number>;
	countByStatus: Record<string, number>;
	label: string;
}

interface SalesGlanceCardProps {
	buckets: SalesGlanceBucket[];
	statuses: string[];
}

const currencyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 0,
	style: "currency",
});

const compactCurrencyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 0,
	notation: "compact",
	style: "currency",
});

const numberFormatter = new Intl.NumberFormat("en-IN");

const formatStatus = (status: string) =>
	status
		.split("_")
		.map((part) => part.charAt(0).toUpperCase() + part.slice(1))
		.join(" ");

const buildChartConfig = (statuses: string[]): ChartConfig =>
	Object.fromEntries(
		statuses.flatMap((status) => {
			const color =
				STATUS_COLORS[status as keyof typeof STATUS_COLORS] ??
				"oklch(0.77 0.02 260)";
			const label = formatStatus(status);

			return [
				[`amount_${status}`, { color, label }],
				[`count_${status}`, { color, label }],
			];
		})
	);

const toPeriodChartRows = (
	bucket: SalesGlanceBucket,
	statuses: string[]
): Record<string, number | string>[] => [
	{
		label: "Sales",
		...Object.fromEntries(
			statuses.map((status) => [
				`amount_${status}`,
				Math.round(bucket.amountByStatus[status] ?? 0),
			])
		),
	},
	{
		label: "Orders",
		...Object.fromEntries(
			statuses.map((status) => [
				`count_${status}`,
				Math.round(bucket.countByStatus[status] ?? 0),
			])
		),
	},
];

export function SalesGlanceCard({ buckets, statuses }: SalesGlanceCardProps) {
	const chartConfig = buildChartConfig(statuses);

	return (
		<Card className="rounded-[2rem] border-border/70 shadow-sm">
			<CardHeader className="space-y-1">
				<CardTitle>Sales distribution at a glance</CardTitle>
			</CardHeader>
			<CardContent className="space-y-6">
				<div className="grid gap-5 lg:grid-cols-3">
					{buckets.map((bucket) => (
						<StatusSplitChart
							bucket={bucket}
							chartConfig={chartConfig}
							key={bucket.label}
							statuses={statuses}
						/>
					))}
				</div>
				<div className="flex flex-wrap items-center justify-center gap-4 border-border/60 border-t pt-1">
					{statuses.map((status) => (
						<div
							className="flex items-center gap-2 text-muted-foreground text-xs"
							key={status}
						>
							<span
								className="size-2.5 rounded-[3px]"
								style={{
									backgroundColor: chartConfig[`amount_${status}`]?.color,
								}}
							/>
							<span className="font-medium">
								{chartConfig[`amount_${status}`]?.label}
							</span>
						</div>
					))}
				</div>
			</CardContent>
		</Card>
	);
}

function StatusSplitChart({
	bucket,
	chartConfig,
	statuses,
}: {
	bucket: SalesGlanceBucket;
	chartConfig: ChartConfig;
	statuses: string[];
}) {
	const chartRows = toPeriodChartRows(bucket, statuses);

	return (
		<section className="space-y-3">
			<h3 className="font-medium text-sm">{bucket.label}</h3>
			<ChartContainer className="h-56 w-full" config={chartConfig}>
				<BarChart accessibilityLayer barGap={22} data={chartRows}>
					<CartesianGrid vertical={false} />
					<XAxis
						axisLine={false}
						dataKey="label"
						tickLine={false}
						tickMargin={10}
					/>
					<YAxis
						axisLine={false}
						tickFormatter={(value) =>
							compactCurrencyFormatter.format(Number(value ?? 0))
						}
						tickLine={false}
						tickMargin={10}
						width={58}
						yAxisId="amount"
					/>
					<YAxis
						axisLine={false}
						orientation="right"
						tickFormatter={(value) =>
							numberFormatter.format(Number(value ?? 0))
						}
						tickLine={false}
						tickMargin={10}
						width={36}
						yAxisId="count"
					/>
					<ChartTooltip
						content={
							<ChartTooltipContent
								formatter={(value, name) =>
									String(name).startsWith("count_")
										? numberFormatter.format(Number(value ?? 0))
										: currencyFormatter.format(Number(value ?? 0))
								}
							/>
						}
					/>
					{statuses.map((status, index) => (
						<Bar
							dataKey={`amount_${status}`}
							fill={chartConfig[`amount_${status}`]?.color}
							key={`amount_${status}`}
							radius={getBarRadius(index, statuses.length)}
							stackId="sales"
							yAxisId="amount"
						/>
					))}
					{statuses.map((status, index) => (
						<Bar
							dataKey={`count_${status}`}
							fill={chartConfig[`count_${status}`]?.color}
							key={`count_${status}`}
							radius={getBarRadius(index, statuses.length)}
							stackId="orders"
							yAxisId="count"
						/>
					))}
				</BarChart>
			</ChartContainer>
		</section>
	);
}

const getBarRadius = (index: number, total: number) => {
	if (total === 1) {
		return [6, 6, 6, 6] as [number, number, number, number];
	}

	if (index === 0) {
		return [0, 0, 6, 6] as [number, number, number, number];
	}

	if (index === total - 1) {
		return [6, 6, 0, 0] as [number, number, number, number];
	}

	return [0, 0, 0, 0] as [number, number, number, number];
};
