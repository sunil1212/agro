import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { ShoppingBasketIcon, UserRoundPlus } from "lucide-react";
import Link from "next/link";
import { QuickActionCard } from "@/components/quick-action-card";
import { StatusPill } from "@/components/ui-patterns";
import {
	type SalesGlanceBucket,
	SalesGlanceCard,
} from "@/features/dashboard/sales-glance-card";
import { fetchServerApi } from "@/lib/api-server";

interface AdvisorTask {
	completedAt: string | null;
	createdAt: string;
	cropName: string;
	cropScheduleEndDay: number;
	cropScheduleStartDay: number;
	farmerCropId: string;
	farmerId: string;
	farmerName: string;
	id: string;
	instruction: string;
	isCompleted: boolean;
	scheduledFor: string;
}

interface AdvisorDashboardStats {
	sales: {
		dailySales: string;
		dailySalesTarget: string | null;
		monthlySales: string;
		monthlySalesTarget: string | null;
		monthlyDeliveredCount: number;
		monthlyDeliveredRate: number;
		monthlyReturnCount: number;
		monthlyReturnRate: number;
	};
	salesGlance: {
		buckets: SalesGlanceBucket[];
		statuses: string[];
	};
	success: true;
}

const dateFormatter = new Intl.DateTimeFormat("en-IN", {
	day: "2-digit",
	month: "short",
	timeZone: "Asia/Kolkata",
	year: "numeric",
});

const moneyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 2,
	minimumFractionDigits: 2,
	style: "currency",
});

const formatMoney = (value: number | string) =>
	moneyFormatter.format(Number(value));

const percentageFormatter = new Intl.NumberFormat("en-IN", {
	maximumFractionDigits: 1,
	style: "percent",
});

const formatAmountLeft = (sales: number, target: null | number) => {
	if (target === null || target <= 0) {
		return "—";
	}

	return formatMoney(Math.max(target - sales, 0));
};

export async function AdvisorDashboard() {
	const [tasksResponse, statsResponse] = await Promise.all([
		fetchServerApi<{ success: true; tasks: AdvisorTask[] }>(
			"advisor-tasks",
			"/tasks?category=current"
		),
		fetchServerApi<AdvisorDashboardStats>("analytics", "/advisor-dashboard"),
	]);
	const tasks = tasksResponse.tasks;

	return (
		<div className="space-y-6">
			<div className="grid gap-6 md:auto-rows-fr md:grid-cols-2">
				<QuickActionCard
					actionLabel="Create farmer"
					description="Onboard a new farmer with crop and farm details for future follow-up."
					href="/farmers/create"
					icon={<UserRoundPlus className="size-5" />}
					label="Farmer"
					size="lg"
					title="Onboard farmer"
					tone="solid"
					variant="tile"
				/>
				<QuickActionCard
					actionLabel="Create order"
					description="Open the advisor order desk to build a cart and place a fresh order."
					href="/orders/create"
					icon={<ShoppingBasketIcon className="size-5" />}
					label="Orders"
					size="lg"
					title="Order desk"
					tone="solid"
					variant="tile"
				/>
			</div>
			<div className="grid gap-6 lg:grid-cols-2">
				<AdvisorSalesStats stats={statsResponse} />
				<AdvisorTasks tasks={tasks} />
			</div>
			<SalesGlanceCard
				buckets={statsResponse.salesGlance.buckets}
				statuses={statsResponse.salesGlance.statuses}
			/>
		</div>
	);
}

function AdvisorSalesStats({ stats }: { stats: AdvisorDashboardStats }) {
	const dailyTarget = stats.sales.dailySalesTarget
		? Number(stats.sales.dailySalesTarget)
		: null;
	const monthlyTarget = stats.sales.monthlySalesTarget
		? Number(stats.sales.monthlySalesTarget)
		: null;
	const dailySales = Number(stats.sales.dailySales);
	const monthlySales = Number(stats.sales.monthlySales);
	const dailyProgress =
		dailyTarget && dailyTarget > 0 ? dailySales / dailyTarget : null;
	const monthlyProgress =
		monthlyTarget && monthlyTarget > 0 ? monthlySales / monthlyTarget : null;

	return (
		<section className="rounded-[2rem] border border-border/70 bg-card p-5 shadow-sm">
			<div className="space-y-1">
				<h2 className="font-semibold text-lg">Sales statistics</h2>
				<p className="text-muted-foreground text-sm">
					Today and this month compared to your targets.
				</p>
			</div>
			<div className="mt-5 overflow-hidden rounded-2xl border border-border/70">
				<Table>
					<TableHeader>
						<TableRow className="hover:bg-transparent">
							<TableHead>Period</TableHead>
							<TableHead className="text-right">Sales</TableHead>
							<TableHead className="text-right">Target</TableHead>
							<TableHead className="text-right">Progress</TableHead>
							<TableHead className="text-right">Left</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						<TableRow>
							<TableCell>Today</TableCell>
							<TableCell className="text-right font-medium">
								{formatMoney(stats.sales.dailySales)}
							</TableCell>
							<TableCell className="text-right font-medium">
								{dailyTarget === null ? "—" : formatMoney(dailyTarget)}
							</TableCell>
							<TableCell className="text-right">
								{dailyProgress === null ? (
									<span className="text-muted-foreground text-sm">
										No target
									</span>
								) : (
									<StatusPill>{Math.round(dailyProgress * 100)}%</StatusPill>
								)}
							</TableCell>
							<TableCell className="text-right font-medium">
								{formatAmountLeft(dailySales, dailyTarget)}
							</TableCell>
						</TableRow>
						<TableRow>
							<TableCell>This month</TableCell>
							<TableCell className="text-right font-medium">
								{formatMoney(stats.sales.monthlySales)}
							</TableCell>
							<TableCell className="text-right font-medium">
								{monthlyTarget === null ? "—" : formatMoney(monthlyTarget)}
							</TableCell>
							<TableCell className="text-right">
								{monthlyProgress === null ? (
									<span className="text-muted-foreground text-sm">
										No target
									</span>
								) : (
									<StatusPill>{Math.round(monthlyProgress * 100)}%</StatusPill>
								)}
							</TableCell>
							<TableCell className="text-right font-medium">
								{formatAmountLeft(monthlySales, monthlyTarget)}
							</TableCell>
						</TableRow>
					</TableBody>
				</Table>
			</div>
			<div className="mt-4 overflow-hidden rounded-2xl border border-border/70">
				<Table>
					<TableHeader>
						<TableRow className="hover:bg-transparent">
							<TableHead>Monthly order outcome</TableHead>
							<TableHead className="text-right">Count</TableHead>
							<TableHead className="text-right">Share of orders</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						<TableRow>
							<TableCell>Delivered</TableCell>
							<TableCell className="text-right font-medium tabular-nums">
								{stats.sales.monthlyDeliveredCount}
							</TableCell>
							<TableCell className="text-right text-muted-foreground tabular-nums">
								{percentageFormatter.format(stats.sales.monthlyDeliveredRate)}
							</TableCell>
						</TableRow>
						<TableRow>
							<TableCell>Returned</TableCell>
							<TableCell className="text-right font-medium tabular-nums">
								{stats.sales.monthlyReturnCount}
							</TableCell>
							<TableCell className="text-right text-muted-foreground tabular-nums">
								{percentageFormatter.format(stats.sales.monthlyReturnRate)}
							</TableCell>
						</TableRow>
					</TableBody>
				</Table>
			</div>
		</section>
	);
}

function AdvisorTasks({ tasks }: { tasks: AdvisorTask[] }) {
	return (
		<section className="rounded-[2rem] border border-border/70 bg-card p-5 shadow-sm">
			<div className="flex items-start justify-between gap-3">
				<div className="space-y-1">
					<h2 className="font-semibold text-lg">Tasks</h2>
					<p className="text-muted-foreground text-sm">
						Scheduled crop follow-ups for this advisor.
					</p>
				</div>
				<StatusPill>
					{tasks.length} {tasks.length === 1 ? "record" : "records"}
				</StatusPill>
			</div>
			<div className="mt-5 overflow-hidden rounded-2xl border border-border/70">
				<Table>
					<TableHeader>
						<TableRow className="hover:bg-transparent">
							<TableHead>Farmer/Task</TableHead>
							<TableHead>Crop</TableHead>
							<TableHead>Scheduled</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{tasks.length > 0 ? (
							tasks.map((task) => (
								<TableRow key={task.id}>
									<TableCell className="min-w-[22rem] max-w-[48rem]">
										<Link
											className="inline-block max-w-full font-medium text-foreground underline-offset-4 hover:underline"
											href={`/farmers/${task.farmerId}`}
										>
											{task.farmerName}
										</Link>
										<p className="mt-1 overflow-hidden text-muted-foreground text-sm leading-5 [-webkit-box-orient:vertical] [-webkit-line-clamp:3] [display:-webkit-box]">
											{task.instruction}
										</p>
									</TableCell>
									<TableCell>{task.cropName}</TableCell>
									<TableCell className="text-muted-foreground">
										{dateFormatter.format(new Date(task.scheduledFor))}
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell className="text-muted-foreground" colSpan={3}>
									No crop tasks.
								</TableCell>
							</TableRow>
						)}
					</TableBody>
				</Table>
			</div>
		</section>
	);
}
