export const getDashboardDescription = (userRole: null | string) => {
	if (userRole === "advisor" || userRole === "team_leader") {
		return "Use the dashboard shortcuts to move between farmer onboarding, order creation, and scheduled crop follow-ups.";
	}

	if (userRole === "warehouse") {
		return "Use the dashboard shortcuts to manage warehouse product updates and order fulfillment.";
	}

	return "Use the dashboard shortcuts to jump into the most common manager flows.";
};
