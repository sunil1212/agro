import type { ReactNode } from "react";
import { PageShell } from "@/components/ui-patterns";

export function DashboardShell({
	children,
	description,
	userName,
}: {
	children: ReactNode;
	description: string;
	userName: string;
}) {
	return (
		<PageShell className="max-w-7xl">
			<div className="max-w-3xl space-y-2">
				<h1 className="font-semibold text-2xl leading-tight tracking-tight sm:text-3xl">
					Welcome {userName}
				</h1>
				<p className="text-muted-foreground text-sm leading-6">{description}</p>
			</div>
			{children}
		</PageShell>
	);
}
