"use client";

import { buttonVariants } from "@agro-erp-fullstack/ui/components/button";
import {
	Card,
	CardContent,
	CardHeader,
	CardTitle,
} from "@agro-erp-fullstack/ui/components/card";
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from "@agro-erp-fullstack/ui/components/table";
import { cn } from "@agro-erp-fullstack/ui/lib/utils";
import { ExternalLinkIcon } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { getClientApiUrl } from "@/lib/api-client";

interface BranchSalesSummary {
	adminName: string;
	adminUserId: string;
	advisorCount: number;
	managerCode: string;
	orderCount: number;
	totalSales: number;
}

const currencyFormatter = new Intl.NumberFormat("en-IN", {
	currency: "INR",
	maximumFractionDigits: 0,
	style: "currency",
});

const numberFormatter = new Intl.NumberFormat("en-IN");

export function SuperAdminDashboard() {
	const [branches, setBranches] = useState<BranchSalesSummary[]>([]);
	const [error, setError] = useState<string | null>(null);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		const loadBranches = async (): Promise<void> => {
			try {
				const response = await fetch(
					getClientApiUrl("analytics", "/branch-stats"),
					{ credentials: "include" }
				);
				const data = (await response.json().catch(() => null)) as {
					branches?: BranchSalesSummary[];
					message?: string;
					success?: boolean;
				} | null;

				if (!(response.ok && data?.success && data.branches)) {
					throw new Error(data?.message ?? "Failed to load branch statistics");
				}

				setBranches(data.branches);
			} catch (loadError) {
				setError(
					loadError instanceof Error
						? loadError.message
						: "Failed to load branch statistics"
				);
			} finally {
				setLoading(false);
			}
		};

		loadBranches().catch(() => {
			setError("Failed to load branch statistics");
			setLoading(false);
		});
	}, []);

	const totalSales = branches.reduce((sum, b) => sum + b.totalSales, 0);
	const totalOrders = branches.reduce((sum, b) => sum + b.orderCount, 0);
	const totalAdvisors = branches.reduce((sum, b) => sum + b.advisorCount, 0);

	if (loading) {
		return <p className="text-muted-foreground">Loading branch data...</p>;
	}
	if (error) {
		return <p className="text-destructive">{error}</p>;
	}

	return (
		<div className="space-y-6">
			<div className="grid gap-4 md:grid-cols-4">
				<Card>
					<CardHeader>
						<CardTitle className="text-muted-foreground text-sm">
							Total branches
						</CardTitle>
					</CardHeader>
					<CardContent>
						<p className="font-semibold text-2xl tabular-nums">
							{numberFormatter.format(branches.length)}
						</p>
					</CardContent>
				</Card>
				<Card>
					<CardHeader>
						<CardTitle className="text-muted-foreground text-sm">
							Total sales
						</CardTitle>
					</CardHeader>
					<CardContent>
						<p className="font-semibold text-2xl tabular-nums">
							{currencyFormatter.format(totalSales)}
						</p>
					</CardContent>
				</Card>
				<Card>
					<CardHeader>
						<CardTitle className="text-muted-foreground text-sm">
							Total orders
						</CardTitle>
					</CardHeader>
					<CardContent>
						<p className="font-semibold text-2xl tabular-nums">
							{numberFormatter.format(totalOrders)}
						</p>
					</CardContent>
				</Card>
				<Card>
					<CardHeader>
						<CardTitle className="text-muted-foreground text-sm">
							Total advisors
						</CardTitle>
					</CardHeader>
					<CardContent>
						<p className="font-semibold text-2xl tabular-nums">
							{numberFormatter.format(totalAdvisors)}
						</p>
					</CardContent>
				</Card>
			</div>

			<Card>
				<CardHeader>
					<CardTitle>Branch comparison</CardTitle>
				</CardHeader>
				<CardContent>
					<Table>
						<TableHeader>
							<TableRow>
								<TableHead>Branch code</TableHead>
								<TableHead>Admin</TableHead>
								<TableHead>Advisors</TableHead>
								<TableHead>Orders</TableHead>
								<TableHead>Sales</TableHead>
								<TableHead />
							</TableRow>
						</TableHeader>
						<TableBody>
							{branches.map((branch) => (
								<TableRow key={branch.managerCode}>
									<TableCell className="font-mono text-xs">
										{branch.managerCode}
									</TableCell>
									<TableCell>{branch.adminName}</TableCell>
									<TableCell>
										{numberFormatter.format(branch.advisorCount)}
									</TableCell>
									<TableCell>
										{numberFormatter.format(branch.orderCount)}
									</TableCell>
									<TableCell>
										{currencyFormatter.format(branch.totalSales)}
									</TableCell>
									<TableCell>
										<Link
											className={cn(
												buttonVariants({ size: "sm", variant: "outline" })
											)}
											href={`/admin/branch-stats/${encodeURIComponent(branch.managerCode)}`}
										>
											<ExternalLinkIcon />
											View
										</Link>
									</TableCell>
								</TableRow>
							))}
							{branches.length === 0 && (
								<TableRow>
									<TableCell className="text-muted-foreground" colSpan={6}>
										No branches found
									</TableCell>
								</TableRow>
							)}
						</TableBody>
					</Table>
				</CardContent>
			</Card>
		</div>
	);
}
