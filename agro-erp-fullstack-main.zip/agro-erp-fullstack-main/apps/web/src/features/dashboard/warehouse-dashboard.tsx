import { PackageSearchIcon, TruckIcon } from "lucide-react";
import { QuickActionCard } from "@/components/quick-action-card";

export function WarehouseDashboard() {
	return (
		<div className="space-y-4">
			<div className="grid gap-4 md:grid-cols-2">
				<QuickActionCard
					actionLabel="Open products"
					description="Update finished-goods inventory from the product catalog workspace."
					href="/products"
					icon={<PackageSearchIcon className="size-5" />}
					label="Product master"
					meta="Catalog stock"
					size="lg"
					title="Update product inventory"
					tone="solid"
					variant="tile"
				/>
				<QuickActionCard
					actionLabel="Update orders"
					description="Move confirmed orders to dispatched and receive returned shipments back to warehouse."
					href="/inventory/dispatch"
					icon={<TruckIcon className="size-5" />}
					label="Dispatch queue"
					meta="Shipping workflow"
					size="lg"
					title="Branch order queues"
					tone="solid"
					variant="tile"
				/>
			</div>
		</div>
	);
}
