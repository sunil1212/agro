import type { NextConfig } from "next";

const nextConfig: NextConfig = {
	experimental: {
		viewTransition: true,
	},
	typedRoutes: true,
	reactCompiler: true,
	allowedDevOrigins: ["srv1741842.hstgr.cloud", "187.127.178.188"],
	async redirects() {
		return [
			{
				source: "/migrations/advisor",
				destination: "/migration/advisor",
				permanent: true,
			},
		];
	},
};

export default nextConfig;
